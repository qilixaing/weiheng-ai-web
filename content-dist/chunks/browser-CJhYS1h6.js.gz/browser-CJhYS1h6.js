var T = Uint8Array, Q = Uint16Array, Tr = Int32Array, gr = new T([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]), wr = new T([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]), Cr = new T([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), Hr = function(r, e) {
  for (var n = new Q(31), a = 0; a < 31; ++a)
    n[a] = e += 1 << r[a - 1];
  for (var v = new Tr(n[30]), a = 1; a < 30; ++a)
    for (var f = n[a]; f < n[a + 1]; ++f)
      v[f] = f - n[a] << 5 | a;
  return { b: n, r: v };
}, Or = Hr(gr, 2), Vr = Or.b, Sr = Or.r;
Vr[28] = 258, Sr[258] = 28;
var Yr = Hr(wr, 0), Pr = Yr.b, Br = Yr.r, Ar = new Q(32768);
for (var M = 0; M < 32768; ++M) {
  var b = (M & 43690) >> 1 | (M & 21845) << 1;
  b = (b & 52428) >> 2 | (b & 13107) << 2, b = (b & 61680) >> 4 | (b & 3855) << 4, Ar[M] = ((b & 65280) >> 8 | (b & 255) << 8) >> 1;
}
var j = (function(r, e, n) {
  for (var a = r.length, v = 0, f = new Q(e); v < a; ++v)
    r[v] && ++f[r[v] - 1];
  var l = new Q(e);
  for (v = 1; v < e; ++v)
    l[v] = l[v - 1] + f[v - 1] << 1;
  var u;
  if (n) {
    u = new Q(1 << e);
    var t = 15 - e;
    for (v = 0; v < a; ++v)
      if (r[v])
        for (var g = v << 4 | r[v], o = e - r[v], i = l[r[v] - 1]++ << o, h = i | (1 << o) - 1; i <= h; ++i)
          u[Ar[i] >> t] = g;
  } else
    for (u = new Q(a), v = 0; v < a; ++v)
      r[v] && (u[v] = Ar[l[r[v] - 1]++] >> 15 - r[v]);
  return u;
}), d = new T(288);
for (var M = 0; M < 144; ++M)
  d[M] = 8;
for (var M = 144; M < 256; ++M)
  d[M] = 9;
for (var M = 256; M < 280; ++M)
  d[M] = 7;
for (var M = 280; M < 288; ++M)
  d[M] = 8;
var or = new T(32);
for (var M = 0; M < 32; ++M)
  or[M] = 5;
var Qr = /* @__PURE__ */ j(d, 9, 0), Rr = /* @__PURE__ */ j(d, 9, 1), Wr = /* @__PURE__ */ j(or, 5, 0), Xr = /* @__PURE__ */ j(or, 5, 1), sr = function(r) {
  for (var e = r[0], n = 1; n < r.length; ++n)
    r[n] > e && (e = r[n]);
  return e;
}, X = function(r, e, n) {
  var a = e / 8 | 0;
  return (r[a] | r[a + 1] << 8) >> (e & 7) & n;
}, xr = function(r, e) {
  var n = e / 8 | 0;
  return (r[n] | r[n + 1] << 8 | r[n + 2] << 16) >> (e & 7);
}, mr = function(r) {
  return (r + 7) / 8 | 0;
}, tr = function(r, e, n) {
  return (e == null || e < 0) && (e = 0), (n == null || n > r.length) && (n = r.length), new T(r.subarray(e, n));
}, Zr = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
], Y = function(r, e, n) {
  var a = new Error(e || Zr[r]);
  if (a.code = r, Error.captureStackTrace && Error.captureStackTrace(a, Y), !n)
    throw a;
  return a;
}, $r = function(r, e, n, a) {
  var v = r.length, f = a ? a.length : 0;
  if (!v || e.f && !e.l)
    return n || new T(0);
  var l = !n, u = l || e.i != 2, t = e.i;
  l && (n = new T(v * 3));
  var g = function(vr) {
    var fr = n.length;
    if (vr > fr) {
      var nr = new T(Math.max(fr * 2, vr));
      nr.set(n), n = nr;
    }
  }, o = e.f || 0, i = e.p || 0, h = e.b || 0, c = e.l, y = e.d, x = e.m, C = e.n, m = v * 8;
  do {
    if (!c) {
      o = X(r, i, 1);
      var O = X(r, i + 1, 3);
      if (i += 3, O)
        if (O == 1)
          c = Rr, y = Xr, x = 9, C = 5;
        else if (O == 2) {
          var U = X(r, i, 31) + 257, k = X(r, i + 10, 15) + 4, s = U + X(r, i + 5, 31) + 1;
          i += 14;
          for (var w = new T(s), D = new T(19), B = 0; B < k; ++B)
            D[Cr[B]] = X(r, i + B * 3, 7);
          i += k * 3;
          for (var V = sr(D), p = (1 << V) - 1, K = j(D, V, 1), B = 0; B < s; ) {
            var G = K[X(r, i, p)];
            i += G & 15;
            var z = G >> 4;
            if (z < 16)
              w[B++] = z;
            else {
              var I = 0, S = 0;
              for (z == 16 ? (S = 3 + X(r, i, 3), i += 2, I = w[B - 1]) : z == 17 ? (S = 3 + X(r, i, 7), i += 3) : z == 18 && (S = 11 + X(r, i, 127), i += 7); S--; )
                w[B++] = I;
            }
          }
          var J = w.subarray(0, U), q = w.subarray(U);
          x = sr(J), C = sr(q), c = j(J, x, 1), y = j(q, C, 1);
        } else
          Y(1);
      else {
        var z = mr(i) + 4, F = r[z - 4] | r[z - 3] << 8, E = z + F;
        if (E > v) {
          t && Y(0);
          break;
        }
        u && g(h + F), n.set(r.subarray(z, E), h), e.b = h += F, e.p = i = E * 8, e.f = o;
        continue;
      }
      if (i > m) {
        t && Y(0);
        break;
      }
    }
    u && g(h + 131072);
    for (var ar = (1 << x) - 1, R = (1 << C) - 1, L = i; ; L = i) {
      var I = c[xr(r, i) & ar], N = I >> 4;
      if (i += I & 15, i > m) {
        t && Y(0);
        break;
      }
      if (I || Y(2), N < 256)
        n[h++] = N;
      else if (N == 256) {
        L = i, c = null;
        break;
      } else {
        var P = N - 254;
        if (N > 264) {
          var B = N - 257, A = gr[B];
          P = X(r, i, (1 << A) - 1) + Vr[B], i += A;
        }
        var Z = y[xr(r, i) & R], rr = Z >> 4;
        Z || Y(3), i += Z & 15;
        var q = Pr[rr];
        if (rr > 3) {
          var A = wr[rr];
          q += xr(r, i) & (1 << A) - 1, i += A;
        }
        if (i > m) {
          t && Y(0);
          break;
        }
        u && g(h + 131072);
        var er = h + P;
        if (h < q) {
          var ur = f - q, hr = Math.min(q, er);
          for (ur + h < 0 && Y(3); h < hr; ++h)
            n[h] = a[ur + h];
        }
        for (; h < er; ++h)
          n[h] = n[h - q];
      }
    }
    e.l = c, e.p = L, e.b = h, e.f = o, c && (o = 1, e.m = x, e.d = y, e.n = C);
  } while (!o);
  return h != n.length && l ? tr(n, 0, h) : n.subarray(0, h);
}, _ = function(r, e, n) {
  n <<= e & 7;
  var a = e / 8 | 0;
  r[a] |= n, r[a + 1] |= n >> 8;
}, ir = function(r, e, n) {
  n <<= e & 7;
  var a = e / 8 | 0;
  r[a] |= n, r[a + 1] |= n >> 8, r[a + 2] |= n >> 16;
}, yr = function(r, e) {
  for (var n = [], a = 0; a < r.length; ++a)
    r[a] && n.push({ s: a, f: r[a] });
  var v = n.length, f = n.slice();
  if (!v)
    return { t: Jr, l: 0 };
  if (v == 1) {
    var l = new T(n[0].s + 1);
    return l[n[0].s] = 1, { t: l, l: 1 };
  }
  n.sort(function(E, U) {
    return E.f - U.f;
  }), n.push({ s: -1, f: 25001 });
  var u = n[0], t = n[1], g = 0, o = 1, i = 2;
  for (n[0] = { s: -1, f: u.f + t.f, l: u, r: t }; o != v - 1; )
    u = n[n[g].f < n[i].f ? g++ : i++], t = n[g != o && n[g].f < n[i].f ? g++ : i++], n[o++] = { s: -1, f: u.f + t.f, l: u, r: t };
  for (var h = f[0].s, a = 1; a < v; ++a)
    f[a].s > h && (h = f[a].s);
  var c = new Q(h + 1), y = zr(n[o - 1], c, 0);
  if (y > e) {
    var a = 0, x = 0, C = y - e, m = 1 << C;
    for (f.sort(function(U, k) {
      return c[k.s] - c[U.s] || U.f - k.f;
    }); a < v; ++a) {
      var O = f[a].s;
      if (c[O] > e)
        x += m - (1 << y - c[O]), c[O] = e;
      else
        break;
    }
    for (x >>= C; x > 0; ) {
      var z = f[a].s;
      c[z] < e ? x -= 1 << e - c[z]++ - 1 : ++a;
    }
    for (; a >= 0 && x; --a) {
      var F = f[a].s;
      c[F] == e && (--c[F], ++x);
    }
    y = e;
  }
  return { t: new T(c), l: y };
}, zr = function(r, e, n) {
  return r.s == -1 ? Math.max(zr(r.l, e, n + 1), zr(r.r, e, n + 1)) : e[r.s] = n;
}, Er = function(r) {
  for (var e = r.length; e && !r[--e]; )
    ;
  for (var n = new Q(++e), a = 0, v = r[0], f = 1, l = function(t) {
    n[a++] = t;
  }, u = 1; u <= e; ++u)
    if (r[u] == v && u != e)
      ++f;
    else {
      if (!v && f > 2) {
        for (; f > 138; f -= 138)
          l(32754);
        f > 2 && (l(f > 10 ? f - 11 << 5 | 28690 : f - 3 << 5 | 12305), f = 0);
      } else if (f > 3) {
        for (l(v), --f; f > 6; f -= 6)
          l(8304);
        f > 2 && (l(f - 3 << 5 | 8208), f = 0);
      }
      for (; f--; )
        l(v);
      f = 1, v = r[u];
    }
  return { c: n.subarray(0, a), n: e };
}, lr = function(r, e) {
  for (var n = 0, a = 0; a < e.length; ++a)
    n += r[a] * e[a];
  return n;
}, Gr = function(r, e, n) {
  var a = n.length, v = mr(e + 2);
  r[v] = a & 255, r[v + 1] = a >> 8, r[v + 2] = r[v] ^ 255, r[v + 3] = r[v + 1] ^ 255;
  for (var f = 0; f < a; ++f)
    r[v + f + 4] = n[f];
  return (v + 4 + a) * 8;
}, Ur = function(r, e, n, a, v, f, l, u, t, g, o) {
  _(e, o++, n), ++v[256];
  for (var i = yr(v, 15), h = i.t, c = i.l, y = yr(f, 15), x = y.t, C = y.l, m = Er(h), O = m.c, z = m.n, F = Er(x), E = F.c, U = F.n, k = new Q(19), s = 0; s < O.length; ++s)
    ++k[O[s] & 31];
  for (var s = 0; s < E.length; ++s)
    ++k[E[s] & 31];
  for (var w = yr(k, 7), D = w.t, B = w.l, V = 19; V > 4 && !D[Cr[V - 1]]; --V)
    ;
  var p = g + 5 << 3, K = lr(v, d) + lr(f, or) + l, G = lr(v, h) + lr(f, x) + l + 14 + 3 * V + lr(k, D) + 2 * k[16] + 3 * k[17] + 7 * k[18];
  if (t >= 0 && p <= K && p <= G)
    return Gr(e, o, r.subarray(t, t + g));
  var I, S, J, q;
  if (_(e, o, 1 + (G < K)), o += 2, G < K) {
    I = j(h, c, 0), S = h, J = j(x, C, 0), q = x;
    var ar = j(D, B, 0);
    _(e, o, z - 257), _(e, o + 5, U - 1), _(e, o + 10, V - 4), o += 14;
    for (var s = 0; s < V; ++s)
      _(e, o + 3 * s, D[Cr[s]]);
    o += 3 * V;
    for (var R = [O, E], L = 0; L < 2; ++L)
      for (var N = R[L], s = 0; s < N.length; ++s) {
        var P = N[s] & 31;
        _(e, o, ar[P]), o += D[P], P > 15 && (_(e, o, N[s] >> 5 & 127), o += N[s] >> 12);
      }
  } else
    I = Qr, S = d, J = Wr, q = or;
  for (var s = 0; s < u; ++s) {
    var A = a[s];
    if (A > 255) {
      var P = A >> 18 & 31;
      ir(e, o, I[P + 257]), o += S[P + 257], P > 7 && (_(e, o, A >> 23 & 31), o += gr[P]);
      var Z = A & 31;
      ir(e, o, J[Z]), o += q[Z], Z > 3 && (ir(e, o, A >> 5 & 8191), o += wr[Z]);
    } else
      ir(e, o, I[A]), o += S[A];
  }
  return ir(e, o, I[256]), o + S[256];
}, jr = /* @__PURE__ */ new Tr([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]), Jr = /* @__PURE__ */ new T(0), Lr = function(r, e, n, a, v, f) {
  var l = f.z || r.length, u = new T(a + l + 5 * (1 + Math.ceil(l / 7e3)) + v), t = u.subarray(a, u.length - v), g = f.l, o = (f.r || 0) & 7;
  if (e) {
    o && (t[0] = f.r >> 3);
    for (var i = jr[e - 1], h = i >> 13, c = i & 8191, y = (1 << n) - 1, x = f.p || new Q(32768), C = f.h || new Q(y + 1), m = Math.ceil(n / 3), O = 2 * m, z = function(cr) {
      return (r[cr] ^ r[cr + 1] << m ^ r[cr + 2] << O) & y;
    }, F = new Tr(25e3), E = new Q(288), U = new Q(32), k = 0, s = 0, w = f.i || 0, D = 0, B = f.w || 0, V = 0; w + 2 < l; ++w) {
      var p = z(w), K = w & 32767, G = C[p];
      if (x[K] = G, C[p] = K, B <= w) {
        var I = l - w;
        if ((k > 7e3 || D > 24576) && (I > 423 || !g)) {
          o = Ur(r, t, 0, F, E, U, s, D, V, w - V, o), D = k = s = 0, V = w;
          for (var S = 0; S < 286; ++S)
            E[S] = 0;
          for (var S = 0; S < 30; ++S)
            U[S] = 0;
        }
        var J = 2, q = 0, ar = c, R = K - G & 32767;
        if (I > 2 && p == z(w - R))
          for (var L = Math.min(h, I) - 1, N = Math.min(32767, w), P = Math.min(258, I); R <= N && --ar && K != G; ) {
            if (r[w + J] == r[w + J - R]) {
              for (var A = 0; A < P && r[w + A] == r[w + A - R]; ++A)
                ;
              if (A > J) {
                if (J = A, q = R, A > L)
                  break;
                for (var Z = Math.min(R, A - 2), rr = 0, S = 0; S < Z; ++S) {
                  var er = w - R + S & 32767, ur = x[er], hr = er - ur & 32767;
                  hr > rr && (rr = hr, G = er);
                }
              }
            }
            K = G, G = x[K], R += K - G & 32767;
          }
        if (q) {
          F[D++] = 268435456 | Sr[J] << 18 | Br[q];
          var vr = Sr[J] & 31, fr = Br[q] & 31;
          s += gr[vr] + wr[fr], ++E[257 + vr], ++U[fr], B = w + J, ++k;
        } else
          F[D++] = r[w], ++E[r[w]];
      }
    }
    for (w = Math.max(w, B); w < l; ++w)
      F[D++] = r[w], ++E[r[w]];
    o = Ur(r, t, g, F, E, U, s, D, V, w - V, o), g || (f.r = o & 7 | t[o / 8 | 0] << 3, o -= 7, f.h = C, f.p = x, f.i = w, f.w = B);
  } else {
    for (var w = f.w || 0; w < l + g; w += 65535) {
      var nr = w + 65535;
      nr >= l && (t[o / 8 | 0] = g, nr = l), o = Gr(t, o + 1, r.subarray(w, nr));
    }
    f.i = l;
  }
  return tr(u, 0, a + mr(o) + v);
}, _r = /* @__PURE__ */ (function() {
  for (var r = new Int32Array(256), e = 0; e < 256; ++e) {
    for (var n = e, a = 9; --a; )
      n = (n & 1 && -306674912) ^ n >>> 1;
    r[e] = n;
  }
  return r;
})(), pr = function() {
  var r = -1;
  return {
    p: function(e) {
      for (var n = r, a = 0; a < e.length; ++a)
        n = _r[n & 255 ^ e[a]] ^ n >>> 8;
      r = n;
    },
    d: function() {
      return ~r;
    }
  };
}, br = function(r, e, n, a, v) {
  if (!v && (v = { l: 1 }, e.dictionary)) {
    var f = e.dictionary.subarray(-32768), l = new T(f.length + r.length);
    l.set(f), l.set(r, f.length), r = l, v.w = f.length;
  }
  return Lr(r, e.level == null ? 6 : e.level, e.mem == null ? v.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(r.length))) * 1.5) : 20 : 12 + e.mem, n, a, v);
}, Kr = function(r, e) {
  var n = {};
  for (var a in r)
    n[a] = r[a];
  for (var a in e)
    n[a] = e[a];
  return n;
}, $ = function(r, e) {
  return r[e] | r[e + 1] << 8;
}, W = function(r, e) {
  return (r[e] | r[e + 1] << 8 | r[e + 2] << 16 | r[e + 3] << 24) >>> 0;
}, Mr = function(r, e) {
  return W(r, e) + W(r, e + 4) * 4294967296;
}, H = function(r, e, n) {
  for (; n; ++e)
    r[e] = n, n >>>= 8;
};
function dr(r, e) {
  return br(r, e || {}, 0, 0);
}
function re(r, e) {
  return $r(r, { i: 2 }, e && e.out, e && e.dictionary);
}
var Nr = function(r, e, n, a) {
  for (var v in r) {
    var f = r[v], l = e + v, u = a;
    Array.isArray(f) && (u = Kr(a, f[1]), f = f[0]), ArrayBuffer.isView(f) ? n[l] = [f, u] : (n[l += "/"] = [new T(0), u], Nr(f, l, n, a));
  }
}, Dr = typeof TextEncoder < "u" && /* @__PURE__ */ new TextEncoder(), Fr = typeof TextDecoder < "u" && /* @__PURE__ */ new TextDecoder(), ee = 0;
try {
  Fr.decode(Jr, { stream: !0 }), ee = 1;
} catch {
}
var ne = function(r) {
  for (var e = "", n = 0; ; ) {
    var a = r[n++], v = (a > 127) + (a > 223) + (a > 239);
    if (n + v > r.length)
      return { s: e, r: tr(r, n - 1) };
    v ? v == 3 ? (a = ((a & 15) << 18 | (r[n++] & 63) << 12 | (r[n++] & 63) << 6 | r[n++] & 63) - 65536, e += String.fromCharCode(55296 | a >> 10, 56320 | a & 1023)) : v & 1 ? e += String.fromCharCode((a & 31) << 6 | r[n++] & 63) : e += String.fromCharCode((a & 15) << 12 | (r[n++] & 63) << 6 | r[n++] & 63) : e += String.fromCharCode(a);
  }
};
function Ir(r, e) {
  var n;
  if (Dr)
    return Dr.encode(r);
  for (var a = r.length, v = new T(r.length + (r.length >> 1)), f = 0, l = function(g) {
    v[f++] = g;
  }, n = 0; n < a; ++n) {
    if (f + 5 > v.length) {
      var u = new T(f + 8 + (a - n << 1));
      u.set(v), v = u;
    }
    var t = r.charCodeAt(n);
    t < 128 || e ? l(t) : t < 2048 ? (l(192 | t >> 6), l(128 | t & 63)) : t > 55295 && t < 57344 ? (t = 65536 + (t & 1047552) | r.charCodeAt(++n) & 1023, l(240 | t >> 18), l(128 | t >> 12 & 63), l(128 | t >> 6 & 63), l(128 | t & 63)) : (l(224 | t >> 12), l(128 | t >> 6 & 63), l(128 | t & 63));
  }
  return tr(v, 0, f);
}
function ae(r, e) {
  if (e) {
    for (var n = "", a = 0; a < r.length; a += 16384)
      n += String.fromCharCode.apply(null, r.subarray(a, a + 16384));
    return n;
  } else {
    if (Fr)
      return Fr.decode(r);
    var v = ne(r), f = v.s, n = v.r;
    return n.length && Y(8), f;
  }
}
var ve = function(r, e) {
  return e + 30 + $(r, e + 26) + $(r, e + 28);
}, fe = function(r, e, n) {
  var a = $(r, e + 28), v = $(r, e + 30), f = ae(r.subarray(e + 46, e + 46 + a), !($(r, e + 8) & 2048)), l = e + 46 + a, u = ie(r, l, v, n, W(r, e + 20), W(r, e + 24), W(r, e + 42)), t = u[0], g = u[1], o = u[2];
  return [$(r, e + 10), t, g, f, l + v + $(r, e + 32), o];
}, ie = function(r, e, n, a, v, f, l) {
  var u = v == 4294967295, t = f == 4294967295, g = l == 4294967295, o = e + n, i = u + t + g;
  if (a && i) {
    for (; e + 4 < o; e += 4 + $(r, e + 2))
      if ($(r, e) == 1)
        return [
          u ? Mr(r, e + 4 + 8 * t) : v,
          t ? Mr(r, e + 4) : f,
          g ? Mr(r, e + 4 + 8 * (t + u)) : l,
          1
        ];
    a < 2 && Y(13);
  }
  return [v, f, l, 0];
}, kr = function(r) {
  var e = 0;
  if (r)
    for (var n in r) {
      var a = r[n].length;
      a > 65535 && Y(9), e += a + 4;
    }
  return e;
}, qr = function(r, e, n, a, v, f, l, u) {
  var t = a.length, g = n.extra, o = u && u.length, i = kr(g);
  H(r, e, l != null ? 33639248 : 67324752), e += 4, l != null && (r[e++] = 20, r[e++] = n.os), r[e] = 20, e += 2, r[e++] = n.flag << 1 | (f < 0 && 8), r[e++] = v && 8, r[e++] = n.compression & 255, r[e++] = n.compression >> 8;
  var h = new Date(n.mtime == null ? Date.now() : n.mtime), c = h.getFullYear() - 1980;
  if ((c < 0 || c > 119) && Y(10), H(r, e, c << 25 | h.getMonth() + 1 << 21 | h.getDate() << 16 | h.getHours() << 11 | h.getMinutes() << 5 | h.getSeconds() >> 1), e += 4, f != -1 && (H(r, e, n.crc), H(r, e + 4, f < 0 ? -f - 2 : f), H(r, e + 8, n.size)), H(r, e + 12, t), H(r, e + 14, i), e += 16, l != null && (H(r, e, o), H(r, e + 6, n.attrs), H(r, e + 10, l), e += 14), r.set(a, e), e += t, i)
    for (var y in g) {
      var x = g[y], C = x.length;
      H(r, e, +y), H(r, e + 2, C), r.set(x, e + 4), e += 4 + C;
    }
  return o && (r.set(u, e), e += o), e;
}, le = function(r, e, n, a, v) {
  H(r, e, 101010256), H(r, e + 8, n), H(r, e + 10, n), H(r, e + 12, a), H(r, e + 16, v);
};
function oe(r, e) {
  e || (e = {});
  var n = {}, a = [];
  Nr(r, "", n, e);
  var v = 0, f = 0;
  for (var l in n) {
    var u = n[l], t = u[0], g = u[1], o = g.level == 0 ? 0 : 8, i = Ir(l), h = i.length, c = g.comment, y = c && Ir(c), x = y && y.length, C = kr(g.extra);
    h > 65535 && Y(11);
    var m = o ? dr(t, g) : t, O = m.length, z = pr();
    z.p(t), a.push(Kr(g, {
      size: t.length,
      crc: z.d(),
      c: m,
      f: i,
      m: y,
      u: h != l.length || y && c.length != x,
      o: v,
      compression: o
    })), v += 30 + h + C + O, f += 76 + 2 * (h + C) + (x || 0) + O;
  }
  for (var F = new T(f + 22), E = v, U = f - v, k = 0; k < a.length; ++k) {
    var i = a[k];
    qr(F, i.o, i, i.f, i.u, i.c.length);
    var s = 30 + i.f.length + kr(i.extra);
    F.set(i.c, i.o + s), qr(F, v, i, i.f, i.u, i.c.length, i.o, i.m), v += 16 + s + (i.m ? i.m.length : 0);
  }
  return le(F, v, a.length, U, E), F;
}
function te(r, e) {
  for (var n = {}, a = r.length - 22; W(r, a) != 101010256; --a)
    (!a || r.length - a > 65558) && Y(13);
  var v = $(r, a + 8);
  if (!v)
    return {};
  var f = W(r, a + 16), l = W(r, a - 20) == 117853008;
  if (l) {
    var u = W(r, a - 12);
    l = W(r, u) == 101075792, l && (v = W(r, u + 32), f = W(r, u + 48));
  }
  for (var t = e && e.filter, g = 0; g < v; ++g) {
    var o = fe(r, f, l), i = o[0], h = o[1], c = o[2], y = o[3], x = o[4], C = o[5], m = ve(r, C);
    f = x, (!t || t({
      name: y,
      size: h,
      originalSize: c,
      compression: i
    })) && (i ? i == 8 ? n[y] = re(r.subarray(m, m + h), { out: new T(c) }) : Y(14, "unknown compression type " + i) : n[y] = tr(r, m, m + h));
  }
  return n;
}
export {
  dr as deflateSync,
  re as inflateSync,
  ae as strFromU8,
  Ir as strToU8,
  te as unzipSync,
  oe as zipSync
};
