var C = Uint8Array, M = Uint16Array, xr = Int32Array, or = new C([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]), lr = new C([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]), Fr = new C([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), ur = function(r, e) {
  for (var n = new M(31), a = 0; a < 31; ++a)
    n[a] = e += 1 << r[a - 1];
  for (var f = new xr(n[30]), a = 1; a < 30; ++a)
    for (var l = n[a]; l < n[a + 1]; ++l)
      f[l] = l - n[a] << 5 | a;
  return { b: n, r: f };
}, tr = ur(or, 2), hr = tr.b, Sr = tr.r;
hr[28] = 258, Sr[258] = 28;
var kr = ur(lr, 0), yr = kr.b, Z = new M(32768);
for (var o = 0; o < 32768; ++o) {
  var z = (o & 43690) >> 1 | (o & 21845) << 1;
  z = (z & 52428) >> 2 | (z & 13107) << 2, z = (z & 61680) >> 4 | (z & 3855) << 4, Z[o] = ((z & 65280) >> 8 | (z & 255) << 8) >> 1;
}
var O = (function(r, e, n) {
  for (var a = r.length, f = 0, l = new M(e); f < a; ++f)
    r[f] && ++l[r[f] - 1];
  var t = new M(e);
  for (f = 1; f < e; ++f)
    t[f] = t[f - 1] + l[f - 1] << 1;
  var u;
  if (n) {
    u = new M(1 << e);
    var w = 15 - e;
    for (f = 0; f < a; ++f)
      if (r[f])
        for (var g = f << 4 | r[f], h = e - r[f], v = t[r[f] - 1]++ << h, i = v | (1 << h) - 1; v <= i; ++v)
          u[Z[v] >> w] = g;
  } else
    for (u = new M(a), f = 0; f < a; ++f)
      r[f] && (u[f] = Z[t[r[f] - 1]++] >> 15 - r[f]);
  return u;
}), q = new C(288);
for (var o = 0; o < 144; ++o)
  q[o] = 8;
for (var o = 144; o < 256; ++o)
  q[o] = 9;
for (var o = 256; o < 280; ++o)
  q[o] = 7;
for (var o = 280; o < 288; ++o)
  q[o] = 8;
var wr = new C(32);
for (var o = 0; o < 32; ++o)
  wr[o] = 5;
var pr = /* @__PURE__ */ O(q, 9, 1), Ar = /* @__PURE__ */ O(wr, 5, 1), W = function(r) {
  for (var e = r[0], n = 1; n < r.length; ++n)
    r[n] > e && (e = r[n]);
  return e;
}, x = function(r, e, n) {
  var a = e / 8 | 0;
  return (r[a] | r[a + 1] << 8) >> (e & 7) & n;
}, X = function(r, e) {
  var n = e / 8 | 0;
  return (r[n] | r[n + 1] << 8 | r[n + 2] << 16) >> (e & 7);
}, zr = function(r) {
  return (r + 7) / 8 | 0;
}, j = function(r, e, n) {
  return (e == null || e < 0) && (e = 0), (n == null || n > r.length) && (n = r.length), new C(r.subarray(e, n));
}, Tr = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
], c = function(r, e, n) {
  var a = new Error(e || Tr[r]);
  if (a.code = r, Error.captureStackTrace && Error.captureStackTrace(a, c), !n)
    throw a;
  return a;
}, Br = function(r, e, n, a) {
  var f = r.length, l = a ? a.length : 0;
  if (!f || e.f && !e.l)
    return n || new C(0);
  var t = !n, u = t || e.i != 2, w = e.i;
  t && (n = new C(f * 3));
  var g = function(fr) {
    var vr = n.length;
    if (fr > vr) {
      var ir = new C(Math.max(vr * 2, fr));
      ir.set(n), n = ir;
    }
  }, h = e.f || 0, v = e.p || 0, i = e.b || 0, F = e.l, y = e.d, T = e.m, B = e.n, p = f * 8;
  do {
    if (!F) {
      h = x(r, v, 1);
      var H = x(r, v + 1, 3);
      if (v += 3, H)
        if (H == 1)
          F = pr, y = Ar, T = 9, B = 5;
        else if (H == 2) {
          var N = x(r, v, 31) + 257, L = x(r, v + 10, 15) + 4, _ = N + x(r, v + 5, 31) + 1;
          v += 14;
          for (var D = new C(_), P = new C(19), m = 0; m < L; ++m)
            P[Fr[m]] = x(r, v + m * 3, 7);
          v += L * 3;
          for (var b = W(P), gr = (1 << b) - 1, cr = O(P, b, 1), m = 0; m < _; ) {
            var d = cr[x(r, v, gr)];
            v += d & 15;
            var S = d >> 4;
            if (S < 16)
              D[m++] = S;
            else {
              var E = 0, G = 0;
              for (S == 16 ? (G = 3 + x(r, v, 3), v += 2, E = D[m - 1]) : S == 17 ? (G = 3 + x(r, v, 7), v += 3) : S == 18 && (G = 11 + x(r, v, 127), v += 7); G--; )
                D[m++] = E;
            }
          }
          var rr = D.subarray(0, N), A = D.subarray(N);
          T = W(rr), B = W(A), F = O(rr, T, 1), y = O(A, B, 1);
        } else
          c(1);
      else {
        var S = zr(v) + 4, J = r[S - 4] | r[S - 3] << 8, K = S + J;
        if (K > f) {
          w && c(0);
          break;
        }
        u && g(i + J), n.set(r.subarray(S, K), i), e.b = i += J, e.p = v = K * 8, e.f = h;
        continue;
      }
      if (v > p) {
        w && c(0);
        break;
      }
    }
    u && g(i + 131072);
    for (var Cr = (1 << T) - 1, mr = (1 << B) - 1, Q = v; ; Q = v) {
      var E = F[X(r, v) & Cr], U = E >> 4;
      if (v += E & 15, v > p) {
        w && c(0);
        break;
      }
      if (E || c(2), U < 256)
        n[i++] = U;
      else if (U == 256) {
        Q = v, F = null;
        break;
      } else {
        var er = U - 254;
        if (U > 264) {
          var m = U - 257, I = or[m];
          er = x(r, v, (1 << I) - 1) + hr[m], v += I;
        }
        var R = y[X(r, v) & mr], V = R >> 4;
        R || c(3), v += R & 15;
        var A = yr[V];
        if (V > 3) {
          var I = lr[V];
          A += X(r, v) & (1 << I) - 1, v += I;
        }
        if (v > p) {
          w && c(0);
          break;
        }
        u && g(i + 131072);
        var nr = i + er;
        if (i < A) {
          var ar = l - A, sr = Math.min(A, nr);
          for (ar + i < 0 && c(3); i < sr; ++i)
            n[i] = a[ar + i];
        }
        for (; i < nr; ++i)
          n[i] = n[i - A];
      }
    }
    e.l = F, e.p = Q, e.b = i, e.f = h, F && (h = 1, e.m = T, e.d = y, e.n = B);
  } while (!h);
  return i != n.length && t ? j(n, 0, i) : n.subarray(0, i);
}, Er = /* @__PURE__ */ new C(0), k = function(r, e) {
  return r[e] | r[e + 1] << 8;
}, s = function(r, e) {
  return (r[e] | r[e + 1] << 8 | r[e + 2] << 16 | r[e + 3] << 24) >>> 0;
}, Y = function(r, e) {
  return s(r, e) + s(r, e + 4) * 4294967296;
};
function Ur(r, e) {
  return Br(r, { i: 2 }, e && e.out, e && e.dictionary);
}
var $ = typeof TextDecoder < "u" && /* @__PURE__ */ new TextDecoder(), Mr = 0;
try {
  $.decode(Er, { stream: !0 }), Mr = 1;
} catch {
}
var Dr = function(r) {
  for (var e = "", n = 0; ; ) {
    var a = r[n++], f = (a > 127) + (a > 223) + (a > 239);
    if (n + f > r.length)
      return { s: e, r: j(r, n - 1) };
    f ? f == 3 ? (a = ((a & 15) << 18 | (r[n++] & 63) << 12 | (r[n++] & 63) << 6 | r[n++] & 63) - 65536, e += String.fromCharCode(55296 | a >> 10, 56320 | a & 1023)) : f & 1 ? e += String.fromCharCode((a & 31) << 6 | r[n++] & 63) : e += String.fromCharCode((a & 15) << 12 | (r[n++] & 63) << 6 | r[n++] & 63) : e += String.fromCharCode(a);
  }
};
function Ir(r, e) {
  if (e) {
    for (var n = "", a = 0; a < r.length; a += 16384)
      n += String.fromCharCode.apply(null, r.subarray(a, a + 16384));
    return n;
  } else {
    if ($)
      return $.decode(r);
    var f = Dr(r), l = f.s, n = f.r;
    return n.length && c(8), l;
  }
}
var Or = function(r, e) {
  return e + 30 + k(r, e + 26) + k(r, e + 28);
}, qr = function(r, e, n) {
  var a = k(r, e + 28), f = k(r, e + 30), l = Ir(r.subarray(e + 46, e + 46 + a), !(k(r, e + 8) & 2048)), t = e + 46 + a, u = Gr(r, t, f, n, s(r, e + 20), s(r, e + 24), s(r, e + 42)), w = u[0], g = u[1], h = u[2];
  return [k(r, e + 10), w, g, l, t + f + k(r, e + 32), h];
}, Gr = function(r, e, n, a, f, l, t) {
  var u = f == 4294967295, w = l == 4294967295, g = t == 4294967295, h = e + n, v = u + w + g;
  if (a && v) {
    for (; e + 4 < h; e += 4 + k(r, e + 2))
      if (k(r, e) == 1)
        return [
          u ? Y(r, e + 4 + 8 * w) : f,
          w ? Y(r, e + 4) : l,
          g ? Y(r, e + 4 + 8 * (w + u)) : t,
          1
        ];
    a < 2 && c(13);
  }
  return [f, l, t, 0];
};
function Hr(r, e) {
  for (var n = {}, a = r.length - 22; s(r, a) != 101010256; --a)
    (!a || r.length - a > 65558) && c(13);
  var f = k(r, a + 8);
  if (!f)
    return {};
  var l = s(r, a + 16), t = s(r, a - 20) == 117853008;
  if (t) {
    var u = s(r, a - 12);
    t = s(r, u) == 101075792, t && (f = s(r, u + 32), l = s(r, u + 48));
  }
  for (var w = e && e.filter, g = 0; g < f; ++g) {
    var h = qr(r, l, t), v = h[0], i = h[1], F = h[2], y = h[3], T = h[4], B = h[5], p = Or(r, B);
    l = T, (!w || w({
      name: y,
      size: i,
      originalSize: F,
      compression: v
    })) && (v ? v == 8 ? n[y] = Ur(r.subarray(p, p + i), { out: new C(F) }) : c(14, "unknown compression type " + v) : n[y] = j(r, p, p + i));
  }
  return n;
}
export {
  Ur as inflateSync,
  Ir as strFromU8,
  Hr as unzipSync
};
