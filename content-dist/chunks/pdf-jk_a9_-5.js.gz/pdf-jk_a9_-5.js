var bi = (d) => {
  throw TypeError(d);
};
var _s = (d, t, e) => t.has(d) || bi("Cannot " + e);
var K = (d, t, e) => (_s(d, t, "read from private field"), e ? e.call(d) : t.get(d)), kt = (d, t, e) => t.has(d) ? bi("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(d) : t.set(d, e), dt = (d, t, e, s) => (_s(d, t, "write to private field"), s ? s.call(d, e) : t.set(d, e), e), Ot = (d, t, e) => (_s(d, t, "access private method"), e);
var yi = (d, t, e, s) => ({
  set _(i) {
    dt(d, t, i, e);
  },
  get _() {
    return K(d, t, s);
  }
});
const bt = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser"), Dt = [1 / 0, 1 / 0, -1 / 0, -1 / 0], ee = new Float32Array(Dt), Ds = [1e-3, 0, 0, 1e-3, 0, 0], ct = "http://www.w3.org/2000/svg", gt = {
  ANY: 1,
  DISPLAY: 2,
  PRINT: 4,
  ANNOTATIONS_FORMS: 16,
  ANNOTATIONS_STORAGE: 32,
  ANNOTATIONS_DISABLE: 64,
  IS_EDITING: 128,
  OPLIST: 256
}, $t = {
  DISABLE: 0,
  ENABLE: 1,
  ENABLE_FORMS: 2,
  ENABLE_STORAGE: 3
}, ge = "pdfjs_internal_id_", ye = "pdfjs_internal_editor_", B = {
  DISABLE: -1,
  NONE: 0,
  FREETEXT: 3,
  HIGHLIGHT: 9,
  STAMP: 13,
  INK: 15,
  POPUP: 16,
  SIGNATURE: 101,
  COMMENT: 102
}, U = {
  RESIZE: 1,
  CREATE: 2,
  FREETEXT_SIZE: 11,
  FREETEXT_COLOR: 12,
  FREETEXT_OPACITY: 13,
  INK_COLOR: 21,
  INK_THICKNESS: 22,
  INK_OPACITY: 23,
  INK_COLOR_AND_OPACITY: 24,
  HIGHLIGHT_COLOR: 31,
  HIGHLIGHT_THICKNESS: 32,
  HIGHLIGHT_FREE: 33,
  HIGHLIGHT_SHOW_ALL: 34,
  DRAW_STEP: 41
}, Fn = {
  PRINT: 4,
  MODIFY_CONTENTS: 8,
  COPY: 16,
  MODIFY_ANNOTATIONS: 32,
  FILL_INTERACTIVE_FORMS: 256,
  COPY_FOR_ACCESSIBILITY: 512,
  ASSEMBLE: 1024,
  PRINT_HIGH_QUALITY: 2048
}, st = {
  FILL: 0,
  STROKE: 1,
  FILL_STROKE: 2,
  INVISIBLE: 3,
  FILL_STROKE_MASK: 3,
  ADD_TO_PATH_FLAG: 4
}, Ke = {
  GRAYSCALE_1BPP: 1,
  RGB_24BPP: 2,
  RGBA_32BPP: 3
}, q = {
  TEXT: 1,
  LINK: 2,
  FREETEXT: 3,
  LINE: 4,
  SQUARE: 5,
  CIRCLE: 6,
  POLYGON: 7,
  POLYLINE: 8,
  HIGHLIGHT: 9,
  UNDERLINE: 10,
  SQUIGGLY: 11,
  STRIKEOUT: 12,
  STAMP: 13,
  CARET: 14,
  INK: 15,
  POPUP: 16,
  FILEATTACHMENT: 17,
  SOUND: 18,
  MOVIE: 19,
  WIDGET: 20,
  SCREEN: 21,
  PRINTERMARK: 22,
  TRAPNET: 23,
  WATERMARK: 24,
  THREED: 25,
  REDACT: 26,
  RICHMEDIA: 27
}, fe = {
  SOLID: 1,
  DASHED: 2,
  BEVELED: 3,
  INSET: 4,
  UNDERLINE: 5
}, os = {
  ERRORS: 0,
  WARNINGS: 1,
  INFOS: 5
}, Nt = {
  dependency: 1,
  setLineWidth: 2,
  setLineCap: 3,
  setLineJoin: 4,
  setMiterLimit: 5,
  setDash: 6,
  setRenderingIntent: 7,
  setFlatness: 8,
  setGState: 9,
  save: 10,
  restore: 11,
  transform: 12,
  moveTo: 13,
  lineTo: 14,
  curveTo: 15,
  curveTo2: 16,
  curveTo3: 17,
  closePath: 18,
  rectangle: 19,
  stroke: 20,
  closeStroke: 21,
  fill: 22,
  eoFill: 23,
  fillStroke: 24,
  eoFillStroke: 25,
  closeFillStroke: 26,
  closeEOFillStroke: 27,
  endPath: 28,
  clip: 29,
  eoClip: 30,
  beginText: 31,
  endText: 32,
  setCharSpacing: 33,
  setWordSpacing: 34,
  setHScale: 35,
  setLeading: 36,
  setFont: 37,
  setTextRenderingMode: 38,
  setTextRise: 39,
  moveText: 40,
  setLeadingMoveText: 41,
  setTextMatrix: 42,
  nextLine: 43,
  showText: 44,
  showSpacedText: 45,
  nextLineShowText: 46,
  nextLineSetSpacingShowText: 47,
  setCharWidth: 48,
  setCharWidthAndBounds: 49,
  setStrokeColorSpace: 50,
  setFillColorSpace: 51,
  setStrokeColor: 52,
  setStrokeColorN: 53,
  setFillColor: 54,
  setFillColorN: 55,
  setStrokeGray: 56,
  setFillGray: 57,
  setStrokeRGBColor: 58,
  setFillRGBColor: 59,
  setStrokeCMYKColor: 60,
  setFillCMYKColor: 61,
  shadingFill: 62,
  beginInlineImage: 63,
  beginImageData: 64,
  endInlineImage: 65,
  paintXObject: 66,
  markPoint: 67,
  markPointProps: 68,
  beginMarkedContent: 69,
  beginMarkedContentProps: 70,
  endMarkedContent: 71,
  beginCompat: 72,
  endCompat: 73,
  paintFormXObjectBegin: 74,
  paintFormXObjectEnd: 75,
  beginGroup: 76,
  endGroup: 77,
  beginAnnotation: 80,
  endAnnotation: 81,
  paintImageMaskXObject: 83,
  paintImageMaskXObjectGroup: 84,
  paintImageXObject: 85,
  paintInlineImageXObject: 86,
  paintInlineImageXObjectGroup: 87,
  paintImageXObjectRepeat: 88,
  paintImageMaskXObjectRepeat: 89,
  paintSolidColorImageMask: 90,
  constructPath: 91,
  setStrokeTransparent: 92,
  setFillTransparent: 93,
  rawFillPath: 94
}, _e = {
  moveTo: 0,
  lineTo: 1,
  curveTo: 2,
  quadraticCurveTo: 3,
  closePath: 4
}, On = {
  NEED_PASSWORD: 1,
  INCORRECT_PASSWORD: 2
};
let ls = os.WARNINGS;
function Rn(d) {
  Number.isInteger(d) && (ls = d);
}
function Yi() {
  return ls;
}
function hs(d) {
  ls >= os.INFOS && console.info(`Info: ${d}`);
}
function R(d) {
  ls >= os.WARNINGS && console.warn(`Warning: ${d}`);
}
function j(d) {
  throw new Error(d);
}
function J(d, t) {
  d || j(t);
}
function Ln(d) {
  switch (d?.protocol) {
    case "http:":
    case "https:":
    case "ftp:":
    case "mailto:":
    case "tel:":
      return !0;
    default:
      return !1;
  }
}
function Ki(d, t = null, e = null) {
  if (!d)
    return null;
  if (e && typeof d == "string" && (e.addDefaultProtocol && d.startsWith("www.") && d.match(/\./g)?.length >= 2 && (d = `http://${d}`), e.tryConvertEncoding))
    try {
      d = Hn(d);
    } catch {
    }
  const s = t ? URL.parse(d, t) : URL.parse(d);
  return Ln(s) ? s : null;
}
function qi(d, t, e = !1) {
  const s = URL.parse(d);
  return s ? (s.hash = t, s.href) : e && Ki(d, "http://example.com") ? d.split("#", 1)[0] + `${t ? `#${t}` : ""}` : "";
}
function Fs(d) {
  return d.substring(d.lastIndexOf("/") + 1);
}
function k(d, t, e, s = !1) {
  return Object.defineProperty(d, t, {
    value: e,
    enumerable: !s,
    configurable: !0,
    writable: !1
  }), e;
}
const he = (function() {
  function t(e, s) {
    this.message = e, this.name = s;
  }
  return t.prototype = new Error(), t.constructor = t, t;
})();
class Os extends he {
  constructor(t, e) {
    super(t, "PasswordException"), this.code = e;
  }
}
class He extends he {
  constructor(t, e) {
    super(t, "UnknownErrorException"), this.details = e;
  }
}
class Rs extends he {
  constructor(t) {
    super(t, "InvalidPDFException");
  }
}
class es extends he {
  constructor(t, e, s) {
    super(t, "ResponseException"), this.status = e, this.missing = s;
  }
}
class Nn extends he {
  constructor(t) {
    super(t, "FormatError");
  }
}
class Yt extends he {
  constructor(t) {
    super(t, "AbortException");
  }
}
function Bn(d) {
  (typeof d != "object" || d?.length === void 0) && j("Invalid argument for bytesToString");
  const t = d.length, e = 8192;
  if (t < e)
    return String.fromCharCode.apply(null, d);
  const s = [];
  for (let i = 0; i < t; i += e) {
    const n = Math.min(i + e, t), r = d.subarray(i, n);
    s.push(String.fromCharCode.apply(null, r));
  }
  return s.join("");
}
function cs(d) {
  typeof d != "string" && j("Invalid argument for stringToBytes");
  const t = d.length, e = new Uint8Array(t);
  for (let s = 0; s < t; ++s)
    e[s] = d.charCodeAt(s) & 255;
  return e;
}
class W {
  static get isLittleEndian() {
    const t = new Uint8Array(4);
    t[0] = 1;
    const e = new Uint32Array(t.buffer, 0, 1);
    return k(this, "isLittleEndian", e[0] === 1);
  }
  static get isOffscreenCanvasSupported() {
    return k(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
  }
  static get isImageDecoderSupported() {
    return k(this, "isImageDecoderSupported", typeof ImageDecoder < "u");
  }
  static get isVideoFrameSupported() {
    return k(this, "isVideoFrameSupported", typeof VideoFrame < "u");
  }
  static get isFloat16ArraySupported() {
    return k(this, "isFloat16ArraySupported", typeof Float16Array < "u");
  }
  static get isSanitizerSupported() {
    return k(this, "isSanitizerSupported", typeof Sanitizer < "u");
  }
  static get platform() {
    const {
      platform: t,
      userAgent: e
    } = navigator;
    return k(this, "platform", {
      isAndroid: e.includes("Android"),
      isLinux: t.includes("Linux"),
      isMac: t.includes("Mac"),
      isWindows: t.includes("Win"),
      isFirefox: e.includes("Firefox")
    });
  }
  static get isCanvasFilterSupported() {
    let t;
    return this.isOffscreenCanvasSupported ? t = new OffscreenCanvas(1, 1).getContext("2d") : typeof document < "u" && (t = document.createElement("canvas").getContext("2d")), k(this, "isCanvasFilterSupported", t?.filter !== void 0);
  }
  static get isAlphaColorInputSupported() {
    if (typeof document > "u")
      return k(this, "isAlphaColorInputSupported", !1);
    const t = document.createElement("input");
    return t.type = "color", t.setAttribute("alpha", ""), t.value = "#ff000080", k(this, "isAlphaColorInputSupported", t.value !== "#ff0000");
  }
  static get isBackdropFilterSupported() {
    return k(this, "isBackdropFilterSupported", typeof CSS < "u" && CSS.supports("backdrop-filter", "blur(1px)"));
  }
}
class x {
  static get hexNums() {
    return k(this, "hexNums", Array.from({
      length: 256
    }, (t, e) => e.toString(16).padStart(2, "0")));
  }
  static makeHexColor(t, e, s) {
    return `#${this.hexNums[t]}${this.hexNums[e]}${this.hexNums[s]}`;
  }
  static get identity0to256Map() {
    return k(this, "identity0to256Map", Uint8Array.from({
      length: 256
    }, (t, e) => e));
  }
  static transform(t, e) {
    return [t[0] * e[0] + t[2] * e[1], t[1] * e[0] + t[3] * e[1], t[0] * e[2] + t[2] * e[3], t[1] * e[2] + t[3] * e[3], t[0] * e[4] + t[2] * e[5] + t[4], t[1] * e[4] + t[3] * e[5] + t[5]];
  }
  static multiplyByDOMMatrix(t, e) {
    return [t[0] * e.a + t[2] * e.b, t[1] * e.a + t[3] * e.b, t[0] * e.c + t[2] * e.d, t[1] * e.c + t[3] * e.d, t[0] * e.e + t[2] * e.f + t[4], t[1] * e.e + t[3] * e.f + t[5]];
  }
  static applyTransform(t, e, s = 0) {
    const i = t[s], n = t[s + 1];
    t[s] = i * e[0] + n * e[2] + e[4], t[s + 1] = i * e[1] + n * e[3] + e[5];
  }
  static applyTransformToBezier(t, e, s = 0) {
    const i = e[0], n = e[1], r = e[2], a = e[3], o = e[4], l = e[5];
    for (let h = 0; h < 6; h += 2) {
      const c = t[s + h], u = t[s + h + 1];
      t[s + h] = c * i + u * r + o, t[s + h + 1] = c * n + u * a + l;
    }
  }
  static applyInverseTransform(t, e) {
    const s = t[0], i = t[1], n = e[0] * e[3] - e[1] * e[2];
    t[0] = (s * e[3] - i * e[2] + e[2] * e[5] - e[4] * e[3]) / n, t[1] = (-s * e[1] + i * e[0] + e[4] * e[1] - e[5] * e[0]) / n;
  }
  static axialAlignedBoundingBox(t, e, s) {
    const i = e[0], n = e[1], r = e[2], a = e[3], o = e[4], l = e[5], h = t[0], c = t[1], u = t[2], f = t[3];
    let p = i * h + o, g = p, m = i * u + o, b = m, y = a * c + l, A = y, w = a * f + l, v = w;
    if (n !== 0 || r !== 0) {
      const S = n * h, _ = n * u, E = r * c, C = r * f;
      p += E, b += E, m += C, g += C, y += S, v += S, w += _, A += _;
    }
    s[0] = Math.min(s[0], p, m, Math.min(g, b)), s[1] = Math.min(s[1], y, w, Math.min(A, v)), s[2] = Math.max(s[2], p, m, Math.max(g, b)), s[3] = Math.max(s[3], y, w, Math.max(A, v));
  }
  static inverseTransform(t) {
    const e = t[0] * t[3] - t[1] * t[2];
    return [t[3] / e, -t[1] / e, -t[2] / e, t[0] / e, (t[2] * t[5] - t[4] * t[3]) / e, (t[4] * t[1] - t[5] * t[0]) / e];
  }
  static singularValueDecompose2dScale(t, e) {
    const s = t[0], i = t[1], n = t[2], r = t[3], a = s ** 2 + i ** 2, o = s * n + i * r, l = n ** 2 + r ** 2, h = (a + l) / 2, c = Math.sqrt(h ** 2 - (a * l - o ** 2));
    e[0] = Math.sqrt(h + c || 1), e[1] = Math.sqrt(h - c || 1);
  }
  static normalizeRect(t) {
    const e = t.slice(0);
    return t[0] > t[2] && (e[0] = t[2], e[2] = t[0]), t[1] > t[3] && (e[1] = t[3], e[3] = t[1]), e;
  }
  static intersect(t, e) {
    const s = Math.max(Math.min(t[0], t[2]), Math.min(e[0], e[2])), i = Math.min(Math.max(t[0], t[2]), Math.max(e[0], e[2]));
    if (s > i)
      return null;
    const n = Math.max(Math.min(t[1], t[3]), Math.min(e[1], e[3])), r = Math.min(Math.max(t[1], t[3]), Math.max(e[1], e[3]));
    return n > r ? null : [s, n, i, r];
  }
  static pointBoundingBox(t, e, s) {
    s[0] = Math.min(s[0], t), s[1] = Math.min(s[1], e), s[2] = Math.max(s[2], t), s[3] = Math.max(s[3], e);
  }
  static rectBoundingBox(t, e, s, i, n) {
    n[0] = Math.min(n[0], t, s), n[1] = Math.min(n[1], e, i), n[2] = Math.max(n[2], t, s), n[3] = Math.max(n[3], e, i);
  }
  static #t(t, e, s, i, n, r, a, o, l, h) {
    if (l <= 0 || l >= 1)
      return;
    const c = 1 - l, u = l * l, f = u * l, p = c * (c * (c * t + 3 * l * e) + 3 * u * s) + f * i, g = c * (c * (c * n + 3 * l * r) + 3 * u * a) + f * o;
    h[0] = Math.min(h[0], p), h[1] = Math.min(h[1], g), h[2] = Math.max(h[2], p), h[3] = Math.max(h[3], g);
  }
  static #e(t, e, s, i, n, r, a, o, l, h, c, u) {
    if (Math.abs(l) < 1e-12) {
      Math.abs(h) >= 1e-12 && this.#t(t, e, s, i, n, r, a, o, -c / h, u);
      return;
    }
    const f = h ** 2 - 4 * c * l;
    if (f < 0)
      return;
    const p = Math.sqrt(f), g = 2 * l;
    this.#t(t, e, s, i, n, r, a, o, (-h + p) / g, u), this.#t(t, e, s, i, n, r, a, o, (-h - p) / g, u);
  }
  static bezierBoundingBox(t, e, s, i, n, r, a, o, l) {
    l[0] = Math.min(l[0], t, a), l[1] = Math.min(l[1], e, o), l[2] = Math.max(l[2], t, a), l[3] = Math.max(l[3], e, o), this.#e(t, s, n, a, e, i, r, o, 3 * (-t + 3 * (s - n) + a), 6 * (t - 2 * s + n), 3 * (s - t), l), this.#e(t, s, n, a, e, i, r, o, 3 * (-e + 3 * (i - r) + o), 6 * (e - 2 * i + r), 3 * (i - e), l);
  }
}
function Hn(d) {
  return decodeURIComponent(escape(d));
}
let Cs = null, Ai = null;
function Un(d) {
  return Cs || (Cs = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40\ufb41\ufb43\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, Ai = /* @__PURE__ */ new Map([["ﬅ", "ſt"]])), d.replaceAll(Cs, (t, e, s) => e ? e.normalize("NFKC") : Ai.get(s));
}
function Qi() {
  if (typeof crypto.randomUUID == "function")
    return crypto.randomUUID();
  const d = new Uint8Array(32);
  return crypto.getRandomValues(d), Bn(d);
}
function Gn(d, t, e) {
  if (!Array.isArray(e) || e.length < 2)
    return !1;
  const [s, i, ...n] = e;
  if (!d(s) && !Number.isInteger(s) || !t(i))
    return !1;
  const r = n.length;
  let a = !0;
  switch (i.name) {
    case "XYZ":
      if (r < 2 || r > 3)
        return !1;
      break;
    case "Fit":
    case "FitB":
      return r === 0;
    case "FitH":
    case "FitBH":
    case "FitV":
    case "FitBV":
      if (r > 1)
        return !1;
      break;
    case "FitR":
      if (r !== 4)
        return !1;
      a = !1;
      break;
    default:
      return !1;
  }
  for (const o of n)
    if (!(typeof o == "number" || a && o === null))
      return !1;
  return !0;
}
const we = () => [], ss = () => /* @__PURE__ */ new Map(), Ls = () => /* @__PURE__ */ Object.create(null), jn = () => /* @__PURE__ */ new Set();
typeof Iterator.prototype.join != "function" && (Iterator.prototype.join = function(d) {
  return [...this].join(d);
});
function Y(d, t, e) {
  return Math.min(Math.max(d, t), e);
}
class Ae {
  static CSS = 96;
  static PDF = 72;
  static PDF_TO_CSS_UNITS = this.CSS / this.PDF;
}
class Ks extends he {
  constructor(t, e = 0) {
    super(t, "RenderingCancelledException"), this.extraDelay = e;
  }
}
function ve(d) {
  if (d.startsWith("#")) {
    const e = d.slice(1);
    return [parseInt(e.slice(0, 2), 16), parseInt(e.slice(2, 4), 16), parseInt(e.slice(4, 6), 16), e.length >= 8 ? parseInt(e.slice(6, 8), 16) / 255 : 1];
  }
  if (d.startsWith("rgb(")) {
    const [e, s, i] = d.slice(4, -1).split(",").map((n) => parseInt(n, 10));
    return [e, s, i, 1];
  }
  if (d.startsWith("rgba(")) {
    const e = d.slice(5, -1).split(",");
    return [parseInt(e[0], 10), parseInt(e[1], 10), parseInt(e[2], 10), parseFloat(e[3])];
  }
  const t = d.match(/^color\(srgb\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)(?:\s*\/\s*([\d.]+|none))?\)$/);
  return t ? [Math.round(parseFloat(t[1]) * 255), Math.round(parseFloat(t[2]) * 255), Math.round(parseFloat(t[3]) * 255), t[4] !== void 0 && t[4] !== "none" ? parseFloat(t[4]) : 1] : null;
}
function Re(d) {
  const t = ve(d);
  return t ? t.slice(0, 3) : (R(`Not a valid color format: "${d}"`), [0, 0, 0]);
}
function X(d) {
  const {
    a: t,
    b: e,
    c: s,
    d: i,
    e: n,
    f: r
  } = d.getTransform();
  return [t, e, s, i, n, r];
}
function Rt(d) {
  const {
    a: t,
    b: e,
    c: s,
    d: i,
    e: n,
    f: r
  } = d.getTransform().invertSelf();
  return [t, e, s, i, n, r];
}
class wt {
  constructor() {
    const {
      pixelRatio: t
    } = wt;
    this.sx = t, this.sy = t;
  }
  get scaled() {
    return this.sx !== 1 || this.sy !== 1;
  }
  get symmetric() {
    return this.sx === this.sy;
  }
  limitCanvas(t, e, s, i, n = -1) {
    let r = 1 / 0, a = 1 / 0, o = 1 / 0;
    s = wt.capPixels(s, n), s > 0 && (r = Math.sqrt(s / (t * e))), i !== -1 && (a = i / t, o = i / e);
    const l = Math.min(r, a, o);
    return this.sx > l || this.sy > l ? (this.sx = l, this.sy = l, !0) : !1;
  }
  static get pixelRatio() {
    return globalThis.devicePixelRatio || 1;
  }
  static capPixels(t, e) {
    if (e >= 0) {
      const s = Math.ceil(window.screen.availWidth * window.screen.availHeight * this.pixelRatio ** 2 * (1 + e / 100));
      return t > 0 ? Math.min(t, s) : s;
    }
    return t;
  }
}
function zn(d, t) {
  t = Y(t ?? 1, 0, 1);
  const e = 255 * (1 - t);
  return d.map((s) => Math.round(s * t + e));
}
function wi(d, t) {
  const e = d[0] / 255, s = d[1] / 255, i = d[2] / 255, n = Math.max(e, s, i), r = Math.min(e, s, i), a = (n + r) / 2;
  if (n === r)
    t[0] = t[1] = 0;
  else {
    const o = n - r;
    switch (t[1] = a < 0.5 ? o / (n + r) : o / (2 - n - r), n) {
      case e:
        t[0] = ((s - i) / o + (s < i ? 6 : 0)) * 60;
        break;
      case s:
        t[0] = ((i - e) / o + 2) * 60;
        break;
      case i:
        t[0] = ((e - s) / o + 4) * 60;
        break;
    }
  }
  t[2] = a;
}
function Ns(d, t) {
  const e = d[0], s = d[1], i = d[2], n = (1 - Math.abs(2 * i - 1)) * s, r = n * (1 - Math.abs(e / 60 % 2 - 1)), a = i - n / 2;
  switch (Math.floor(e / 60)) {
    case 0:
      t[0] = n + a, t[1] = r + a, t[2] = a;
      break;
    case 1:
      t[0] = r + a, t[1] = n + a, t[2] = a;
      break;
    case 2:
      t[0] = a, t[1] = n + a, t[2] = r + a;
      break;
    case 3:
      t[0] = a, t[1] = r + a, t[2] = n + a;
      break;
    case 4:
      t[0] = r + a, t[1] = a, t[2] = n + a;
      break;
    case 5:
    case 6:
      t[0] = n + a, t[1] = a, t[2] = r + a;
      break;
  }
}
function Bs(d) {
  return d <= 0.03928 ? d / 12.92 : ((d + 0.055) / 1.055) ** 2.4;
}
function vi(d, t, e) {
  Ns(d, e), e.map(Bs);
  const s = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  Ns(t, e), e.map(Bs);
  const i = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  return s > i ? (s + 0.05) / (i + 0.05) : (i + 0.05) / (s + 0.05);
}
const Si = /* @__PURE__ */ new Map();
function $n(d, t) {
  const e = d[0] + d[1] * 256 + d[2] * 65536 + t[0] * 16777216 + t[1] * 4294967296 + t[2] * 1099511627776;
  let s = Si.get(e);
  if (s)
    return s;
  const i = new Float32Array(9), n = i.subarray(0, 3), r = i.subarray(3, 6);
  wi(d, r);
  const a = i.subarray(6, 9);
  wi(t, a);
  const o = a[2] < 0.5, l = o ? 12 : 4.5;
  if (r[2] = o ? Math.sqrt(r[2]) : 1 - Math.sqrt(1 - r[2]), vi(r, a, n) < l) {
    let h, c;
    o ? (h = r[2], c = 1) : (h = 0, c = r[2]);
    const u = 5e-3;
    for (; c - h > u; ) {
      const f = r[2] = (h + c) / 2;
      o === vi(r, a, n) < l ? h = f : c = f;
    }
    r[2] = o ? c : h;
  }
  return Ns(r, n), s = x.makeHexColor(Math.round(n[0] * 255), Math.round(n[1] * 255), Math.round(n[2] * 255)), Si.set(e, s), s;
}
function Ji(d) {
  const t = new Path2D();
  if (!d)
    return t;
  for (let e = 0, s = d.length; e < s; )
    switch (d[e++]) {
      case _e.moveTo:
        t.moveTo(d[e++], d[e++]);
        break;
      case _e.lineTo:
        t.lineTo(d[e++], d[e++]);
        break;
      case _e.curveTo:
        t.bezierCurveTo(d[e++], d[e++], d[e++], d[e++], d[e++], d[e++]);
        break;
      case _e.quadraticCurveTo:
        t.quadraticCurveTo(d[e++], d[e++], d[e++], d[e++]);
        break;
      case _e.closePath:
        t.closePath();
        break;
      default:
        R(`Unrecognized drawing path operator: ${d[e - 1]}`);
        break;
    }
  return t;
}
class Le {
  constructor({
    viewBox: t,
    userUnit: e,
    scale: s,
    rotation: i,
    offsetX: n = 0,
    offsetY: r = 0,
    dontFlip: a = !1
  }) {
    this.viewBox = t, this.userUnit = e, this.scale = s, this.rotation = i, this.offsetX = n, this.offsetY = r, s *= e;
    const o = (t[2] + t[0]) / 2, l = (t[3] + t[1]) / 2;
    let h, c, u, f;
    switch (i %= 360, i < 0 && (i += 360), i) {
      case 180:
        h = -1, c = 0, u = 0, f = 1;
        break;
      case 90:
        h = 0, c = 1, u = 1, f = 0;
        break;
      case 270:
        h = 0, c = -1, u = -1, f = 0;
        break;
      case 0:
        h = 1, c = 0, u = 0, f = -1;
        break;
      default:
        throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
    }
    a && (u = -u, f = -f);
    let p, g, m, b;
    h === 0 ? (p = Math.abs(l - t[1]) * s + n, g = Math.abs(o - t[0]) * s + r, m = (t[3] - t[1]) * s, b = (t[2] - t[0]) * s) : (p = Math.abs(o - t[0]) * s + n, g = Math.abs(l - t[1]) * s + r, m = (t[2] - t[0]) * s, b = (t[3] - t[1]) * s), this.transform = [h * s, c * s, u * s, f * s, p - h * s * o - u * s * l, g - c * s * o - f * s * l], this.width = m, this.height = b;
  }
  get rawDims() {
    const t = this.viewBox;
    return k(this, "rawDims", {
      pageWidth: t[2] - t[0],
      pageHeight: t[3] - t[1],
      pageX: t[0],
      pageY: t[1]
    });
  }
  clone({
    scale: t = this.scale,
    rotation: e = this.rotation,
    offsetX: s = this.offsetX,
    offsetY: i = this.offsetY,
    dontFlip: n = !1
  } = {}) {
    return new Le({
      viewBox: this.viewBox.slice(),
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: i,
      dontFlip: n
    });
  }
  convertToViewportPoint(t, e) {
    const s = [t, e];
    return x.applyTransform(s, this.transform), s;
  }
  convertToPdfPoint(t, e) {
    const s = [t, e];
    return x.applyInverseTransform(s, this.transform), s;
  }
}
class Me {
  static textContent(t) {
    const e = [], s = {
      items: e,
      styles: /* @__PURE__ */ Object.create(null)
    };
    function i(n) {
      if (!n)
        return;
      let r = null;
      const a = n.name;
      if (a === "#text")
        r = n.value;
      else if (Me.shouldBuildText(a))
        n?.attributes?.textContent ? r = n.attributes.textContent : n.value && (r = n.value);
      else return;
      if (r !== null && e.push({
        str: r
      }), !!n.children)
        for (const o of n.children)
          i(o);
    }
    return i(t), s;
  }
  static shouldBuildText(t) {
    return !(t === "textarea" || t === "input" || t === "option" || t === "select");
  }
}
const Wn = /url\(|image-set\(/i, Vn = /^on/i;
class Zi {
  static get _allowedHtmlElements() {
    return k(this, "_allowedHtmlElements", /* @__PURE__ */ new Set(["a", "b", "br", "button", "div", "i", "img", "input", "label", "li", "ol", "option", "p", "select", "span", "sub", "sup", "textarea", "ul"]));
  }
  static get _allowedSvgElements() {
    return k(this, "_allowedSvgElements", /* @__PURE__ */ new Set(["ellipse", "line", "path", "rect", "svg"]));
  }
  static get _allowedRichTextElements() {
    return k(this, "_allowedRichTextElements", /* @__PURE__ */ new Set(["a", "b", "br", "div", "i", "li", "ol", "p", "span", "sub", "sup", "ul"]));
  }
  static get _allowedRichTextAttributes() {
    return k(this, "_allowedRichTextAttributes", /* @__PURE__ */ new Set(["class", "dir", "style"]));
  }
  static get _allowedRichTextStyles() {
    return k(this, "_allowedRichTextStyles", /* @__PURE__ */ new Set(["color", "font", "fontFamily", "fontSize", "fontStretch", "fontStyle", "fontWeight", "kerningMode", "letterSpacing", "lineHeight", "margin", "marginBottom", "marginLeft", "marginRight", "marginTop", "orphans", "paddingLeft", "paddingRight", "breakAfter", "breakBefore", "breakInside", "tabInterval", "tabStop", "textAlign", "textDecoration", "textIndent", "transform", "verticalAlign", "widows"]));
  }
  static setupStorage(t, e, s, i, n) {
    const r = i.getValue(e, {
      value: null
    });
    switch (s.name) {
      case "textarea":
        if (r.value !== null && (t.textContent = r.value), n === "print")
          break;
        t.addEventListener("input", (a) => {
          i.setValue(e, {
            value: a.target.value
          });
        });
        break;
      case "input":
        if (s.attributes.type === "radio" || s.attributes.type === "checkbox") {
          if (r.value === s.attributes.xfaOn ? t.setAttribute("checked", !0) : r.value === s.attributes.xfaOff && t.removeAttribute("checked"), n === "print")
            break;
          t.addEventListener("change", (a) => {
            i.setValue(e, {
              value: a.target.checked ? a.target.getAttribute("xfaOn") : a.target.getAttribute("xfaOff")
            });
          });
        } else {
          if (r.value !== null && t.setAttribute("value", r.value), n === "print")
            break;
          t.addEventListener("input", (a) => {
            i.setValue(e, {
              value: a.target.value
            });
          });
        }
        break;
      case "select":
        if (r.value !== null) {
          t.setAttribute("value", r.value);
          for (const a of s.children)
            a.attributes.value === r.value ? a.attributes.selected = !0 : Object.hasOwn(a.attributes, "selected") && delete a.attributes.selected;
        }
        t.addEventListener("input", (a) => {
          const o = a.target.options, l = o.selectedIndex === -1 ? "" : o[o.selectedIndex].value;
          i.setValue(e, {
            value: l
          });
        });
        break;
    }
  }
  static setAttributes({
    html: t,
    element: e,
    storage: s = null,
    intent: i,
    linkService: n
  }) {
    const {
      attributes: r
    } = e, a = t instanceof HTMLAnchorElement;
    r.type === "radio" && (r.name = `${r.name}-${i}`);
    for (const [o, l] of Object.entries(r))
      if (!(l == null || Vn.test(o)) && !(i === "richText" && !this._allowedRichTextAttributes.has(o)))
        switch (o) {
          case "class":
            l.length && t.setAttribute(o, l.join(" "));
            break;
          case "dataId":
            break;
          case "id":
            t.setAttribute("data-element-id", l);
            break;
          case "style":
            if (i === "richText") {
              const h = this._allowedRichTextStyles;
              for (const [c, u] of Object.entries(l))
                h.has(c) && !Wn.test(u) && (t.style[c] = u);
            } else
              Object.assign(t.style, l);
            break;
          case "textContent":
            t.textContent = l;
            break;
          default:
            (!a || o !== "href" && o !== "newWindow") && t.setAttribute(o, l);
        }
    a && n?.addLinkAttributes(t, r.href, r.newWindow), s && r.dataId && this.setupStorage(t, r.dataId, e, s);
  }
  static #t(t, e, s) {
    return s === "richText" ? !e && this._allowedRichTextElements.has(t) ? document.createElement(t) : null : e ? e === ct && this._allowedSvgElements.has(t) ? document.createElementNS(ct, t) : null : this._allowedHtmlElements.has(t) ? document.createElement(t) : null;
  }
  static render(t) {
    const e = t.annotationStorage, s = t.linkService, i = t.xfaHtml, n = t.intent || "display", r = this.#t(i.name, i.attributes?.xmlns, n) ?? document.createElement("div");
    i.attributes && this.setAttributes({
      html: r,
      element: i,
      intent: n,
      linkService: s
    });
    const a = n !== "richText", o = t.div;
    if (o.append(r), t.viewport) {
      const c = `matrix(${t.viewport.transform.join(",")})`;
      o.style.transform = c;
    }
    a && o.setAttribute("class", "xfaLayer xfaFont");
    const l = [];
    if (i.children.length === 0) {
      if (i.value) {
        const c = document.createTextNode(i.value);
        r.append(c), a && Me.shouldBuildText(i.name) && l.push(c);
      }
      return {
        textDivs: l
      };
    }
    const h = [[i, -1, r]];
    for (; h.length > 0; ) {
      const [c, u, f] = h.at(-1);
      if (u + 1 === c.children.length) {
        h.pop();
        continue;
      }
      const p = c.children[++h.at(-1)[1]];
      if (p === null)
        continue;
      const {
        name: g
      } = p;
      if (g === "#text") {
        const b = document.createTextNode(p.value);
        l.push(b), f.append(b);
        continue;
      }
      const m = this.#t(g, p.attributes?.xmlns, n);
      if (m) {
        if (f.append(m), p.attributes && this.setAttributes({
          html: m,
          element: p,
          storage: e,
          intent: n,
          linkService: s
        }), p.children?.length > 0)
          h.push([p, -1, m]);
        else if (p.value) {
          const b = document.createTextNode(p.value);
          a && Me.shouldBuildText(g) && l.push(b), m.append(b);
        }
      }
    }
    for (const c of o.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
      c.setAttribute("readOnly", !0);
    return {
      textDivs: l
    };
  }
  static update(t) {
    const e = `matrix(${t.viewport.transform.join(",")})`;
    t.div.style.transform = e, t.div.hidden = !1;
  }
  static getPageViewport(t, {
    scale: e = 1,
    rotation: s = 0
  }) {
    const {
      width: i,
      height: n
    } = t.attributes.style;
    return new Le({
      viewBox: [0, 0, parseInt(i, 10), parseInt(n, 10)],
      userUnit: 1,
      scale: e,
      rotation: s
    });
  }
}
async function qs(d, t = "text") {
  if (xe(d, document.baseURI)) {
    const e = await fetch(d);
    if (!e.ok)
      throw new Error(e.statusText);
    switch (t) {
      case "blob":
        return e.blob();
      case "bytes":
        return e.bytes();
      case "json":
        return e.json();
    }
    return e.text();
  }
  return new Promise((e, s) => {
    const i = new XMLHttpRequest();
    i.open("GET", d, !0), i.responseType = t === "bytes" ? "arraybuffer" : t, i.onreadystatechange = () => {
      if (i.readyState === XMLHttpRequest.DONE) {
        if (i.status === 200 || i.status === 0) {
          switch (t) {
            case "bytes":
              e(new Uint8Array(i.response));
              return;
            case "blob":
            case "json":
              e(i.response);
              return;
          }
          e(i.responseText);
          return;
        }
        s(new Error(i.statusText));
      }
    }, i.send(null);
  });
}
function ds(d) {
  const t = d.length;
  let e = 0;
  for (; e < t && d[e].trim() === ""; )
    e++;
  return d.substring(e, e + 5).toLowerCase() === "data:";
}
function Qs(d) {
  return typeof d == "string" && /\.pdf$/i.test(d);
}
function Xn(d) {
  return [d] = d.split(/[#?]/, 1), Fs(d);
}
function Yn(d, t = "document.pdf") {
  if (typeof d != "string")
    return t;
  if (ds(d))
    return R('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), t;
  const s = ((a) => {
    try {
      return new URL(a);
    } catch {
    }
    try {
      return new URL(decodeURIComponent(a));
    } catch {
    }
    try {
      return new URL(a, "https://foo.bar");
    } catch {
    }
    try {
      return new URL(decodeURIComponent(a), "https://foo.bar");
    } catch {
    }
    return null;
  })(d);
  if (!s)
    return t;
  const i = (a) => {
    try {
      let o = decodeURIComponent(a);
      return o.includes("/") && (o = Fs(o), o.length === 4 && n.test(o)) ? a : o;
    } catch {
      return a;
    }
  }, n = /\.pdf$/i, r = Fs(s.pathname);
  if (n.test(r))
    return i(r);
  if (s.searchParams.size > 0) {
    const a = (l) => [...l].findLast((h) => n.test(h)), o = a(s.searchParams.values()) ?? a(s.searchParams.keys());
    if (o)
      return i(o);
  }
  if (s.hash) {
    const {
      hash: a
    } = s;
    let o = -1;
    for (const {
      index: l
    } of a.matchAll(/\.pdf\b/gi))
      o = l;
    if (o > 0) {
      let l = o;
      for (; l > 0 && !"/?#=".includes(a[l - 1]); )
        l--;
      if (l < o)
        return i(a.slice(l, o + 4));
    }
  }
  return t;
}
function xe(d, t) {
  const e = t ? URL.parse(d, t) : URL.parse(d);
  return /https?:/.test(e?.protocol ?? "");
}
function xt(d) {
  d.preventDefault();
}
function nt(d) {
  d.preventDefault(), d.stopPropagation();
}
class Hs {
  static #t;
  static toDateObject(t) {
    if (t instanceof Date)
      return t;
    if (!t || typeof t != "string")
      return null;
    this.#t ||= new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+\\-])?(\\d{2})?'?(\\d{2})?'?");
    const e = this.#t.exec(t);
    if (!e)
      return null;
    const s = parseInt(e[1], 10);
    let i = parseInt(e[2], 10);
    i = i >= 1 && i <= 12 ? i - 1 : 0;
    let n = parseInt(e[3], 10);
    n = n >= 1 && n <= 31 ? n : 1;
    let r = parseInt(e[4], 10);
    r = r >= 0 && r <= 23 ? r : 0;
    let a = parseInt(e[5], 10);
    a = a >= 0 && a <= 59 ? a : 0;
    let o = parseInt(e[6], 10);
    o = o >= 0 && o <= 59 ? o : 0;
    const l = e[7] || "Z";
    let h = parseInt(e[8], 10);
    h = h >= 0 && h <= 23 ? h : 0;
    let c = parseInt(e[9], 10) || 0;
    return c = c >= 0 && c <= 59 ? c : 0, l === "-" ? (r += h, a += c) : l === "+" && (r -= h, a -= c), new Date(Date.UTC(s, i, n, r, a, o));
  }
}
function Kn(d) {
  const t = document.createElement("span");
  t.style.visibility = "hidden", t.style.colorScheme = "only light", document.body.append(t);
  for (const e of d.keys()) {
    t.style.color = e;
    const s = window.getComputedStyle(t).color;
    d.set(e, Re(s));
  }
  t.remove();
}
function oe(d, t, e = !1, s = !0) {
  if (t instanceof Le) {
    const {
      pageWidth: i,
      pageHeight: n
    } = t.rawDims, {
      style: r
    } = d, a = `round(down, var(--total-scale-factor) * ${i}px, var(--scale-round-x))`, o = `round(down, var(--total-scale-factor) * ${n}px, var(--scale-round-y))`;
    !e || t.rotation % 180 === 0 ? (r.width = a, r.height = o) : (r.width = o, r.height = a);
  }
  s && d.setAttribute("data-main-rotation", t.rotation);
}
const Us = /* @__PURE__ */ new Set(["image/apng", "image/avif", "image/bmp", "image/gif", "image/jpeg", "image/png", "image/svg+xml", "image/webp", "image/x-icon"]);
class qn {
  static get isDarkMode() {
    return k(this, "isDarkMode", !!window?.matchMedia?.("(prefers-color-scheme: dark)").matches);
  }
}
class Qn {
  static get commentForegroundColor() {
    const t = document.createElement("span");
    t.classList.add("comment", "sidebar");
    const {
      style: e
    } = t;
    e.width = e.height = "0", e.display = "none", e.color = "var(--comment-fg-color)", document.body.append(t);
    const {
      color: s
    } = window.getComputedStyle(t);
    return t.remove(), k(this, "commentForegroundColor", Re(s));
  }
}
function tn({
  html: d,
  dir: t,
  className: e
}, s) {
  const i = document.createDocumentFragment();
  if (typeof d == "string") {
    const n = document.createElement("p");
    n.dir = t || "auto";
    const r = d.split(/\r\n?|\n/);
    for (let a = 0, o = r.length; a < o; ++a) {
      const l = r[a];
      n.append(document.createTextNode(l)), a < o - 1 && n.append(document.createElement("br"));
    }
    i.append(n);
  } else
    Zi.render({
      xfaHtml: d,
      div: i,
      intent: "richText"
    });
  i.firstElementChild.classList.add("richText", e), s.append(i);
}
class Te {
  #t = null;
  #e = null;
  #s;
  #i = null;
  #n = null;
  #r = null;
  #a = null;
  #o = null;
  static #l = null;
  constructor(t) {
    this.#s = t, Te.#l ||= Object.freeze({
      freetext: "pdfjs-editor-remove-freetext-button",
      highlight: "pdfjs-editor-remove-highlight-button",
      ink: "pdfjs-editor-remove-ink-button",
      stamp: "pdfjs-editor-remove-stamp-button",
      signature: "pdfjs-editor-remove-signature-button"
    });
  }
  render() {
    const t = this.#t = document.createElement("div");
    t.classList.add("editToolbar", "hidden"), t.setAttribute("role", "toolbar");
    const e = this.#s._uiManager._signal;
    e instanceof AbortSignal && !e.aborted && (t.addEventListener("contextmenu", xt, {
      signal: e
    }), t.addEventListener("pointerdown", Te.#h, {
      signal: e
    }));
    const s = this.#i = document.createElement("div");
    s.className = "buttons", t.append(s);
    const i = this.#s.toolbarPosition;
    if (i) {
      const {
        style: n
      } = t, r = this.#s._uiManager.direction === "ltr" ? 1 - i[0] : i[0];
      n.insetInlineEnd = `${100 * r}%`, n.top = `calc(${100 * i[1]}% + var(--editor-toolbar-vert-offset))`;
    }
    return t;
  }
  get div() {
    return this.#t;
  }
  static #h(t) {
    t.stopPropagation();
  }
  #u(t) {
    this.#s._focusEventsAllowed = !1, nt(t);
  }
  #c(t) {
    this.#s._focusEventsAllowed = !0, nt(t);
  }
  #f(t) {
    const e = this.#s._uiManager._signal;
    return !(e instanceof AbortSignal) || e.aborted ? !1 : (t.addEventListener("focusin", this.#u.bind(this), {
      capture: !0,
      signal: e
    }), t.addEventListener("focusout", this.#c.bind(this), {
      capture: !0,
      signal: e
    }), t.addEventListener("contextmenu", xt, {
      signal: e
    }), !0);
  }
  hide() {
    this.#t.classList.add("hidden"), this.#e?.hideDropdown();
  }
  show() {
    this.#t.classList.remove("hidden"), this.#n?.shown(), this.#r?.shown();
  }
  addDeleteButton() {
    const {
      editorType: t,
      _uiManager: e
    } = this.#s, s = document.createElement("button");
    s.classList.add("basic", "deleteButton"), s.tabIndex = 0, s.setAttribute("data-l10n-id", Te.#l[t]), this.#f(s) && s.addEventListener("click", (i) => {
      e.delete();
    }, {
      signal: e._signal
    }), this.#i.append(s);
  }
  get #p() {
    const t = document.createElement("div");
    return t.className = "divider", t;
  }
  async addAltText(t) {
    const e = await t.render();
    this.#f(e), this.#i.append(e, this.#p), this.#n = t;
  }
  addComment(t, e = null) {
    if (this.#r)
      return;
    const s = t.renderForToolbar();
    if (!s)
      return;
    this.#f(s);
    const i = this.#a = this.#p;
    e ? (this.#i.insertBefore(s, e), this.#i.insertBefore(i, e)) : this.#i.append(s, i), this.#r = t, t.toolbar = this;
  }
  addColorPicker(t) {
    if (this.#e)
      return;
    this.#e = t;
    const e = t.renderButton();
    this.#f(e), this.#i.append(e, this.#p);
  }
  async addEditSignatureButton(t) {
    const e = this.#o = await t.renderEditButton(this.#s);
    e && (this.#f(e), this.#i.append(e, this.#p));
  }
  removeButton(t) {
    t === "comment" && (this.#r?.removeToolbarCommentButton(), this.#r = null, this.#a?.remove(), this.#a = null);
  }
  async addButton(t, e) {
    switch (t) {
      case "colorPicker":
        e && this.addColorPicker(e);
        break;
      case "altText":
        e && await this.addAltText(e);
        break;
      case "editSignature":
        e && await this.addEditSignatureButton(e);
        break;
      case "delete":
        this.addDeleteButton();
        break;
      case "comment":
        e && this.addComment(e);
        break;
    }
  }
  async addButtonBefore(t, e, s) {
    if (!e && t === "comment")
      return;
    const i = this.#i.querySelector(s);
    i && t === "comment" && this.addComment(e, i);
  }
  updateEditSignatureButton(t) {
    this.#o && (this.#o.title = t);
  }
  remove() {
    this.#t.remove(), this.#e?.destroy(), this.#e = null;
  }
}
class Jn {
  #t = null;
  #e = null;
  #s;
  constructor(t) {
    this.#s = t;
  }
  #i() {
    const t = this.#e = document.createElement("div");
    t.className = "editToolbar", t.setAttribute("role", "toolbar"), t.dir = this.#s.direction;
    const e = this.#s._signal;
    e instanceof AbortSignal && !e.aborted && t.addEventListener("contextmenu", xt, {
      signal: e
    });
    const s = this.#t = document.createElement("div");
    return s.className = "buttons", t.append(s), this.#s.hasCommentManager() && this.#r("commentButton", "pdfjs-comment-floating-button", "pdfjs-comment-floating-button-label", () => {
      this.#s.commentSelection("floating_button");
    }), this.#r("highlightButton", "pdfjs-highlight-floating-button1", "pdfjs-highlight-floating-button-label", () => {
      this.#s.highlightSelection("floating_button");
    }), t;
  }
  #n(t, e) {
    let s = 0, i = 0;
    for (const n of t) {
      const r = n.y + n.height;
      if (r < s)
        continue;
      const a = n.x + (e ? n.width : 0);
      if (r > s) {
        i = a, s = r;
        continue;
      }
      e ? a > i && (i = a) : a < i && (i = a);
    }
    return [e ? 1 - i : i, s];
  }
  show(t, e, s) {
    const [i, n] = this.#n(e, s), {
      style: r
    } = this.#e ||= this.#i();
    t.append(this.#e), r.insetInlineEnd = `${100 * i}%`, r.top = `calc(${100 * n}% + var(--editor-toolbar-vert-offset))`;
  }
  hide() {
    this.#e.remove();
  }
  #r(t, e, s, i) {
    const n = document.createElement("button");
    n.classList.add("basic", t), n.tabIndex = 0, n.setAttribute("data-l10n-id", e);
    const r = document.createElement("span");
    n.append(r), r.className = "visuallyHidden", r.setAttribute("data-l10n-id", s);
    const a = this.#s._signal;
    a instanceof AbortSignal && !a.aborted && (n.addEventListener("contextmenu", xt, {
      signal: a
    }), n.addEventListener("click", i, {
      signal: a
    })), this.#t.append(n);
  }
}
const Zn = "0a475cb6-573c-46ed-869d-fa7c5839d995", Es = Object.freeze({
  internal: Zn
});
function en(d, t, e) {
  for (const s of e)
    t.addEventListener(s, d[s].bind(d));
}
class $ {
  static #t = NaN;
  static #e = null;
  static #s = NaN;
  static #i = null;
  static initializeAndAddPointerId(t) {
    ($.#e ||= /* @__PURE__ */ new Set()).add(t);
  }
  static setPointer(t, e) {
    $.#t ||= e, $.#i ??= t;
  }
  static setTimeStamp(t) {
    $.#s = t;
  }
  static isSamePointerId(t) {
    return $.#t === t;
  }
  static isSamePointerIdOrRemove(t) {
    return $.#t === t ? !0 : ($.#e?.delete(t), !1);
  }
  static isSamePointerType(t) {
    return $.#i === t;
  }
  static isInitializedAndDifferentPointerType(t) {
    return $.#i !== null && !$.isSamePointerType(t);
  }
  static isSameTimeStamp(t) {
    return $.#s === t;
  }
  static isUsingMultiplePointers() {
    return $.#e?.size >= 1;
  }
  static clearPointerType() {
    $.#i = null;
  }
  static clearPointerIds() {
    $.#t = NaN, $.#e = null;
  }
  static clearTimeStamp() {
    $.#s = NaN;
  }
}
class tr {
  #t = 0;
  get id() {
    return `${ye}${this.#t++}`;
  }
}
class Js {
  #t = Qi();
  #e = 0;
  #s = null;
  static get _isSVGFittingCanvas() {
    const t = `data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="${ct}"><rect width="1" height="1" style="fill:red;"/></svg>`, s = new OffscreenCanvas(1, 3).getContext("2d", {
      willReadFrequently: !0
    }), i = new Image();
    i.src = t;
    const n = i.decode().then(() => (s.drawImage(i, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(s.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
    return k(this, "_isSVGFittingCanvas", n);
  }
  async #i(t, e) {
    this.#s ||= /* @__PURE__ */ new Map();
    let s = this.#s.get(t);
    if (s === null)
      return null;
    if (s?.bitmap)
      return s.refCounter += 1, s;
    try {
      s ||= {
        bitmap: null,
        id: `image_${this.#t}_${this.#e++}`,
        refCounter: 0,
        isSvg: !1
      };
      let i;
      if (typeof e == "string" ? (s.url = e, i = await qs(e, "blob")) : e instanceof File ? i = s.file = e : e instanceof Blob && (i = e), i.type === "image/svg+xml") {
        const n = Js._isSVGFittingCanvas, r = new FileReader(), a = new Image(), o = new Promise((l, h) => {
          a.onload = () => {
            s.bitmap = a, s.isSvg = !0, l();
          }, r.onload = async () => {
            const c = s.svgUrl = r.result;
            a.src = await n ? `${c}#svgView(preserveAspectRatio(none))` : c;
          }, a.onerror = r.onerror = h;
        });
        r.readAsDataURL(i), await o;
      } else
        s.bitmap = await createImageBitmap(i);
      s.refCounter = 1;
    } catch (i) {
      R(i), s = null;
    }
    return this.#s.set(t, s), s && this.#s.set(s.id, s), s;
  }
  async getFromFile(t) {
    const {
      lastModified: e,
      name: s,
      size: i,
      type: n
    } = t;
    return this.#i(`${e}_${s}_${i}_${n}`, t);
  }
  async getFromUrl(t) {
    return this.#i(t, t);
  }
  async getFromBlob(t, e) {
    const s = await e;
    return this.#i(t, s);
  }
  async getFromId(t) {
    this.#s ||= /* @__PURE__ */ new Map();
    const e = this.#s.get(t);
    if (!e)
      return null;
    if (e.bitmap)
      return e.refCounter += 1, e;
    if (e.file)
      return this.getFromFile(e.file);
    if (e.blobPromise) {
      const {
        blobPromise: s
      } = e;
      return delete e.blobPromise, this.getFromBlob(e.id, s);
    }
    return this.getFromUrl(e.url);
  }
  getFromCanvas(t, e) {
    this.#s ||= /* @__PURE__ */ new Map();
    let s = this.#s.get(t);
    if (s?.bitmap)
      return s.refCounter += 1, s;
    const i = new OffscreenCanvas(e.width, e.height);
    return i.getContext("2d").drawImage(e, 0, 0), s = {
      bitmap: i.transferToImageBitmap(),
      id: `image_${this.#t}_${this.#e++}`,
      refCounter: 1,
      isSvg: !1
    }, this.#s.set(t, s), this.#s.set(s.id, s), s;
  }
  getSvgUrl(t) {
    const e = this.#s.get(t);
    return e?.isSvg ? e.svgUrl : null;
  }
  deleteId(t) {
    this.#s ||= /* @__PURE__ */ new Map();
    const e = this.#s.get(t);
    if (!e || (e.refCounter -= 1, e.refCounter !== 0))
      return;
    const {
      bitmap: s
    } = e;
    if (!e.url && !e.file) {
      const i = new OffscreenCanvas(s.width, s.height);
      i.getContext("bitmaprenderer").transferFromImageBitmap(s), e.blobPromise = i.convertToBlob();
    }
    s.close?.(), e.bitmap = null;
  }
  isValidId(t) {
    return t.startsWith(`image_${this.#t}_`);
  }
}
class er {
  #t = [];
  #e = !1;
  #s;
  #i = -1;
  constructor(t = 128) {
    this.#s = t;
  }
  add({
    cmd: t,
    undo: e,
    post: s,
    mustExec: i,
    type: n = NaN,
    overwriteIfSameType: r = !1,
    keepUndo: a = !1
  }) {
    if (i && t(), this.#e)
      return;
    const o = {
      cmd: t,
      undo: e,
      post: s,
      type: n
    };
    if (this.#i === -1) {
      this.#t.length > 0 && (this.#t.length = 0), this.#i = 0, this.#t.push(o);
      return;
    }
    if (r && this.#t[this.#i].type === n) {
      a && (o.undo = this.#t[this.#i].undo), this.#t[this.#i] = o;
      return;
    }
    const l = this.#i + 1;
    l === this.#s ? this.#t.splice(0, 1) : (this.#i = l, l < this.#t.length && this.#t.splice(l)), this.#t.push(o);
  }
  undo() {
    if (this.#i === -1)
      return;
    this.#e = !0;
    const {
      undo: t,
      post: e
    } = this.#t[this.#i];
    t(), e?.(), this.#e = !1, this.#i -= 1;
  }
  redo() {
    if (this.#i < this.#t.length - 1) {
      this.#i += 1, this.#e = !0;
      const {
        cmd: t,
        post: e
      } = this.#t[this.#i];
      t(), e?.(), this.#e = !1;
    }
  }
  hasSomethingToUndo() {
    return this.#i !== -1;
  }
  hasSomethingToRedo() {
    return this.#i < this.#t.length - 1;
  }
  cleanType(t) {
    if (this.#i !== -1) {
      for (let e = this.#i; e >= 0; e--)
        if (this.#t[e].type !== t) {
          this.#t.splice(e + 1, this.#i - e), this.#i = e;
          return;
        }
      this.#t.length = 0, this.#i = -1;
    }
  }
  destroy() {
    this.#t = null;
  }
}
class yt {
  static ALT = 1;
  static CTRL = 2;
  static META = 4;
  static SHIFT = 8;
  constructor(t) {
    this.callbacks = /* @__PURE__ */ new Map();
    const {
      isMac: e
    } = W.platform;
    for (const [s, i, n = {}] of t) {
      const r = s.some((a) => a.startsWith("mac+"));
      for (const a of s) {
        let o = a;
        if (r) {
          const c = a.startsWith("mac+");
          if (e !== c)
            continue;
          c && (o = a.slice(4));
        }
        const [l, h] = yt.#t(o);
        l !== null && this.callbacks.getOrInsertComputed(l, we).push({
          callback: i,
          options: n,
          modifiers: h
        });
      }
    }
  }
  static #t(t) {
    let e = null, s = 0;
    for (let i of t.split("+")) {
      if (i = i.trim(), !i)
        continue;
      const n = i.toUpperCase(), r = yt[n];
      if (r) {
        s |= r;
        continue;
      }
      if (e !== null) {
        R(`KeyboardManager: multiple keys in shortcut "${t}"`);
        break;
      }
      e = n === "SPACE" ? " " : i;
    }
    return e === null && R(`KeyboardManager: no key found in shortcut "${t}"`), [e, s];
  }
  static #e(t) {
    const e = /^(?:Key([A-Z])|(?:Digit|Numpad)(\d))$/.exec(t);
    return e ? e[1]?.toLowerCase() ?? e[2] : null;
  }
  exec(t, e) {
    let s = this.callbacks.get(e.key);
    if (!s) {
      if (/^[a-z]$/i.test(e.key))
        return;
      const h = yt.#e(e.code);
      if (h === null || h === e.key || (s = this.callbacks.get(h), !s))
        return;
    }
    const i = (e.altKey ? yt.ALT : 0) | (e.ctrlKey ? yt.CTRL : 0) | (e.metaKey ? yt.META : 0) | (e.shiftKey ? yt.SHIFT : 0), n = s.find((h) => h.modifiers === i);
    if (!n)
      return;
    const {
      callback: r,
      options: {
        bubbles: a = !1,
        args: o = [],
        checker: l = null
      }
    } = n;
    l && !l(t, e) || (r.bind(t, ...o, e)(), a || nt(e));
  }
}
class Zs {
  static _colorsMapping = /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]);
  get _colors() {
    const t = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
    return Kn(t), k(this, "_colors", t);
  }
  convert(t) {
    const e = Re(t);
    if (!window.matchMedia("(forced-colors: active)").matches)
      return e;
    for (const [s, i] of this._colors)
      if (i.every((n, r) => n === e[r]))
        return Zs._colorsMapping.get(s);
    return e;
  }
  getHexCode(t) {
    const e = this._colors.get(t);
    return e ? x.makeHexColor(...e) : t;
  }
}
class Kt {
  #t = new AbortController();
  #e = null;
  #s = null;
  #i = /* @__PURE__ */ new Map();
  #n = /* @__PURE__ */ new Map();
  #r = null;
  #a = null;
  #o = null;
  #l = null;
  #h = null;
  #u = new er();
  #c = null;
  #f = null;
  #p = null;
  #m = 0;
  #d = /* @__PURE__ */ new Set();
  #g = null;
  #b = null;
  #y = /* @__PURE__ */ new Set();
  _editorUndoBar = null;
  #A = !1;
  #w = !1;
  #S = !1;
  #_ = null;
  #v = null;
  #C = null;
  #I = null;
  #k = !1;
  #T = null;
  #O = new tr();
  #P = !1;
  #D = !1;
  #R = !1;
  #F = null;
  #B = null;
  #W = null;
  #H = null;
  #j = null;
  #x = B.NONE;
  #E = /* @__PURE__ */ new Set();
  #U = null;
  #z = null;
  #V = null;
  #q = null;
  #Y = null;
  #K = {
    isEditing: !1,
    isEmpty: !0,
    hasSomethingToUndo: !1,
    hasSomethingToRedo: !1,
    hasSelectedEditor: !1,
    hasSelectedText: !1
  };
  #L = [0, 0];
  #N = null;
  #X = null;
  #tt = null;
  #et = null;
  #G = null;
  static TRANSLATE_SMALL = 1;
  static TRANSLATE_BIG = 10;
  static get _keyboardManager() {
    const t = Kt.prototype, e = (r) => r.#X.contains(document.activeElement) && document.activeElement.tagName !== "BUTTON" && r.hasSomethingToControl(), s = (r, {
      target: a
    }) => {
      if (a instanceof HTMLInputElement) {
        const {
          type: o
        } = a;
        return o !== "text" && o !== "number";
      }
      return !0;
    }, i = this.TRANSLATE_SMALL, n = this.TRANSLATE_BIG;
    return k(this, "_keyboardManager", new yt([[["ctrl+a", "mac+meta+a"], t.selectAll, {
      checker: s
    }], [["ctrl+z", "mac+meta+z"], t.undo, {
      checker: s
    }], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], t.redo, {
      checker: s
    }], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], t.delete, {
      checker: s
    }], [["Enter"], t.addNewEditorFromKeyboard, {
      checker: (r, {
        target: a
      }) => !(a instanceof HTMLButtonElement) && r.#X.contains(a) && !r.isEnterHandled
    }], [["Space"], t.addNewEditorFromKeyboard, {
      checker: (r, {
        target: a
      }) => !(a instanceof HTMLButtonElement) && r.#X.contains(document.activeElement)
    }], [["Escape"], t.unselectAll], [["ArrowLeft"], t.translateSelectedEditors, {
      args: [-i, 0],
      checker: e
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t.translateSelectedEditors, {
      args: [-n, 0],
      checker: e
    }], [["ArrowRight"], t.translateSelectedEditors, {
      args: [i, 0],
      checker: e
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t.translateSelectedEditors, {
      args: [n, 0],
      checker: e
    }], [["ArrowUp"], t.translateSelectedEditors, {
      args: [0, -i],
      checker: e
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t.translateSelectedEditors, {
      args: [0, -n],
      checker: e
    }], [["ArrowDown"], t.translateSelectedEditors, {
      args: [0, i],
      checker: e
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t.translateSelectedEditors, {
      args: [0, n],
      checker: e
    }]]));
  }
  constructor(t, e, s, i, n, r, a, o, l, h, c, u, f, p, g, m, b) {
    const y = this._signal = this.#t.signal;
    this.#X = t, this.#tt = e, this.#et = s, this.#o = i, this.#c = n, this.#z = r, this.#Y = o, this._eventBus = a;
    const A = {
      signal: y,
      ...Es
    };
    a.on("editingaction", this.onEditingAction.bind(this), A), a.on("pagechanging", this.onPageChanging.bind(this), A), a.on("scalechanging", this.onScaleChanging.bind(this), A), a.on("rotationchanging", this.onRotationChanging.bind(this), A), a.on("setpreference", this.onSetPreference.bind(this), A), a.on("switchannotationeditorparams", (w) => this.updateParams(w.type, w.value), A), window.addEventListener("pointerdown", () => {
      this.#D = !0;
    }, {
      capture: !0,
      signal: y
    }), window.addEventListener("pointerup", () => {
      this.#D = !1;
    }, {
      capture: !0,
      signal: y
    }), window.addEventListener("beforeunload", this.endCurrentEditing.bind(this), {
      capture: !0,
      signal: y
    }), this.#lt(), this.#pt(), this.#it(), this.#l = o.annotationStorage, this.#_ = o.filterFactory, this.#V = l, this.#I = h || null, this.#A = c, this.#w = u, this.#S = f, this.#j = p || null, this.viewParameters = {
      realScale: Ae.PDF_TO_CSS_UNITS,
      rotation: 0
    }, this.isShiftKeyDown = !1, this._editorUndoBar = g || null, this._supportsPinchToZoom = m !== !1, this._keepToolbarInPage = b === !0, n?.setSidebarUiManager(this);
  }
  destroy() {
    this.#G?.resolve(), this.#G = null, this.#t?.abort(), this.#t = null, this._signal = null;
    for (const t of this.#n.values())
      t.destroy();
    this.#n.clear(), this.#i.clear(), this.#y.clear(), this.#H?.clear(), this.#e = null, this.#E.clear(), this.#u.destroy(), this.#o?.destroy(), this.#c?.destroy(), this.#z?.destroy(), this.#T?.hide(), this.#T = null, this.#W?.destroy(), this.#W = null, this.#s = null, this.#v && (clearTimeout(this.#v), this.#v = null), this.#N && (clearTimeout(this.#N), this.#N = null), this._editorUndoBar?.destroy(), this.#Y = null;
  }
  combinedSignal(t) {
    return AbortSignal.any([this._signal, t.signal]);
  }
  get mlManager() {
    return this.#j;
  }
  get useNewAltTextFlow() {
    return this.#w;
  }
  get useNewAltTextWhenAddingImage() {
    return this.#S;
  }
  get hcmFilter() {
    return k(this, "hcmFilter", this.#V ? this.#_.addHCMFilter(this.#V.foreground, this.#V.background) : "none");
  }
  get direction() {
    return k(this, "direction", getComputedStyle(this.#X).direction);
  }
  get _highlightColors() {
    return k(this, "_highlightColors", this.#I ? new Map(this.#I.split(",").map((t) => (t = t.split("=").map((e) => e.trim()), t[1] = t[1].toUpperCase(), t))) : null);
  }
  get highlightColors() {
    const {
      _highlightColors: t
    } = this;
    if (!t)
      return k(this, "highlightColors", null);
    const e = /* @__PURE__ */ new Map(), s = !!this.#V;
    for (const [i, n] of t) {
      const r = i.endsWith("_HCM");
      if (s && r) {
        e.set(i.replace("_HCM", ""), n);
        continue;
      }
      !s && !r && e.set(i, n);
    }
    return k(this, "highlightColors", e);
  }
  get highlightColorNames() {
    return k(this, "highlightColorNames", this.highlightColors ? new Map(Array.from(this.highlightColors, (t) => t.reverse())) : null);
  }
  getNonHCMColor(t) {
    if (!this._highlightColors)
      return t;
    const e = this.highlightColorNames.get(t);
    return this._highlightColors.get(e) || t;
  }
  getNonHCMColorName(t) {
    return this.highlightColorNames.get(t) || t;
  }
  setCurrentDrawingSession(t) {
    t ? (this.unselectAll(), this.disableUserSelect(!0)) : this.disableUserSelect(!1), this.#p = t;
  }
  setMainHighlightColorPicker(t) {
    this.#W = t;
  }
  editAltText(t, e = !1) {
    this.#o?.editAltText(this, t, e);
  }
  hasCommentManager() {
    return !!this.#c;
  }
  editComment(t, e, s, i) {
    this.#c?.showDialog(this, t, e, s, i);
  }
  selectComment(t, e) {
    this.#n.get(t)?.getEditorByUID(e)?.toggleComment(!0, !0);
  }
  updateComment(t) {
    this.#c?.updateComment(t.getData());
  }
  updatePopupColor(t) {
    this.#c?.updatePopupColor(t);
  }
  removeComment(t) {
    this.#c?.removeComments([t.uid]);
  }
  deleteComment(t, e) {
    const s = () => {
      t.comment = e;
    }, i = () => {
      this._editorUndoBar?.show(s, "comment"), this.toggleComment(null), t.comment = null;
    };
    this.addCommands({
      cmd: i,
      undo: s,
      mustExec: !0
    });
  }
  toggleComment(t, e, s = void 0) {
    this.#c?.toggleCommentPopup(t, e, s);
  }
  makeCommentColor(t, e) {
    return t && this.#c?.makeCommentColor(t, e) || null;
  }
  getCommentDialogElement() {
    return this.#c?.dialogElement || null;
  }
  async waitForEditorsRendered(t) {
    if (this.#n.has(t - 1))
      return;
    const {
      resolve: e,
      promise: s
    } = Promise.withResolvers(), i = (n) => {
      n.pageNumber === t && (this._eventBus.off("editorsrendered", i), e());
    };
    this._eventBus.on("editorsrendered", i, Es), await s;
  }
  getSignature(t) {
    this.#z?.getSignature({
      uiManager: this,
      editor: t
    });
  }
  get signatureManager() {
    return this.#z;
  }
  switchToMode(t, e) {
    this._eventBus.on("annotationeditormodechanged", e, {
      once: !0,
      signal: this._signal,
      ...Es
    }), this._eventBus.dispatch("showannotationeditorui", {
      source: this,
      mode: t
    });
  }
  setPreference(t, e) {
    this._eventBus.dispatch("setpreference", {
      source: this,
      name: t,
      value: e
    });
  }
  onSetPreference({
    name: t,
    value: e
  }) {
    t === "enableNewAltTextWhenAddingImage" && (this.#S = e);
  }
  onPageChanging({
    pageNumber: t
  }) {
    this.#m = t - 1;
  }
  deletePage(t) {
    for (const e of this.getEditors(t))
      e.remove();
    this.#n.delete(t), this.#m === t && (this.#m = 0);
  }
  focusMainContainer() {
    this.#X.focus();
  }
  findParent(t, e) {
    for (const s of this.#n.values()) {
      const {
        x: i,
        y: n,
        width: r,
        height: a
      } = s.div.getBoundingClientRect();
      if (t >= i && t <= i + r && e >= n && e <= n + a)
        return s;
    }
    return null;
  }
  disableUserSelect(t = !1) {
    this.#tt.classList.toggle("noUserSelect", t);
  }
  addShouldRescale(t) {
    this.#y.add(t);
  }
  removeShouldRescale(t) {
    this.#y.delete(t);
  }
  onScaleChanging({
    scale: t
  }) {
    this.commitOrRemove(), this.viewParameters.realScale = t * Ae.PDF_TO_CSS_UNITS;
    for (const e of this.#y)
      e.onScaleChanging();
    this.#p?.onScaleChanging();
  }
  onRotationChanging({
    pagesRotation: t
  }) {
    this.commitOrRemove(), this.viewParameters.rotation = t;
  }
  #Z({
    anchorNode: t
  }) {
    return t.nodeType === Node.TEXT_NODE ? t.parentElement : t;
  }
  #st(t) {
    const {
      currentLayer: e
    } = this;
    if (e.hasTextLayer(t))
      return e;
    for (const s of this.#n.values())
      if (s.hasTextLayer(t))
        return s;
    return null;
  }
  highlightSelection(t = "", e = !1) {
    const s = document.getSelection();
    if (!s || s.isCollapsed)
      return;
    const {
      anchorNode: i,
      anchorOffset: n,
      focusNode: r,
      focusOffset: a
    } = s, o = s.toString(), h = this.#Z(s).closest(".textLayer"), c = this.getSelectionBoxes(h);
    if (!c)
      return;
    s.empty();
    const u = this.#st(h), f = this.#x === B.NONE, p = () => {
      const g = u?.createAndAddNewEditor({
        x: 0,
        y: 0
      }, !1, {
        methodOfCreation: t,
        boxes: c,
        anchorNode: i,
        anchorOffset: n,
        focusNode: r,
        focusOffset: a,
        text: o
      });
      f && this.showAllEditors("highlight", !0, !0), e && g?.editComment();
    };
    if (f) {
      this.switchToMode(B.HIGHLIGHT, p);
      return;
    }
    p();
  }
  commentSelection(t = "") {
    this.highlightSelection(t, !0);
  }
  endCurrentEditing() {
    this.commitOrRemove(), this.currentLayer?.endDrawingSession(!1);
  }
  #at() {
    const t = document.getSelection();
    if (!t || t.isCollapsed)
      return;
    const s = this.#Z(t).closest(".textLayer"), i = this.getSelectionBoxes(s);
    i && (this.#T ||= new Jn(this), this.#T.show(s, i, this.direction === "ltr"));
  }
  getAndRemoveDataFromAnnotationStorage(t) {
    if (!this.#l)
      return null;
    const e = `${ye}${t}`, s = this.#l.getRawValue(e);
    return s && this.#l.remove(e), s;
  }
  addToAnnotationStorage(t) {
    !t.isEmpty() && this.#l && !this.#l.has(t.id) && this.#l.setValue(t.id, t);
  }
  a11yAlert(t, e = null) {
    const s = this.#et;
    s && (s.setAttribute("data-l10n-id", t), e ? s.setAttribute("data-l10n-args", JSON.stringify(e)) : s.removeAttribute("data-l10n-args"));
  }
  #ot() {
    const t = document.getSelection();
    if (!t || t.isCollapsed) {
      this.#U && (this.#T?.hide(), this.#U = null, this.#M({
        hasSelectedText: !1
      }));
      return;
    }
    const {
      anchorNode: e
    } = t;
    if (e === this.#U)
      return;
    const i = this.#Z(t).closest(".textLayer");
    if (!i) {
      this.#U && (this.#T?.hide(), this.#U = null, this.#M({
        hasSelectedText: !1
      }));
      return;
    }
    if (this.#T?.hide(), this.#U = e, this.#M({
      hasSelectedText: !0
    }), !(this.#x !== B.HIGHLIGHT && this.#x !== B.NONE) && (this.#x === B.HIGHLIGHT && this.showAllEditors("highlight", !0, !0), this.#k = this.isShiftKeyDown, !this.isShiftKeyDown)) {
      const n = this.#x === B.HIGHLIGHT ? this.#st(i) : null;
      if (n?.toggleDrawing(), this.#D) {
        const r = new AbortController(), a = this.combinedSignal(r), o = (l) => {
          l.type === "pointerup" && l.button !== 0 || (r.abort(), n?.toggleDrawing(!0), l.type === "pointerup" && this.#Q("main_toolbar"));
        };
        window.addEventListener("pointerup", o, {
          signal: a
        }), window.addEventListener("blur", o, {
          signal: a
        });
      } else
        n?.toggleDrawing(!0), this.#Q("main_toolbar");
    }
  }
  #Q(t = "") {
    this.#x === B.HIGHLIGHT ? this.highlightSelection(t) : this.#A && this.#at();
  }
  #lt() {
    document.addEventListener("selectionchange", this.#ot.bind(this), {
      signal: this._signal
    });
  }
  #ht() {
    if (this.#C)
      return;
    this.#C = new AbortController();
    const t = this.combinedSignal(this.#C);
    window.addEventListener("focus", this.focus.bind(this), {
      signal: t
    }), window.addEventListener("blur", this.blur.bind(this), {
      signal: t
    });
  }
  #ct() {
    this.#C?.abort(), this.#C = null;
  }
  blur() {
    if (this.isShiftKeyDown = !1, this.#k && (this.#k = !1, this.#Q("main_toolbar")), !this.hasSelection)
      return;
    const {
      activeElement: t
    } = document;
    for (const e of this.#E)
      if (e.div.contains(t)) {
        this.#B = [e, t], e._focusEventsAllowed = !1;
        break;
      }
  }
  focus() {
    if (!this.#B)
      return;
    const [t, e] = this.#B;
    this.#B = null, e.addEventListener("focusin", () => {
      t._focusEventsAllowed = !0;
    }, {
      once: !0,
      signal: this._signal
    }), e.focus();
  }
  #it() {
    if (this.#F)
      return;
    this.#F = new AbortController();
    const t = this.combinedSignal(this.#F);
    window.addEventListener("keydown", this.keydown.bind(this), {
      signal: t
    }), window.addEventListener("keyup", this.keyup.bind(this), {
      signal: t
    });
  }
  #dt() {
    this.#F?.abort(), this.#F = null;
  }
  #ut() {
    if (this.#f)
      return;
    this.#f = new AbortController();
    const t = this.combinedSignal(this.#f);
    document.addEventListener("copy", this.copy.bind(this), {
      signal: t
    }), document.addEventListener("cut", this.cut.bind(this), {
      signal: t
    }), document.addEventListener("paste", this.paste.bind(this), {
      signal: t
    });
  }
  #ft() {
    this.#f?.abort(), this.#f = null;
  }
  #pt() {
    const t = this._signal;
    document.addEventListener("dragover", this.dragOver.bind(this), {
      signal: t
    }), document.addEventListener("drop", this.drop.bind(this), {
      signal: t
    });
  }
  addEditListeners() {
    this.#it(), this.setEditingState(!0);
  }
  removeEditListeners() {
    this.#dt(), this.setEditingState(!1);
  }
  dragOver(t) {
    for (const {
      type: e
    } of t.dataTransfer.items)
      for (const s of this.#b)
        if (s.isHandlingMimeForPasting(e)) {
          t.dataTransfer.dropEffect = "copy", t.preventDefault();
          return;
        }
  }
  drop(t) {
    for (const e of t.dataTransfer.items)
      for (const s of this.#b)
        if (s.isHandlingMimeForPasting(e.type)) {
          s.paste(e, this.currentLayer), t.preventDefault();
          return;
        }
  }
  copy(t) {
    if (t.preventDefault(), this.#e?.commitOrRemove(), !this.hasSelection)
      return;
    const e = [];
    for (const s of this.#E) {
      const i = s.serialize(!0);
      i && e.push(i);
    }
    e.length !== 0 && t.clipboardData.setData("application/pdfjs", JSON.stringify(e));
  }
  cut(t) {
    this.copy(t), this.delete();
  }
  async paste(t) {
    t.preventDefault();
    const {
      clipboardData: e
    } = t;
    for (const n of e.items)
      for (const r of this.#b)
        if (r.isHandlingMimeForPasting(n.type)) {
          r.paste(n, this.currentLayer);
          return;
        }
    let s = e.getData("application/pdfjs");
    if (!s)
      return;
    try {
      s = JSON.parse(s);
    } catch (n) {
      R(`paste: "${n.message}".`);
      return;
    }
    if (!Array.isArray(s))
      return;
    this.unselectAll();
    const i = this.currentLayer;
    try {
      const n = [];
      for (const o of s) {
        const l = await i.deserialize(o);
        if (!l)
          return;
        n.push(l);
      }
      const r = () => {
        for (const o of n)
          this.#nt(o);
        this.#rt(n);
      }, a = () => {
        for (const o of n)
          o.remove();
      };
      this.addCommands({
        cmd: r,
        undo: a,
        mustExec: !0
      });
    } catch (n) {
      R(`paste: "${n.message}".`);
    }
  }
  keydown(t) {
    !this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !0), this.#x !== B.NONE && !this.isEditorHandlingKeyboard && Kt._keyboardManager.exec(this, t);
  }
  keyup(t) {
    this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !1, this.#k && (this.#k = !1, this.#Q("main_toolbar")));
  }
  onEditingAction({
    name: t
  }) {
    switch (t) {
      case "undo":
      case "redo":
      case "delete":
      case "selectAll":
        this[t]();
        break;
      case "highlightSelection":
        this.highlightSelection("context_menu");
        break;
      case "commentSelection":
        this.commentSelection("context_menu");
        break;
    }
  }
  updatePageIndex(t, e) {
    for (const i of this.#a.get(t) || [])
      i.pageIndex = e;
    const s = this.#r.get(t);
    s && (s.pageIndex = e, this.#n.set(e, s), this.#P ? s.enable() : s.disable());
  }
  startUpdatePages() {
    this.#r = new Map(this.#n), this.#n.clear();
    const t = this.#a = /* @__PURE__ */ new Map(), e = (s) => {
      t.getOrInsertComputed(s.pageIndex, we).push(s);
    };
    for (const s of this.#i.values())
      e(s);
    for (const [s, i] of this.#l)
      s.startsWith(ye) && !this.#i.has(s) && Number.isInteger(i?.pageIndex) && e(i);
  }
  endUpdatePages() {
    this.#r = null, this.#a = null;
  }
  clonePage(t, e) {
    for (const s of this.getEditors(t)) {
      const i = s.serialize(s.mode !== B.HIGHLIGHT);
      i && (i.pageIndex = e, i.id = this.getId(), i.isClone = !0, delete i.popupRef, this.#l.setValue(i.id, i));
    }
  }
  findClonesForPage(t) {
    const e = [], {
      pageIndex: s
    } = t;
    for (const [i, n] of this.#l)
      n.pageIndex === s && n.isClone && (this.#l.remove(i), e.push(t.deserialize(n).then((r) => {
        r && (r.isClone = !0, t.addOrRebuild(r));
      })));
    return Promise.all(e);
  }
  #M(t) {
    Object.entries(t).some(([s, i]) => this.#K[s] !== i) && (this._eventBus.dispatch("editingstateschanged", {
      source: this,
      details: Object.assign(this.#K, t)
    }), this.#x === B.HIGHLIGHT && t.hasSelectedEditor === !1 && this.#$([[U.HIGHLIGHT_FREE, !0]]));
  }
  #$(t) {
    this._eventBus.dispatch("annotationeditorparamschanged", {
      source: this,
      details: t
    });
  }
  setEditingState(t) {
    t ? (this.#ht(), this.#ut(), this.#M({
      isEditing: this.#x !== B.NONE,
      isEmpty: this.#J(),
      hasSomethingToUndo: this.#u.hasSomethingToUndo(),
      hasSomethingToRedo: this.#u.hasSomethingToRedo(),
      hasSelectedEditor: !1
    })) : (this.#ct(), this.#ft(), this.#M({
      isEditing: !1
    }), this.disableUserSelect(!1));
  }
  registerEditorTypes(t) {
    if (!this.#b) {
      this.#b = t;
      for (const e of this.#b)
        this.#$(e.defaultPropertiesToUpdate);
    }
  }
  getId() {
    return this.#O.id;
  }
  get currentLayer() {
    return this.#n.get(this.#m);
  }
  getLayer(t) {
    return this.#n.get(t);
  }
  get currentPageIndex() {
    return this.#m;
  }
  addLayer(t) {
    this.#n.set(t.pageIndex, t), this.#P ? t.enable() : t.disable();
  }
  removeLayer(t) {
    this.#n.delete(t.pageIndex);
  }
  async updateMode(t, e = null, s = !1, i = !1, n = !1, r = !1) {
    if (this.#x !== t && !(this.#G && (await this.#G.promise, !this.#G))) {
      if (this.#G = Promise.withResolvers(), this.#p?.commitOrRemove(), this.#x === B.POPUP && this.#c?.hideSidebar(), this.#c?.destroyPopup(), this.#x = t, t === B.NONE) {
        this.setEditingState(!1), this.#mt();
        for (const a of this.#i.values())
          a.hideStandaloneCommentButton();
        this._editorUndoBar?.hide(), this.toggleComment(null), this.#G.resolve();
        return;
      }
      for (const a of this.#i.values())
        a.addStandaloneCommentButton();
      t === B.SIGNATURE && await this.#z?.loadSignatures(), s && $.clearPointerType(), this.setEditingState(!0), await this.#gt(), this.unselectAll();
      for (const a of this.#n.values())
        a.updateMode(t);
      if (t === B.POPUP) {
        this.#s ||= await this.#Y.getAnnotationsByType(new Set(this.#b.map((l) => l._editorType)));
        const a = /* @__PURE__ */ new Set(), o = [];
        for (const l of this.#i.values()) {
          const {
            annotationElementId: h,
            hasComment: c,
            deleted: u
          } = l;
          h && a.add(h), c && !u && o.push(l.getData());
        }
        for (const l of this.#s) {
          const {
            id: h,
            popupRef: c,
            contentsObj: u
          } = l;
          c && u?.str && !a.has(h) && !this.#d.has(h) && o.push(l);
        }
        this.#c?.showSidebar(o);
      }
      if (!e) {
        i && this.addNewEditorFromKeyboard(), this.#G.resolve();
        return;
      }
      for (const a of this.#i.values())
        a.uid === e ? (this.setSelected(a), r ? a.editComment() : n ? a.enterInEditMode() : a.focus()) : a.unselect();
      this.#G.resolve();
    }
  }
  addNewEditorFromKeyboard() {
    this.currentLayer.canCreateNewEmptyEditor() && this.currentLayer.addNewEditor();
  }
  updateToolbar(t) {
    t.mode !== this.#x && this._eventBus.dispatch("switchannotationeditormode", {
      source: this,
      ...t
    });
  }
  updateParams(t, e) {
    if (this.#b) {
      switch (t) {
        case U.CREATE:
          this.currentLayer.addNewEditor(e);
          return;
        case U.HIGHLIGHT_SHOW_ALL:
          this._eventBus.dispatch("reporttelemetry", {
            source: this,
            details: {
              type: "editing",
              data: {
                type: "highlight",
                action: "toggle_visibility"
              }
            }
          }), (this.#q ||= /* @__PURE__ */ new Map()).set(t, e), this.showAllEditors("highlight", e);
          break;
      }
      if (this.hasSelection)
        for (const s of this.#E)
          s.updateParams(t, e);
      else
        for (const s of this.#b)
          s.updateDefaultParams(t, e);
    }
  }
  showAllEditors(t, e, s = !1) {
    for (const n of this.#i.values())
      n.editorType === t && n.show(e);
    (this.#q?.get(U.HIGHLIGHT_SHOW_ALL) ?? !0) !== e && this.#$([[U.HIGHLIGHT_SHOW_ALL, e]]);
  }
  enableWaiting(t = !1) {
    if (this.#R !== t) {
      this.#R = t;
      for (const e of this.#n.values())
        t ? e.disableClick() : e.enableClick(), e.div.classList.toggle("waiting", t);
    }
  }
  async #gt() {
    if (!this.#P) {
      this.#P = !0;
      const t = [];
      for (const e of this.#n.values())
        t.push(e.enable());
      await Promise.all(t);
      for (const e of this.#i.values())
        e.enable();
    }
  }
  #mt() {
    if (this.unselectAll(), this.#P) {
      this.#P = !1;
      for (const t of this.#n.values())
        t.disable();
      for (const t of this.#i.values())
        t.disable();
    }
  }
  *getEditors(t) {
    for (const e of this.#i.values())
      e.pageIndex === t && (yield e);
  }
  getEditor(t) {
    return this.#i.get(t);
  }
  addEditor(t) {
    this.#i.set(t.id, t);
  }
  removeEditor(t) {
    t.div.contains(document.activeElement) && (this.#v && clearTimeout(this.#v), this.#v = setTimeout(() => {
      this.focusMainContainer(), this.#v = null;
    }, 0)), this.#i.delete(t.id), t.annotationElementId && this.#H?.delete(t.annotationElementId), this.unselect(t), (!t.annotationElementId || !this.#d.has(t.annotationElementId)) && this.#l?.remove(t.id);
  }
  addDeletedAnnotationElement(t) {
    this.#d.add(t.annotationElementId), this.addChangedExistingAnnotation(t), t.deleted = !0;
  }
  isDeletedAnnotationElement(t) {
    return this.#d.has(t);
  }
  removeDeletedAnnotationElement(t) {
    this.#d.delete(t.annotationElementId), this.removeChangedExistingAnnotation(t), t.deleted = !1;
  }
  #nt(t) {
    const e = this.#n.get(t.pageIndex);
    e ? e.addOrRebuild(t) : (this.addEditor(t), this.addToAnnotationStorage(t));
  }
  setActiveEditor(t) {
    this.#e !== t && (this.#e = t, t && this.#$(t.propertiesToUpdate));
  }
  get #bt() {
    let t = null;
    for (t of this.#E)
      ;
    return t;
  }
  updateUI(t) {
    this.#bt === t && this.#$(t.propertiesToUpdate);
  }
  updateUIForDefaultProperties(t) {
    this.#$(t.defaultPropertiesToUpdate);
  }
  toggleSelected(t) {
    if (this.#E.has(t)) {
      this.#E.delete(t), t.unselect(), this.#M({
        hasSelectedEditor: this.hasSelection
      });
      return;
    }
    this.#E.add(t), t.select(), this.#$(t.propertiesToUpdate), this.#M({
      hasSelectedEditor: !0
    });
  }
  setSelected(t) {
    this.updateToolbar({
      mode: t.mode,
      editId: t.uid
    }), this.#p?.commitOrRemove();
    for (const e of this.#E)
      e !== t && e.unselect();
    this.#c?.destroyPopup(), this.#E.clear(), this.#E.add(t), t.select(), this.#$(t.propertiesToUpdate), this.#M({
      hasSelectedEditor: !0
    });
  }
  get firstSelectedEditor() {
    return this.#E.values().next().value;
  }
  unselect(t) {
    t.unselect(), this.#E.delete(t), this.#M({
      hasSelectedEditor: this.hasSelection
    });
  }
  get hasSelection() {
    return this.#E.size !== 0;
  }
  get isEnterHandled() {
    return this.#E.size === 1 && this.firstSelectedEditor.isEnterHandled;
  }
  undo() {
    this.#u.undo(), this.#M({
      hasSomethingToUndo: this.#u.hasSomethingToUndo(),
      hasSomethingToRedo: this.#u.hasSomethingToRedo(),
      isEmpty: this.#J()
    }), this._editorUndoBar?.hide();
  }
  redo() {
    this.#u.redo(), this.#M({
      hasSomethingToUndo: this.#u.hasSomethingToUndo(),
      hasSomethingToRedo: this.#u.hasSomethingToRedo(),
      isEmpty: this.#J()
    });
  }
  addCommands(t) {
    this.#u.add(t), this.#M({
      hasSomethingToUndo: !0,
      hasSomethingToRedo: !1,
      isEmpty: this.#J()
    });
  }
  cleanUndoStack(t) {
    this.#u.cleanType(t);
  }
  #J() {
    if (this.#i.size === 0)
      return !0;
    if (this.#i.size === 1)
      for (const t of this.#i.values())
        return t.isEmpty();
    return !1;
  }
  delete() {
    this.commitOrRemove();
    const t = this.currentLayer?.endDrawingSession(!0);
    if (!this.hasSelection && !t)
      return;
    const e = t ? [t] : [...this.#E], s = () => {
      this._editorUndoBar?.show(i, e.length === 1 ? e[0].editorType : e.length);
      for (const n of e)
        n.remove();
    }, i = () => {
      for (const n of e)
        this.#nt(n);
    };
    this.addCommands({
      cmd: s,
      undo: i,
      mustExec: !0
    });
  }
  commitOrRemove() {
    this.#e?.commitOrRemove();
  }
  hasSomethingToControl() {
    return this.#e || this.hasSelection;
  }
  #rt(t) {
    for (const e of this.#E)
      e.unselect();
    this.#E.clear();
    for (const e of t)
      e.isEmpty() || (this.#E.add(e), e.select());
    this.#M({
      hasSelectedEditor: this.hasSelection
    });
  }
  selectAll() {
    for (const t of this.#E)
      t.commit();
    this.#rt(this.#i.values());
  }
  unselectAll() {
    if (!(this.#e && (this.#e.commitOrRemove(), this.#x !== B.NONE)) && !this.#p?.commitOrRemove() && (this.#c?.destroyPopup(), !!this.hasSelection)) {
      for (const t of this.#E)
        t.unselect();
      this.#E.clear(), this.#M({
        hasSelectedEditor: !1
      });
    }
  }
  translateSelectedEditors(t, e, s = !1) {
    if (s || this.commitOrRemove(), !this.hasSelection)
      return;
    this.#L[0] += t, this.#L[1] += e;
    const [i, n] = this.#L, r = [...this.#E], a = 1e3;
    this.#N && clearTimeout(this.#N), this.#N = setTimeout(() => {
      this.#N = null, this.#L[0] = this.#L[1] = 0, this.addCommands({
        cmd: () => {
          for (const o of r)
            this.#i.has(o.id) && (o.translateInPage(i, n), o.translationDone());
        },
        undo: () => {
          for (const o of r)
            this.#i.has(o.id) && (o.translateInPage(-i, -n), o.translationDone());
        },
        mustExec: !1
      });
    }, a);
    for (const o of r)
      o.translateInPage(t, e), o.translationDone();
  }
  setUpDragSession() {
    if (this.hasSelection) {
      this.disableUserSelect(!0), this.#g = /* @__PURE__ */ new Map();
      for (const t of this.#E)
        this.#g.set(t, {
          savedX: t.x,
          savedY: t.y,
          savedPageIndex: t.pageIndex,
          newX: 0,
          newY: 0,
          newPageIndex: -1
        });
    }
  }
  endDragSession() {
    if (!this.#g)
      return !1;
    this.disableUserSelect(!1);
    const t = this.#g;
    this.#g = null;
    let e = !1;
    for (const [{
      x: i,
      y: n,
      pageIndex: r
    }, a] of t)
      a.newX = i, a.newY = n, a.newPageIndex = r, e ||= i !== a.savedX || n !== a.savedY || r !== a.savedPageIndex;
    if (!e)
      return !1;
    const s = (i, n, r, a) => {
      if (this.#i.has(i.id)) {
        const o = this.#n.get(a);
        o ? i._setParentAndPosition(o, n, r) : (i.pageIndex = a, i.x = n, i.y = r);
      }
    };
    return this.addCommands({
      cmd: () => {
        for (const [i, {
          newX: n,
          newY: r,
          newPageIndex: a
        }] of t)
          s(i, n, r, a);
      },
      undo: () => {
        for (const [i, {
          savedX: n,
          savedY: r,
          savedPageIndex: a
        }] of t)
          s(i, n, r, a);
      },
      mustExec: !0
    }), !0;
  }
  dragSelectedEditors(t, e) {
    if (this.#g)
      for (const s of this.#g.keys())
        s.drag(t, e);
  }
  rebuild(t) {
    if (t.parent === null) {
      const e = this.getLayer(t.pageIndex);
      e ? (e.changeParent(t), e.addOrRebuild(t)) : (this.addEditor(t), this.addToAnnotationStorage(t), t.rebuild());
    } else
      t.parent.addOrRebuild(t);
  }
  get isEditorHandlingKeyboard() {
    return this.getActive()?.shouldGetKeyboardEvents() || this.#E.size === 1 && this.firstSelectedEditor.shouldGetKeyboardEvents();
  }
  isActive(t) {
    return this.#e === t;
  }
  getActive() {
    return this.#e;
  }
  getMode() {
    return this.#x;
  }
  isEditingMode() {
    return this.#x !== B.NONE;
  }
  get imageManager() {
    return k(this, "imageManager", new Js());
  }
  getSelectionBoxes(t) {
    if (!t)
      return null;
    const e = document.getSelection();
    for (let l = 0, h = e.rangeCount; l < h; l++)
      if (!t.contains(e.getRangeAt(l).commonAncestorContainer))
        return null;
    const {
      x: s,
      y: i,
      width: n,
      height: r
    } = t.getBoundingClientRect();
    let a;
    switch (t.getAttribute("data-main-rotation")) {
      case "90":
        a = (l, h, c, u) => ({
          x: (h - i) / r,
          y: 1 - (l + c - s) / n,
          width: u / r,
          height: c / n
        });
        break;
      case "180":
        a = (l, h, c, u) => ({
          x: 1 - (l + c - s) / n,
          y: 1 - (h + u - i) / r,
          width: c / n,
          height: u / r
        });
        break;
      case "270":
        a = (l, h, c, u) => ({
          x: 1 - (h + u - i) / r,
          y: (l - s) / n,
          width: u / r,
          height: c / n
        });
        break;
      default:
        a = (l, h, c, u) => ({
          x: (l - s) / n,
          y: (h - i) / r,
          width: c / n,
          height: u / r
        });
        break;
    }
    const o = [];
    for (let l = 0, h = e.rangeCount; l < h; l++) {
      const c = e.getRangeAt(l);
      if (!c.collapsed)
        for (const {
          x: u,
          y: f,
          width: p,
          height: g
        } of c.getClientRects())
          p === 0 || g === 0 || o.push(a(u, f, p, g));
    }
    return o.length === 0 ? null : o;
  }
  addChangedExistingAnnotation({
    annotationElementId: t,
    id: e
  }) {
    (this.#h ||= /* @__PURE__ */ new Map()).set(t, e);
  }
  removeChangedExistingAnnotation({
    annotationElementId: t
  }) {
    this.#h?.delete(t);
  }
  renderAnnotationElement(t) {
    const e = this.#h?.get(t.data.id);
    if (!e)
      return;
    const s = this.#l.getRawValue(e);
    s && (this.#x === B.NONE && !s.hasBeenModified || s.renderAnnotationElement(t));
  }
  setMissingCanvas(t, e, s) {
    const i = this.#H?.get(t);
    i && (i.setCanvas(e, s), this.#H.delete(t));
  }
  addMissingCanvas(t, e) {
    (this.#H ||= /* @__PURE__ */ new Map()).set(t, e);
  }
}
class It {
  #t = null;
  #e = !1;
  #s = null;
  #i = null;
  #n = null;
  #r = null;
  #a = !1;
  #o = null;
  #l = null;
  #h = null;
  #u = null;
  #c = !1;
  static #f = null;
  static _l10n = null;
  constructor(t) {
    this.#l = t, this.#c = t._uiManager.useNewAltTextFlow, It.#f ||= Object.freeze({
      added: "pdfjs-editor-new-alt-text-added-button",
      "added-label": "pdfjs-editor-new-alt-text-added-button-label",
      missing: "pdfjs-editor-new-alt-text-missing-button",
      "missing-label": "pdfjs-editor-new-alt-text-missing-button-label",
      review: "pdfjs-editor-new-alt-text-to-review-button",
      "review-label": "pdfjs-editor-new-alt-text-to-review-button-label"
    });
  }
  static initialize(t) {
    It._l10n ??= t;
  }
  async render() {
    const t = this.#s = document.createElement("button");
    t.className = "altText", t.tabIndex = "0";
    const e = this.#i = document.createElement("span");
    t.append(e), this.#c ? (t.classList.add("new"), t.setAttribute("data-l10n-id", It.#f.missing), e.setAttribute("data-l10n-id", It.#f["missing-label"])) : (t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button"), e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button-label"));
    const s = this.#l._uiManager._signal;
    t.addEventListener("contextmenu", xt, {
      signal: s
    }), t.addEventListener("pointerdown", (n) => n.stopPropagation(), {
      signal: s
    });
    const i = (n) => {
      n.preventDefault(), this.#l._uiManager.editAltText(this.#l), this.#c && this.#l._reportTelemetry({
        action: "pdfjs.image.alt_text.image_status_label_clicked",
        data: {
          label: this.#p
        }
      });
    };
    return t.addEventListener("click", i, {
      capture: !0,
      signal: s
    }), t.addEventListener("keydown", (n) => {
      n.target === t && n.key === "Enter" && (this.#a = !0, i(n));
    }, {
      signal: s
    }), await this.#m(), t;
  }
  get #p() {
    return this.#t && "added" || this.#t === null && this.guessedText && "review" || "missing";
  }
  finish() {
    this.#s && (this.#s.focus({
      focusVisible: this.#a
    }), this.#a = !1);
  }
  isEmpty() {
    return this.#c ? this.#t === null : !this.#t && !this.#e;
  }
  hasData() {
    return this.#c ? this.#t !== null || !!this.#h : this.isEmpty();
  }
  get guessedText() {
    return this.#h;
  }
  async setGuessedText(t) {
    this.#t === null && (this.#h = t, this.#u = await It._l10n.get("pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer", {
      generatedAltText: t
    }), this.#m());
  }
  toggleAltTextBadge(t = !1) {
    if (!this.#c || this.#t) {
      this.#o?.remove(), this.#o = null;
      return;
    }
    if (!this.#o) {
      const e = this.#o = document.createElement("div");
      e.className = "noAltTextBadge", this.#l.div.append(e);
    }
    this.#o.classList.toggle("hidden", !t);
  }
  serialize(t) {
    let e = this.#t;
    return !t && this.#h === e && (e = this.#u), {
      altText: e,
      decorative: this.#e,
      guessedText: this.#h,
      textWithDisclaimer: this.#u
    };
  }
  get data() {
    return {
      altText: this.#t,
      decorative: this.#e
    };
  }
  set data({
    altText: t,
    decorative: e,
    guessedText: s,
    textWithDisclaimer: i,
    cancel: n = !1
  }) {
    s && (this.#h = s, this.#u = i), !(this.#t === t && this.#e === e) && (n || (this.#t = t, this.#e = e), this.#m());
  }
  toggle(t = !1) {
    this.#s && (!t && this.#r && (clearTimeout(this.#r), this.#r = null), this.#s.disabled = !t);
  }
  shown() {
    this.#l._reportTelemetry({
      action: "pdfjs.image.alt_text.image_status_label_displayed",
      data: {
        label: this.#p
      }
    });
  }
  destroy() {
    this.#s?.remove(), this.#s = null, this.#i = null, this.#n = null, this.#o?.remove(), this.#o = null;
  }
  async #m() {
    const t = this.#s;
    if (!t)
      return;
    if (this.#c) {
      if (t.classList.toggle("done", !!this.#t), t.setAttribute("data-l10n-id", It.#f[this.#p]), this.#i?.setAttribute("data-l10n-id", It.#f[`${this.#p}-label`]), !this.#t) {
        this.#n?.remove();
        return;
      }
    } else {
      if (!this.#t && !this.#e) {
        t.classList.remove("done"), this.#n?.remove();
        return;
      }
      t.classList.add("done"), t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-edit-button");
    }
    let e = this.#n;
    if (!e) {
      this.#n = e = document.createElement("span"), e.className = "tooltip", e.setAttribute("role", "tooltip"), e.id = `alt-text-tooltip-${this.#l.id}`;
      const i = 100, n = this.#l._uiManager._signal;
      n.addEventListener("abort", () => {
        clearTimeout(this.#r), this.#r = null;
      }, {
        once: !0
      }), t.addEventListener("mouseenter", () => {
        this.#r = setTimeout(() => {
          this.#r = null, this.#n.classList.add("show"), this.#l._reportTelemetry({
            action: "alt_text_tooltip"
          });
        }, i);
      }, {
        signal: n
      }), t.addEventListener("mouseleave", () => {
        this.#r && (clearTimeout(this.#r), this.#r = null), this.#n?.classList.remove("show");
      }, {
        signal: n
      });
    }
    this.#e ? e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-decorative-tooltip") : (e.removeAttribute("data-l10n-id"), e.textContent = this.#t), e.parentNode || t.append(e), this.#l.getElementForAltText()?.setAttribute("aria-describedby", e.id);
  }
}
class Ue {
  #t = null;
  #e = null;
  #s = !1;
  #i = null;
  #n = null;
  #r = null;
  #a = null;
  #o = null;
  #l = !1;
  #h = null;
  constructor(t) {
    this.#i = t;
  }
  renderForToolbar() {
    const t = this.#e = document.createElement("button");
    return t.className = "comment", this.#u(t, !1);
  }
  renderForStandalone() {
    const t = this.#t = document.createElement("button");
    t.className = "annotationCommentButton";
    const e = this.#i.commentButtonPosition;
    if (e) {
      const {
        style: s
      } = t;
      s.insetInlineEnd = `calc(${100 * (this.#i._uiManager.direction === "ltr" ? 1 - e[0] : e[0])}% - var(--comment-button-dim))`, s.top = `calc(${100 * e[1]}% - var(--comment-button-dim))`;
      const i = this.#i.commentButtonColor;
      i && (s.backgroundColor = i);
    }
    return this.#u(t, !0);
  }
  focusButton() {
    setTimeout(() => {
      (this.#t ?? this.#e)?.focus();
    }, 0);
  }
  onUpdatedColor() {
    if (!this.#t)
      return;
    const t = this.#i.commentButtonColor;
    t && (this.#t.style.backgroundColor = t), this.#i._uiManager.updatePopupColor(this.#i);
  }
  get commentButtonWidth() {
    return (this.#t?.getBoundingClientRect().width ?? 0) / this.#i.parent.boundingClientRect.width;
  }
  get commentPopupPositionInLayer() {
    if (this.#h)
      return this.#h;
    if (!this.#t)
      return null;
    const {
      x: t,
      y: e,
      height: s
    } = this.#t.getBoundingClientRect(), {
      x: i,
      y: n,
      width: r,
      height: a
    } = this.#i.parent.boundingClientRect;
    return [(t - i) / r, (e + s - n) / a];
  }
  set commentPopupPositionInLayer(t) {
    this.#h = t;
  }
  hasDefaultPopupPosition() {
    return this.#h === null;
  }
  removeStandaloneCommentButton() {
    this.#t?.remove(), this.#t = null;
  }
  removeToolbarCommentButton() {
    this.#e?.remove(), this.#e = null;
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    this.#t && (this.#t.classList.toggle("selected", t), this.#t.ariaExpanded = e);
  }
  #u(t, e) {
    if (!this.#i._uiManager.hasCommentManager())
      return null;
    t.tabIndex = "0", t.ariaHasPopup = "dialog", e ? (t.ariaControls = "commentPopup", t.setAttribute("data-l10n-id", "pdfjs-show-comment-button")) : (t.ariaControlsElements = [this.#i._uiManager.getCommentDialogElement()], t.setAttribute("data-l10n-id", "pdfjs-editor-add-comment-button"));
    const s = this.#i._uiManager._signal;
    if (!(s instanceof AbortSignal) || s.aborted)
      return t;
    t.addEventListener("contextmenu", xt, {
      signal: s
    }), e && (t.addEventListener("focusin", (n) => {
      this.#i._focusEventsAllowed = !1, nt(n);
    }, {
      capture: !0,
      signal: s
    }), t.addEventListener("focusout", (n) => {
      this.#i._focusEventsAllowed = !0, nt(n);
    }, {
      capture: !0,
      signal: s
    })), t.addEventListener("pointerdown", (n) => n.stopPropagation(), {
      signal: s
    });
    const i = (n) => {
      n.preventDefault(), t === this.#e ? this.edit() : this.#i.toggleComment(!0);
    };
    return t.addEventListener("click", i, {
      capture: !0,
      signal: s
    }), t.addEventListener("keydown", (n) => {
      n.target === t && n.key === "Enter" && (this.#s = !0, i(n));
    }, {
      signal: s
    }), t.addEventListener("pointerenter", () => {
      this.#i.toggleComment(!1, !0);
    }, {
      signal: s
    }), t.addEventListener("pointerleave", () => {
      this.#i.toggleComment(!1, !1);
    }, {
      signal: s
    }), t;
  }
  edit(t) {
    const e = this.commentPopupPositionInLayer;
    let s, i;
    if (e)
      [s, i] = e;
    else {
      [s, i] = this.#i.commentButtonPosition;
      const {
        width: h,
        height: c,
        x: u,
        y: f
      } = this.#i;
      s = u + s * h, i = f + i * c;
    }
    const n = this.#i.parent.boundingClientRect, {
      x: r,
      y: a,
      width: o,
      height: l
    } = n;
    this.#i._uiManager.editComment(this.#i, r + s * o, a + i * l, {
      ...t,
      parentDimensions: n
    });
  }
  finish() {
    this.#e && (this.#e.focus({
      focusVisible: this.#s
    }), this.#s = !1);
  }
  isDeleted() {
    return this.#l || this.#a === "";
  }
  isEmpty() {
    return this.#a === null;
  }
  hasBeenEdited() {
    return this.isDeleted() || this.#a !== this.#n;
  }
  serialize() {
    return this.data;
  }
  get data() {
    return {
      text: this.#a,
      richText: this.#r,
      date: this.#o,
      deleted: this.isDeleted()
    };
  }
  set data(t) {
    if (t !== this.#a && (this.#r = null), t === null) {
      this.#a = "", this.#l = !0;
      return;
    }
    this.#a = t, this.#o = /* @__PURE__ */ new Date(), this.#l = !1;
  }
  restoreData({
    text: t,
    richText: e,
    date: s
  }) {
    this.#a = t, this.#r = e, this.#o = s, this.#l = !1;
  }
  setInitialText(t, e = null) {
    this.#n = t, this.data = t, this.#o = null, this.#r = e;
  }
  shown() {
  }
  destroy() {
    this.#e?.remove(), this.#e = null, this.#t?.remove(), this.#t = null, this.#a = "", this.#r = null, this.#o = null, this.#i = null, this.#s = !1, this.#l = !1;
  }
}
function _i(d) {
  d.preventDefault();
}
const Ci = 1e-4;
function xs(d) {
  return d.cancelable ? (nt(d), !0) : (d.stopPropagation(), !1);
}
class sn {
  #t;
  #e = !1;
  #s = null;
  #i;
  #n;
  #r;
  #a;
  #o;
  #l = !1;
  #h = null;
  #u;
  #c = /* @__PURE__ */ new Set();
  #f = null;
  #p;
  #m = null;
  #d = 0;
  constructor({
    container: t,
    isPinchingDisabled: e = null,
    isPinchingStopped: s = null,
    onPinchStart: i = null,
    onPinching: n = null,
    onPinchEnd: r = null,
    onPanning: a = null,
    signal: o
  }) {
    this.#t = t, this.#s = s, this.#i = e, this.#n = i, this.#r = n, this.#a = r, this.#o = a, this.#p = new AbortController(), this.#u = AbortSignal.any([o, this.#p.signal]), t.addEventListener("touchstart", this.#g.bind(this), {
      passive: !1,
      signal: this.#u
    });
  }
  get MIN_TOUCH_DISTANCE_TO_PINCH() {
    return 35 / wt.pixelRatio;
  }
  get MIN_TOUCH_DISTANCE_TO_SCALE() {
    return 4 / wt.pixelRatio;
  }
  #g(t) {
    if (this.#i?.())
      return;
    this.#y(t);
    const e = this.#c;
    for (const {
      identifier: s
    } of t.changedTouches)
      e.add(s);
    if (e.size === 1) {
      this.#b();
      return;
    }
    if (!this.#m) {
      this.#m = new AbortController();
      const s = AbortSignal.any([this.#u, this.#m.signal]), i = this.#t, n = {
        signal: s,
        capture: !1,
        passive: !1
      };
      i.addEventListener("touchmove", this.#S.bind(this), n);
      const r = this.#_.bind(this);
      i.addEventListener("touchend", r, n), i.addEventListener("touchcancel", r, n), n.capture = !0, i.addEventListener("pointerdown", nt, n), i.addEventListener("pointermove", nt, n), i.addEventListener("pointercancel", _i, n), i.addEventListener("pointerup", _i, n), this.#n?.();
    }
    this.#l = xs(t), this.#w(t);
  }
  #b() {
    if (this.#h)
      return;
    const t = this.#h = new AbortController(), e = AbortSignal.any([this.#u, t.signal]), s = this.#t, i = {
      capture: !0,
      signal: e,
      passive: !1
    }, n = (r) => {
      r.pointerType === "touch" && (this.#h?.abort(), this.#h = null);
    };
    s.addEventListener("pointerdown", (r) => {
      r.pointerType === "touch" && (nt(r), n(r));
    }, i), s.addEventListener("pointerup", n, i), s.addEventListener("pointercancel", n, i);
  }
  #y(t) {
    const e = this.#c;
    if (e.size === 0)
      return;
    const s = this.#c = /* @__PURE__ */ new Set();
    for (const {
      identifier: i
    } of t.touches)
      e.has(i) && s.add(i);
  }
  #A(t) {
    const e = this.#c, s = [];
    for (const i of t.touches)
      e.has(i.identifier) && s.push(i);
    return s;
  }
  #w(t) {
    const e = this.#A(t);
    if (e.length !== 2 || this.#s?.()) {
      this.#f = null;
      return;
    }
    const [s, i] = e;
    this.#f = {
      touch0X: s.screenX,
      touch0Y: s.screenY,
      touch1X: i.screenX,
      touch1Y: i.screenY,
      panX: (s.clientX + i.clientX) / 2,
      panY: (s.clientY + i.clientY) / 2,
      screenPanX: (s.screenX + i.screenX) / 2,
      screenPanY: (s.screenY + i.screenY) / 2
    };
  }
  #S(t) {
    if (!this.#f)
      return;
    const e = this.#A(t);
    if (e.length !== 2)
      return;
    const s = this.#l;
    if (this.#l = xs(t), !this.#l)
      return;
    if (!s) {
      this.#w(t);
      return;
    }
    const [i, n] = e, {
      screenX: r,
      screenY: a
    } = i, {
      screenX: o,
      screenY: l
    } = n, h = this.#f, {
      touch0X: c,
      touch0Y: u,
      touch1X: f,
      touch1Y: p,
      panX: g,
      panY: m
    } = h, b = f - c, y = p - u, A = o - r, w = l - a, v = (i.clientX + n.clientX) / 2, S = (i.clientY + n.clientY) / 2;
    h.panX = v, h.panY = S;
    const _ = v - g, E = S - m, C = (r + o) / 2, T = (a + l) / 2, D = Math.hypot(C - h.screenPanX, T - h.screenPanY);
    h.screenPanX = C, h.screenPanY = T;
    const P = Math.hypot(A, w), N = Math.hypot(b, y), G = this.#e ? this.MIN_TOUCH_DISTANCE_TO_SCALE : this.MIN_TOUCH_DISTANCE_TO_PINCH + 2 * D;
    if (P < Ci || N < Ci || Math.abs(N - P) <= G) {
      (_ || E) && this.#o?.(_, E);
      return;
    }
    h.touch0X = r, h.touch0Y = a, h.touch1X = o, h.touch1Y = l;
    const z = Math.sign(P - N);
    if (!this.#e) {
      this.#e = !0, this.#d = z, (_ || E) && this.#o?.(_, E);
      return;
    }
    if (this.#d) {
      const F = this.#d;
      if (this.#d = 0, z !== F && Math.abs(P - N) <= 2 * D) {
        this.#e = !1, (_ || E) && this.#o?.(_, E);
        return;
      }
    }
    this.#r?.([g, m], N, P, _, E);
  }
  #_(t) {
    if (this.#y(t), this.#c.size >= 2) {
      this.#w(t);
      return;
    }
    const e = !!this.#f;
    this.#v(), this.#c.size === 1 && this.#b(), e && xs(t);
  }
  #v() {
    this.#f = null, this.#e = !1, this.#d = 0, this.#l = !1, this.#m && (this.#m.abort(), this.#m = null, this.#a?.());
  }
  destroy() {
    this.#v(), this.#c.clear(), this.#p?.abort(), this.#p = null, this.#h?.abort(), this.#h = null;
  }
}
class I {
  #t = null;
  #e = null;
  #s = null;
  #i = null;
  #n = null;
  #r = !1;
  #a = null;
  #o = "";
  #l = null;
  #h = null;
  #u = null;
  #c = null;
  #f = null;
  #p = "";
  #m = !1;
  #d = null;
  #g = !1;
  #b = !1;
  #y = !1;
  #A = null;
  #w = 0;
  #S = 0;
  #_ = null;
  #v = null;
  isSelected = !1;
  _isCopy = !1;
  _editToolbar = null;
  _initialOptions = /* @__PURE__ */ Object.create(null);
  _initialData = null;
  _isVisible = !0;
  _uiManager = null;
  _focusEventsAllowed = !0;
  static _l10n = null;
  static _l10nAlert = null;
  static _l10nResizer = null;
  #C = !1;
  #I = I._zIndex++;
  static _borderLineWidth = -1;
  static _colorManager = new Zs();
  static _zIndex = 1;
  static _telemetryTimeout = 1e3;
  static get _resizerKeyboardManager() {
    const t = I.prototype._resizeWithKeyboard, e = Kt.TRANSLATE_SMALL, s = Kt.TRANSLATE_BIG;
    return k(this, "_resizerKeyboardManager", new yt([[["ArrowLeft"], t, {
      args: [-e, 0]
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t, {
      args: [-s, 0]
    }], [["ArrowRight"], t, {
      args: [e, 0]
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t, {
      args: [s, 0]
    }], [["ArrowUp"], t, {
      args: [0, -e]
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t, {
      args: [0, -s]
    }], [["ArrowDown"], t, {
      args: [0, e]
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t, {
      args: [0, s]
    }], [["Escape"], I.prototype._stopResizingWithKeyboard]]));
  }
  constructor(t) {
    this.parent = t.parent, this.id = t.id, this.width = this.height = null, this.pageIndex = t.parent.pageIndex, this.name = t.name, this.div = null, this._uiManager = t.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = t.isCentered, this._structTreeParentId = null, this.annotationElementId = t.annotationElementId || null, this.creationDate = t.creationDate || /* @__PURE__ */ new Date(), this.modificationDate = t.modificationDate || null, this.canAddComment = !0;
    const {
      rotation: e,
      rawDims: {
        pageWidth: s,
        pageHeight: i,
        pageX: n,
        pageY: r
      }
    } = this.parent.viewport;
    this.rotation = e, this.pageRotation = (360 + e - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [s, i], this.pageTranslation = [n, r];
    const [a, o] = this.parentDimensions;
    this.x = t.x / a, this.y = t.y / o, this.isAttachedToDOM = !1, this.deleted = !1;
  }
  updatePageIndex(t) {
    this.pageIndex = t;
  }
  get editorType() {
    return Object.getPrototypeOf(this).constructor._type;
  }
  get mode() {
    return Object.getPrototypeOf(this).constructor._editorType;
  }
  static get isDrawer() {
    return !1;
  }
  static get _defaultLineColor() {
    return k(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
  }
  static deleteAnnotationElement(t) {
    const e = new sr({
      id: t._uiManager.getId(),
      parent: t.parent,
      uiManager: t._uiManager
    });
    e.annotationElementId = t.annotationElementId, e.deleted = !0, e._uiManager.addToAnnotationStorage(e);
  }
  static initialize(t, e) {
    if (I._l10n ??= t, I._l10nAlert ??= Object.freeze({
      highlight: "pdfjs-editor-highlight-added-alert",
      freetext: "pdfjs-editor-freetext-added-alert",
      ink: "pdfjs-editor-ink-added-alert",
      stamp: "pdfjs-editor-stamp-added-alert",
      signature: "pdfjs-editor-signature-added-alert"
    }), I._l10nResizer ??= Object.freeze({
      topLeft: "pdfjs-editor-resizer-top-left",
      topMiddle: "pdfjs-editor-resizer-top-middle",
      topRight: "pdfjs-editor-resizer-top-right",
      middleRight: "pdfjs-editor-resizer-middle-right",
      bottomRight: "pdfjs-editor-resizer-bottom-right",
      bottomMiddle: "pdfjs-editor-resizer-bottom-middle",
      bottomLeft: "pdfjs-editor-resizer-bottom-left",
      middleLeft: "pdfjs-editor-resizer-middle-left"
    }), I._borderLineWidth !== -1)
      return;
    const s = getComputedStyle(document.documentElement);
    I._borderLineWidth = parseFloat(s.getPropertyValue("--outline-width")) || 0;
  }
  static updateDefaultParams(t, e) {
  }
  static get defaultPropertiesToUpdate() {
    return [];
  }
  static isHandlingMimeForPasting(t) {
    return !1;
  }
  static paste(t, e) {
    j("Not implemented");
  }
  get propertiesToUpdate() {
    return [];
  }
  get _isDraggable() {
    return this.#C;
  }
  set _isDraggable(t) {
    this.#C = t, this.div?.classList.toggle("draggable", t);
  }
  get uid() {
    return this.annotationElementId || this.id;
  }
  get isEnterHandled() {
    return !0;
  }
  center() {
    const [t, e] = this.pageDimensions;
    switch (this.parentRotation) {
      case 90:
        this.x -= this.height * e / (t * 2), this.y += this.width * t / (e * 2);
        break;
      case 180:
        this.x += this.width / 2, this.y += this.height / 2;
        break;
      case 270:
        this.x += this.height * e / (t * 2), this.y -= this.width * t / (e * 2);
        break;
      default:
        this.x -= this.width / 2, this.y -= this.height / 2;
        break;
    }
    this.fixAndSetPosition();
  }
  addCommands(t) {
    this._uiManager.addCommands(t);
  }
  get currentLayer() {
    return this._uiManager.currentLayer;
  }
  setInBackground() {
    this.div.style.zIndex = 0;
  }
  setInForeground() {
    this.div.style.zIndex = this.#I;
  }
  setParent(t) {
    t !== null ? (this.pageIndex = t.pageIndex, this.pageDimensions = t.pageDimensions) : (this.#L(), this.#c?.remove(), this.#c = null), this.parent = t;
  }
  focusin(t) {
    this._focusEventsAllowed && (this.#m ? this.#m = !1 : this.parent.setSelected(this));
  }
  focusout(t) {
    !this._focusEventsAllowed || !this.isAttachedToDOM || t.relatedTarget?.closest(`#${this.id}`) || (t.preventDefault(), this.parent?.isMultipleSelection || this.commitOrRemove());
  }
  commitOrRemove() {
    this.isEmpty() ? this.remove() : this.commit();
  }
  commit() {
    this.isInEditMode() && this.addToAnnotationStorage();
  }
  addToAnnotationStorage() {
    this._uiManager.addToAnnotationStorage(this);
  }
  setAt(t, e, s, i) {
    const [n, r] = this.parentDimensions;
    [s, i] = this.screenToPageTranslation(s, i), this.x = (t + s) / n, this.y = (e + i) / r, this.fixAndSetPosition();
  }
  _moveAfterPaste(t, e) {
    if (this.isClone) {
      delete this.isClone;
      return;
    }
    const [s, i] = this.parentDimensions;
    this.setAt(t * s, e * i, this.width * s, this.height * i), this._onTranslated();
  }
  #k([t, e], s, i) {
    [s, i] = this.screenToPageTranslation(s, i), this.x += s / t, this.y += i / e, this._onTranslating(this.x, this.y), this.fixAndSetPosition();
  }
  translate(t, e) {
    this.#k(this.parentDimensions, t, e);
  }
  translateInPage(t, e) {
    this.#d ||= [this.x, this.y, this.width, this.height], this.#k(this.pageDimensions, t, e), this.div.scrollIntoView({
      block: "nearest"
    });
  }
  translationDone() {
    this._onTranslated(this.x, this.y);
  }
  drag(t, e) {
    this.#d ||= [this.x, this.y, this.width, this.height];
    const {
      div: s,
      parentDimensions: [i, n]
    } = this;
    if (this.x += t / i, this.y += e / n, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
      const {
        x: c,
        y: u
      } = this.div.getBoundingClientRect();
      this.parent.findNewParent(this, c, u) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
    }
    let {
      x: r,
      y: a
    } = this;
    const [o, l] = this.getBaseTranslation();
    r += o, a += l;
    const {
      style: h
    } = s;
    h.left = `${(100 * r).toFixed(2)}%`, h.top = `${(100 * a).toFixed(2)}%`, this._onTranslating(r, a);
  }
  _onTranslating(t, e) {
  }
  _onTranslated(t, e) {
  }
  get _hasBeenMoved() {
    return !!this.#d && (this.#d[0] !== this.x || this.#d[1] !== this.y);
  }
  get _hasBeenResized() {
    return !!this.#d && (this.#d[2] !== this.width || this.#d[3] !== this.height);
  }
  getBaseTranslation() {
    const [t, e] = this.parentDimensions, {
      _borderLineWidth: s
    } = I, i = s / t, n = s / e;
    switch (this.rotation) {
      case 90:
        return [-i, n];
      case 180:
        return [i, n];
      case 270:
        return [i, -n];
      default:
        return [-i, -n];
    }
  }
  get _mustFixPosition() {
    return !0;
  }
  fixAndSetPosition(t = this.rotation) {
    const {
      div: {
        style: e
      },
      pageDimensions: [s, i]
    } = this;
    let {
      x: n,
      y: r,
      width: a,
      height: o
    } = this;
    a *= s, o *= i, n *= s, r *= i;
    let l = 0, h = 0;
    const c = this._uiManager._keepToolbarInPage && this._editToolbar?.div;
    if (c?.offsetParent) {
      const p = this.parentScale, g = c.offsetLeft + this.div.clientLeft, m = c.offsetTop + this.div.clientTop, b = Math.min(0, g) / p, y = Math.min(0, m) / p, A = a - b + Math.max(0, g + c.offsetWidth - this.div.offsetWidth) / p, w = o - y + Math.max(0, m + c.offsetHeight - this.div.offsetHeight) / p;
      A <= (t % 180 ? i : s) && (a = A, l = b), w <= (t % 180 ? s : i) && (o = w, h = y), [l, h] = I.#T(l, h, t), n += l, r += h;
    }
    if (this._mustFixPosition)
      switch (t) {
        case 0:
          n = Y(n, 0, s - a), r = Y(r, 0, i - o);
          break;
        case 90:
          n = Y(n, 0, s - o), r = Y(r, a, i);
          break;
        case 180:
          n = Y(n, a, s), r = Y(r, o, i);
          break;
        case 270:
          n = Y(n, o, s), r = Y(r, 0, i - a);
          break;
      }
    this.x = n = (n - l) / s, this.y = r = (r - h) / i;
    const [u, f] = this.getBaseTranslation();
    n += u, r += f, e.left = `${(100 * n).toFixed(2)}%`, e.top = `${(100 * r).toFixed(2)}%`, this.moveInDOM();
  }
  static #T(t, e, s) {
    switch (s) {
      case 90:
        return [e, -t];
      case 180:
        return [-t, -e];
      case 270:
        return [-e, t];
      default:
        return [t, e];
    }
  }
  screenToPageTranslation(t, e) {
    return I.#T(t, e, this.parentRotation);
  }
  pageTranslationToScreen(t, e) {
    return I.#T(t, e, 360 - this.parentRotation);
  }
  #O(t) {
    switch (t) {
      case 90: {
        const [e, s] = this.pageDimensions;
        return [0, -e / s, s / e, 0];
      }
      case 180:
        return [-1, 0, 0, -1];
      case 270: {
        const [e, s] = this.pageDimensions;
        return [0, e / s, -s / e, 0];
      }
      default:
        return [1, 0, 0, 1];
    }
  }
  get parentScale() {
    return this._uiManager.viewParameters.realScale;
  }
  get parentRotation() {
    return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
  }
  get parentDimensions() {
    const {
      parentScale: t,
      pageDimensions: [e, s]
    } = this;
    return [e * t, s * t];
  }
  setDims() {
    const {
      div: {
        style: t
      },
      width: e,
      height: s
    } = this;
    t.width = `${(100 * e).toFixed(2)}%`, t.height = `${(100 * s).toFixed(2)}%`;
  }
  getInitialTranslation() {
    return [0, 0];
  }
  #P() {
    if (this.#l)
      return;
    this.#l = document.createElement("div"), this.#l.classList.add("resizers");
    const t = this._willKeepAspectRatio ? ["topLeft", "topRight", "bottomRight", "bottomLeft"] : ["topLeft", "topMiddle", "topRight", "middleRight", "bottomRight", "bottomMiddle", "bottomLeft", "middleLeft"], e = this._uiManager._signal;
    for (const s of t) {
      const i = document.createElement("div");
      this.#l.append(i), i.classList.add("resizer", s), i.setAttribute("data-resizer-name", s), i.addEventListener("pointerdown", this.#D.bind(this, s), {
        signal: e
      }), i.addEventListener("contextmenu", xt, {
        signal: e
      }), i.tabIndex = -1;
    }
    this.div.prepend(this.#l);
  }
  #D(t, e) {
    e.preventDefault();
    const {
      isMac: s
    } = W.platform;
    if (e.button !== 0 || e.ctrlKey && s)
      return;
    this.#s?.toggle(!1);
    const i = this._isDraggable;
    this._isDraggable = !1, this.#h = [e.screenX, e.screenY];
    const n = new AbortController(), r = this._uiManager.combinedSignal(n);
    this.parent.togglePointerEvents(!1), window.addEventListener("pointermove", this.#B.bind(this, t), {
      passive: !0,
      capture: !0,
      signal: r
    }), window.addEventListener("touchmove", nt, {
      passive: !1,
      signal: r
    }), window.addEventListener("contextmenu", xt, {
      signal: r
    }), this.#u = {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    };
    const a = this.parent.div.style.cursor, o = this.div.style.cursor;
    this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(e.target).cursor;
    const l = () => {
      n.abort(), this.parent.togglePointerEvents(!0), this.#s?.toggle(!0), this._isDraggable = i, this.parent.div.style.cursor = a, this.div.style.cursor = o, this.#F();
    };
    window.addEventListener("pointerup", l, {
      signal: r
    }), window.addEventListener("blur", l, {
      signal: r
    });
  }
  #R(t, e, s, i) {
    this.width = s, this.height = i, this.x = t, this.y = e, this.setDims(), this.fixAndSetPosition(), this._onResized();
  }
  _onResized() {
  }
  #F() {
    if (!this.#u)
      return;
    const {
      savedX: t,
      savedY: e,
      savedWidth: s,
      savedHeight: i
    } = this.#u;
    this.#u = null;
    const n = this.x, r = this.y, a = this.width, o = this.height;
    n === t && r === e && a === s && o === i || this.addCommands({
      cmd: this.#R.bind(this, n, r, a, o),
      undo: this.#R.bind(this, t, e, s, i),
      mustExec: !0
    });
  }
  static _round(t) {
    return Math.round(t * 1e4) / 1e4;
  }
  #B(t, e) {
    const [s, i] = this.parentDimensions, n = this.x, r = this.y, a = this.width, o = this.height, l = I.MIN_SIZE / s, h = I.MIN_SIZE / i, c = this.#O(this.rotation), u = (F, O) => [c[0] * F + c[2] * O, c[1] * F + c[3] * O], f = this.#O(360 - this.rotation), p = (F, O) => [f[0] * F + f[2] * O, f[1] * F + f[3] * O];
    let g, m, b = !1, y = !1;
    switch (t) {
      case "topLeft":
        b = !0, g = (F, O) => [0, 0], m = (F, O) => [F, O];
        break;
      case "topMiddle":
        g = (F, O) => [F / 2, 0], m = (F, O) => [F / 2, O];
        break;
      case "topRight":
        b = !0, g = (F, O) => [F, 0], m = (F, O) => [0, O];
        break;
      case "middleRight":
        y = !0, g = (F, O) => [F, O / 2], m = (F, O) => [0, O / 2];
        break;
      case "bottomRight":
        b = !0, g = (F, O) => [F, O], m = (F, O) => [0, 0];
        break;
      case "bottomMiddle":
        g = (F, O) => [F / 2, O], m = (F, O) => [F / 2, 0];
        break;
      case "bottomLeft":
        b = !0, g = (F, O) => [0, O], m = (F, O) => [F, 0];
        break;
      case "middleLeft":
        y = !0, g = (F, O) => [0, O / 2], m = (F, O) => [F, O / 2];
        break;
    }
    const A = g(a, o), w = m(a, o);
    let v = u(...w);
    const S = I._round(n + v[0]), _ = I._round(r + v[1]);
    let E = 1, C = 1, T, D;
    if (e.fromKeyboard)
      ({
        deltaX: T,
        deltaY: D
      } = e);
    else {
      const {
        screenX: F,
        screenY: O
      } = e, [rt, lt] = this.#h;
      [T, D] = this.screenToPageTranslation(F - rt, O - lt), this.#h[0] = F, this.#h[1] = O;
    }
    if ([T, D] = p(T / s, D / i), b) {
      const F = Math.hypot(a, o);
      E = C = Math.max(Math.min(Math.hypot(w[0] - A[0] - T, w[1] - A[1] - D) / F, 1 / a, 1 / o), l / a, h / o);
    } else y ? E = Y(Math.abs(w[0] - A[0] - T), l, 1) / a : C = Y(Math.abs(w[1] - A[1] - D), h, 1) / o;
    const P = I._round(a * E), N = I._round(o * C);
    v = u(...m(P, N));
    const G = S - v[0], z = _ - v[1];
    this.#d ||= [this.x, this.y, this.width, this.height], this.width = P, this.height = N, this.x = G, this.y = z, this.setDims(), this.fixAndSetPosition(), this._onResizing();
  }
  _onResizing() {
  }
  altTextFinish() {
    this.#s?.finish();
  }
  get toolbarButtons() {
    return null;
  }
  async addEditToolbar() {
    if (this._editToolbar || this.#b)
      return this._editToolbar;
    this._editToolbar = new Te(this), this.div.append(this._editToolbar.render());
    const {
      toolbarButtons: t
    } = this;
    if (t)
      for (const [e, s] of t)
        await this._editToolbar.addButton(e, s);
    return this.hasComment || this._editToolbar.addButton("comment", this.addCommentButton()), this._editToolbar.addButton("delete"), this._editToolbar;
  }
  addCommentButtonInToolbar() {
    this._editToolbar?.addButtonBefore("comment", this.addCommentButton(), ".deleteButton");
  }
  removeCommentButtonFromToolbar() {
    this._editToolbar?.removeButton("comment");
  }
  removeEditToolbar() {
    this._editToolbar?.remove(), this._editToolbar = null, this.#s?.destroy();
  }
  addContainer(t) {
    const e = this._editToolbar?.div;
    e ? e.before(t) : this.div.append(t);
  }
  getClientDimensions() {
    return this.div.getBoundingClientRect();
  }
  createAltText() {
    return this.#s || (It.initialize(I._l10n), this.#s = new It(this), this.#t && (this.#s.data = this.#t, this.#t = null)), this.#s;
  }
  get altTextData() {
    return this.#s?.data;
  }
  set altTextData(t) {
    this.#s && (this.#s.data = t);
  }
  get guessedAltText() {
    return this.#s?.guessedText;
  }
  async setGuessedAltText(t) {
    await this.#s?.setGuessedText(t);
  }
  serializeAltText(t) {
    return this.#s?.serialize(t);
  }
  hasAltText() {
    return !!this.#s && !this.#s.isEmpty();
  }
  hasAltTextData() {
    return this.#s?.hasData() ?? !1;
  }
  focusCommentButton() {
    this.#i?.focusButton();
  }
  addCommentButton() {
    return this.canAddComment ? this.#i ||= new Ue(this) : null;
  }
  addStandaloneCommentButton() {
    if (this._uiManager.hasCommentManager()) {
      if (this.#n) {
        this._uiManager.isEditingMode() && this.#n.classList.remove("hidden");
        return;
      }
      this.hasComment && (this.#n = this.#i.renderForStandalone(), this.div.append(this.#n));
    }
  }
  removeStandaloneCommentButton() {
    this.#i.removeStandaloneCommentButton(), this.#n = null;
  }
  hideStandaloneCommentButton() {
    this.#n?.classList.add("hidden");
  }
  get comment() {
    if (!this.#i)
      return null;
    const {
      data: {
        richText: t,
        text: e,
        date: s,
        deleted: i
      }
    } = this.#i;
    return {
      text: e,
      richText: t,
      date: s,
      deleted: i,
      color: this.getNonHCMColor(),
      opacity: this.opacity ?? 1
    };
  }
  set comment(t) {
    this.#i ||= new Ue(this), typeof t == "object" && t !== null ? this.#i.restoreData(t) : this.#i.data = t, this.hasComment ? (this.removeCommentButtonFromToolbar(), this.addStandaloneCommentButton(), this._uiManager.updateComment(this)) : (this.addCommentButtonInToolbar(), this.removeStandaloneCommentButton(), this._uiManager.removeComment(this));
  }
  setCommentData({
    comment: t,
    popupRef: e,
    richText: s
  }) {
    if (!e || (this.#i ||= new Ue(this), this.#i.setInitialText(t, s), !this.annotationElementId))
      return;
    const i = this._uiManager.getAndRemoveDataFromAnnotationStorage(this.annotationElementId);
    i && this.updateFromAnnotationLayer(i);
  }
  get hasEditedComment() {
    return this.#i?.hasBeenEdited();
  }
  get hasDeletedComment() {
    return this.#i?.isDeleted();
  }
  get hasComment() {
    return !!this.#i && !this.#i.isEmpty() && !this.#i.isDeleted();
  }
  async editComment(t) {
    this.#i ||= new Ue(this), this.#i.edit(t);
  }
  toggleComment(t, e = void 0) {
    this.hasComment && this._uiManager.toggleComment(this, t, e);
  }
  setSelectedCommentButton(t) {
    this.#i.setSelectedButton(t);
  }
  addComment(t) {
    if (this.hasEditedComment) {
      const [, , , i] = t.rect, [n] = this.pageDimensions, [r] = this.pageTranslation, a = r + n + 1, o = i - 100, l = a + 180;
      t.popup = {
        contents: this.comment.text,
        deleted: this.comment.deleted,
        rect: [a, o, l, i]
      };
    }
  }
  updateFromAnnotationLayer({
    popup: {
      contents: t,
      deleted: e
    }
  }) {
    this.#i.data = e ? null : t;
  }
  get parentBoundingClientRect() {
    return this.parent.boundingClientRect;
  }
  render() {
    const t = this.div = document.createElement("div");
    t.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), t.className = this.name, t.setAttribute("id", this.id), t.tabIndex = this.#r ? -1 : 0, t.setAttribute("role", "application"), this.defaultL10nId && t.setAttribute("data-l10n-id", this.defaultL10nId), this._isVisible || t.classList.add("hidden"), this.setInForeground(), this.#U();
    const [e, s] = this.parentDimensions;
    this.parentRotation % 180 !== 0 && (t.style.maxWidth = `${(100 * s / e).toFixed(2)}%`, t.style.maxHeight = `${(100 * e / s).toFixed(2)}%`);
    const [i, n] = this.getInitialTranslation();
    return this.translate(i, n), en(this, t, ["keydown", "pointerdown", "dblclick"]), this.#z(), this.addStandaloneCommentButton(), this._uiManager._editorUndoBar?.hide(), t;
  }
  #W() {
    this.#u = {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    }, this.#s?.toggle(!1), this.parent.togglePointerEvents(!1);
  }
  #H(t, e, s) {
    let n = 0.7 * (s / e) + 1 - 0.7;
    if (n === 1)
      return;
    const r = this.#O(this.rotation), a = (S, _) => [r[0] * S + r[2] * _, r[1] * S + r[3] * _], [o, l] = this.parentDimensions, h = this.x, c = this.y, u = this.width, f = this.height, p = I.MIN_SIZE / o, g = I.MIN_SIZE / l;
    n = Math.max(Math.min(n, 1 / u, 1 / f), p / u, g / f);
    const m = I._round(u * n), b = I._round(f * n);
    if (m === u && b === f)
      return;
    this.#d ||= [h, c, u, f];
    const y = a(u / 2, f / 2), A = I._round(h + y[0]), w = I._round(c + y[1]), v = a(m / 2, b / 2);
    this.x = A - v[0], this.y = w - v[1], this.width = m, this.height = b, this.setDims(), this.fixAndSetPosition(), this._onResizing();
  }
  #j() {
    this.#s?.toggle(!0), this.parent.togglePointerEvents(!0), this.#F();
  }
  pointerdown(t) {
    const {
      isMac: e
    } = W.platform;
    if (t.button !== 0 || t.ctrlKey && e) {
      t.preventDefault();
      return;
    }
    if (this.#m = !0, this._isDraggable) {
      this.#E(t);
      return;
    }
    this.#x(t);
  }
  #x(t) {
    const {
      isMac: e
    } = W.platform;
    t.ctrlKey && !e || t.shiftKey || t.metaKey && e ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
  }
  #E(t) {
    const {
      isSelected: e
    } = this;
    this._uiManager.setUpDragSession();
    let s = !1;
    const i = new AbortController(), n = this._uiManager.combinedSignal(i), r = {
      capture: !0,
      passive: !1,
      signal: n
    }, a = (l) => {
      i.abort(), this.#a = null, this.#m = !1, this._uiManager.endDragSession() || this.#x(l), s && this._onStopDragging();
    };
    e && (this.#w = t.clientX, this.#S = t.clientY, this.#a = t.pointerId, this.#o = t.pointerType, window.addEventListener("pointermove", (l) => {
      s || (s = !0, this._uiManager.toggleComment(this, !0, !1), this._onStartDragging());
      const {
        clientX: h,
        clientY: c,
        pointerId: u
      } = l;
      if (u !== this.#a) {
        nt(l);
        return;
      }
      const [f, p] = this.screenToPageTranslation(h - this.#w, c - this.#S);
      this.#w = h, this.#S = c, this._uiManager.dragSelectedEditors(f, p), this.div.scrollIntoView({
        block: "nearest"
      });
    }, r), window.addEventListener("touchmove", nt, r), window.addEventListener("pointerdown", (l) => {
      l.pointerType === this.#o && (this.#v || l.isPrimary) && a(l), nt(l);
    }, r));
    const o = (l) => {
      if (!this.#a || this.#a === l.pointerId) {
        a(l);
        return;
      }
      nt(l);
    };
    window.addEventListener("pointerup", o, {
      signal: n
    }), window.addEventListener("blur", o, {
      signal: n
    });
  }
  _onStartDragging() {
  }
  _onStopDragging() {
  }
  moveInDOM() {
    this.#A && clearTimeout(this.#A), this.#A = setTimeout(() => {
      this.#A = null, this.parent?.moveEditorInDOM(this);
    }, 0);
  }
  _setParentAndPosition(t, e, s) {
    t.changeParent(this), this.x = e, this.y = s, this.fixAndSetPosition(), this._onTranslated();
  }
  getRect(t, e, s = this.rotation) {
    const i = this.parentScale, [n, r] = this.pageDimensions, [a, o] = this.pageTranslation, l = t / i, h = e / i, c = this.x * n, u = this.y * r, f = this.width * n, p = this.height * r;
    switch (s) {
      case 0:
        return [c + l + a, r - u - h - p + o, c + l + f + a, r - u - h + o];
      case 90:
        return [c + h + a, r - u + l + o, c + h + p + a, r - u + l + f + o];
      case 180:
        return [c - l - f + a, r - u + h + o, c - l + a, r - u + h + p + o];
      case 270:
        return [c - h - p + a, r - u - l - f + o, c - h + a, r - u - l + o];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getRectInCurrentCoords(t, e) {
    const [s, i, n, r] = t, a = n - s, o = r - i;
    switch (this.rotation) {
      case 0:
        return [s, e - r, a, o];
      case 90:
        return [s, e - i, o, a];
      case 180:
        return [n, e - i, a, o];
      case 270:
        return [n, e - r, o, a];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getPDFRect() {
    return this.getRect(0, 0);
  }
  getNonHCMColor() {
    return this.color && I._colorManager.convert(this._uiManager.getNonHCMColor(this.color));
  }
  onUpdatedColor() {
    this.#i?.onUpdatedColor();
  }
  getData() {
    const {
      comment: {
        text: t,
        color: e,
        date: s,
        opacity: i,
        deleted: n,
        richText: r
      },
      uid: a,
      pageIndex: o,
      creationDate: l,
      modificationDate: h
    } = this;
    return {
      id: a,
      pageIndex: o,
      rect: this.getPDFRect(),
      richText: r,
      contentsObj: {
        str: t
      },
      creationDate: l,
      modificationDate: s || h,
      popupRef: !n,
      color: e,
      opacity: i
    };
  }
  onceAdded(t) {
  }
  isEmpty() {
    return !1;
  }
  enableEditMode() {
    return this.isInEditMode() ? !1 : (this.parent.setEditingState(!1), this.#b = !0, !0);
  }
  disableEditMode() {
    return this.isInEditMode() ? (this.parent.setEditingState(!0), this.#b = !1, !0) : !1;
  }
  isInEditMode() {
    return this.#b;
  }
  shouldGetKeyboardEvents() {
    return this.#y;
  }
  needsToBeRebuilt() {
    return this.div && !this.isAttachedToDOM;
  }
  get isOnScreen() {
    const {
      top: t,
      left: e,
      bottom: s,
      right: i
    } = this.getClientDimensions(), {
      innerHeight: n,
      innerWidth: r
    } = window;
    return e < r && i > 0 && t < n && s > 0;
  }
  #U() {
    if (this.#f || !this.div)
      return;
    this.#f = new AbortController();
    const t = this._uiManager.combinedSignal(this.#f);
    this.div.addEventListener("focusin", this.focusin.bind(this), {
      signal: t
    }), this.div.addEventListener("focusout", this.focusout.bind(this), {
      signal: t
    });
  }
  #z() {
    this.#v || !this.div || !this.isResizable || !this._uiManager._supportsPinchToZoom || (this.#v = new sn({
      container: this.div,
      isPinchingDisabled: () => !this.isSelected,
      onPinchStart: this.#W.bind(this),
      onPinching: this.#H.bind(this),
      onPinchEnd: this.#j.bind(this),
      signal: this._uiManager._signal
    }));
  }
  rebuild() {
    this.#U(), this.#z();
  }
  rotate(t) {
  }
  resize() {
  }
  serializeDeleted() {
    return {
      id: this.annotationElementId,
      deleted: !0,
      pageIndex: this.pageIndex,
      popupRef: this._initialData?.popupRef || ""
    };
  }
  serialize(t = !1, e = null) {
    return {
      annotationType: this.mode,
      pageIndex: this.pageIndex,
      rect: this.getPDFRect(),
      rotation: this.rotation,
      structTreeParentId: this._structTreeParentId,
      popupRef: this._initialData?.popupRef || ""
    };
  }
  static async deserialize(t, e, s) {
    const i = new this.prototype.constructor({
      parent: e,
      id: s.getId(),
      uiManager: s,
      annotationElementId: t.annotationElementId,
      creationDate: t.creationDate,
      modificationDate: t.modificationDate
    });
    i.rotation = t.rotation, i.#t = t.accessibilityData, i._isCopy = t.isCopy || !1;
    const [n, r] = i.pageDimensions, [a, o, l, h] = i.getRectInCurrentCoords(t.rect, r);
    return i.x = a / n, i.y = o / r, i.width = l / n, i.height = h / r, i;
  }
  get hasBeenModified() {
    return !!this.annotationElementId && (this.deleted || this.serialize() !== null);
  }
  remove() {
    if (this.#f?.abort(), this.#f = null, this.isEmpty() || this.commit(), this.#v?.destroy(), this.#v = null, this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), this.hideCommentPopup(), this.#A && (clearTimeout(this.#A), this.#A = null), this.#L(), this.removeEditToolbar(), this.#_) {
      for (const t of this.#_.values())
        clearTimeout(t);
      this.#_ = null;
    }
    this.parent = null, this.#c?.remove(), this.#c = null;
  }
  get isResizable() {
    return !1;
  }
  makeResizable() {
    this.isResizable && (this.#P(), this.#l.classList.remove("hidden"));
  }
  get toolbarPosition() {
    return null;
  }
  get commentButtonPosition() {
    return this._uiManager.direction === "ltr" ? [1, 0] : [0, 0];
  }
  get commentButtonPositionInPage() {
    const {
      commentButtonPosition: [t, e]
    } = this, [s, i, n, r] = this.getPDFRect();
    return [I._round(s + (n - s) * t), I._round(i + (r - i) * (1 - e))];
  }
  get commentButtonColor() {
    return this._uiManager.makeCommentColor(this.getNonHCMColor(), this.opacity);
  }
  get commentPopupPosition() {
    return this.#i.commentPopupPositionInLayer;
  }
  set commentPopupPosition(t) {
    this.#i.commentPopupPositionInLayer = t;
  }
  hasDefaultPopupPosition() {
    return this.#i.hasDefaultPopupPosition();
  }
  get commentButtonWidth() {
    return this.#i.commentButtonWidth;
  }
  get elementBeforePopup() {
    return this.div;
  }
  setCommentButtonStates(t) {
    this.#i?.setCommentButtonStates(t);
  }
  keydown(t) {
    if (!this.isResizable || t.target !== this.div || t.key !== "Enter")
      return;
    this._uiManager.setSelected(this), this.#u = {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    };
    const e = this.#l.children;
    if (!this.#e) {
      this.#e = Array.from(e);
      const r = this.#V.bind(this), a = this.#q.bind(this), o = this._uiManager._signal;
      for (const l of this.#e) {
        const h = l.getAttribute("data-resizer-name");
        l.setAttribute("role", "spinbutton"), l.addEventListener("keydown", r, {
          signal: o
        }), l.addEventListener("blur", a, {
          signal: o
        }), l.addEventListener("focus", this.#Y.bind(this, h), {
          signal: o
        }), l.setAttribute("data-l10n-id", I._l10nResizer[h]);
      }
    }
    const s = this.#e[0];
    let i = 0;
    for (const r of e) {
      if (r === s)
        break;
      i++;
    }
    const n = (360 - this.rotation + this.parentRotation) % 360 / 90 * (this.#e.length / 4);
    if (n !== i) {
      if (n < i)
        for (let a = 0; a < i - n; a++)
          this.#l.append(this.#l.firstElementChild);
      else if (n > i)
        for (let a = 0; a < n - i; a++)
          this.#l.firstElementChild.before(this.#l.lastElementChild);
      let r = 0;
      for (const a of e) {
        const l = this.#e[r++].getAttribute("data-resizer-name");
        a.setAttribute("data-l10n-id", I._l10nResizer[l]);
      }
    }
    this.#K(0), this.#y = !0, this.#l.firstElementChild.focus({
      focusVisible: !0
    }), t.preventDefault(), t.stopImmediatePropagation();
  }
  #V(t) {
    I._resizerKeyboardManager.exec(this, t);
  }
  #q(t) {
    this.#y && t.relatedTarget?.parentNode !== this.#l && this.#L();
  }
  #Y(t) {
    this.#p = this.#y ? t : "";
  }
  #K(t) {
    if (this.#e)
      for (const e of this.#e)
        e.tabIndex = t;
  }
  _resizeWithKeyboard(t, e) {
    this.#y && this.#B(this.#p, {
      deltaX: t,
      deltaY: e,
      fromKeyboard: !0
    });
  }
  #L() {
    this.#y = !1, this.#K(-1), this.#F();
  }
  _stopResizingWithKeyboard() {
    this.#L(), this.div.focus();
  }
  select() {
    if (this.isSelected && this._editToolbar) {
      this._editToolbar.show();
      return;
    }
    if (this.isSelected = !0, this.makeResizable(), this.div?.classList.add("selectedEditor"), !this._editToolbar) {
      this.addEditToolbar().then(() => {
        this.div?.classList.contains("selectedEditor") && this.#N();
      });
      return;
    }
    this.#N(), this.#s?.toggleAltTextBadge(!1);
  }
  #N() {
    this._editToolbar?.show(), this._uiManager._keepToolbarInPage && (this.fixAndSetPosition(), this._onTranslated());
  }
  focus() {
    this.div && !this.div.contains(document.activeElement) && setTimeout(() => this.div?.focus({
      preventScroll: !0
    }), 0);
  }
  unselect() {
    this.isSelected && (this.isSelected = !1, this.#l?.classList.add("hidden"), this.div?.classList.remove("selectedEditor"), this.div?.contains(document.activeElement) && this._uiManager.currentLayer.div.focus({
      preventScroll: !0
    }), this._editToolbar?.hide(), this.#s?.toggleAltTextBadge(!0), this.hideCommentPopup());
  }
  hideCommentPopup() {
    this.hasComment && this._uiManager.toggleComment(null);
  }
  updateParams(t, e) {
  }
  disableEditing() {
  }
  enableEditing() {
  }
  get canChangeContent() {
    return !1;
  }
  enterInEditMode() {
    this.canChangeContent && (this.enableEditMode(), this.div.focus());
  }
  dblclick(t) {
    t.target.nodeName !== "BUTTON" && (this.enterInEditMode(), this.parent.updateToolbar({
      mode: this.constructor._editorType,
      editId: this.uid
    }));
  }
  getElementForAltText() {
    return this.div;
  }
  get contentDiv() {
    return this.div;
  }
  get isEditing() {
    return this.#g;
  }
  set isEditing(t) {
    this.#g = t, this.parent && (t ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
  }
  static get MIN_SIZE() {
    return 16;
  }
  static canCreateNewEmptyEditor() {
    return !0;
  }
  get telemetryInitialData() {
    return {
      action: "added"
    };
  }
  get telemetryFinalData() {
    return null;
  }
  _reportTelemetry(t, e = !1) {
    if (e) {
      this.#_ ||= /* @__PURE__ */ new Map();
      const {
        action: s
      } = t;
      let i = this.#_.get(s);
      i && clearTimeout(i), i = setTimeout(() => {
        this._reportTelemetry(t), this.#_.delete(s), this.#_.size === 0 && (this.#_ = null);
      }, I._telemetryTimeout), this.#_.set(s, i);
      return;
    }
    t.type ||= this.editorType, this._uiManager._eventBus.dispatch("reporttelemetry", {
      source: this,
      details: {
        type: "editing",
        data: t
      }
    });
  }
  show(t = this._isVisible) {
    this.div.classList.toggle("hidden", !t), this._isVisible = t;
  }
  enable() {
    this.div && (this.div.tabIndex = 0), this.#r = !1;
  }
  disable() {
    this.div && (this.div.tabIndex = -1), this.#r = !0;
  }
  updateFakeAnnotationElement(t) {
    if (!this.#c && !this.deleted) {
      this.#c = t.addFakeAnnotation(this);
      return;
    }
    if (this.deleted) {
      this.#c.remove(), this.#c = null;
      return;
    }
    (this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized) && this.#c.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    });
  }
  renderAnnotationElement(t) {
    if (this.deleted)
      return t.hide(), null;
    let e = t.container.querySelector(".annotationContent");
    if (!e)
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), t.container.prepend(e);
    else if (e.nodeName === "CANVAS") {
      const s = e;
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), s.before(e);
    }
    return e;
  }
  resetAnnotationElement(t) {
    const {
      firstElementChild: e
    } = t.container;
    e?.nodeName === "DIV" && e.classList.contains("annotationContent") && e.remove();
  }
}
class sr extends I {
  constructor(t) {
    super(t), this.annotationElementId = t.annotationElementId, this.deleted = !0;
  }
  serialize() {
    return this.serializeDeleted();
  }
}
const Ei = 3285377520, vt = 4294901760, Pt = 65535;
class Gs {
  constructor(t) {
    this.h1 = t ? t & 4294967295 : Ei, this.h2 = t ? t & 4294967295 : Ei;
  }
  update(t) {
    let e, s;
    if (typeof t == "string") {
      e = new Uint8Array(t.length * 2), s = 0;
      for (let g = 0, m = t.length; g < m; g++) {
        const b = t.charCodeAt(g);
        b <= 255 ? e[s++] = b : (e[s++] = b >>> 8, e[s++] = b & 255);
      }
    } else if (ArrayBuffer.isView(t))
      e = t.slice(), s = e.byteLength;
    else
      throw new Error("Invalid data format, must be a string or TypedArray.");
    const i = s >> 2, n = s - i * 4, r = new Uint32Array(e.buffer, 0, i);
    let a = 0, o = 0, l = this.h1, h = this.h2;
    const c = 3432918353, u = 461845907, f = c & Pt, p = u & Pt;
    for (let g = 0; g < i; g++)
      g & 1 ? (a = r[g], a = a * c & vt | a * f & Pt, a = a << 15 | a >>> 17, a = a * u & vt | a * p & Pt, l ^= a, l = l << 13 | l >>> 19, l = l * 5 + 3864292196) : (o = r[g], o = o * c & vt | o * f & Pt, o = o << 15 | o >>> 17, o = o * u & vt | o * p & Pt, h ^= o, h = h << 13 | h >>> 19, h = h * 5 + 3864292196);
    switch (a = 0, n) {
      case 3:
        a ^= e[i * 4 + 2] << 16;
      case 2:
        a ^= e[i * 4 + 1] << 8;
      case 1:
        a ^= e[i * 4], a = a * c & vt | a * f & Pt, a = a << 15 | a >>> 17, a = a * u & vt | a * p & Pt, i & 1 ? l ^= a : h ^= a;
    }
    this.h1 = l, this.h2 = h;
  }
  hexdigest() {
    let t = this.h1, e = this.h2;
    return t ^= e >>> 1, t = t * 3981806797 & vt | t * 36045 & Pt, e = e * 4283543511 & vt | ((e << 16 | t >>> 16) * 2950163797 & vt) >>> 16, t ^= e >>> 1, t = t * 444984403 & vt | t * 60499 & Pt, e = e * 3301882366 & vt | ((e << 16 | t >>> 16) * 3120437893 & vt) >>> 16, t ^= e >>> 1, (t >>> 0).toString(16).padStart(8, "0") + (e >>> 0).toString(16).padStart(8, "0");
  }
}
const Ie = Object.freeze({
  map: null,
  hash: "",
  transfer: void 0
});
class ti {
  #t = !1;
  #e = null;
  #s = null;
  #i = /* @__PURE__ */ new Map();
  onSetModified = null;
  onResetModified = null;
  onAnnotationEditor = null;
  getValue(t, e) {
    const s = this.#i.get(t);
    return s === void 0 ? e : Object.assign(e, s);
  }
  getRawValue(t) {
    return this.#i.get(t);
  }
  remove(t) {
    const e = this.#i.get(t);
    e !== void 0 && (e instanceof I && this.#s.delete(e.annotationElementId), this.#i.delete(t), this.#i.size === 0 && this.resetModified(), !this.#i.values().some((s) => s instanceof I) && this.onAnnotationEditor?.(null));
  }
  setValue(t, e) {
    const s = this.#i.get(t);
    let i = !1;
    if (s !== void 0)
      for (const [n, r] of Object.entries(e))
        s[n] !== r && (i = !0, s[n] = r);
    else
      i = !0, this.#i.set(t, e);
    i && this.#n(), e instanceof I && ((this.#s ||= /* @__PURE__ */ new Map()).set(e.annotationElementId, e), this.onAnnotationEditor?.(e.constructor._type));
  }
  has(t) {
    return this.#i.has(t);
  }
  get size() {
    return this.#i.size;
  }
  #n() {
    this.#t || (this.#t = !0, this.onSetModified?.());
  }
  resetModified() {
    this.#t && (this.#t = !1, this.onResetModified?.());
  }
  get print() {
    return new nn(this);
  }
  get serializable() {
    if (this.#i.size === 0)
      return Ie;
    const t = /* @__PURE__ */ new Map(), e = new Gs(), s = [], i = /* @__PURE__ */ Object.create(null);
    let n = !1;
    for (const [r, a] of this.#i) {
      const o = a instanceof I ? a.serialize(!1, i) : a;
      a.page && (a.pageIndex = a.page._pageIndex, delete a.page), o && (t.set(r, o), e.update(`${r}:${JSON.stringify(o)}`), n ||= !!o.bitmap);
    }
    if (n)
      for (const r of t.values())
        r.bitmap && s.push(r.bitmap);
    return t.size > 0 ? {
      map: t,
      hash: e.hexdigest(),
      transfer: s
    } : Ie;
  }
  get editorStats() {
    let t = null;
    const e = /* @__PURE__ */ new Map();
    let s = 0, i = 0;
    for (const n of this.#i.values()) {
      if (!(n instanceof I)) {
        n.popup && (n.popup.deleted ? i += 1 : s += 1);
        continue;
      }
      n.isCommentDeleted ? i += 1 : n.hasEditedComment && (s += 1);
      const r = n.telemetryFinalData;
      if (!r)
        continue;
      const {
        type: a
      } = r;
      e.getOrInsertComputed(a, () => Object.getPrototypeOf(n).constructor), t ||= /* @__PURE__ */ Object.create(null);
      const o = t[a] ||= /* @__PURE__ */ new Map();
      for (const [l, h] of Object.entries(r)) {
        if (l === "type")
          continue;
        const c = o.getOrInsertComputed(l, ss);
        c.set(h, (c.get(h) ?? 0) + 1);
      }
    }
    if ((i > 0 || s > 0) && (t ||= /* @__PURE__ */ Object.create(null), t.comments = {
      deleted: i,
      edited: s
    }), !t)
      return null;
    for (const [n, r] of e)
      t[n] = r.computeTelemetryFinalData(t[n]);
    return t;
  }
  resetModifiedIds() {
    this.#e = null;
  }
  updateEditor(t, e) {
    const s = this.#s?.get(t);
    return s ? (s.updateFromAnnotationLayer(e), !0) : !1;
  }
  getEditor(t) {
    return this.#s?.get(t) || null;
  }
  get modifiedIds() {
    if (this.#e)
      return this.#e;
    const t = [];
    if (this.#s)
      for (const s of this.#s.values())
        s.serialize() && t.push(s.annotationElementId);
    let e = "";
    if (t.length) {
      const s = new Gs();
      s.update(t.join(",")), e = s.hexdigest();
    }
    return this.#e = {
      ids: new Set(t),
      hash: e
    };
  }
  [Symbol.iterator]() {
    return this.#i.entries();
  }
}
class nn extends ti {
  #t = Ie;
  constructor(t) {
    super();
    const {
      serializable: e
    } = t;
    if (e === Ie)
      return;
    const {
      map: s,
      hash: i,
      transfer: n
    } = e, r = structuredClone(s, n ? {
      transfer: n
    } : null);
    this.#t = {
      map: r,
      hash: i,
      transfer: []
    };
  }
  get print() {
    j("Should not call PrintAnnotationStorage.print");
  }
  get serializable() {
    return this.#t;
  }
  get modifiedIds() {
    return k(this, "modifiedIds", {
      ids: /* @__PURE__ */ new Set(),
      hash: ""
    });
  }
}
function ir(d) {
  if (d instanceof URL)
    return d;
  if (typeof d == "string") {
    if (bt) {
      if (/^[a-z][a-z0-9\-+.]+:/i.test(d))
        return new URL(d);
      const e = process.getBuiltinModule("url");
      return new URL(e.pathToFileURL(d));
    }
    const t = URL.parse(d, window.location);
    if (t)
      return t;
  }
  throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
}
function nr(d) {
  if (bt && typeof Buffer < "u" && d instanceof Buffer)
    throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
  if (d instanceof Uint8Array && d.byteLength === d.buffer.byteLength)
    return d;
  if (typeof d == "string")
    return cs(d);
  if (d instanceof ArrayBuffer || ArrayBuffer.isView(d) || typeof d == "object" && !isNaN(d?.length))
    return new Uint8Array(d);
  throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
}
function Ge(d) {
  if (typeof d != "string")
    return null;
  if (d.endsWith("/"))
    return d;
  throw new Error(`Invalid factory url: "${d}" must include trailing slash.`);
}
const js = (d) => typeof d == "object" && Number.isInteger(d?.num) && d.num >= 0 && Number.isInteger(d?.gen) && d.gen >= 0, rr = (d) => typeof d == "object" && typeof d?.name == "string", ar = Gn.bind(null, js, rr);
function or(d, t) {
  const e = URL.parse(d);
  if (!e?.origin || e.origin === "null")
    return !1;
  const s = new URL(t, e);
  return e.origin === s.origin;
}
function rn(d) {
  if (!or(window.location, d)) {
    const t = `await import("${new URL(d, window.location).href}");`;
    return URL.createObjectURL(new Blob([t], {
      type: "text/javascript"
    }));
  }
  return d;
}
class lr {
  #t = /* @__PURE__ */ new Map();
  #e = Promise.resolve();
  postMessage(t, e) {
    const s = {
      data: structuredClone(t, e ? {
        transfer: e
      } : null)
    };
    this.#e.then(() => {
      for (const [i] of this.#t)
        i.call(this, s);
    });
  }
  addEventListener(t, e, s = null) {
    let i = null;
    if (s?.signal instanceof AbortSignal) {
      const {
        signal: n
      } = s;
      if (n.aborted) {
        R("LoopbackPort - cannot use an `aborted` signal.");
        return;
      }
      const r = () => this.removeEventListener(t, e);
      i = () => n.removeEventListener("abort", r), n.addEventListener("abort", r);
    }
    this.#t.set(e, i);
  }
  removeEventListener(t, e) {
    this.#t.get(e)?.(), this.#t.delete(e);
  }
  terminate() {
    for (const [, t] of this.#t)
      t?.();
    this.#t.clear();
  }
}
class xi {
  #t = /* @__PURE__ */ new Map();
  times = [];
  time(t) {
    this.#t.has(t) && R(`Timer is already running for ${t}`), this.#t.set(t, Date.now());
  }
  timeEnd(t) {
    this.#t.has(t) || R(`Timer has not been started for ${t}`), this.times.push({
      name: t,
      start: this.#t.get(t),
      end: Date.now()
    }), this.#t.delete(t);
  }
  toString() {
    const t = Math.max(...this.times.map((e) => e.name.length));
    return this.times.map((e) => `${e.name.padEnd(t)} ${e.end - e.start}ms
`).join("");
  }
}
const hr = `
struct Uniforms {
  offsetX      : f32,
  offsetY      : f32,
  scaleX       : f32,
  scaleY       : f32,
  paddedWidth  : f32,
  paddedHeight : f32,
  borderSize   : f32,
  _pad         : f32,
};

@group(0) @binding(0) var<uniform> u : Uniforms;

struct VertexInput {
  @location(0) position : vec2<f32>,
  @location(1) color    : vec4<f32>,
};

struct VertexOutput {
  @builtin(position) position : vec4<f32>,
  @location(0)       color    : vec3<f32>,
};

@vertex
fn vs_main(in : VertexInput) -> VertexOutput {
  var out : VertexOutput;
  let cx = (in.position.x + u.offsetX) * u.scaleX;
  let cy = (in.position.y + u.offsetY) * u.scaleY;
  out.position = vec4<f32>(
    ((cx + u.borderSize) / u.paddedWidth) * 2.0 - 1.0,
    1.0 - ((cy + u.borderSize) / u.paddedHeight) * 2.0,
    0.0,
    1.0
  );
  out.color = in.color.rgb;
  return out;
}

@fragment
fn fs_main(in : VertexOutput) -> @location(0) vec4<f32> {
  return vec4<f32>(in.color, 1.0);
}
`;
class cr {
  #t = null;
  #e = null;
  #s = null;
  #i = null;
  async #n() {
    if (!globalThis.navigator?.gpu)
      return !1;
    try {
      const t = await navigator.gpu.requestAdapter();
      return t ? (this.#i = navigator.gpu.getPreferredCanvasFormat(), this.#e = await t.requestDevice(), !0) : !1;
    } catch {
      return !1;
    }
  }
  init() {
    return this.#t ||= this.#n();
  }
  get isReady() {
    return this.#e !== null;
  }
  loadMeshShader() {
    if (!this.#e || this.#s)
      return;
    const t = this.#e.createShaderModule({
      code: hr
    });
    this.#s = this.#e.createRenderPipeline({
      layout: "auto",
      vertex: {
        module: t,
        entryPoint: "vs_main",
        buffers: [{
          arrayStride: 8,
          attributes: [{
            shaderLocation: 0,
            offset: 0,
            format: "float32x2"
          }]
        }, {
          arrayStride: 4,
          attributes: [{
            shaderLocation: 1,
            offset: 0,
            format: "unorm8x4"
          }]
        }]
      },
      fragment: {
        module: t,
        entryPoint: "fs_main",
        targets: [{
          format: this.#i
        }]
      },
      primitive: {
        topology: "triangle-list"
      }
    });
  }
  draw(t, e, s, i, n, r, a, o) {
    this.loadMeshShader();
    const l = this.#e, {
      offsetX: h,
      offsetY: c,
      scaleX: u,
      scaleY: f
    } = i, p = l.createBuffer({
      size: Math.max(t.byteLength, 4),
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
    });
    t.byteLength > 0 && l.queue.writeBuffer(p, 0, t);
    const g = l.createBuffer({
      size: Math.max(e.byteLength, 4),
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
    });
    e.byteLength > 0 && l.queue.writeBuffer(g, 0, e);
    const m = l.createBuffer({
      size: 32,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
    });
    l.queue.writeBuffer(m, 0, new Float32Array([h, c, u, f, r, a, o, 0]));
    const b = l.createBindGroup({
      layout: this.#s.getBindGroupLayout(0),
      entries: [{
        binding: 0,
        resource: {
          buffer: m
        }
      }]
    }), y = new OffscreenCanvas(r, a), A = y.getContext("webgpu");
    A.configure({
      device: l,
      format: this.#i,
      alphaMode: n ? "opaque" : "premultiplied"
    });
    const w = n ? {
      r: n[0] / 255,
      g: n[1] / 255,
      b: n[2] / 255,
      a: 1
    } : {
      r: 0,
      g: 0,
      b: 0,
      a: 0
    }, v = l.createCommandEncoder(), S = v.beginRenderPass({
      colorAttachments: [{
        view: A.getCurrentTexture().createView(),
        clearValue: w,
        loadOp: "clear",
        storeOp: "store"
      }]
    });
    return s > 0 && (S.setPipeline(this.#s), S.setBindGroup(0, b), S.setVertexBuffer(0, p), S.setVertexBuffer(1, g), S.draw(s)), S.end(), l.queue.submit([v.finish()]), p.destroy(), g.destroy(), m.destroy(), y.transferToImageBitmap();
  }
}
const us = new cr();
function an() {
  return us.init();
}
function on() {
  return us.isReady;
}
function dr() {
  us.loadMeshShader();
}
function ur(d, t, e, s, i, n, r, a) {
  return us.draw(d, t, e, s, i, n, r, a);
}
const je = {
  DATA: 1,
  ERROR: 2
}, Z = {
  CANCEL: 1,
  CANCEL_COMPLETE: 2,
  CLOSE: 3,
  ENQUEUE: 4,
  ERROR: 5,
  PULL: 6,
  PULL_COMPLETE: 7,
  START_COMPLETE: 8
};
function Ti() {
}
function ut(d) {
  if (d instanceof Yt || d instanceof Rs || d instanceof Os || d instanceof es || d instanceof He)
    return d;
  if (typeof d != "object" || d === null)
    return new He(String(d), String(d));
  switch (d.name) {
    case "AbortException":
      return new Yt(d.message);
    case "InvalidPDFException":
      return new Rs(d.message);
    case "PasswordException":
      return new Os(d.message, d.code);
    case "ResponseException":
      return new es(d.message, d.status, d.missing);
    case "UnknownErrorException":
      return new He(d.message, d.details);
  }
  return new He(d.message, d.toString());
}
class Vt {
  #t = /* @__PURE__ */ new Map();
  #e = /* @__PURE__ */ new Map();
  #s = 1;
  #i;
  #n = new AbortController();
  #r;
  #a = /* @__PURE__ */ new Map();
  #o = 1;
  #l = /* @__PURE__ */ new Map();
  #h;
  constructor(t, e, s) {
    this.#r = t, this.#h = e, this.#i = s, s.addEventListener("message", this.#u.bind(this), {
      signal: this.#n.signal
    });
  }
  #u({
    data: t
  }) {
    if (t.targetName !== this.#r)
      return;
    if (t.stream) {
      this.#f(t);
      return;
    }
    if (t.callback) {
      const {
        callbackId: s,
        callback: i
      } = t, n = this.#e.get(s);
      if (!n)
        throw new Error(`Cannot resolve callback ${s}`);
      if (this.#e.delete(s), i === je.DATA)
        n.resolve(t.data);
      else if (i === je.ERROR)
        n.reject(ut(t.reason));
      else
        throw new Error("Unexpected callback case");
      return;
    }
    const e = this.#t.get(t.action);
    if (!e)
      throw new Error(`Unknown action from worker: ${t.action}`);
    if (t.callbackId) {
      const s = this.#r, i = t.sourceName, n = this.#i;
      Promise.try(e, t.data).then((r) => {
        n.postMessage({
          sourceName: s,
          targetName: i,
          callback: je.DATA,
          callbackId: t.callbackId,
          data: r
        });
      }).catch((r) => {
        n.postMessage({
          sourceName: s,
          targetName: i,
          callback: je.ERROR,
          callbackId: t.callbackId,
          reason: ut(r)
        });
      });
      return;
    }
    if (t.streamId) {
      this.#c(t);
      return;
    }
    e(t.data);
  }
  on(t, e) {
    const s = this.#t;
    if (s.has(t))
      throw new Error(`There is already a "${t}" handler.`);
    s.set(t, e);
  }
  send(t, e, s) {
    this.#i.postMessage({
      sourceName: this.#r,
      targetName: this.#h,
      action: t,
      data: e
    }, s);
  }
  sendWithPromise(t, e, s) {
    const i = this.#s++, n = Promise.withResolvers();
    this.#e.set(i, n);
    try {
      this.#i.postMessage({
        sourceName: this.#r,
        targetName: this.#h,
        action: t,
        callbackId: i,
        data: e
      }, s);
    } catch (r) {
      n.reject(r);
    }
    return n.promise;
  }
  sendWithStream(t, e, s, i) {
    const n = this.#o++, r = this.#r, a = this.#h, o = this.#i;
    return new ReadableStream({
      start: (l) => {
        const h = Promise.withResolvers();
        return this.#a.set(n, {
          controller: l,
          startCall: h,
          pullCall: null,
          cancelCall: null,
          isClosed: !1
        }), o.postMessage({
          sourceName: r,
          targetName: a,
          action: t,
          streamId: n,
          data: e,
          desiredSize: l.desiredSize
        }, i), h.promise;
      },
      pull: (l) => {
        const h = Promise.withResolvers();
        return this.#a.get(n).pullCall = h, o.postMessage({
          sourceName: r,
          targetName: a,
          stream: Z.PULL,
          streamId: n,
          desiredSize: l.desiredSize
        }), h.promise;
      },
      cancel: (l) => {
        J(l instanceof Error, "cancel must have a valid reason");
        const h = Promise.withResolvers();
        return this.#a.get(n).cancelCall = h, this.#a.get(n).isClosed = !0, o.postMessage({
          sourceName: r,
          targetName: a,
          stream: Z.CANCEL,
          streamId: n,
          reason: ut(l)
        }), h.promise;
      }
    }, s);
  }
  #c(t) {
    const e = t.streamId, s = this.#r, i = t.sourceName, n = this.#i, r = this.#l, a = this.#t.get(t.action), o = {
      enqueue(l, h = 1, c) {
        if (this.isCancelled)
          return;
        const u = this.desiredSize;
        this.desiredSize -= h, u > 0 && this.desiredSize <= 0 && (this.sinkCapability = Promise.withResolvers(), this.ready = this.sinkCapability.promise), n.postMessage({
          sourceName: s,
          targetName: i,
          stream: Z.ENQUEUE,
          streamId: e,
          chunk: l
        }, c);
      },
      close() {
        this.isCancelled || (this.isCancelled = !0, n.postMessage({
          sourceName: s,
          targetName: i,
          stream: Z.CLOSE,
          streamId: e
        }), r.delete(e));
      },
      error(l) {
        this.isCancelled || (this.isCancelled = !0, n.postMessage({
          sourceName: s,
          targetName: i,
          stream: Z.ERROR,
          streamId: e,
          reason: ut(l)
        }));
      },
      sinkCapability: Promise.withResolvers(),
      onPull: null,
      onCancel: null,
      isCancelled: !1,
      desiredSize: t.desiredSize,
      ready: null
    };
    o.sinkCapability.resolve(), o.ready = o.sinkCapability.promise, r.set(e, o), Promise.try(a, t.data, o).then(() => {
      n.postMessage({
        sourceName: s,
        targetName: i,
        stream: Z.START_COMPLETE,
        streamId: e,
        success: !0
      });
    }, (l) => {
      n.postMessage({
        sourceName: s,
        targetName: i,
        stream: Z.START_COMPLETE,
        streamId: e,
        reason: ut(l)
      });
    });
  }
  #f(t) {
    const e = t.streamId, s = this.#r, i = t.sourceName, n = this.#i, r = this.#a.get(e), a = this.#l.get(e);
    switch (t.stream) {
      case Z.START_COMPLETE:
        t.success ? r.startCall.resolve() : r.startCall.reject(ut(t.reason));
        break;
      case Z.PULL_COMPLETE:
        t.success ? r.pullCall.resolve() : r.pullCall.reject(ut(t.reason));
        break;
      case Z.PULL:
        if (!a) {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: Z.PULL_COMPLETE,
            streamId: e,
            success: !0
          });
          break;
        }
        a.desiredSize <= 0 && t.desiredSize > 0 && a.sinkCapability.resolve(), a.desiredSize = t.desiredSize, Promise.try(a.onPull || Ti).then(() => {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: Z.PULL_COMPLETE,
            streamId: e,
            success: !0
          });
        }, (l) => {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: Z.PULL_COMPLETE,
            streamId: e,
            reason: ut(l)
          });
        });
        break;
      case Z.ENQUEUE:
        if (J(r, "enqueue should have stream controller"), r.isClosed)
          break;
        r.controller.enqueue(t.chunk);
        break;
      case Z.CLOSE:
        if (J(r, "close should have stream controller"), r.isClosed)
          break;
        r.isClosed = !0, r.controller.close(), this.#p(r, e);
        break;
      case Z.ERROR:
        J(r, "error should have stream controller"), r.controller.error(ut(t.reason)), this.#p(r, e);
        break;
      case Z.CANCEL_COMPLETE:
        t.success ? r.cancelCall.resolve() : r.cancelCall.reject(ut(t.reason)), this.#p(r, e);
        break;
      case Z.CANCEL:
        if (!a)
          break;
        const o = ut(t.reason);
        Promise.try(a.onCancel || Ti, o).then(() => {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: Z.CANCEL_COMPLETE,
            streamId: e,
            success: !0
          });
        }, (l) => {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: Z.CANCEL_COMPLETE,
            streamId: e,
            reason: ut(l)
          });
        }), a.sinkCapability.reject(o), a.isCancelled = !0, this.#l.delete(e);
        break;
      default:
        throw new Error("Unexpected stream case");
    }
  }
  async #p(t, e) {
    await Promise.allSettled([t.startCall?.promise, t.pullCall?.promise, t.cancelCall?.promise]), this.#a.delete(e);
  }
  destroy() {
    this.#n?.abort(), this.#n = null;
  }
  get destroyed() {
    return !this.#n;
  }
}
class ln {
  #t = Object.freeze({
    cMapUrl: "CMap",
    standardFontDataUrl: "font",
    wasmUrl: "wasm"
  });
  constructor({
    cMapUrl: t = null,
    standardFontDataUrl: e = null,
    wasmUrl: s = null
  }) {
    this.cMapUrl = t, this.standardFontDataUrl = e, this.wasmUrl = s;
  }
  async fetch({
    kind: t,
    filename: e
  }) {
    switch (t) {
      case "cMapUrl":
      case "standardFontDataUrl":
      case "wasmUrl":
        break;
      default:
        j(`Not implemented: ${t}`);
    }
    const s = this[t];
    if (!s)
      throw new Error(`Ensure that the \`${t}\` API parameter is provided.`);
    const i = `${s}${e}`;
    return this._fetch(i, t).catch((n) => {
      throw new Error(`Unable to load ${this.#t[t]} data at: ${i}`);
    });
  }
  async _fetch(t, e) {
    j("Abstract method `_fetch` called.");
  }
}
class ki extends ln {
  async _fetch(t, e) {
    const s = e === "cMapUrl" && !t.endsWith(".bcmap") ? "text" : "bytes", i = await qs(t, s);
    return i instanceof Uint8Array ? i : cs(i);
  }
}
class hn {
  #t = !1;
  constructor({
    enableHWA: t = !1
  }) {
    this.#t = t;
  }
  create(t, e) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid canvas size");
    const s = this._createCanvas(t, e);
    return {
      canvas: s,
      context: s.getContext("2d", {
        willReadFrequently: !this.#t
      })
    };
  }
  reset({
    canvas: t
  }, e, s) {
    if (!t)
      throw new Error("Canvas is not specified");
    if (e <= 0 || s <= 0)
      throw new Error("Invalid canvas size");
    t.width = e, t.height = s;
  }
  destroy(t) {
    const {
      canvas: e
    } = t;
    if (!e)
      throw new Error("Canvas is not specified");
    e.width = e.height = 0, t.canvas = null, t.context = null;
  }
  getNoAlphaContext(t) {
    return t.getContext("2d", {
      alpha: !1,
      willReadFrequently: !this.#t
    });
  }
  _createCanvas(t, e) {
    j("Abstract method `_createCanvas` called.");
  }
}
class cn {
  addFilter(t) {
    return "none";
  }
  addHCMFilter(t, e) {
    return "none";
  }
  addAlphaFilter(t) {
    return "none";
  }
  addLuminosityFilter(t) {
    return "none";
  }
  addKnockoutFilter(t = 0) {
    return "none";
  }
  addHighlightHCMFilter(t, e, s, i, n) {
    return "none";
  }
  addSelectionHCMFilter(t, e) {
    return "none";
  }
  addSelectionFilter() {
    return "none";
  }
  createSelectionStyle(t = null) {
    return null;
  }
  destroy(t = !1) {
  }
}
bt && R("Please use the `legacy` build in Node.js environments.");
async function fr(d) {
  const e = await process.getBuiltinModule("fs/promises").readFile(d);
  return new Uint8Array(e);
}
class pr extends cn {
}
class gr extends hn {
  _createCanvas(t, e) {
    return process.getBuiltinModule("module").createRequire(import.meta.url)("@napi-rs/canvas").createCanvas(t, e);
  }
}
class mr extends ln {
  async _fetch(t, e) {
    return fr(t);
  }
}
const de = "__forcedDependency", {
  floor: Pi,
  ceil: Mi
} = Math;
function Ii(d, t, e, s, i, n) {
  d[t * 4 + 0] = Math.min(d[t * 4 + 0], e), d[t * 4 + 1] = Math.min(d[t * 4 + 1], s), d[t * 4 + 2] = Math.max(d[t * 4 + 2], i), d[t * 4 + 3] = Math.max(d[t * 4 + 3], n);
}
function br(d, t, e, s, i) {
  let n;
  d ? (d < 0 && (n = i[0], i[0] = i[2], i[2] = n), i[0] *= d, i[2] *= d, t < 0 && (n = i[1], i[1] = i[3], i[3] = n), i[1] *= t, i[3] *= t) : i.fill(0), i[0] += e, i[1] += s, i[2] += e, i[3] += s;
}
const zs = new Uint32Array(new Uint8Array([255, 255, 0, 0]).buffer)[0];
class fs {
  #t;
  #e;
  constructor(t, e) {
    this.#t = t, this.#e = e;
  }
  static fromBuffer(t) {
    return new fs(new Uint32Array(t), new Uint8ClampedArray(t));
  }
  get buffer() {
    return this.#t.buffer;
  }
  get length() {
    return this.#t.length;
  }
  isEmpty(t) {
    return this.#t[t] === zs;
  }
  minX(t) {
    return this.#e[t * 4 + 0] / 256;
  }
  minY(t) {
    return this.#e[t * 4 + 1] / 256;
  }
  maxX(t) {
    return (this.#e[t * 4 + 2] + 1) / 256;
  }
  maxY(t) {
    return (this.#e[t * 4 + 3] + 1) / 256;
  }
}
const Di = (d, t) => d?.getOrInsertComputed(t, () => ({
  dependencies: /* @__PURE__ */ new Set(),
  isRenderingOperation: !1
}));
class yr {
  #t = [[1, 0, 0, 1, 0, 0]];
  #e = [-1 / 0, -1 / 0, 1 / 0, 1 / 0];
  #s = new Float64Array(Dt);
  _pendingBBoxIdx = -1;
  #i;
  #n;
  #r;
  #a;
  _savesStack = [];
  _markedContentStack = [];
  constructor(t, e) {
    this.#i = t.width, this.#n = t.height, this.#o(e);
  }
  growOperationsCount(t) {
    t >= this.#a.length && this.#o(t, this.#a);
  }
  #o(t, e) {
    const s = new ArrayBuffer(t * 4);
    this.#r = new Uint8ClampedArray(s), this.#a = new Uint32Array(s), e && e.length > 0 ? (this.#a.set(e), this.#a.fill(zs, e.length)) : this.#a.fill(zs);
  }
  get clipBox() {
    return this.#e;
  }
  save(t) {
    return this.#e = {
      __proto__: this.#e
    }, this._savesStack.push(t), this;
  }
  restore(t, e) {
    const s = Object.getPrototypeOf(this.#e);
    if (s === null)
      return this;
    this.#e = s;
    const i = this._savesStack.pop();
    return i !== void 0 && (e?.(i, t), this.#a[t] = this.#a[i]), this;
  }
  recordOpenMarker(t) {
    return this._savesStack.push(t), this;
  }
  getOpenMarker() {
    return this._savesStack.length === 0 ? null : this._savesStack.at(-1);
  }
  recordCloseMarker(t, e) {
    const s = this._savesStack.pop();
    return s !== void 0 && (e?.(s, t), this.#a[t] = this.#a[s]), this;
  }
  beginMarkedContent(t) {
    return this._markedContentStack.push(t), this;
  }
  endMarkedContent(t, e) {
    const s = this._markedContentStack.pop();
    return s !== void 0 && (e?.(s, t), this.#a[t] = this.#a[s]), this;
  }
  pushBaseTransform(t) {
    return this.#t.push(x.multiplyByDOMMatrix(this.#t.at(-1), t.getTransform())), this;
  }
  popBaseTransform() {
    return this.#t.length > 1 && this.#t.pop(), this;
  }
  resetBBox(t) {
    return this._pendingBBoxIdx !== t && (this._pendingBBoxIdx = t, this.#s.set(Dt, 0)), this;
  }
  recordClipBox(t, e, s, i, n, r) {
    const a = x.multiplyByDOMMatrix(this.#t.at(-1), e.getTransform()), o = Dt.slice();
    x.axialAlignedBoundingBox([s, n, i, r], a, o);
    const l = x.intersect(this.#e, o);
    return l ? (this.#e[0] = l[0], this.#e[1] = l[1], this.#e[2] = l[2], this.#e[3] = l[3]) : (this.#e[0] = this.#e[1] = 1 / 0, this.#e[2] = this.#e[3] = -1 / 0), this;
  }
  recordBBox(t, e, s, i, n, r) {
    const a = this.#e;
    if (a[0] === 1 / 0)
      return this;
    const o = x.multiplyByDOMMatrix(this.#t.at(-1), e.getTransform());
    if (a[0] === -1 / 0)
      return x.axialAlignedBoundingBox([s, n, i, r], o, this.#s), this;
    const l = Dt.slice();
    return x.axialAlignedBoundingBox([s, n, i, r], o, l), this.#s[0] = Y(l[0], a[0], this.#s[0]), this.#s[1] = Y(l[1], a[1], this.#s[1]), this.#s[2] = Y(l[2], this.#s[2], a[2]), this.#s[3] = Y(l[3], this.#s[3], a[3]), this;
  }
  recordFullPageBBox(t) {
    return this.#s[0] = Math.max(0, this.#e[0]), this.#s[1] = Math.max(0, this.#e[1]), this.#s[2] = Math.min(this.#i, this.#e[2]), this.#s[3] = Math.min(this.#n, this.#e[3]), this;
  }
  recordOperation(t, e = !1, s) {
    if (this._pendingBBoxIdx !== t)
      return this;
    const i = Pi(this.#s[0] * 256 / this.#i), n = Pi(this.#s[1] * 256 / this.#n), r = Mi(this.#s[2] * 256 / this.#i), a = Mi(this.#s[3] * 256 / this.#n);
    if (Ii(this.#r, t, i, n, r, a), s)
      for (const o of s)
        for (const l of o)
          l !== t && Ii(this.#r, l, i, n, r, a);
    return e || (this._pendingBBoxIdx = -1), this;
  }
  bboxToClipBoxDropOperation(t) {
    return this._pendingBBoxIdx === t && (this._pendingBBoxIdx = -1, this.#e[0] = Math.max(this.#e[0], this.#s[0]), this.#e[1] = Math.max(this.#e[1], this.#s[1]), this.#e[2] = Math.min(this.#e[2], this.#s[2]), this.#e[3] = Math.min(this.#e[3], this.#s[3])), this;
  }
  take() {
    return new fs(this.#a, this.#r);
  }
  takeDebugMetadata() {
    throw new Error("Unreachable");
  }
  recordSimpleData(t, e) {
    return this;
  }
  recordIncrementalData(t, e) {
    return this;
  }
  resetIncrementalData(t, e) {
    return this;
  }
  recordNamedData(t, e) {
    return this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    return this;
  }
  recordFutureForcedDependency(t, e) {
    return this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    return this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    return this;
  }
  recordCharacterBBox(t, e, s, i = 1, n = 0, r = 0, a) {
    return this;
  }
  getSimpleIndex(t) {
  }
  recordDependencies(t, e) {
    return this;
  }
  recordNamedDependency(t, e) {
    return this;
  }
  recordShowTextOperation(t, e = !1) {
    return this;
  }
}
class Ar {
  #t = {
    __proto__: null
  };
  #e = {
    __proto__: null,
    transform: [],
    moveText: [],
    sameLineText: [],
    [de]: []
  };
  #s = /* @__PURE__ */ new Map();
  #i = /* @__PURE__ */ new Set();
  #n = /* @__PURE__ */ new Map();
  #r;
  #a;
  #o;
  constructor(t, e = !1) {
    this.#o = t, e && (this.#r = /* @__PURE__ */ new Map(), this.#a = (s, i) => {
      Di(this.#r, i).dependencies.add(s);
    });
  }
  get clipBox() {
    return this.#o.clipBox;
  }
  growOperationsCount(t) {
    this.#o.growOperationsCount(t);
  }
  save(t) {
    return this.#t = {
      __proto__: this.#t
    }, this.#e = {
      __proto__: this.#e,
      transform: {
        __proto__: this.#e.transform
      },
      moveText: {
        __proto__: this.#e.moveText
      },
      sameLineText: {
        __proto__: this.#e.sameLineText
      },
      [de]: {
        __proto__: this.#e[de]
      }
    }, this.#o.save(t), this;
  }
  restore(t) {
    this.#o.restore(t, this.#a);
    const e = Object.getPrototypeOf(this.#t);
    return e === null ? this : (this.#t = e, this.#e = Object.getPrototypeOf(this.#e), this);
  }
  recordOpenMarker(t) {
    return this.#o.recordOpenMarker(t, this.#a), this;
  }
  getOpenMarker() {
    return this.#o.getOpenMarker();
  }
  recordCloseMarker(t) {
    return this.#o.recordCloseMarker(t, this.#a), this;
  }
  beginMarkedContent(t) {
    return this.#o.beginMarkedContent(t), this;
  }
  endMarkedContent(t) {
    return this.#o.endMarkedContent(t, this.#a), this;
  }
  pushBaseTransform(t) {
    return this.#o.pushBaseTransform(t), this;
  }
  popBaseTransform() {
    return this.#o.popBaseTransform(), this;
  }
  recordSimpleData(t, e) {
    return this.#t[t] = e, this;
  }
  recordIncrementalData(t, e) {
    return this.#e[t].push(e), this;
  }
  resetIncrementalData(t, e) {
    return this.#e[t].length = 0, this;
  }
  recordNamedData(t, e) {
    return this.#s.set(t, e), this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    this.#t[t] = this.#s.get(e) ?? s;
  }
  recordFutureForcedDependency(t, e) {
    return this.recordIncrementalData(de, e), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    for (const e of t)
      e in this.#t && this.recordFutureForcedDependency(e, this.#t[e]);
    return this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    for (const t of this.#i)
      this.recordFutureForcedDependency(de, t);
    return this;
  }
  resetBBox(t) {
    return this.#o.resetBBox(t), this;
  }
  recordClipBox(t, e, s, i, n, r) {
    return this.#o.recordClipBox(t, e, s, i, n, r), this;
  }
  recordBBox(t, e, s, i, n, r) {
    return this.#o.recordBBox(t, e, s, i, n, r), this;
  }
  recordCharacterBBox(t, e, s, i = 1, n = 0, r = 0, a) {
    const o = s.bbox;
    let l, h;
    if (o && (l = o[2] !== o[0] && o[3] !== o[1] && this.#n.get(s), l !== !1 && (h = [0, 0, 0, 0], x.axialAlignedBoundingBox(o, s.fontMatrix, h), (i !== 1 || n !== 0 || r !== 0) && br(i, -i, n, r, h), l)))
      return this.recordBBox(t, e, h[0], h[2], h[1], h[3]);
    if (!a)
      return this.recordFullPageBBox(t);
    const c = a();
    return o && h && l === void 0 && (l = h[0] <= n - c.actualBoundingBoxLeft && h[2] >= n + c.actualBoundingBoxRight && h[1] <= r - c.actualBoundingBoxAscent && h[3] >= r + c.actualBoundingBoxDescent, this.#n.set(s, l), l) ? this.recordBBox(t, e, h[0], h[2], h[1], h[3]) : this.recordBBox(t, e, n - c.actualBoundingBoxLeft, n + c.actualBoundingBoxRight, r - c.actualBoundingBoxAscent, r + c.actualBoundingBoxDescent);
  }
  recordFullPageBBox(t) {
    return this.#o.recordFullPageBBox(t), this;
  }
  getSimpleIndex(t) {
    return this.#t[t];
  }
  recordDependencies(t, e) {
    const s = this.#i, i = this.#t, n = this.#e;
    for (const r of e)
      r in this.#t ? s.add(i[r]) : r in n && n[r].forEach(s.add, s);
    return this;
  }
  recordNamedDependency(t, e) {
    return this.#s.has(e) && this.#i.add(this.#s.get(e)), this;
  }
  recordOperation(t, e = !1) {
    if (this.recordDependencies(t, [de]), this.#r) {
      const i = Di(this.#r, t), {
        dependencies: n
      } = i;
      this.#i.forEach(n.add, n), this.#o._savesStack.forEach(n.add, n), this.#o._markedContentStack.forEach(n.add, n), n.delete(t), i.isRenderingOperation = !0;
    }
    const s = !e && t === this.#o._pendingBBoxIdx;
    return this.#o.recordOperation(t, e, [this.#i, this.#o._savesStack, this.#o._markedContentStack]), s && this.#i.clear(), this;
  }
  recordShowTextOperation(t, e = !1) {
    const s = Array.from(this.#i);
    this.recordOperation(t, e), this.recordIncrementalData("sameLineText", t);
    for (const i of s)
      this.recordIncrementalData("sameLineText", i);
    return this;
  }
  bboxToClipBoxDropOperation(t, e = !1) {
    const s = !e && t === this.#o._pendingBBoxIdx;
    return this.#o.bboxToClipBoxDropOperation(t), s && this.#i.clear(), this;
  }
  take() {
    return this.#n.clear(), this.#o.take();
  }
  takeDebugMetadata() {
    return this.#r;
  }
}
class De {
  #t;
  #e;
  #s;
  #i = 0;
  #n = 0;
  constructor(t, e, s) {
    if (t instanceof De && t.#s === !!s)
      return t;
    this.#t = t, this.#e = e, this.#s = !!s;
  }
  get clipBox() {
    return this.#t.clipBox;
  }
  growOperationsCount() {
    throw new Error("Unreachable");
  }
  save(t) {
    return this.#n++, this.#t.save(this.#e), this;
  }
  restore(t) {
    return this.#n > 0 && (this.#t.restore(this.#e), this.#n--), this;
  }
  recordOpenMarker(t) {
    return this.#i++, this;
  }
  getOpenMarker() {
    return this.#i > 0 ? this.#e : this.#t.getOpenMarker();
  }
  recordCloseMarker(t) {
    return this.#i--, this;
  }
  beginMarkedContent(t) {
    return this;
  }
  endMarkedContent(t) {
    return this;
  }
  pushBaseTransform(t) {
    return this.#t.pushBaseTransform(t), this;
  }
  popBaseTransform() {
    return this.#t.popBaseTransform(), this;
  }
  recordSimpleData(t, e) {
    return this.#t.recordSimpleData(t, this.#e), this;
  }
  recordIncrementalData(t, e) {
    return this.#t.recordIncrementalData(t, this.#e), this;
  }
  resetIncrementalData(t, e) {
    return this.#t.resetIncrementalData(t, this.#e), this;
  }
  recordNamedData(t, e) {
    return this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    return this.#t.recordSimpleDataFromNamed(t, e, this.#e), this;
  }
  recordFutureForcedDependency(t, e) {
    return this.#t.recordFutureForcedDependency(t, this.#e), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    return this.#t.inheritSimpleDataAsFutureForcedDependencies(t), this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    return this.#t.inheritPendingDependenciesAsFutureForcedDependencies(), this;
  }
  resetBBox(t) {
    return this.#s || this.#t.resetBBox(this.#e), this;
  }
  recordClipBox(t, e, s, i, n, r) {
    return this.#s || this.#t.recordClipBox(this.#e, e, s, i, n, r), this;
  }
  recordBBox(t, e, s, i, n, r) {
    return this.#s || this.#t.recordBBox(this.#e, e, s, i, n, r), this;
  }
  recordCharacterBBox(t, e, s, i, n, r, a) {
    return this.#s || this.#t.recordCharacterBBox(this.#e, e, s, i, n, r, a), this;
  }
  recordFullPageBBox(t) {
    return this.#s || this.#t.recordFullPageBBox(this.#e), this;
  }
  getSimpleIndex(t) {
    return this.#t.getSimpleIndex(t);
  }
  recordDependencies(t, e) {
    return this.#t.recordDependencies(this.#e, e), this;
  }
  recordNamedDependency(t, e) {
    return this.#t.recordNamedDependency(this.#e, e), this;
  }
  recordOperation(t) {
    return this.#t.recordOperation(this.#e, !0), this;
  }
  recordShowTextOperation(t) {
    return this.#t.recordShowTextOperation(this.#e, !0), this;
  }
  bboxToClipBoxDropOperation(t) {
    return this.#s || this.#t.bboxToClipBoxDropOperation(this.#e, !0), this;
  }
  take() {
    throw new Error("Unreachable");
  }
  takeDebugMetadata() {
    throw new Error("Unreachable");
  }
}
const St = {
  stroke: ["path", "transform", "filter", "strokeColor", "strokeAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "dash"],
  fill: ["path", "transform", "filter", "fillColor", "fillAlpha", "globalCompositeOperation", "SMask"],
  imageXObject: ["transform", "SMask", "filter", "fillAlpha", "strokeAlpha", "globalCompositeOperation"],
  rawFillPath: ["filter", "fillColor", "fillAlpha"],
  showText: ["transform", "leading", "charSpacing", "wordSpacing", "hScale", "textRise", "moveText", "textMatrix", "font", "fontObj", "filter", "fillColor", "textRenderingMode", "SMask", "fillAlpha", "strokeAlpha", "globalCompositeOperation", "sameLineText"],
  transform: ["transform"],
  transformAndFill: ["transform", "filter", "fillColor"]
};
class is {
  #t;
  #e;
  #s = 4;
  #i = 0;
  #n = new is.#r(this.#s * 6);
  static #r = W.isFloat16ArraySupported ? Float16Array : Float32Array;
  constructor(t) {
    this.#t = t.width, this.#e = t.height;
  }
  record(t, e, s, i) {
    if (this.#i === this.#s) {
      this.#s *= 2;
      const a = new is.#r(this.#s * 6);
      a.set(this.#n), this.#n = a;
    }
    const n = X(t);
    let r;
    if (i[0] !== 1 / 0) {
      const a = Dt.slice();
      x.axialAlignedBoundingBox([0, -s, e, 0], n, a);
      const o = x.intersect(i, a);
      if (!o)
        return;
      const [l, h, c, u] = o;
      if (l !== a[0] || h !== a[1] || c !== a[2] || u !== a[3]) {
        const f = Math.atan2(n[1], n[0]), p = Math.abs(Math.sin(f)), g = Math.abs(Math.cos(f));
        if (p < 1e-6 || g < 1e-6 || Math.abs(p - g) < 1e-6)
          r = [l, h, l, u, c, h];
        else {
          const m = c - l, b = u - h, y = p * p, A = g * g, w = g * p, v = A - y, S = (b * A - m * w) / v, _ = (b * w - m * y) / v;
          r = [l + _, h, l, h + S, c, u - S];
        }
      }
    }
    r || (r = [0, -s, 0, 0, e, -s], x.applyTransform(r, n, 0), x.applyTransform(r, n, 2), x.applyTransform(r, n, 4)), r[0] /= this.#t, r[1] /= this.#e, r[2] /= this.#t, r[3] /= this.#e, r[4] /= this.#t, r[5] /= this.#e, this.#n.set(r, this.#i * 6), this.#i++;
  }
  take() {
    return this.#n.subarray(0, this.#i * 6);
  }
}
function wr(d, t, {
  recordOperations: e = !1,
  recordImages: s = !1,
  recordDebugMetadata: i = !1
}) {
  const n = e || s ? new yr(d, t) : null;
  return {
    dependencyTracker: e ? new Ar(n, i) : n,
    imagesTracker: s ? new is(d) : null
  };
}
function dn({
  src: d,
  srcPos: t = 0,
  dest: e,
  width: s,
  height: i,
  nonBlackColor: n = 4294967295,
  inverseDecode: r = !1
}) {
  const a = W.isLittleEndian ? 4278190080 : 255, [o, l] = r ? [n, a] : [a, n], h = s >> 3, c = s & 7, u = o ^ l, f = d.length;
  e = new Uint32Array(e.buffer);
  let p = 0;
  for (let g = 0; g < i; ++g) {
    for (const b = t + h; t < b; ++t, p += 8) {
      const y = d[t];
      e[p] = o ^ -(y >> 7 & 1) & u, e[p + 1] = o ^ -(y >> 6 & 1) & u, e[p + 2] = o ^ -(y >> 5 & 1) & u, e[p + 3] = o ^ -(y >> 4 & 1) & u, e[p + 4] = o ^ -(y >> 3 & 1) & u, e[p + 5] = o ^ -(y >> 2 & 1) & u, e[p + 6] = o ^ -(y >> 1 & 1) & u, e[p + 7] = o ^ -(y & 1) & u;
    }
    if (c === 0)
      continue;
    const m = t < f ? d[t++] : 255;
    for (let b = 0; b < c; ++b, ++p)
      e[p] = o ^ -(m >> 7 - b & 1) & u;
  }
  return {
    srcPos: t,
    destPos: p
  };
}
function vr({
  src: d,
  srcPos: t = 0,
  dest: e,
  destPos: s = 0,
  width: i,
  height: n
}) {
  let r = 0;
  const a = i * n * 3, o = d.byteOffset + t, l = o % 4 === 0 ? Math.floor(Y(d.length - t, 0, a) / 4) : 0, h = l > 0 ? new Uint32Array(d.buffer, o, l) : null, c = W.isLittleEndian ? 4278190080 : 255;
  if (W.isLittleEndian) {
    for (; r < l - 2; r += 3, s += 4) {
      const u = h[r], f = h[r + 1], p = h[r + 2];
      e[s] = u | c, e[s + 1] = u >>> 24 | f << 8 | c, e[s + 2] = f >>> 16 | p << 16 | c, e[s + 3] = p >>> 8 | c;
    }
    for (let u = t + r * 4, f = t + a; u < f; u += 3)
      e[s++] = d[u] | d[u + 1] << 8 | d[u + 2] << 16 | c;
  } else {
    for (; r < l - 2; r += 3, s += 4) {
      const u = h[r], f = h[r + 1], p = h[r + 2];
      e[s] = u | c, e[s + 1] = u << 24 | f >>> 8 | c, e[s + 2] = f << 16 | p >>> 16 | c, e[s + 3] = p << 8 | c;
    }
    for (let u = t + r * 4, f = t + a; u < f; u += 3)
      e[s++] = d[u] << 24 | d[u + 1] << 16 | d[u + 2] << 8 | c;
  }
  return {
    srcPos: t + a,
    destPos: s
  };
}
const it = {
  FILL: "Fill",
  STROKE: "Stroke",
  SHADING: "Shading"
};
function qe(d, t) {
  if (!t)
    return;
  const e = t[2] - t[0], s = t[3] - t[1], i = new Path2D();
  i.rect(t[0], t[1], e, s), d.clip(i);
}
class ei {
  matrix = null;
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern() {
    j("Abstract method `getPattern` called.");
  }
}
class Sr extends ei {
  constructor(t) {
    super(), this._type = t[1], this._bbox = t[2], this._colorStops = t[3], this._p0 = t[4], this._p1 = t[5], this._r0 = t[6], this._r1 = t[7];
  }
  isOriginBased() {
    return this._p0[0] === 0 && this._p0[1] === 0 && (!this.isRadial() || this._p1[0] === 0 && this._p1[1] === 0);
  }
  isRadial() {
    return this._type === "radial";
  }
  areConic() {
    if (!this.isRadial())
      return !1;
    const t = Math.hypot(this._p0[0] - this._p1[0], this._p0[1] - this._p1[1]);
    return t + this._r1 > this._r0 && t + this._r0 > this._r1;
  }
  _createGradient(t, e = null) {
    let s, i = this._p0, n = this._p1;
    if (e && (i = i.slice(), n = n.slice(), x.applyTransform(i, e), x.applyTransform(n, e)), this._type === "axial")
      s = t.createLinearGradient(i[0], i[1], n[0], n[1]);
    else if (this._type === "radial") {
      let r = this._r0, a = this._r1;
      if (e) {
        const o = new Float32Array(2);
        x.singularValueDecompose2dScale(e, o), r *= o[0], a *= o[0];
      }
      s = t.createRadialGradient(i[0], i[1], r, n[0], n[1], a);
    }
    for (const r of this._colorStops)
      s.addColorStop(r[0], r[1]);
    return s;
  }
  _createReversedGradient(t, e = null) {
    let s = this._p1, i = this._p0;
    e && (s = s.slice(), i = i.slice(), x.applyTransform(s, e), x.applyTransform(i, e));
    let n = this._r1, r = this._r0;
    if (e) {
      const l = new Float32Array(2);
      x.singularValueDecompose2dScale(e, l), n *= l[0], r *= l[0];
    }
    const a = t.createRadialGradient(s[0], s[1], n, i[0], i[1], r), o = this._colorStops.map(([l, h]) => [1 - l, h]).reverse();
    for (const [l, h] of o)
      a.addColorStop(l, h);
    return a;
  }
  _createRasterPattern(t, e, s, i, n, r) {
    const a = Math.ceil(i[2] - i[0]) || 1, o = Math.ceil(i[3] - i[1]) || 1, l = e.canvasFactory.create(a, o), h = l.context;
    h.clearRect(0, 0, a, o), h.beginPath(), h.rect(0, 0, a, o), h.translate(-i[0], -i[1]), s = x.transform(s, [1, 0, 0, 1, i[0], i[1]]), h.transform(...n), qe(h, this._bbox), this.areConic() && (h.fillStyle = this._createReversedGradient(h), h.fill()), h.fillStyle = this._createGradient(h), h.fill(), r?.applyToCanvas(h);
    const c = t.createPattern(l.canvas, "no-repeat");
    return e.canvasFactory.destroy(l), c.setTransform(new DOMMatrix(s)), c;
  }
  getPattern(t, e, s, i) {
    const n = e.current.transferMapsFallback;
    if (i === it.STROKE || i === it.FILL) {
      if (this.isOriginBased() && !n) {
        let o = x.transform(s, e.baseTransform);
        this.matrix && (o = x.transform(o, this.matrix));
        const l = 1e-3, h = Math.hypot(o[0], o[1]), c = Math.hypot(o[2], o[3]), u = (o[0] * o[2] + o[1] * o[3]) / (h * c);
        if (Math.abs(u) < l)
          if (this.isRadial()) {
            if (Math.abs(h - c) < l)
              return this._createGradient(t, o);
          } else
            return this._createGradient(t, o);
      }
      const r = e.current.getClippedPathBoundingBox(i, X(t)) || [0, 0, 0, 0], a = this.matrix ? x.transform(e.baseTransform, this.matrix) : e.baseTransform;
      return this._createRasterPattern(t, e, s, r, a, n);
    }
    return n && s ? this._createRasterPattern(t, e, s, e.current.clipBox, X(t), n) : (this.areConic() && (t.save(), qe(t, this._bbox), t.fillStyle = this._createReversedGradient(t), t.fillRect(-1e10, -1e10, 2e10, 2e10), t.restore()), qe(t, this._bbox), this._createGradient(t));
  }
}
function _r(d, t, e, s, i, n, r, a) {
  const o = t.coords, l = t.colors, h = d.data, c = d.width * 4;
  let u;
  o[e * 2 + 1] > o[s * 2 + 1] && (u = e, e = s, s = u, u = n, n = r, r = u), o[s * 2 + 1] > o[i * 2 + 1] && (u = s, s = i, i = u, u = r, r = a, a = u), o[e * 2 + 1] > o[s * 2 + 1] && (u = e, e = s, s = u, u = n, n = r, r = u);
  const f = (o[e * 2] + t.offsetX) * t.scaleX, p = (o[e * 2 + 1] + t.offsetY) * t.scaleY, g = (o[s * 2] + t.offsetX) * t.scaleX, m = (o[s * 2 + 1] + t.offsetY) * t.scaleY, b = (o[i * 2] + t.offsetX) * t.scaleX, y = (o[i * 2 + 1] + t.offsetY) * t.scaleY;
  if (p >= y)
    return;
  const A = l[n * 4], w = l[n * 4 + 1], v = l[n * 4 + 2], S = l[r * 4], _ = l[r * 4 + 1], E = l[r * 4 + 2], C = l[a * 4], T = l[a * 4 + 1], D = l[a * 4 + 2], P = Math.round(p), N = Math.round(y);
  let G, z, F, O, rt, lt, Ft, Tt;
  for (let tt = P; tt <= N; tt++) {
    if (tt < m) {
      const Q = tt < p ? 0 : (p - tt) / (p - m);
      G = f - (f - g) * Q, z = A - (A - S) * Q, F = w - (w - _) * Q, O = v - (v - E) * Q;
    } else {
      let Q;
      tt > y ? Q = 1 : m === y ? Q = 0 : Q = (m - tt) / (m - y), G = g - (g - b) * Q, z = S - (S - C) * Q, F = _ - (_ - T) * Q, O = E - (E - D) * Q;
    }
    let et;
    tt < p ? et = 0 : tt > y ? et = 1 : et = (p - tt) / (p - y), rt = f - (f - b) * et, lt = A - (A - C) * et, Ft = w - (w - T) * et, Tt = v - (v - D) * et;
    const ht = Math.round(Math.min(G, rt)), qt = Math.round(Math.max(G, rt));
    let Gt = c * tt + ht * 4;
    for (let Q = ht; Q <= qt; Q++)
      et = (G - Q) / (G - rt), et < 0 ? et = 0 : et > 1 && (et = 1), h[Gt++] = z - (z - lt) * et | 0, h[Gt++] = F - (F - Ft) * et | 0, h[Gt++] = O - (O - Tt) * et | 0, h[Gt++] = 255;
  }
}
class Cr extends ei {
  constructor(t) {
    super(), this._posData = t[2], this._colData = t[3], this._vertexCount = t[4], this._bounds = t[5], this._bbox = t[6], this._background = t[7], dr();
  }
  _createMeshCanvas(t, e, s, i = null) {
    const o = Math.floor(this._bounds[0]), l = Math.floor(this._bounds[1]), h = Math.ceil(this._bounds[2]) - o, c = Math.ceil(this._bounds[3]) - l, u = Math.min(Math.ceil(Math.abs(h * t[0] * 1.1)), 3e3) || 1, f = Math.min(Math.ceil(Math.abs(c * t[1] * 1.1)), 3e3) || 1, p = h ? h / u : 1, g = c ? c / f : 1, m = {
      coords: this._posData,
      colors: this._colData,
      offsetX: -o,
      offsetY: -l,
      scaleX: 1 / p,
      scaleY: 1 / g
    }, b = u + 4, y = f + 4, A = s.create(b, y);
    if (on() && this._vertexCount > 48)
      A.context.drawImage(ur(this._posData, this._colData, this._vertexCount, m, e, b, y, 2), 0, 0);
    else {
      const w = A.context.createImageData(u, f);
      if (e) {
        const v = w.data;
        for (let S = 0, _ = v.length; S < _; S += 4)
          v[S] = e[0], v[S + 1] = e[1], v[S + 2] = e[2], v[S + 3] = 255;
      }
      for (let v = 0, S = this._vertexCount; v < S; v += 3)
        _r(w, m, v, v + 1, v + 2, v, v + 1, v + 2);
      A.context.putImageData(w, 2, 2);
    }
    return i?.applyToCanvas(A.context), {
      canvas: A.canvas,
      offsetX: o - 2 * p,
      offsetY: l - 2 * g,
      scaleX: p,
      scaleY: g
    };
  }
  isModifyingCurrentTransform() {
    return !0;
  }
  getPattern(t, e, s, i) {
    qe(t, this._bbox);
    const n = new Float32Array(2);
    if (i === it.SHADING)
      x.singularValueDecompose2dScale(X(t), n);
    else if (this.matrix) {
      x.singularValueDecompose2dScale(this.matrix, n);
      const [o, l] = n;
      x.singularValueDecompose2dScale(e.baseTransform, n), n[0] *= o, n[1] *= l;
    } else
      x.singularValueDecompose2dScale(e.baseTransform, n);
    const r = this._createMeshCanvas(n, i === it.SHADING ? null : this._background, e.canvasFactory, e.current.transferMapsFallback);
    i !== it.SHADING && (t.setTransform(...e.baseTransform), this.matrix && t.transform(...this.matrix)), t.translate(r.offsetX, r.offsetY), t.scale(r.scaleX, r.scaleY);
    const a = t.createPattern(r.canvas, "no-repeat");
    return e.canvasFactory.destroy(r), a;
  }
}
class Er extends ei {
  getPattern() {
    return "hotpink";
  }
}
function xr(d) {
  switch (d[0]) {
    case "RadialAxial":
      return new Sr(d);
    case "Mesh":
      return new Cr(d);
    case "Dummy":
      return new Er();
  }
  throw new Error(`Unknown IR type: ${d[0]}`);
}
const Fi = {
  COLORED: 1,
  UNCOLORED: 2
};
class ke {
  static MAX_PATTERN_SIZE = 3e3;
  constructor(t, e, s, i) {
    this.color = t[1], this.operatorList = t[2], this.matrix = t[3], this.bbox = t[4], this.xstep = t[5], this.ystep = t[6], this.paintType = t[7], this.tilingType = t[8], this.needsIsolation = t[9] ?? !0, this.ctx = e, this.canvasGraphicsFactory = s, this.baseTransform = i, this.patternBaseMatrix = this.matrix ? x.transform(i, this.matrix) : i;
  }
  canSkipPatternCanvas([t, e, s, i]) {
    const [n, r, a, o] = this.bbox, l = Math.abs(this.xstep), h = Math.abs(this.ystep);
    if (t > l + 1e-6 || e > h + 1e-6)
      return null;
    const c = Math.floor((s - a) / l) + 1, u = Math.ceil((s + t - n) / l) - 1, f = Math.floor((i - o) / h) + 1, p = Math.ceil((i + e - r) / h) - 1;
    return u <= c && p <= f ? [c, f] : null;
  }
  updatePatternDims(t, e) {
    const s = Dt.slice();
    x.axialAlignedBoundingBox(t, x.inverseTransform(this.patternBaseMatrix), s), e[0] = s[2] - s[0], e[1] = s[3] - s[1], e[2] = s[0], e[3] = s[1];
  }
  _renderTileCanvas(t, e, s, i) {
    const [n, r, a, o] = this.bbox, l = t.canvasFactory.create(s.size, i.size), h = l.context, c = this.canvasGraphicsFactory.createCanvasGraphics(h, e);
    return c.groupLevel = t.groupLevel, c.current.transferMapsFallback = t.current.transferMapsFallback, this.setFillAndStrokeStyleToContext(c, this.paintType, this.color), h.translate(-s.scale * n, -i.scale * r), c.transform(0, s.scale, 0, 0, i.scale, 0, 0), h.save(), c.dependencyTracker?.save(), this.clipBbox(c, n, r, a, o), c.baseTransform = X(c.ctx), c.executeOperatorList(this.operatorList), c.endDrawing(), c.dependencyTracker?.restore(), h.restore(), l;
  }
  _getCombinedScales() {
    const t = new Float32Array(2);
    x.singularValueDecompose2dScale(this.matrix, t);
    const [e, s] = t;
    return x.singularValueDecompose2dScale(this.baseTransform, t), [e * t[0], s * t[1]];
  }
  drawPattern(t, e, s = !1, [i, n], r) {
    const [a, o, l, h] = this.bbox, c = t.dependencyTracker;
    c && (t.dependencyTracker = new De(c, r));
    try {
      if (t.save(), s ? t.ctx.clip(e, "evenodd") : t.ctx.clip(e), t.ctx.setTransform(...this.patternBaseMatrix), t.ctx.translate(i * this.xstep, n * this.ystep), this.needsIsolation || t.ctx.globalAlpha !== 1 || t.ctx.globalCompositeOperation !== "source-over" || t.inSMaskMode) {
        const u = l - a, f = h - o, [p, g] = this._getCombinedScales(), m = this.getSizeAndScale(u, this.ctx.canvas.width, p), b = this.getSizeAndScale(f, this.ctx.canvas.height, g), y = this._renderTileCanvas(t, r, m, b);
        t.ctx.drawImage(y.canvas, a, o, u, f), t.canvasFactory.destroy(y);
      } else
        t.resetGraphicsState(), this.setFillAndStrokeStyleToContext(t, this.paintType, this.color), this.clipBbox(t, a, o, l, h), t.baseTransformStack.push(t.baseTransform), t.baseTransform = X(t.ctx), t.executeOperatorList(this.operatorList), t.baseTransform = t.baseTransformStack.pop();
      t.restore();
    } finally {
      c && (t.dependencyTracker = c);
    }
  }
  createPatternCanvas(t, e) {
    const [s, i, n, r] = this.bbox, a = n - s, o = r - i;
    let {
      xstep: l,
      ystep: h
    } = this;
    l = Math.abs(l), h = Math.abs(h), hs("TilingType: " + this.tilingType);
    const [c, u] = this._getCombinedScales();
    let f = a, p = o, g = !1, m = !1;
    Math.ceil(l * c) >= Math.ceil(a * c) ? f = l : g = !0, Math.ceil(h * u) >= Math.ceil(o * u) ? p = h : m = !0;
    const b = this.getSizeAndScale(f, this.ctx.canvas.width, c), y = this.getSizeAndScale(p, this.ctx.canvas.height, u), A = this._renderTileCanvas(t, e, b, y);
    if (g || m) {
      const w = A.canvas;
      g && (f = l), m && (p = h);
      const v = this.getSizeAndScale(f, this.ctx.canvas.width, c), S = this.getSizeAndScale(p, this.ctx.canvas.height, u), _ = v.size, E = S.size, C = t.canvasFactory.create(_, E), T = C.context, D = g ? Math.min(Math.floor(a / l), Math.ceil(w.width / _)) : 0, P = m ? Math.min(Math.floor(o / h), Math.ceil(w.height / E)) : 0;
      let N = w, G = null;
      if (m) {
        G = t.canvasFactory.create(w.width, E);
        const z = G.context;
        for (let F = P; F >= 0; F--)
          z.drawImage(w, 0, E * F, w.width, E, 0, 0, w.width, E);
        N = G.canvas;
      }
      for (let z = D; z >= 0; z--)
        T.drawImage(N, _ * z, 0, _, E, 0, 0, _, E);
      return G && t.canvasFactory.destroy(G), t.canvasFactory.destroy(A), {
        canvas: C.canvas,
        canvasEntry: C,
        scaleX: v.scale,
        scaleY: S.scale,
        offsetX: s,
        offsetY: i
      };
    }
    return {
      canvas: A.canvas,
      canvasEntry: A,
      scaleX: b.scale,
      scaleY: y.scale,
      offsetX: s,
      offsetY: i
    };
  }
  getSizeAndScale(t, e, s) {
    const i = Math.max(ke.MAX_PATTERN_SIZE, e);
    let n = Math.ceil(t * s);
    return n >= i ? n = i : s = n / t, {
      scale: s,
      size: n
    };
  }
  clipBbox(t, e, s, i, n) {
    const r = i - e, a = n - s, o = new Path2D();
    o.rect(e, s, r, a), x.axialAlignedBoundingBox([e, s, i, n], X(t.ctx), t.current.minMax), t.ctx.clip(o), t.current.updateClipFromPath();
  }
  setFillAndStrokeStyleToContext(t, e, s) {
    switch (e) {
      case Fi.COLORED:
        s = "#000000";
        break;
      case Fi.UNCOLORED:
        break;
      default:
        throw new Nn(`Unsupported paint type: ${e}`);
    }
    const {
      ctx: i,
      current: n
    } = t;
    n.patternFill = n.patternStroke = !1, i.fillStyle = i.strokeStyle = n.transferMapsFallback?.applyToColor(s) ?? s, n.fillColor = n.strokeColor = s;
  }
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern(t, e, s, i, n) {
    const r = i !== it.SHADING ? x.transform(s, this.patternBaseMatrix) : s, a = this.createPatternCanvas(e, n);
    let o = new DOMMatrix(r);
    o = o.translate(a.offsetX, a.offsetY), o = o.scale(1 / a.scaleX, 1 / a.scaleY);
    const l = t.createPattern(a.canvas, "repeat");
    return e.canvasFactory.destroy(a.canvasEntry), l.setTransform(o), l;
  }
}
const Tr = 16, kr = 100, Pr = 15, Oi = 10, ft = 16, At = new Float32Array(2);
function Ri(d, t) {
  if (d._removeMirroring)
    throw new Error("Context is already forwarding operations.");
  const e = /* @__PURE__ */ new Map();
  for (const s of ["save", "restore", "rotate", "scale", "translate", "transform", "setTransform", "resetTransform", "clip", "moveTo", "lineTo", "bezierCurveTo", "quadraticCurveTo", "arc", "arcTo", "ellipse", "rect", "roundRect", "closePath", "beginPath"]) {
    const i = d[s];
    typeof i != "function" || typeof t[s] != "function" || (e.set(s, i), d[s] = function(...n) {
      return t[s](...n), i.apply(this, n);
    });
  }
  d._removeMirroring = () => {
    for (const [s, i] of e)
      d[s] = i;
    delete d._removeMirroring;
  };
}
function ze(d, t, e, s, i, n, r, a, o, l) {
  const [h, c, u, f, p, g] = X(d);
  if (c === 0 && u === 0) {
    const y = r * h + p, A = Math.round(y), w = a * f + g, v = Math.round(w), S = (r + o) * h + p, _ = Math.abs(Math.round(S) - A) || 1, E = (a + l) * f + g, C = Math.abs(Math.round(E) - v) || 1;
    return d.setTransform(Math.sign(h), 0, 0, Math.sign(f), A, v), d.drawImage(t, e, s, i, n, 0, 0, _, C), d.setTransform(h, c, u, f, p, g), [_, C];
  }
  if (h === 0 && f === 0) {
    const y = a * u + p, A = Math.round(y), w = r * c + g, v = Math.round(w), S = (a + l) * u + p, _ = Math.abs(Math.round(S) - A) || 1, E = (r + o) * c + g, C = Math.abs(Math.round(E) - v) || 1;
    return d.setTransform(0, Math.sign(c), Math.sign(u), 0, A, v), d.drawImage(t, e, s, i, n, 0, 0, C, _), d.setTransform(h, c, u, f, p, g), [C, _];
  }
  d.drawImage(t, e, s, i, n, r, a, o, l);
  const m = Math.hypot(h, c), b = Math.hypot(u, f);
  return [m * o, b * l];
}
class Ts {
  alphaIsShape = !1;
  fontSize = 0;
  fontSizeScale = 1;
  textMatrix = null;
  textMatrixScale = 1;
  fontMatrix = Ds;
  leading = 0;
  x = 0;
  y = 0;
  lineX = 0;
  lineY = 0;
  charSpacing = 0;
  wordSpacing = 0;
  textHScale = 1;
  textRenderingMode = st.FILL;
  textRise = 0;
  fillColor = "#000000";
  strokeColor = "#000000";
  tilingPatternDims = null;
  patternFill = !1;
  patternStroke = !1;
  fillAlpha = 1;
  strokeAlpha = 1;
  lineWidth = 1;
  activeSMask = null;
  transferMaps = "none";
  transferMapsFallback = null;
  minMax = ee.slice();
  constructor(t, e) {
    this.clipBox = new Float32Array([0, 0, t, e]);
  }
  clone() {
    const t = Object.create(this);
    return t.clipBox = this.clipBox.slice(), t.minMax = this.minMax.slice(), t.tilingPatternDims = this.tilingPatternDims?.slice(), t;
  }
  getPathBoundingBox(t = it.FILL, e = null) {
    const s = this.minMax.slice();
    if (t === it.STROKE) {
      e || j("Stroke bounding box must include transform."), x.singularValueDecompose2dScale(e, At);
      const i = At[0] * this.lineWidth / 2, n = At[1] * this.lineWidth / 2;
      s[0] -= i, s[1] -= n, s[2] += i, s[3] += n;
    }
    return s;
  }
  updateClipFromPath() {
    const t = x.intersect(this.clipBox, this.getPathBoundingBox());
    this.startNewPathAndClipBox(t || [0, 0, 0, 0]);
  }
  isEmptyClip() {
    return this.minMax[0] === 1 / 0;
  }
  startNewPathAndClipBox(t) {
    this.clipBox.set(t, 0), this.minMax.set(ee, 0);
  }
  getClippedPathBoundingBox(t = it.FILL, e = null) {
    return x.intersect(this.clipBox, this.getPathBoundingBox(t, e));
  }
}
function Li(d, t) {
  const {
    width: e,
    height: s,
    kind: i
  } = t, n = s % ft, r = (s - n) / ft, a = n === 0 ? r : r + 1, o = d.createImageData(e, ft);
  let l = 0;
  const h = t.data, c = o.data;
  let u;
  if (i === Ke.GRAYSCALE_1BPP)
    for (u = 0; u < a; u++)
      ({
        srcPos: l
      } = dn({
        src: h,
        srcPos: l,
        dest: c,
        width: e,
        height: u < r ? ft : n
      })), d.putImageData(o, 0, u * ft);
  else if (i === Ke.RGBA_32BPP) {
    let f = 0, p = e * ft * 4;
    for (u = 0; u < r; u++)
      c.set(h.subarray(l, l + p)), l += p, d.putImageData(o, 0, f), f += ft;
    u < a && (p = e * n * 4, c.set(h.subarray(l, l + p)), d.putImageData(o, 0, f));
  } else if (i === Ke.RGB_24BPP)
    for (u = 0; u < a; u++)
      ({
        srcPos: l
      } = vr({
        src: h,
        srcPos: l,
        dest: new Uint32Array(c.buffer),
        width: e,
        height: u < r ? ft : n
      })), d.putImageData(o, 0, u * ft);
  else
    throw new Error(`bad image kind: ${i}`);
}
function Ni(d, t) {
  if (t.bitmap) {
    d.drawImage(t.bitmap, 0, 0);
    return;
  }
  const {
    width: e,
    height: s
  } = t, i = s % ft, n = (s - i) / ft, r = i === 0 ? n : n + 1, a = d.createImageData(e, ft);
  let o = 0;
  const l = t.data, h = a.data;
  for (let c = 0; c < r; c++)
    ({
      srcPos: o
    } = dn({
      src: l,
      srcPos: o,
      dest: h,
      width: e,
      height: c < n ? ft : i,
      nonBlackColor: 0
    })), d.putImageData(a, 0, c * ft);
}
function Qt(d, t) {
  const e = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
  for (const s of e)
    d[s] !== void 0 && (t[s] = d[s]);
  d.setLineDash !== void 0 && (t.setLineDash(d.getLineDash()), t.lineDashOffset = d.lineDashOffset);
}
function un(d, t) {
  d.setAttribute?.("data-canvas-name", t), d._pdfjsCanvasName = t;
}
function Mr(d) {
  return d._pdfjsCanvasName ?? null;
}
function $e(d) {
  d.strokeStyle = d.fillStyle = "#000000", d.fillRule = "nonzero", d.globalAlpha = 1, d.lineWidth = 1, d.lineCap = "butt", d.lineJoin = "miter", d.miterLimit = 10, d.globalCompositeOperation = "source-over", d.font = "10px sans-serif", d.setLineDash !== void 0 && (d.setLineDash([]), d.lineDashOffset = 0);
  const {
    filter: t
  } = d;
  t !== "none" && t !== "" && (d.filter = "none");
}
class Ir {
  #t;
  constructor(t) {
    const [e, s = e, i = e] = t, n = x.identity0to256Map.slice();
    this.#t = [e || n, s || n, i || n];
  }
  applyToColor(t) {
    if (typeof t != "string" || !t.startsWith("#"))
      return t;
    const [e, s, i] = ve(t), [n, r, a] = this.#t;
    return x.makeHexColor(n[e], r[s], a[i]);
  }
  applyToImageData({
    data: t
  }) {
    const [e, s, i] = this.#t;
    for (let n = 0, r = t.length; n < r; n += 4)
      t[n] = e[t[n]], t[n + 1] = s[t[n + 1]], t[n + 2] = i[t[n + 2]];
  }
  applyToCanvas(t) {
    const {
      width: e,
      height: s
    } = t.canvas, i = t.getImageData(0, 0, e, s);
    this.applyToImageData(i), t.putImageData(i, 0, 0);
  }
}
function Bi(d, t, e) {
  if (t)
    return !0;
  x.singularValueDecompose2dScale(d, At);
  const s = Math.fround(e * Ae.PDF_TO_CSS_UNITS);
  return At[0] <= s && At[1] <= s;
}
const Dr = ["butt", "round", "square"], Fr = ["miter", "round", "bevel"], Or = {}, Hi = {};
class Xt {
  static #t = null;
  static #e = /* @__PURE__ */ new WeakMap();
  #s = 0;
  #i = 0;
  #n = null;
  #r = null;
  #a = null;
  #o = null;
  #l = 1;
  #h;
  #u = null;
  #c = [];
  constructor(t, e, s, i, n, {
    optionalContentConfig: r,
    markedContentStack: a = null,
    pixelRatio: o = wt.pixelRatio
  }, l, h, c, u) {
    this.ctx = t, this.current = new Ts(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.commonObjs = e, this.objs = s, this.canvasFactory = i, this.filterFactory = n, this.groupStack = [], this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.tempSMask = null, this.smaskGroupCanvases = [], this.smaskPreparedEntry = null, this.smaskPreparedFor = null, this.smaskPreparedOffsetX = 0, this.smaskPreparedOffsetY = 0, this.smaskPreparedOOBAlpha = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = a || [], this.optionalContentConfig = r, this.pixelRatio = o, this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = l, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = h, this._cachedScaleForStroking = [-1, 0], this._cachedBitmapsMap = /* @__PURE__ */ new Map(), this.dependencyTracker = c ?? null, this.imagesTracker = u ?? null;
  }
  getObject(t, e, s = null) {
    return typeof e == "string" ? (this.dependencyTracker?.recordNamedDependency(t, e), e.startsWith("g_") ? this.commonObjs.get(e) : this.objs.get(e)) : s;
  }
  beginDrawing({
    transform: t,
    viewport: e,
    transparency: s = !1,
    background: i = null
  }) {
    const n = this.ctx.canvas.width, r = this.ctx.canvas.height, a = this.ctx.fillStyle;
    if (this.ctx.fillStyle = i || "#ffffff", this.ctx.fillRect(0, 0, n, r), this.ctx.fillStyle = a, s) {
      const o = this.transparentCanvasEntry = this.canvasFactory.create(n, r);
      this.compositeCtx = this.ctx, {
        canvas: this.transparentCanvas,
        context: this.ctx
      } = o, this.ctx.save(), this.ctx.transform(...X(this.compositeCtx));
    }
    this.ctx.save(), $e(this.ctx), t && (this.ctx.transform(...t), this.outputScaleX = t[0], this.outputScaleY = t[3]), this.ctx.transform(...e.transform), this.viewportScale = e.scale, this.baseTransform = X(this.ctx);
  }
  executeOperatorList(t, e, s, i, n, r) {
    const a = t.argsArray, o = t.fnArray, l = this._pathCache;
    this._pathCache = t.pathCache ?? Xt.#e.getOrInsertComputed(t, ss);
    try {
      let h = e || 0;
      const c = a.length;
      if (c === h)
        return h;
      const u = c - h > Oi && typeof s == "function", f = u ? Date.now() + Pr : 0;
      let p = 0;
      const g = this.commonObjs, m = this.objs;
      let b, y;
      for (; ; ) {
        if (n !== void 0) {
          if (h === n.nextBreakPoint)
            return n.breakIt(h, s), h;
          if (n.shouldSkip(h)) {
            if (++h === c)
              return h;
            continue;
          }
        }
        if (!r || r(h, t))
          if (b = o[h], y = a[h] ?? null, b !== Nt.dependency)
            y === null ? this[b](h) : this[b](h, ...y);
          else
            for (const A of y) {
              this.dependencyTracker?.recordNamedData(A, h);
              const w = A.startsWith("g_") ? g : m;
              if (!w.has(A))
                return w.get(A, s, i), h;
            }
        if (h++, h === c)
          return h;
        if (u && ++p > Oi) {
          if (Date.now() > f)
            return s(), h;
          p = 0;
        }
      }
    } finally {
      this._pathCache = l;
    }
  }
  #f() {
    for (; this.stateStack.length || this.inSMaskMode; )
      this.restore();
    this.current.activeSMask = null, this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.canvasFactory.destroy(this.transparentCanvasEntry), this.transparentCanvas = null, this.transparentCanvasEntry = null);
  }
  endDrawing() {
    this.#f();
    for (const t of this.smaskGroupCanvases)
      this.canvasFactory.destroy(t);
    this.smaskGroupCanvases.length = 0, this._clearPreparedSMask(), this.tempSMask = null, this.smaskStack.length = 0;
    for (const t of this.#c)
      this.#v(t);
    this.#c.length = 0, this.#n = null, this.#r = null, this.#a = null, this.#o = null, this.#l = 1, this.#u = null, this.#i = 0, this.#s = 0, this.cachedPatterns.clear();
    for (const t of this._cachedBitmapsMap.values()) {
      for (const e of t.values())
        typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement && (e.width = e.height = 0);
      t.clear();
    }
    this._cachedBitmapsMap.clear(), this.#p();
  }
  #p() {
    if (this.pageColors) {
      const t = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
      if (t !== "none") {
        const e = this.ctx.filter;
        this.ctx.filter = t, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = e;
      }
    }
  }
  _scaleImage(t, e) {
    const s = t.width ?? t.displayWidth, i = t.height ?? t.displayHeight, n = Math.max(Math.hypot(e[0], e[1]), 1), r = Math.max(Math.hypot(e[2], e[3]), 1), a = [];
    let o = n, l = r, h = s, c = i;
    for (; o > 2 && h > 1 || l > 2 && c > 1; ) {
      let b = h, y = c;
      o > 2 && h > 1 && (b = Math.ceil(h / 2), o /= h / b), l > 2 && c > 1 && (y = Math.ceil(c / 2), l /= c / y), a.push({
        newWidth: b,
        newHeight: y
      }), h = b, c = y;
    }
    if (a.length === 0)
      return {
        img: t,
        paintWidth: s,
        paintHeight: i,
        tmpCanvas: null
      };
    if (a.length === 1) {
      const {
        newWidth: b,
        newHeight: y
      } = a[0], A = this.canvasFactory.create(b, y);
      return A.context.drawImage(t, 0, 0, s, i, 0, 0, b, y), {
        img: A.canvas,
        paintWidth: b,
        paintHeight: y,
        tmpCanvas: A
      };
    }
    let u = this.canvasFactory.create(1, 1), f = this.canvasFactory.create(1, 1), p = s, g = i, m = t;
    for (const {
      newWidth: b,
      newHeight: y
    } of a)
      this.canvasFactory.reset(f, b, y), f.context.drawImage(m, 0, 0, p, g, 0, 0, b, y), [u, f] = [f, u], m = u.canvas, p = b, g = y;
    return this.canvasFactory.destroy(f), {
      img: u.canvas,
      paintWidth: p,
      paintHeight: g,
      tmpCanvas: u
    };
  }
  _createMaskCanvas(t, e) {
    const s = this.ctx, {
      width: i,
      height: n
    } = e, r = this.current.patternFill, a = r ? this.current.fillColor : s.fillStyle, o = X(s);
    let l, h, c, u;
    if ((e.bitmap || e.data) && e.count > 1) {
      const D = e.bitmap || e.data.buffer;
      h = JSON.stringify(r ? o : [o.slice(0, 4), a]), l = this._cachedBitmapsMap.getOrInsertComputed(D, ss);
      const P = l.get(h);
      if (P && !r) {
        const N = Math.round(Math.min(o[0], o[2]) + o[4]), G = Math.round(Math.min(o[1], o[3]) + o[5]);
        return this.dependencyTracker?.recordDependencies(t, St.transformAndFill), {
          canvas: P,
          offsetX: N,
          offsetY: G
        };
      }
      c = P;
    }
    c || (u = this.canvasFactory.create(i, n), Ni(u.context, e));
    let f = x.transform(o, [1 / i, 0, 0, -1 / n, 0, 0]);
    f = x.transform(f, [1, 0, 0, 1, 0, -n]);
    const p = ee.slice();
    x.axialAlignedBoundingBox([0, 0, i, n], f, p);
    const [g, m, b, y] = p, A = Math.round(b - g) || 1, w = Math.round(y - m) || 1, v = this.canvasFactory.create(A, w), S = v.context, _ = g, E = m;
    S.translate(-_, -E), S.transform(...f);
    let C = null;
    if (!c) {
      const D = this._scaleImage(u.canvas, Rt(S));
      c = D.img, C = D.tmpCanvas, c !== u.canvas && (this.canvasFactory.destroy(u), u = null), l && r && (l.set(h, c), C = null, u = null);
    }
    S.imageSmoothingEnabled = Bi(X(S), e.interpolate, this.pixelRatio), ze(S, c, 0, 0, c.width, c.height, 0, 0, i, n), C && this.canvasFactory.destroy(C), u && this.canvasFactory.destroy(u), S.globalCompositeOperation = "source-in";
    const T = x.transform(Rt(S), [1, 0, 0, 1, -_, -E]);
    return S.fillStyle = r ? a.getPattern(s, this, T, it.FILL, t) : a, S.fillRect(0, 0, i, n), l && !r && l.set(h, v.canvas), this.dependencyTracker?.recordDependencies(t, St.transformAndFill), {
      canvas: v.canvas,
      canvasEntry: l && !r ? null : v,
      offsetX: Math.round(_),
      offsetY: Math.round(E)
    };
  }
  setLineWidth(t, e) {
    this.dependencyTracker?.recordSimpleData("lineWidth", t), e !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = e, this.ctx.lineWidth = e;
  }
  setLineCap(t, e) {
    this.dependencyTracker?.recordSimpleData("lineCap", t), this.ctx.lineCap = Dr[e];
  }
  setLineJoin(t, e) {
    this.dependencyTracker?.recordSimpleData("lineJoin", t), this.ctx.lineJoin = Fr[e];
  }
  setMiterLimit(t, e) {
    this.dependencyTracker?.recordSimpleData("miterLimit", t), this.ctx.miterLimit = e;
  }
  setDash(t, e, s) {
    this.dependencyTracker?.recordSimpleData("dash", t);
    const i = this.ctx;
    i.setLineDash !== void 0 && (i.setLineDash(e), i.lineDashOffset = s);
  }
  setRenderingIntent(t, e) {
  }
  setFlatness(t, e) {
  }
  setGState(t, e) {
    for (const [s, i] of e)
      switch (s) {
        case "LW":
          this.setLineWidth(t, i);
          break;
        case "LC":
          this.setLineCap(t, i);
          break;
        case "LJ":
          this.setLineJoin(t, i);
          break;
        case "ML":
          this.setMiterLimit(t, i);
          break;
        case "D":
          this.setDash(t, i[0], i[1]);
          break;
        case "RI":
          this.setRenderingIntent(t, i);
          break;
        case "FL":
          this.setFlatness(t, i);
          break;
        case "Font":
          this.setFont(t, i[0], i[1]);
          break;
        case "CA":
          this.dependencyTracker?.recordSimpleData("strokeAlpha", t), this.current.strokeAlpha = i;
          break;
        case "ca":
          this.dependencyTracker?.recordSimpleData("fillAlpha", t), this.ctx.globalAlpha = this.current.fillAlpha = i;
          break;
        case "BM":
          this.dependencyTracker?.recordSimpleData("globalCompositeOperation", t), this.ctx.globalCompositeOperation = i;
          break;
        case "SMask":
          this.dependencyTracker?.recordSimpleData("SMask", t), this.current.activeSMask = i ? this.tempSMask : null, this.current.activeSMask && (this.current.activeSMask.blendMode = this.ctx.globalCompositeOperation), this.tempSMask = null, this.checkSMaskState(t);
          break;
        case "TR": {
          this.dependencyTracker?.recordSimpleData("filter", t);
          let n = this.filterFactory.addFilter(i);
          this.ctx.filter = n;
          let r = null;
          i && (n === "none" || !W.isCanvasFilterSupported || this.ctx.filter === "none" || this.ctx.filter === "") && (this.ctx.filter = n = "none", r = new Ir(i)), this.current.transferMaps = n, (r || this.current.transferMapsFallback) && (this.current.transferMapsFallback = r, this.current.patternFill || (this.ctx.fillStyle = this.#S(this.current.fillColor)), this.current.patternStroke || (this.ctx.strokeStyle = this.#S(this.current.strokeColor)));
          break;
        }
      }
  }
  get inSMaskMode() {
    return !!this.suspendedCtx;
  }
  _clearPreparedSMask() {
    this.smaskPreparedEntry && (this.canvasFactory.destroy(this.smaskPreparedEntry), this.smaskPreparedEntry = null), this.smaskPreparedFor = null, this.smaskPreparedOffsetX = 0, this.smaskPreparedOffsetY = 0, this.smaskPreparedOOBAlpha = null;
  }
  _ensurePreparedSMask(t) {
    t !== this.smaskPreparedFor && (this._clearPreparedSMask(), this._prepareSMaskCanvas(t));
  }
  checkSMaskState(t) {
    const e = this.inSMaskMode;
    this.current.activeSMask && !e ? this.beginSMaskMode(t) : !this.current.activeSMask && e ? this.endSMaskMode() : this.current.activeSMask && e && this._ensurePreparedSMask(this.current.activeSMask);
  }
  _prepareSMaskCanvas(t) {
    const {
      canvas: e,
      subtype: s,
      backdrop: i,
      transferMap: n
    } = t, r = s === "Luminosity" || s === "Alpha" && n;
    if (!r && !(s === "Luminosity" && i)) {
      this.smaskPreparedFor = t;
      return;
    }
    let a;
    if (s === "Luminosity" && i) {
      const [y, A, w] = ve(i), v = Math.round(0.3 * y + 0.59 * A + 0.11 * w);
      a = n?.[v] ?? v;
    } else
      a = n?.[0] ?? 0;
    const o = 4, {
      width: l,
      height: h
    } = this.ctx.canvas, c = e.width * e.height, u = l * h < o * c, f = r ? {
      url: s === "Alpha" ? this.filterFactory.addAlphaFilter(n) : this.filterFactory.addLuminosityFilter(n),
      subtype: s,
      transferMap: n
    } : null, p = s === "Luminosity" ? i : null;
    let g, m, b;
    u ? (g = this._bakeSMaskCanvas(e, t.offsetX, t.offsetY, l, h, p, f), m = 0, b = 0) : (g = this._bakeSMaskCanvas(e, 0, 0, e.width, e.height, p, f), m = t.offsetX, b = t.offsetY), this.smaskPreparedEntry = g, this.smaskPreparedFor = t, this.smaskPreparedOffsetX = m, this.smaskPreparedOffsetY = b, this.smaskPreparedOOBAlpha = !u && a !== 0 ? a : null;
  }
  _bakeSMaskCanvas(t, e, s, i, n, r, a) {
    !r && !a && j("_bakeSMaskCanvas with neither backdrop nor filter");
    const o = this.canvasFactory.create(i, n), l = o.context;
    if (l.drawImage(t, e, s), r && (l.globalCompositeOperation = "destination-atop", l.fillStyle = r, l.fillRect(0, 0, i, n)), !a)
      return o;
    const h = this.canvasFactory.create(i, n), c = h.context;
    c.filter = a.url;
    const u = W.isCanvasFilterSupported && c.filter !== "none" && c.filter !== "";
    if (c.drawImage(o.canvas, 0, 0), W.isCanvasFilterSupported && (c.filter = "none"), !u) {
      const f = c.getImageData(0, 0, i, n), {
        data: p
      } = f, {
        transferMap: g
      } = a;
      if (a.subtype === "Luminosity")
        for (let m = 0, b = p.length; m < b; m += 4) {
          const y = 0.3 * p[m] + 0.59 * p[m + 1] + 0.11 * p[m + 2] + 0.5 | 0;
          p[m] = p[m + 1] = p[m + 2] = 0, p[m + 3] = g?.[y] ?? y;
        }
      else
        for (let m = 3, b = p.length; m < b; m += 4)
          p[m] = g[p[m]];
      c.putImageData(f, 0, 0);
    }
    return this.canvasFactory.destroy(o), h;
  }
  beginSMaskMode(t) {
    if (this.inSMaskMode)
      throw new Error("beginSMaskMode called while already in smask mode");
    const {
      width: e,
      height: s
    } = this.ctx.canvas, i = this.canvasFactory.create(e, s);
    this.smaskScratchCanvas = i, this.suspendedCtx = this.ctx;
    const n = this.ctx = i.context;
    n.setTransform(this.suspendedCtx.getTransform()), Qt(this.suspendedCtx, n), Ri(n, this.suspendedCtx), this._ensurePreparedSMask(this.current.activeSMask), this.setGState(t, [["BM", "source-over"]]);
  }
  endSMaskMode() {
    if (!this.inSMaskMode)
      throw new Error("endSMaskMode called while not in smask mode");
    this.ctx._removeMirroring(), Qt(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null, this.canvasFactory.destroy(this.smaskScratchCanvas), this.smaskScratchCanvas = null, this._clearPreparedSMask();
  }
  #m(t, e = null, s = 1) {
    const {
      width: i,
      height: n
    } = t, r = e ?? this.canvasFactory.create(i, n), a = r.context;
    s = Math.round(s * 255) / 255;
    const o = s < 1;
    o && this.#h === void 0 && (this.#h = W.isCanvasFilterSupported ? /* @__PURE__ */ new Map() : "none");
    let l = "none";
    if (o && this.#h instanceof Map && (l = this.#h.getOrInsertComputed(s, () => this.filterFactory.addKnockoutFilter(s))), !o || l !== "none")
      return e && (a.save(), a.setTransform(1, 0, 0, 1, 0, 0), a.clearRect(0, 0, i, n), a.restore()), a.filter = l, a.drawImage(t, 0, 0), a.filter = "none", r;
    const h = t.getContext("2d", {
      willReadFrequently: !0
    }).getImageData(0, 0, i, n), c = a.createImageData(i, n), u = h.data, f = c.data, p = s > 0 ? 1 / s : 1e6;
    for (let g = 3, m = u.length; g < m; g += 4)
      f[g] = Math.min(Math.round(u[g] * p), 255);
    return a.putImageData(c, 0, 0), r;
  }
  #d(t, e, s, i) {
    let n = t?.[e] ?? null;
    if (n && (n.canvas.width !== s || n.canvas.height !== i) && (this.canvasFactory.destroy(n), n = null), !n)
      return n = this.canvasFactory.create(s, i), t && (t[e] = n), n;
    const r = n.context;
    return r.save(), r.setTransform(1, 0, 0, 1, 0, 0), r.clearRect(0, 0, s, i), r.restore(), n;
  }
  #g(t, e, s = {}) {
    const {
      backdropCanvas: i = null,
      destTransform: n = [1, 0, 0, 1, 0, 0],
      backdropOffset: r = [0, 0],
      reuseMaskEntry: a = null,
      poolMeta: o = null,
      sourceAlpha: l = 1,
      sourceFilter: h = "none",
      knockoutAlpha: c = 1
    } = s, {
      width: u,
      height: f
    } = e, p = this.#m(e, a, c), g = t.globalCompositeOperation;
    if (t.save(), t.setTransform(...n), t.globalAlpha = 1, W.isCanvasFilterSupported && (t.filter = "none"), t.globalCompositeOperation = "destination-out", t.drawImage(p.canvas, 0, 0), i) {
      const [m, b] = r, y = this.#d(o, "knockoutBackdropEntry", u, f), A = y.context;
      A.drawImage(i, m, b, u, f, 0, 0, u, f), A.globalCompositeOperation = "destination-in", A.drawImage(p.canvas, 0, 0), A.globalCompositeOperation = "source-over", t.globalCompositeOperation = "destination-over", t.drawImage(y.canvas, 0, 0), o || this.canvasFactory.destroy(y);
    }
    t.globalCompositeOperation = g, t.globalAlpha = l, W.isCanvasFilterSupported && (t.filter = h ?? "none"), t.drawImage(e, 0, 0), t.restore(), a || this.canvasFactory.destroy(p);
  }
  #b(t = 1) {
    if (this.#s === 0 || this.#i > 0 || !this.contentVisible)
      return !1;
    this.#i++, this.#l = t;
    const e = this.#c.at(-1), {
      canvas: s
    } = this.ctx, i = this.#d(e, "knockoutTempEntry", s.width, s.height);
    this.#n = i;
    const n = i.context;
    return n.save(), n.setTransform(this.ctx.getTransform()), Qt(this.ctx, n), this.#o = n.globalCompositeOperation, n.globalCompositeOperation = "source-over", Ri(n, this.ctx), this.#u = e, this.#r = this.ctx, this.#a = this.suspendedCtx, this.ctx = n, this.inSMaskMode && (this.suspendedCtx = n), !0;
  }
  #y(t) {
    if (!t)
      return;
    const e = this.#n, s = this.#r, i = this.#a, n = e.context;
    this.#n = null, this.#r = null, this.#a = null, this.inSMaskMode && this.suspendedCtx === n && this.ctx !== n && this.endSMaskMode(), this.inSMaskMode && (this.suspendedCtx = i), this.ctx._removeMirroring(), this.ctx.globalCompositeOperation = this.#o, this.#o = null, Qt(this.ctx, s), this.ctx = s;
    const r = this.#u;
    this.#u = null;
    const a = this.#l;
    this.#l = 1;
    try {
      this.#g(i ?? s, e.canvas, {
        backdropCanvas: r?.backdropCtx?.canvas ?? null,
        backdropOffset: r?.backdropCtx ? [r.offsetX, r.offsetY] : [0, 0],
        reuseMaskEntry: r?.knockoutMaskEntry ?? null,
        poolMeta: r,
        knockoutAlpha: a
      });
    } finally {
      n.restore(), this.#i--, r || this.canvasFactory.destroy(e);
    }
  }
  compose(t) {
    if (!this.current.activeSMask)
      return;
    t = t ? [Math.floor(t[0]), Math.floor(t[1]), Math.ceil(t[2]), Math.ceil(t[3])] : [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
    const e = this.current.activeSMask, s = this.suspendedCtx, i = this.#i > 0 && s === this.ctx;
    this.composeSMask(i ? null : s, e, this.ctx, t), !i && (this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore());
  }
  composeSMask(t, e, s, i) {
    const n = i[0], r = i[1], a = i[2] - n, o = i[3] - r;
    if (a === 0 || o === 0)
      return;
    const l = this.smaskPreparedEntry;
    if (l) {
      let h = n, c = r, u = a, f = o;
      const p = this.smaskPreparedOOBAlpha, g = p !== null;
      if (g) {
        h = Math.max(n, e.offsetX), c = Math.max(r, e.offsetY);
        const m = Math.min(n + a, e.offsetX + e.canvas.width), b = Math.min(r + o, e.offsetY + e.canvas.height);
        u = m - h, f = b - c;
      }
      if (u > 0 && f > 0) {
        const m = h - this.smaskPreparedOffsetX, b = c - this.smaskPreparedOffsetY;
        s.save(), s.globalAlpha = 1, s.setTransform(1, 0, 0, 1, 0, 0);
        const y = new Path2D();
        y.rect(h, c, u, f), s.clip(y), s.globalCompositeOperation = "destination-in", s.drawImage(l.canvas, m, b, u, f, h, c, u, f), s.restore();
      }
      g && p < 255 && this._applySMaskOOBAlpha(s, n, r, a, o, h, c, h + u, c + f, p);
    } else
      this.genericComposeSMask(e, s, a, o, n, r);
    t && (t.save(), t.globalAlpha = 1, t.globalCompositeOperation = e.blendMode || "source-over", t.setTransform(1, 0, 0, 1, 0, 0), t.drawImage(s.canvas, n, r, a, o, n, r, a, o), t.restore());
  }
  _applySMaskOOBAlpha(t, e, s, i, n, r, a, o, l, h) {
    const c = r < o && a < l;
    if (c && r === e && a === s && o === e + i && l === s + n)
      return;
    const u = new Path2D();
    u.rect(e, s, i, n), c && u.rect(r, a, o - r, l - a), t.save(), t.globalAlpha = h / 255, t.setTransform(1, 0, 0, 1, 0, 0), t.clip(u, "evenodd"), t.globalCompositeOperation = "destination-in", t.fillStyle = "#000000", t.fillRect(e, s, i, n), t.restore();
  }
  genericComposeSMask(t, e, s, i, n, r) {
    const {
      context: a,
      offsetX: o,
      offsetY: l
    } = t;
    e.save(), e.globalAlpha = 1, e.setTransform(1, 0, 0, 1, 0, 0);
    const h = new Path2D();
    h.rect(n, r, s, i), e.clip(h), e.globalCompositeOperation = "destination-in", e.drawImage(a.canvas, n - o, r - l, s, i, n, r, s, i), e.restore();
  }
  save(t) {
    this.inSMaskMode && Qt(this.ctx, this.suspendedCtx), this.ctx.save();
    const e = this.current;
    this.stateStack.push(e), this.current = e.clone(), this.dependencyTracker?.save(t);
  }
  restore(t) {
    if (this.dependencyTracker?.restore(t), this.stateStack.length === 0) {
      this.inSMaskMode && this.endSMaskMode();
      return;
    }
    this.current = this.stateStack.pop(), this.ctx.restore(), this.inSMaskMode && (Qt(this.suspendedCtx, this.ctx), this.ctx.setTransform(this.suspendedCtx.getTransform())), this.checkSMaskState(t), this.pendingClip = null, this._cachedScaleForStroking[0] = -1;
  }
  resetGraphicsState() {
    const {
      clipBox: t,
      transferMaps: e,
      transferMapsFallback: s
    } = this.current, i = this.current = new Ts(0, 0);
    i.clipBox = t, i.transferMaps = e, i.transferMapsFallback = s;
    const n = this.ctx;
    n.lineWidth = 1, n.lineCap = "butt", n.lineJoin = "miter", n.miterLimit = 10, n.setLineDash !== void 0 && (n.setLineDash([]), n.lineDashOffset = 0), this._cachedScaleForStroking[0] = -1;
  }
  transform(t, e, s, i, n, r, a) {
    this.dependencyTracker?.recordIncrementalData("transform", t), this.ctx.transform(e, s, i, n, r, a), this._cachedScaleForStroking[0] = -1;
  }
  constructPath(t, e, s, i) {
    let n = this._pathCache.get(t);
    if (!i) {
      n || (n = new Path2D(), this._pathCache.set(t, n)), e !== Nt.stroke && e !== Nt.closeStroke && (this.current.tilingPatternDims = null), this[e](t, n);
      return;
    }
    if (this.dependencyTracker !== null) {
      const a = e === Nt.stroke ? this.current.lineWidth / 2 : 0;
      this.dependencyTracker.resetBBox(t).recordBBox(t, this.ctx, i[0] - a, i[2] + a, i[1] - a, i[3] + a).recordDependencies(t, ["transform"]);
    }
    n || (n = Ji(s[0]), this._pathCache.set(t, n)), x.axialAlignedBoundingBox(i, X(this.ctx), this.current.minMax);
    const r = this.current.tilingPatternDims;
    if (r && e !== Nt.stroke && e !== Nt.closeStroke && this.current.fillColor instanceof ke) {
      const a = x.intersect(this.current.clipBox, this.current.minMax);
      a ? this.current.fillColor.updatePatternDims(a, r) : this.current.tilingPatternDims = null;
    }
    this[e](t, n), this._pathStartIdx = t;
  }
  closePath(t) {
    this.ctx.closePath();
  }
  stroke(t, e, s = !0) {
    const i = s && this.#b(this.current.strokeAlpha), n = this.ctx, r = this.current.strokeColor;
    if (n.globalAlpha = this.current.strokeAlpha, this.contentVisible)
      if (typeof r == "object" && r?.getPattern) {
        const a = r.isModifyingCurrentTransform() ? n.getTransform() : null;
        if (n.save(), n.strokeStyle = r.getPattern(n, this, Rt(n), it.STROKE, t), a) {
          const o = new Path2D();
          o.addPath(e, n.getTransform().invertSelf().multiplySelf(a)), e = o;
        }
        this.rescaleAndStroke(e, !1), n.restore();
      } else
        this.rescaleAndStroke(e, !0);
    this.dependencyTracker?.recordDependencies(t, St.stroke), s && this.consumePath(t, e, this.current.getClippedPathBoundingBox(it.STROKE, X(this.ctx))), n.globalAlpha = this.current.fillAlpha, this.#y(i);
  }
  closeStroke(t, e) {
    this.stroke(t, e);
  }
  fill(t, e, s = !0) {
    const i = s && this.#b(this.current.fillAlpha), n = this.ctx, r = this.current.fillColor, a = this.current.patternFill;
    let o = !1;
    const l = this.current.getClippedPathBoundingBox();
    if (this.dependencyTracker?.recordDependencies(t, St.fill), a) {
      const h = this.current.tilingPatternDims, c = h && r.canSkipPatternCanvas(h);
      if (c) {
        const {
          pendingClip: f,
          pendingEOFill: p
        } = this;
        this.pendingClip = null, this.pendingEOFill = !1, r.drawPattern(this, e, p, c, t), this.pendingClip = f, s && this.consumePath(t, e, l), this.current.tilingPatternDims = null, this.#y(i);
        return;
      }
      const u = r.isModifyingCurrentTransform() ? n.getTransform() : null;
      if (this.dependencyTracker?.save(t), n.save(), n.fillStyle = r.getPattern(n, this, Rt(n), it.FILL, t), u) {
        const f = new Path2D();
        f.addPath(e, n.getTransform().invertSelf().multiplySelf(u)), e = f;
      }
      o = !0;
    }
    this.contentVisible && l !== null && (this.pendingEOFill ? (n.fill(e, "evenodd"), this.pendingEOFill = !1) : n.fill(e)), o && (n.restore(), this.dependencyTracker?.restore(t)), s && this.consumePath(t, e, l), this.#y(i);
  }
  eoFill(t, e) {
    this.pendingEOFill = !0, this.fill(t, e);
  }
  fillStroke(t, e) {
    const s = this.#b(Math.min(this.current.fillAlpha, this.current.strokeAlpha));
    this.fill(t, e, !1), this.stroke(t, e, !1), this.consumePath(t, e), this.#y(s);
  }
  eoFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  closeFillStroke(t, e) {
    this.fillStroke(t, e);
  }
  closeEOFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  endPath(t, e) {
    this.consumePath(t, e);
  }
  rawFillPath(t, e) {
    const s = this.#b(this.current.fillAlpha);
    this.ctx.fill(e), this.dependencyTracker?.recordDependencies(t, St.rawFillPath).recordOperation(t), this.#y(s);
  }
  clip(t) {
    this.dependencyTracker?.recordFutureForcedDependency("clipMode", t), this.pendingClip = Or;
  }
  eoClip(t) {
    this.dependencyTracker?.recordFutureForcedDependency("clipMode", t), this.pendingClip = Hi;
  }
  beginText(t) {
    this.current.textMatrix = null, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0, this.dependencyTracker?.recordOpenMarker(t).resetIncrementalData("sameLineText").resetIncrementalData("moveText", t);
  }
  endText(t) {
    const e = this.pendingTextPaths, s = this.ctx;
    if (this.dependencyTracker) {
      const {
        dependencyTracker: i
      } = this;
      e !== void 0 && i.recordFutureForcedDependency("textClip", i.getOpenMarker()).recordFutureForcedDependency("textClip", t), i.recordCloseMarker(t);
    }
    if (e !== void 0) {
      const i = new Path2D(), n = s.getTransform().invertSelf();
      for (const {
        transform: r,
        x: a,
        y: o,
        fontSize: l,
        path: h
      } of e)
        h && i.addPath(h, new DOMMatrix(r).preMultiplySelf(n).translate(a, o).scale(l, -l));
      s.clip(i);
    }
    delete this.pendingTextPaths;
  }
  setCharSpacing(t, e) {
    this.dependencyTracker?.recordSimpleData("charSpacing", t), this.current.charSpacing = e;
  }
  setWordSpacing(t, e) {
    this.dependencyTracker?.recordSimpleData("wordSpacing", t), this.current.wordSpacing = e;
  }
  setHScale(t, e) {
    this.dependencyTracker?.recordSimpleData("hScale", t), this.current.textHScale = e / 100;
  }
  setLeading(t, e) {
    this.dependencyTracker?.recordSimpleData("leading", t), this.current.leading = -e;
  }
  setFont(t, e, s) {
    this.dependencyTracker?.recordSimpleData("font", t).recordSimpleDataFromNamed("fontObj", e, t);
    const i = this.commonObjs.get(e), n = this.current;
    if (!i)
      throw new Error(`Can't find font for ${e}`);
    if (n.fontMatrix = i.fontMatrix || Ds, (n.fontMatrix[0] === 0 || n.fontMatrix[3] === 0) && R("Invalid font matrix for font " + e), s < 0 ? (s = -s, n.fontDirection = -1) : n.fontDirection = 1, this.current.font = i, this.current.fontSize = s, i.isType3Font)
      return;
    const r = i.loadedName || "sans-serif", a = i.systemFontInfo?.css || `"${r}", ${i.fallbackName}`;
    let o = "normal";
    i.black ? o = "900" : i.bold && (o = "bold");
    const l = i.italic ? "italic" : "normal", h = Y(s, Tr, kr);
    this.current.fontSizeScale = s / h, this.ctx.font = `${l} ${o} ${h}px ${a}`;
  }
  setTextRenderingMode(t, e) {
    this.dependencyTracker?.recordSimpleData("textRenderingMode", t), this.current.textRenderingMode = e;
  }
  setTextRise(t, e) {
    this.dependencyTracker?.recordSimpleData("textRise", t), this.current.textRise = e;
  }
  moveText(t, e, s) {
    this.dependencyTracker?.resetIncrementalData("sameLineText").recordIncrementalData("moveText", t), this.current.x = this.current.lineX += e, this.current.y = this.current.lineY += s;
  }
  setLeadingMoveText(t, e, s) {
    this.setLeading(t, -s), this.moveText(t, e, s);
  }
  setTextMatrix(t, e) {
    this.dependencyTracker?.resetIncrementalData("sameLineText").recordSimpleData("textMatrix", t);
    const {
      current: s
    } = this;
    s.textMatrix = e, s.textMatrixScale = Math.hypot(e[0], e[1]), s.x = s.lineX = 0, s.y = s.lineY = 0;
  }
  nextLine(t) {
    this.moveText(t, 0, this.current.leading), this.dependencyTracker?.recordIncrementalData("moveText", this.dependencyTracker.getSimpleIndex("leading") ?? t);
  }
  #A(t, e, s) {
    const i = new Path2D();
    return i.addPath(t, new DOMMatrix(s).invertSelf().multiplySelf(e)), i;
  }
  paintChar(t, e, s, i, n, r) {
    const a = this.ctx, o = this.current, l = o.font, h = o.textRenderingMode, c = o.fontSize / o.fontSizeScale, u = h & st.FILL_STROKE_MASK, f = !!(h & st.ADD_TO_PATH_FLAG), p = o.patternFill && !l.missingFile, g = o.patternStroke && !l.missingFile;
    let m;
    if ((l.disableFontFace || f || p || g) && !l.missingFile && (m = l.getPathGenerator(this.commonObjs, e)), m && (l.disableFontFace || p || g)) {
      a.save(), a.translate(s, i), a.scale(c, -c), this.dependencyTracker?.recordCharacterBBox(t, a, l);
      let b;
      if (u === st.FILL || u === st.FILL_STROKE)
        if (n) {
          b = a.getTransform(), a.setTransform(...n);
          const y = this.#A(m, b, n);
          a.fill(y);
        } else
          a.fill(m);
      if (u === st.STROKE || u === st.FILL_STROKE)
        if (r) {
          b ||= a.getTransform(), a.setTransform(...r);
          const {
            a: y,
            b: A,
            c: w,
            d: v
          } = b, S = x.inverseTransform(r), _ = x.transform([y, A, w, v, 0, 0], S);
          x.singularValueDecompose2dScale(_, At), a.lineWidth *= Math.max(At[0], At[1]) / c, a.stroke(this.#A(m, b, r));
        } else
          a.lineWidth /= c, a.stroke(m);
      a.restore();
    } else
      (u === st.FILL || u === st.FILL_STROKE) && (a.fillText(e, s, i), this.dependencyTracker?.recordCharacterBBox(t, a, l, c, s, i, () => a.measureText(e))), (u === st.STROKE || u === st.FILL_STROKE) && (this.dependencyTracker && this.dependencyTracker?.recordCharacterBBox(t, a, l, c, s, i, () => a.measureText(e)).recordDependencies(t, St.stroke), a.strokeText(e, s, i));
    f && ((this.pendingTextPaths ||= []).push({
      transform: X(a),
      x: s,
      y: i,
      fontSize: c,
      path: m
    }), this.dependencyTracker?.recordCharacterBBox(t, a, l, c, s, i));
  }
  get isFontSubpixelAAEnabled() {
    const t = this.canvasFactory.create(10, 10), e = t.context;
    e.scale(1.5, 1), e.fillText("I", 0, 10);
    const s = e.getImageData(0, 0, 10, 10).data;
    this.canvasFactory.destroy(t);
    let i = !1;
    for (let n = 3; n < s.length; n += 4)
      if (s[n] > 0 && s[n] < 255) {
        i = !0;
        break;
      }
    return k(this, "isFontSubpixelAAEnabled", i);
  }
  #w(t, e, s) {
    const i = this.ctx;
    i.save();
    const n = t.getPattern(i, this, Rt(i), e, s), r = X(i);
    return i.restore(), [n, r];
  }
  showText(t, e) {
    this.dependencyTracker && (this.dependencyTracker.recordDependencies(t, St.showText).resetBBox(t), this.current.textRenderingMode & st.ADD_TO_PATH_FLAG && this.dependencyTracker.recordFutureForcedDependency("textClip", t).inheritPendingDependenciesAsFutureForcedDependencies());
    const s = this.current, i = s.font;
    if (i.isType3Font) {
      const P = this.#b(s.fillAlpha);
      this.showType3Text(t, e), this.dependencyTracker?.recordShowTextOperation(t), this.#y(P);
      return;
    }
    const n = s.fontSize;
    if (n === 0) {
      this.dependencyTracker?.recordOperation(t);
      return;
    }
    const r = this.#b(s.fillAlpha), a = this.ctx, o = s.fontSizeScale, l = s.charSpacing, h = s.wordSpacing, c = s.fontDirection, u = s.textHScale * c, f = e.length, p = i.vertical, g = p ? 1 : -1, m = n * s.fontMatrix[0], b = s.textRenderingMode === st.FILL && !i.disableFontFace && !s.patternFill;
    a.save(), s.textMatrix && a.transform(...s.textMatrix), a.translate(s.x, s.y + s.textRise), c > 0 ? a.scale(u, -1) : a.scale(u, 1);
    let y, A;
    const w = s.textRenderingMode & st.FILL_STROKE_MASK, v = w === st.FILL || w === st.FILL_STROKE, S = w === st.STROKE || w === st.FILL_STROKE;
    let _ = s.lineWidth;
    const E = s.textMatrixScale;
    if (E === 0 || _ === 0 ? S && (_ = this.getSinglePixelWidth()) : _ /= E, o !== 1 && (a.scale(o, o), _ /= o), a.lineWidth = _, v && s.patternFill && ([a.fillStyle, y] = this.#w(s.fillColor, it.FILL, t)), S && s.patternStroke && ([a.strokeStyle, A] = this.#w(s.strokeColor, it.STROKE, t)), i.isInvalidPDFjsFont) {
      const P = [];
      let N = 0;
      for (const z of e)
        P.push(z.unicode), N += z.width;
      const G = P.join("");
      if (a.fillText(G, 0, 0), this.dependencyTracker !== null) {
        const z = a.measureText(G);
        this.dependencyTracker.recordBBox(t, this.ctx, -z.actualBoundingBoxLeft, z.actualBoundingBoxRight, -z.actualBoundingBoxAscent, z.actualBoundingBoxDescent).recordShowTextOperation(t);
      }
      s.x += N * m * u, a.restore(), this.compose(), this.#y(r);
      return;
    }
    let C = 0, T, D = null;
    for (T = 0; T < f; ++T) {
      const P = e[T];
      if (typeof P == "number") {
        C += g * P * n / 1e3;
        continue;
      }
      let N = !1;
      const G = (P.isSpace ? h : 0) + l, z = P.fontChar, F = P.accent;
      let O, rt, lt, Ft = P.width;
      if (p) {
        const ht = P.vmetric, qt = -ht[1] * m, Gt = ht[2] * m;
        if (Ft = -ht[0], O = qt / o, rt = (C + Gt) / o, P.isRotated) {
          lt = a.measureText(z);
          const Q = m / o, Be = P.width / 2 * Q, jt = O + Be;
          O = rt - /* inlined export .DEFAULT_VERTICAL_ORIGIN_Y */
          (880 - /* inlined export .DEFAULT_VERTICAL_ADVANCE */
          1e3 / 2) * Q - Be, rt = (lt.actualBoundingBoxAscent - lt.actualBoundingBoxDescent) / 2 - jt, N = !0, a.save(), a.rotate(Math.PI / 2);
        }
      } else
        O = C / o, rt = 0;
      const Tt = P.isRotated ? P.width : Ft;
      let tt = 1;
      if ((i.remeasure || P.isRotated) && Tt > 0) {
        lt ??= a.measureText(z);
        const ht = lt.width * 1e3 / n * o;
        Tt < ht && this.isFontSubpixelAAEnabled ? (tt = Tt / ht, N || (N = !0, a.save()), a.scale(tt, 1), O /= tt) : Tt !== ht && (O += (Tt - ht) / 2e3 * n / o);
      }
      if (N && i.missingFile && (y || A) && (D ||= /* @__PURE__ */ new Map(), [a.fillStyle, a.strokeStyle] = D.getOrInsertComputed(P.isRotated ? -tt : tt, () => [y ? this.#w(s.fillColor, it.FILL, t)[0] : a.fillStyle, A ? this.#w(s.strokeColor, it.STROKE, t)[0] : a.strokeStyle])), this.contentVisible && (P.isInFont || i.missingFile)) {
        if (b && !F)
          a.fillText(z, O, rt), this.dependencyTracker?.recordCharacterBBox(t, a, lt ? {
            bbox: null
          } : i, n / o, O, rt, () => lt ?? a.measureText(z));
        else if (this.paintChar(t, z, O, rt, y, A), F) {
          const ht = O + n * F.offset.x / o, qt = rt - n * F.offset.y / o;
          this.paintChar(t, F.fontChar, ht, qt, y, A);
        }
      }
      const et = p ? Ft * m - G * c : Ft * m + G * c;
      C += et, N && a.restore();
    }
    p ? s.y -= C : s.x += C * u, a.restore(), this.compose(), this.dependencyTracker?.recordShowTextOperation(t), this.#y(r);
  }
  showType3Text(t, e) {
    const s = this.ctx, i = this.current, n = i.font, r = i.fontSize, a = i.fontDirection, o = n.vertical ? 1 : -1, l = i.charSpacing, h = i.wordSpacing, c = i.textHScale * a, u = i.fontMatrix || Ds, f = e.length, p = i.textRenderingMode !== st.INVISIBLE;
    let g, m, b, y;
    if (r === 0)
      return;
    this._cachedScaleForStroking[0] = -1, s.save(), i.textMatrix && s.transform(...i.textMatrix), s.translate(i.x, i.y + i.textRise), s.scale(c, a);
    const A = this.dependencyTracker;
    this.dependencyTracker = A ? new De(A, t) : null;
    try {
      for (g = 0; g < f; ++g) {
        if (m = e[g], typeof m == "number") {
          y = o * m * r / 1e3, this.ctx.translate(y, 0), i.x += y * c;
          continue;
        }
        const w = (m.isSpace ? h : 0) + l, v = n.charProcOperatorList.get(m.operatorListId);
        v ? this.contentVisible && p && (this.save(), s.scale(r, r), s.transform(...u), this.executeOperatorList(v), this.restore()) : R(`Type3 character "${m.operatorListId}" is not available.`), b = m.width * u[0] * r + w * a, s.translate(b, 0), i.x += b * c;
      }
    } finally {
      A && (this.dependencyTracker = A);
    }
    s.restore();
  }
  setCharWidth(t, e, s) {
  }
  setCharWidthAndBounds(t, e, s, i, n, r, a) {
    const o = new Path2D();
    o.rect(i, n, r - i, a - n), this.ctx.clip(o), this.dependencyTracker?.recordBBox(t, this.ctx, i, r, n, a).recordClipBox(t, this.ctx, i, r, n, a), this.endPath(t);
  }
  getColorN_Pattern(t, e) {
    let s;
    if (e[0] === "TilingPattern") {
      const i = this.baseTransform || X(this.ctx), n = {
        createCanvasGraphics: (r, a) => new Xt(r, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
          optionalContentConfig: this.optionalContentConfig,
          markedContentStack: this.markedContentStack,
          pixelRatio: this.pixelRatio
        }, void 0, void 0, this.dependencyTracker ? new De(this.dependencyTracker, a, !0) : null)
      };
      s = new ke(e, this.ctx, n, i);
    } else
      s = this._getPattern(t, e[1], e[2]);
    return s;
  }
  setStrokeColorN(t, ...e) {
    this.dependencyTracker?.recordSimpleData("strokeColor", t), this.current.strokeColor = this.getColorN_Pattern(t, e), this.current.patternStroke = !0;
  }
  setFillColorN(t, ...e) {
    this.dependencyTracker?.recordSimpleData("fillColor", t);
    const s = this.current.fillColor = this.getColorN_Pattern(t, e);
    this.current.patternFill = !0, this.current.tilingPatternDims = s instanceof ke ? [0, 0, 0, 0] : null;
  }
  #S(t) {
    return this.current.transferMapsFallback?.applyToColor(t) ?? t;
  }
  setStrokeRGBColor(t, e) {
    this.dependencyTracker?.recordSimpleData("strokeColor", t), this.current.strokeColor = e, this.ctx.strokeStyle = this.#S(e), this.current.patternStroke = !1;
  }
  setStrokeTransparent(t) {
    this.dependencyTracker?.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = "transparent", this.current.patternStroke = !1;
  }
  setFillRGBColor(t, e) {
    this.dependencyTracker?.recordSimpleData("fillColor", t), this.current.fillColor = e, this.ctx.fillStyle = this.#S(e), this.current.patternFill = !1, this.current.tilingPatternDims = null;
  }
  setFillTransparent(t) {
    this.dependencyTracker?.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = "transparent", this.current.patternFill = !1, this.current.tilingPatternDims = null;
  }
  _getPattern(t, e, s = null) {
    const i = this.cachedPatterns.getOrInsertComputed(e, () => xr(this.getObject(t, e)));
    return s && (i.matrix = s), i;
  }
  shadingFill(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.#b(this.current.fillAlpha), i = this.ctx;
    this.save(t);
    const n = this._getPattern(t, e);
    i.fillStyle = n.getPattern(i, this, Rt(i), it.SHADING, t);
    const r = Rt(i);
    if (r) {
      const {
        width: a,
        height: o
      } = i.canvas, l = ee.slice();
      x.axialAlignedBoundingBox([0, 0, a, o], r, l);
      const [h, c, u, f] = l;
      this.ctx.fillRect(h, c, u - h, f - c);
    } else
      this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
    this.dependencyTracker?.resetBBox(t).recordFullPageBBox(t).recordDependencies(t, St.transform).recordDependencies(t, St.fill).recordOperation(t), this.compose(this.current.getClippedPathBoundingBox()), this.restore(t), this.#y(s);
  }
  beginInlineImage() {
    j("Should not call beginInlineImage");
  }
  beginImageData() {
    j("Should not call beginImageData");
  }
  paintFormXObjectBegin(t, e, s) {
    if (this.contentVisible && (this.save(t), this.baseTransformStack.push(this.baseTransform), e && this.transform(t, ...e), this.baseTransform = X(this.ctx), s)) {
      x.axialAlignedBoundingBox(s, this.baseTransform, this.current.minMax);
      const [i, n, r, a] = s, o = new Path2D();
      o.rect(i, n, r - i, a - n), this.ctx.clip(o), this.dependencyTracker?.recordClipBox(t, this.ctx, i, r, n, a), this.endPath(t);
    }
  }
  paintFormXObjectEnd(t) {
    this.contentVisible && (this.restore(t), this.baseTransform = this.baseTransformStack.pop());
  }
  beginGroup(t, e) {
    if (!this.contentVisible)
      return;
    this.save(t);
    const {
      inSMaskMode: s
    } = this;
    s && (this.endSMaskMode(), this.current.activeSMask = null);
    const i = this.ctx;
    if ((!e.needsIsolation || !e.isolated && !e.hasSoftMask) && !e.knockout && !e.isGray && this.#s === 0 && i.globalAlpha === 1 && i.globalCompositeOperation === "source-over" && !s) {
      if (e.bbox) {
        let w = new Path2D();
        const [v, S, _, E] = e.bbox;
        if (w.rect(v, S, _ - v, E - S), e.matrix) {
          const C = new Path2D();
          C.addPath(w, new DOMMatrix(e.matrix)), w = C;
        }
        i.clip(w);
      }
      this.groupStack.push(null), this.#c.push(null), this.groupLevel++;
      return;
    }
    !e.isolated && !e.knockout && this.#s === 0 && hs("TODO: Fully support non-isolated non-knockout groups.");
    const n = X(i);
    e.matrix && i.transform(...e.matrix);
    const r = [0, 0, i.canvas.width, i.canvas.height];
    let a;
    e.bbox ? (a = ee.slice(), x.axialAlignedBoundingBox(e.bbox, X(i), a), a = x.intersect(a, r) || [0, 0, 0, 0]) : a = r;
    const o = Math.floor(a[0]), l = Math.floor(a[1]), h = Math.max(Math.ceil(a[2]) - o, 1), c = Math.max(Math.ceil(a[3]) - l, 1);
    this.current.startNewPathAndClipBox([0, 0, h, c]);
    const u = this.canvasFactory.create(h, c);
    e.smask && this.smaskGroupCanvases.push(u);
    const f = u.context, p = e.knockout && !e.isolated ? i : null, g = !e.isolated && !e.knockout && !e.smask && e.needsIsolation && this.#s > 0, m = e.knockout ? this.canvasFactory.create(h, c) : null, b = this.#s;
    e.knockout ? this.#s++ : this.#s = 0, f.translate(-o, -l), f.transform(...n);
    const y = !e.isolated && !e.smask && e.needsIsolation, A = y && !s && b === 0 && !e.knockout && !e.isGray && e.hasSoftMask && i.globalAlpha === 1 && i.globalCompositeOperation === "source-over" && this.current.transferMaps === "none" && !this.current.transferMapsFallback;
    if (y && (s || A) && (f.save(), f.setTransform(1, 0, 0, 1, 0, 0), f.drawImage(i.canvas, -o, -l), f.restore()), e.bbox) {
      let w = new Path2D();
      const [v, S, _, E] = e.bbox;
      if (w.rect(v, S, _ - v, E - S), e.matrix) {
        const C = new Path2D();
        C.addPath(w, new DOMMatrix(e.matrix)), w = C;
      }
      f.clip(w);
    }
    e.smask && this.smaskStack.push({
      canvas: u.canvas,
      context: f,
      offsetX: o,
      offsetY: l,
      subtype: e.smask.subtype,
      backdrop: e.smask.backdrop,
      transferMap: e.smask.transferMap || null
    }), (!e.smask || this.dependencyTracker) && (i.setTransform(1, 0, 0, 1, 0, 0), i.translate(o, l), i.save()), Qt(i, f), this.ctx = f, this.dependencyTracker?.inheritSimpleDataAsFutureForcedDependencies(["fillAlpha", "strokeAlpha", "globalCompositeOperation"]).pushBaseTransform(i), this.setGState(t, [["BM", "source-over"], ["ca", 1], ["CA", 1], ["TR", null]]), this.groupStack.push(i), this.#c.push({
      backdropCtx: p,
      savedKnockoutLevel: b,
      offsetX: o,
      offsetY: l,
      hasInnerBackdrop: g,
      replaceBackdrop: A,
      knockoutMaskEntry: m,
      knockoutTempEntry: null,
      knockoutBackdropEntry: null
    }), this.groupLevel++;
  }
  endGroup(t, e) {
    if (!this.contentVisible)
      return;
    this.groupLevel--;
    const s = this.ctx, i = this.groupStack.pop(), n = this.#c.pop();
    if (n && (this.#s = n.savedKnockoutLevel), i === null) {
      this.restore(t);
      return;
    }
    if (e.isGray && this.#_(s), this.ctx = i, this.ctx.imageSmoothingEnabled = !1, this.dependencyTracker?.popBaseTransform(), e.smask)
      this.tempSMask = this.smaskStack.pop(), this.restore(t), this.dependencyTracker && (this.ctx.restore(), this.inSMaskMode && this.ctx.setTransform(this.suspendedCtx.getTransform())), this.#v(n);
    else {
      this.ctx.restore();
      const r = X(this.ctx);
      this.restore(t), this.current.transferMapsFallback?.applyToCanvas(s), this.ctx.save(), this.ctx.setTransform(...r);
      const a = ee.slice();
      x.axialAlignedBoundingBox([0, 0, s.canvas.width, s.canvas.height], r, a);
      const o = this.#c.at(-1);
      if (this.#s > 0)
        if (n.hasInnerBackdrop) {
          const {
            width: l,
            height: h
          } = s.canvas, c = this.canvasFactory.create(l, h), u = c.context;
          u.drawImage(i.canvas, n.offsetX, n.offsetY, l, h, 0, 0, l, h), u.globalCompositeOperation = "source-over", u.drawImage(s.canvas, 0, 0);
          const f = this.#m(s.canvas);
          u.globalCompositeOperation = "destination-in", u.drawImage(f.canvas, 0, 0);
          const p = this.ctx.globalCompositeOperation, g = this.ctx.globalAlpha, m = this.ctx.filter;
          this.ctx.save(), this.ctx.setTransform(...r), this.ctx.globalAlpha = 1, W.isCanvasFilterSupported && (this.ctx.filter = "none"), this.ctx.globalCompositeOperation = "destination-out", this.ctx.drawImage(f.canvas, 0, 0), this.ctx.globalCompositeOperation = p, this.ctx.globalAlpha = g, W.isCanvasFilterSupported && (this.ctx.filter = m ?? "none"), this.ctx.drawImage(c.canvas, 0, 0), this.ctx.restore(), this.canvasFactory.destroy(f), this.canvasFactory.destroy(c);
        } else {
          const l = o?.backdropCtx ?? null;
          this.#g(this.ctx, s.canvas, {
            backdropCanvas: l?.canvas ?? null,
            destTransform: r,
            backdropOffset: l ? [o.offsetX + n.offsetX, o.offsetY + n.offsetY] : [0, 0],
            sourceAlpha: this.ctx.globalAlpha,
            sourceFilter: this.ctx.filter
          });
        }
      else {
        if (n.replaceBackdrop) {
          const l = new Path2D();
          l.rect(0, 0, s.canvas.width, s.canvas.height), this.ctx.clip(l), this.ctx.globalCompositeOperation = "copy";
        }
        this.ctx.drawImage(s.canvas, 0, 0);
      }
      this.ctx.restore(), this.canvasFactory.destroy({
        canvas: s.canvas,
        context: s
      }), this.#v(n), this.compose(a);
    }
  }
  #_(t) {
    const {
      canvas: e
    } = t, {
      width: s,
      height: i
    } = e;
    if (W.isCanvasFilterSupported) {
      t.save(), t.setTransform(1, 0, 0, 1, 0, 0), t.filter = "grayscale(1)", t.globalAlpha = 1, t.globalCompositeOperation = "copy", t.drawImage(e, 0, 0), t.restore();
      return;
    }
    const n = t.getImageData(0, 0, s, i), {
      data: r
    } = n;
    for (let a = 0, o = r.length; a < o; a += 4) {
      const l = r[a] * 0.2126 + r[a + 1] * 0.7152 + r[a + 2] * 0.0722 + 0.5 | 0;
      r[a] = r[a + 1] = r[a + 2] = l;
    }
    t.putImageData(n, 0, 0);
  }
  #v(t) {
    t && (t.knockoutMaskEntry && (this.canvasFactory.destroy(t.knockoutMaskEntry), t.knockoutMaskEntry = null), t.knockoutTempEntry && (this.canvasFactory.destroy(t.knockoutTempEntry), t.knockoutTempEntry = null), t.knockoutBackdropEntry && (this.canvasFactory.destroy(t.knockoutBackdropEntry), t.knockoutBackdropEntry = null));
  }
  beginAnnotation(t, e, s, i, n, r, a) {
    if (this.#f(), $e(this.ctx), this.ctx.save(), this.save(t), this.baseTransform && this.ctx.setTransform(...this.baseTransform), s) {
      const o = s[2] - s[0], l = s[3] - s[1];
      if (r && this.annotationCanvasMap) {
        i = i.slice(), i[4] -= s[0], i[5] -= s[1], x.singularValueDecompose2dScale(X(this.ctx), At);
        const {
          viewportScale: h
        } = this, c = Math.ceil(o * this.outputScaleX * h), u = Math.ceil(l * this.outputScaleY * h);
        this.annotationCanvas = this.canvasFactory.create(c, u);
        const {
          canvas: f,
          context: p
        } = this.annotationCanvas;
        if (a) {
          const g = this.annotationCanvasMap.getOrInsertComputed(e, we);
          un(f, a);
          const m = g.findIndex((b) => Mr(b) === a);
          m === -1 ? g.push(f) : g[m] = f;
        } else
          this.annotationCanvasMap.set(e, f);
        this.annotationCanvas.savedCtx = this.ctx, this.ctx = p, this.ctx.save(), this.ctx.setTransform(At[0], 0, 0, -At[1], 0, l * At[1]), $e(this.ctx);
      } else {
        $e(this.ctx), this.endPath(t);
        const h = new Path2D();
        h.rect(s[0], s[1], o, l), this.ctx.clip(h);
      }
    }
    this.current = new Ts(this.ctx.canvas.width, this.ctx.canvas.height), this.baseTransformStack.push(this.baseTransform), this.transform(t, ...i), this.transform(t, ...n), this.baseTransform = X(this.ctx);
  }
  endAnnotation(t) {
    this.annotationCanvas && (this.ctx.restore(), this.#p(), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas), this.baseTransform = this.baseTransformStack.pop();
  }
  paintImageMaskXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = e.count;
    e = this.getObject(t, e.data, e), e.count = s;
    const i = this.#b(this.current.fillAlpha), n = this.ctx, r = this._createMaskCanvas(t, e), a = r.canvas;
    n.save(), n.setTransform(1, 0, 0, 1, 0, 0), n.drawImage(a, r.offsetX, r.offsetY), this.dependencyTracker?.resetBBox(t).recordBBox(t, this.ctx, r.offsetX, r.offsetX + a.width, r.offsetY, r.offsetY + a.height).recordOperation(t), n.restore(), r.canvasEntry && this.canvasFactory.destroy(r.canvasEntry), this.compose(), this.#y(i);
  }
  paintImageMaskXObjectRepeat(t, e, s, i = 0, n = 0, r, a) {
    if (!this.contentVisible)
      return;
    e = this.getObject(t, e.data, e);
    const o = this.#b(this.current.fillAlpha), l = this.ctx;
    l.save();
    const h = X(l);
    l.transform(s, i, n, r, 0, 0);
    const c = this._createMaskCanvas(t, e);
    l.setTransform(1, 0, 0, 1, c.offsetX - h[4], c.offsetY - h[5]), this.dependencyTracker?.resetBBox(t);
    for (let u = 0, f = a.length; u < f; u += 2) {
      const p = x.transform(h, [s, i, n, r, a[u], a[u + 1]]);
      l.drawImage(c.canvas, p[4], p[5]), this.dependencyTracker?.recordBBox(t, this.ctx, p[4], p[4] + c.canvas.width, p[5], p[5] + c.canvas.height);
    }
    l.restore(), c.canvasEntry && this.canvasFactory.destroy(c.canvasEntry), this.compose(), this.dependencyTracker?.recordOperation(t), this.#y(o);
  }
  paintImageMaskXObjectGroup(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.#b(this.current.fillAlpha), i = this.ctx, n = this.current.patternFill, r = n ? this.current.fillColor : i.fillStyle;
    this.dependencyTracker?.resetBBox(t).recordDependencies(t, St.transformAndFill);
    for (const a of e) {
      const {
        data: o,
        width: l,
        height: h,
        transform: c
      } = a, u = this.canvasFactory.create(l, h), f = u.context;
      f.save();
      const p = this.getObject(t, o, a);
      Ni(f, p), f.globalCompositeOperation = "source-in", f.fillStyle = n ? r.getPattern(f, this, Rt(i), it.FILL, t) : r, f.fillRect(0, 0, l, h), f.restore(), i.save(), i.transform(...c), i.scale(1, -1), ze(i, u.canvas, 0, 0, l, h, 0, -1, 1, 1), this.canvasFactory.destroy(u), this.dependencyTracker?.recordBBox(t, i, 0, l, 0, h), i.restore();
    }
    this.compose(), this.dependencyTracker?.recordOperation(t), this.#y(s);
  }
  paintImageXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.getObject(t, e);
    if (!s) {
      R("Dependent image isn't ready yet");
      return;
    }
    this.paintInlineImageXObject(t, s);
  }
  paintImageXObjectRepeat(t, e, s, i, n) {
    if (!this.contentVisible)
      return;
    const r = this.getObject(t, e);
    if (!r) {
      R("Dependent image isn't ready yet");
      return;
    }
    const a = r.width, o = r.height, l = [];
    for (let h = 0, c = n.length; h < c; h += 2)
      l.push({
        transform: [s, 0, 0, i, n[h], n[h + 1]],
        x: 0,
        y: 0,
        w: a,
        h: o
      });
    this.paintInlineImageXObjectGroup(t, r, l);
  }
  applyTransferMapsToCanvas(t) {
    return this.current.transferMaps !== "none" ? (t.filter = this.current.transferMaps, t.drawImage(t.canvas, 0, 0), t.filter = "none") : this.current.transferMapsFallback?.applyToCanvas(t), t.canvas;
  }
  applyTransferMapsToBitmap(t) {
    const {
      transferMaps: e,
      transferMapsFallback: s
    } = this.current;
    if (e === "none" && !s)
      return {
        img: t.bitmap,
        canvasEntry: null
      };
    const {
      bitmap: i,
      width: n,
      height: r
    } = t, a = this.canvasFactory.create(n, r), o = a.context;
    return o.filter = e, o.drawImage(i, 0, 0), o.filter = "none", s?.applyToCanvas(o), {
      img: a.canvas,
      canvasEntry: a
    };
  }
  paintInlineImageXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = e.width, i = e.height, n = this.#b(this.current.fillAlpha), r = this.ctx;
    this.save(t);
    const {
      filter: a
    } = r;
    a !== "none" && a !== "" && (r.filter = "none"), r.scale(1 / s, -1 / i);
    let o, l = null;
    if (e.bitmap) {
      const c = this.applyTransferMapsToBitmap(e);
      o = c.img, l = c.canvasEntry;
    } else {
      const c = this.canvasFactory.create(s, i);
      Li(c.context, e), o = this.applyTransferMapsToCanvas(c.context), l = c;
    }
    const h = this._scaleImage(o, Rt(r));
    r.imageSmoothingEnabled = Bi(X(r), e.interpolate, this.pixelRatio), this.dependencyTracker && (this.dependencyTracker.resetBBox(t).recordBBox(t, r, 0, s, -i, 0).recordDependencies(t, St.imageXObject).recordOperation(t), this.imagesTracker?.record(r, s, i, this.dependencyTracker.clipBox)), ze(r, h.img, 0, 0, h.paintWidth, h.paintHeight, 0, -i, s, i), h.tmpCanvas && this.canvasFactory.destroy(h.tmpCanvas), l && this.canvasFactory.destroy(l), this.compose(), this.restore(t), this.#y(n);
  }
  paintInlineImageXObjectGroup(t, e, s) {
    if (!this.contentVisible)
      return;
    const i = this.#b(this.current.fillAlpha), n = this.ctx;
    let r, a = null;
    if (e.bitmap && !this.current.transferMapsFallback)
      r = e.bitmap;
    else if (e.bitmap)
      ({
        img: r,
        canvasEntry: a
      } = this.applyTransferMapsToBitmap(e));
    else {
      const o = e.width, l = e.height, h = this.canvasFactory.create(o, l);
      Li(h.context, e), r = this.applyTransferMapsToCanvas(h.context), a = h;
    }
    this.dependencyTracker?.resetBBox(t);
    for (const o of s)
      n.save(), n.transform(...o.transform), n.scale(1, -1), ze(n, r, o.x, o.y, o.w, o.h, 0, -1, 1, 1), this.dependencyTracker?.recordBBox(t, n, 0, 1, -1, 0), n.restore();
    a && this.canvasFactory.destroy(a), this.dependencyTracker?.recordOperation(t), this.compose(), this.#y(i);
  }
  paintSolidColorImageMask(t) {
    if (!this.contentVisible)
      return;
    const e = this.#b(this.current.fillAlpha);
    this.dependencyTracker?.resetBBox(t).recordBBox(t, this.ctx, 0, 1, 0, 1).recordDependencies(t, St.fill).recordOperation(t), this.ctx.fillRect(0, 0, 1, 1), this.compose(), this.#y(e);
  }
  markPoint(t, e) {
  }
  markPointProps(t, e, s) {
  }
  beginMarkedContent(t, e) {
    this.dependencyTracker?.beginMarkedContent(t), this.markedContentStack.push({
      visible: !0
    });
  }
  beginMarkedContentProps(t, e, s) {
    this.dependencyTracker?.beginMarkedContent(t), e === "OC" ? this.markedContentStack.push({
      visible: this.optionalContentConfig.isVisible(s)
    }) : this.markedContentStack.push({
      visible: !0
    }), this.contentVisible = this.isContentVisible();
  }
  endMarkedContent(t) {
    this.dependencyTracker?.endMarkedContent(t), this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
  }
  beginCompat(t) {
  }
  endCompat(t) {
  }
  consumePath(t, e, s) {
    const i = this.current.isEmptyClip();
    this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(s);
    const n = this.ctx;
    this.pendingClip ? (i || (this.pendingClip === Hi ? n.clip(e, "evenodd") : n.clip(e)), this.pendingClip = null, this.dependencyTracker?.bboxToClipBoxDropOperation(t).recordFutureForcedDependency("clipPath", t)) : this.dependencyTracker?.recordOperation(t), this.current.startNewPathAndClipBox(this.current.clipBox);
  }
  getSinglePixelWidth() {
    const t = X(this.ctx);
    if (t[1] === 0 && t[2] === 0)
      return 1 / Math.min(Math.abs(t[0]), Math.abs(t[3]));
    const e = Math.abs(t[0] * t[3] - t[2] * t[1]), s = Math.hypot(t[0], t[2]), i = Math.hypot(t[1], t[3]);
    return Math.max(s, i) / e;
  }
  getScaleForStroking() {
    if (this._cachedScaleForStroking[0] === -1) {
      const {
        lineWidth: t
      } = this.current, {
        a: e,
        b: s,
        c: i,
        d: n
      } = this.ctx.getTransform();
      let r, a;
      if (s === 0 && i === 0) {
        const o = Math.abs(e), l = Math.abs(n);
        if (o === l)
          if (t === 0)
            r = a = 1 / o;
          else {
            const h = o * t;
            r = a = h < 1 ? 1 / h : 1;
          }
        else if (t === 0)
          r = 1 / o, a = 1 / l;
        else {
          const h = o * t, c = l * t;
          r = h < 1 ? 1 / h : 1, a = c < 1 ? 1 / c : 1;
        }
      } else {
        const o = Math.abs(e * n - s * i), l = Math.hypot(e, s), h = Math.hypot(i, n);
        if (t === 0)
          r = h / o, a = l / o;
        else {
          const c = t * o;
          r = h > c ? h / c : 1, a = l > c ? l / c : 1;
        }
      }
      this._cachedScaleForStroking[0] = r, this._cachedScaleForStroking[1] = a;
    }
    return this._cachedScaleForStroking;
  }
  rescaleAndStroke(t, e) {
    const {
      ctx: s,
      current: {
        lineWidth: i
      }
    } = this, [n, r] = this.getScaleForStroking();
    if (n === r) {
      s.lineWidth = (i || 1) * n, s.stroke(t);
      return;
    }
    const a = Xt.#t ??= new DOMMatrix(), o = s.getLineDash();
    e && s.save(), s.scale(n, r), a.a = 1 / n, a.d = 1 / r;
    const l = new Path2D();
    if (l.addPath(t, a), o.length > 0) {
      const h = Math.max(n, r);
      s.setLineDash(o.map((c) => c / h)), s.lineDashOffset /= h;
    }
    s.lineWidth = i || 1, s.stroke(l), e && s.restore();
  }
  isContentVisible() {
    for (let t = this.markedContentStack.length - 1; t >= 0; t--)
      if (!this.markedContentStack[t].visible)
        return !1;
    return !0;
  }
}
for (const d in Nt)
  Xt.prototype[d] !== void 0 && (Xt.prototype[Nt[d]] = Xt.prototype[d]);
class Rr extends hn {
  constructor({
    ownerDocument: t = globalThis.document,
    enableHWA: e = !1
  }) {
    super({
      enableHWA: e
    }), this._document = t;
  }
  _createCanvas(t, e) {
    const s = this._document.createElement("canvas");
    return s.width = t, s.height = e, s;
  }
}
class Lr extends cn {
  #t;
  #e;
  #s;
  #i;
  #n;
  #r;
  #a = 0;
  constructor({
    docId: t,
    ownerDocument: e = globalThis.document
  }) {
    super(), this.#i = t, this.#n = e;
  }
  get #o() {
    return this.#e ||= /* @__PURE__ */ new Map();
  }
  get #l() {
    return this.#r ||= /* @__PURE__ */ new Map();
  }
  get #h() {
    if (!this.#s) {
      const t = this.#n.createElement("div"), {
        style: e
      } = t;
      e.colorScheme = "only light", e.visibility = "hidden", e.contain = "strict", e.width = e.height = 0, e.position = "absolute", e.top = e.left = 0, e.zIndex = -1;
      const s = this.#n.createElementNS(ct, "svg");
      s.setAttribute("width", 0), s.setAttribute("height", 0), this.#s = this.#n.createElementNS(ct, "defs"), t.append(s), s.append(this.#s), this.#n.body.append(t);
    }
    return this.#s;
  }
  #u(t) {
    const e = (r) => r && Array.from(r, (a) => a / 255).join(",");
    if (t.length === 1) {
      const r = e(t[0]);
      return [r, r, r];
    }
    const [s, i, n] = t;
    return [e(s), e(i), e(n)];
  }
  #c(t) {
    if (this.#t === void 0) {
      this.#t = "";
      const e = this.#n.URL;
      e !== this.#n.baseURI && (ds(e) ? R('#createUrl: ignore "data:"-URL for performance reasons.') : this.#t = qi(e, ""));
    }
    return `url(${this.#t}#${t})`;
  }
  addFilter(t) {
    if (!t)
      return "none";
    let e = this.#o.get(t);
    if (e)
      return e;
    const [s, i, n] = this.#u(t), r = t.length === 1 ? s : `${s}${i}${n}`;
    if (e = this.#o.get(r), e)
      return this.#o.set(t, e), e;
    const a = `g_${this.#i}_transfer_map_${this.#a++}`, o = this.#c(a);
    this.#o.set(t, o), this.#o.set(r, o);
    const l = this.#m(a);
    return this.#g(s, i, n, l), o;
  }
  addHCMFilter(t, e) {
    const s = `${t}-${e}`, i = "base";
    let n = this.#l.get(i);
    if (n?.key === s || (n ? (n.filter?.remove(), n.key = s, n.url = "none", n.filter = null) : (n = {
      key: s,
      url: "none",
      filter: null
    }, this.#l.set(i, n)), !t || !e))
      return n.url;
    const r = this.#y(t);
    t = x.makeHexColor(...r);
    const a = this.#y(e);
    if (e = x.makeHexColor(...a), this.#w(), t === "#000000" && e === "#ffffff" || t === e)
      return n.url;
    const l = Array.from({
      length: 256
    }, (f, p) => Bs(p / 255)).join(","), h = `g_${this.#i}_hcm_filter`, c = n.filter = this.#m(h);
    this.#g(l, l, l, c), this.#p(c);
    const u = (f, p) => {
      const g = r[f] / 255, m = a[f] / 255, b = new Array(p + 1);
      for (let y = 0; y <= p; y++)
        b[y] = g + y / p * (m - g);
      return b.join(",");
    };
    return this.#g(u(0, 5), u(1, 5), u(2, 5), c), n.url = this.#c(h), n.url;
  }
  addSelectionHCMFilter(t, e) {
    return this.addHighlightHCMFilter("selection", t, e, "HighlightText", "Highlight");
  }
  addSelectionFilter() {
    return this.addHighlightHCMFilter("selection_default", "black", "white", "HighlightText", "Highlight");
  }
  createSelectionStyle(t = null) {
    const e = t ? this.addSelectionHCMFilter(t.foreground, t.background) : this.addSelectionFilter();
    return e === "none" || !W.platform.isFirefox ? null : {
      "backdrop-filter": e,
      "background-color": "transparent"
    };
  }
  addAlphaFilter(t) {
    let e = this.#o.get(t);
    if (e)
      return e;
    const [s] = this.#u([t]), i = `alpha_${s}`;
    if (e = this.#o.get(i), e)
      return this.#o.set(t, e), e;
    const n = `g_${this.#i}_alpha_map_${this.#a++}`, r = this.#c(n);
    this.#o.set(t, r), this.#o.set(i, r);
    const a = this.#m(n);
    return this.#b(s, a), r;
  }
  addLuminosityFilter(t) {
    let e = this.#o.get(t || "luminosity");
    if (e)
      return e;
    let s, i;
    if (t ? ([s] = this.#u([t]), i = `luminosity_${s}`) : i = "luminosity", e = this.#o.get(i), e)
      return this.#o.set(t, e), e;
    const n = `g_${this.#i}_luminosity_map_${this.#a++}`, r = this.#c(n);
    this.#o.set(t, r), this.#o.set(i, r);
    const a = this.#m(n);
    return this.#f(a), t && this.#b(s, a), r;
  }
  addKnockoutFilter(t = 0) {
    const e = t > 0 ? Math.min(1 / t, 1e6) : 1e6, s = `knockout_${e}`, i = this.#o.get(s);
    if (i)
      return i;
    const n = `g_${this.#i}_knockout_filter_${this.#a++}`, r = this.#c(n);
    this.#o.set(s, r);
    const a = this.#m(n), o = this.#n.createElementNS(ct, "feComponentTransfer");
    a.append(o);
    const l = this.#n.createElementNS(ct, "feFuncA");
    return l.setAttribute("type", "linear"), l.setAttribute("slope", `${e}`), l.setAttribute("intercept", "0"), o.append(l), r;
  }
  addHighlightHCMFilter(t, e, s, i, n) {
    const r = `${e}-${s}-${i}-${n}`;
    let a = this.#l.get(t);
    if (a?.key === r || (a ? (a.filter?.remove(), a.key = r, a.url = "none", a.filter = null) : (a = {
      key: r,
      url: "none",
      filter: null
    }, this.#l.set(t, a)), !e || !s))
      return a.url;
    const [o, l] = [e, s].map(this.#y.bind(this));
    let h = Math.round(0.2126 * o[0] + 0.7152 * o[1] + 0.0722 * o[2]), c = Math.round(0.2126 * l[0] + 0.7152 * l[1] + 0.0722 * l[2]), [u, f] = [i, n].map(this.#S.bind(this));
    c < h && ([h, c, u, f] = [c, h, f, u]), this.#w();
    const p = (b, y, A) => {
      const w = new Array(256), v = (c - h) / A, S = b / 255, _ = (y - b) / (255 * A);
      let E = 0;
      for (let C = 0; C <= A; C++) {
        const T = Math.round(h + C * v), D = S + C * _;
        for (let P = E; P <= T; P++)
          w[P] = D;
        E = T + 1;
      }
      for (let C = E; C < 256; C++)
        w[C] = w[E - 1];
      return w.join(",");
    }, g = `g_${this.#i}_hcm_${t}_filter`, m = a.filter = this.#m(g);
    return this.#p(m), this.#g(p(u[0], f[0], 5), p(u[1], f[1], 5), p(u[2], f[2], 5), m), a.url = this.#c(g), a.url;
  }
  destroy(t = !1) {
    t && this.#r?.size || (this.#s?.parentNode.parentNode.remove(), this.#s = null, this.#e?.clear(), this.#e = null, this.#r?.clear(), this.#r = null, this.#a = 0);
  }
  #f(t) {
    const e = this.#n.createElementNS(ct, "feColorMatrix");
    e.setAttribute("type", "matrix"), e.setAttribute("values", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.3 0.59 0.11 0 0"), t.append(e);
  }
  #p(t) {
    const e = this.#n.createElementNS(ct, "feColorMatrix");
    e.setAttribute("type", "matrix"), e.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), t.append(e);
  }
  #m(t) {
    const e = this.#n.createElementNS(ct, "filter");
    return e.setAttribute("color-interpolation-filters", "sRGB"), e.setAttribute("id", t), this.#h.append(e), e;
  }
  #d(t, e, s) {
    if (!s)
      return;
    const i = this.#n.createElementNS(ct, e);
    i.setAttribute("type", "discrete"), i.setAttribute("tableValues", s), t.append(i);
  }
  #g(t, e, s, i) {
    const n = this.#n.createElementNS(ct, "feComponentTransfer");
    i.append(n), this.#d(n, "feFuncR", t), this.#d(n, "feFuncG", e), this.#d(n, "feFuncB", s);
  }
  #b(t, e) {
    const s = this.#n.createElementNS(ct, "feComponentTransfer");
    e.append(s), this.#d(s, "feFuncA", t);
  }
  #y(t) {
    return this.#h.style.color = "CanvasText", this.#h.style.backgroundColor = t, Re(getComputedStyle(this.#h).getPropertyValue("background-color"));
  }
  #A(t) {
    return this.#h.style.color = "CanvasText", this.#h.style.backgroundColor = t, ve(getComputedStyle(this.#h).getPropertyValue("background-color"));
  }
  #w() {
    this.#h.style.color = "", this.#h.style.backgroundColor = "";
  }
  #S(t) {
    const [e, s, i, n] = this.#A(t);
    if (n === 1)
      return [e, s, i];
    const [r, a, o] = this.#y("Canvas");
    return [ks(e, r, n), ks(s, a, n), ks(i, o, n)];
  }
}
function ks(d, t, e) {
  return Math.round(e * d + (1 - e) * t);
}
const Ui = new RegExp("\\p{Cc}", "u");
function Nr(d) {
  const t = d[0];
  if (d.length < 2 || t !== '"' && t !== "'" || d.at(-1) !== t)
    return !1;
  const e = d.length - 1;
  for (let s = 1; s < e; s++) {
    const i = d[s];
    if (i === t || Ui.test(i) || i === "\\" && (++s >= e || Ui.test(d[s])))
      return !1;
  }
  return !0;
}
function Gi(d) {
  return Nr(d) ? d : `"${d.replaceAll(/["\\\p{Cc}]/gu, (e) => e === '"' || e === "\\" ? `\\${e}` : `\\${e.codePointAt(0).toString(16)} `)}"`;
}
class Br {
  #t = /* @__PURE__ */ new Set();
  #e = /* @__PURE__ */ new Set();
  #s = null;
  constructor({
    ownerDocument: t = globalThis.document,
    styleElement: e = null
  }) {
    this._document = t, this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
  }
  addNativeFontFace(t) {
    this.#t.add(t), this._document.fonts.add(t);
  }
  removeNativeFontFace(t) {
    this.#t.delete(t), this._document.fonts.delete(t);
  }
  insertRule(t) {
    const e = this.#i();
    e.insertRule(t, e.cssRules.length);
  }
  #i() {
    if (this.#s)
      return this.#s;
    const t = this._document.defaultView?.CSSStyleSheet || globalThis.CSSStyleSheet;
    if (!this.styleElement && t) {
      const {
        adoptedStyleSheets: e
      } = this._document;
      if (e) {
        const s = new t();
        return e.push(s), this.#s = s;
      }
    }
    return this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement)), this.#s = this.styleElement.sheet;
  }
  clear() {
    for (const t of this.#t)
      this._document.fonts.delete(t);
    if (this.#t.clear(), this.#e.clear(), this.#s) {
      const {
        adoptedStyleSheets: t
      } = this._document;
      t?.includes(this.#s) && (this._document.adoptedStyleSheets = t.filter((e) => e !== this.#s)), this.#s = null;
    }
    this.styleElement?.remove(), this.styleElement = null;
  }
  async loadSystemFont({
    systemFontInfo: t,
    disableFontFace: e,
    _inspectFont: s
  }) {
    if (!(!t || this.#e.has(t.loadedName))) {
      if (J(!e, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
        const {
          loadedName: i,
          src: n,
          style: r
        } = t, a = new FontFace(i, n, r);
        this.addNativeFontFace(a);
        try {
          await a.load(), this.#e.add(i), s?.(t);
        } catch {
          R(`Cannot load system font: ${t.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(a);
        }
        return;
      }
      j("Not implemented: loadSystemFont without the Font Loading API.");
    }
  }
  async bind(t) {
    if (t.attached || t.missingFile && !t.systemFontInfo)
      return;
    if (t.attached = !0, t.systemFontInfo) {
      await this.loadSystemFont(t);
      return;
    }
    if (this.isFontLoadingAPISupported) {
      const s = t.createNativeFontFace();
      if (s) {
        this.addNativeFontFace(s);
        try {
          await s.loaded;
        } catch (i) {
          throw R(`Failed to load font '${s.family}': '${i}'.`), t.disableFontFace = !0, i;
        }
      }
      return;
    }
    const e = t.createFontFaceRule();
    if (e) {
      if (this.insertRule(e), this.isSyncFontLoadingSupported)
        return;
      await this.#n(t);
    }
  }
  get isFontLoadingAPISupported() {
    return k(this, "isFontLoadingAPISupported", !!this._document?.fonts);
  }
  get isSyncFontLoadingSupported() {
    return k(this, "isSyncFontLoadingSupported", bt || W.platform.isFirefox);
  }
  #n(t) {
    function e() {
      for (J(!r.done, "completeRequest() cannot be called twice."), r.done = !0; s.length > 0 && s[0].done; ) {
        const C = s.shift();
        setTimeout(C.resolve, 0);
      }
    }
    const {
      loadingRequests: s
    } = this, {
      promise: i,
      resolve: n
    } = Promise.withResolvers(), r = {
      done: !1,
      resolve: n
    };
    s.push(r), this._loadTestFont ??= atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
    function a(C, T) {
      return C.charCodeAt(T) << 24 | C.charCodeAt(T + 1) << 16 | C.charCodeAt(T + 2) << 8 | C.charCodeAt(T + 3) & 255;
    }
    function o(C) {
      return String.fromCharCode(C >> 24 & 255, C >> 16 & 255, C >> 8 & 255, C & 255);
    }
    function l(C, T, D, P) {
      const N = C.substring(0, T), G = C.substring(T + D);
      return N + P + G;
    }
    let h, c;
    const u = this._document.createElement("canvas");
    u.width = 1, u.height = 1;
    const f = u.getContext("2d");
    let p = 0;
    function g(C, T) {
      if (++p > 30) {
        R("Load test font never loaded."), T();
        return;
      }
      if (f.font = "30px " + C, f.fillText(".", 0, 20), f.getImageData(0, 0, 1, 1).data[3] > 0) {
        T();
        return;
      }
      setTimeout(g.bind(null, C, T));
    }
    const m = `lt${Date.now()}${this.loadTestFontId++}`;
    let b = this._loadTestFont;
    b = l(b, 976, m.length, m);
    const A = 16, w = 1482184792;
    let v = a(b, A);
    for (h = 0, c = m.length - 3; h < c; h += 4)
      v = v - w + a(m, h) | 0;
    h < m.length && (v = v - w + a(m + "XXX", h) | 0), b = l(b, A, 4, o(v));
    const S = `url(data:font/opentype;base64,${btoa(b)});`, _ = `@font-face {font-family:"${m}";src:${S}}`;
    this.insertRule(_);
    const E = this._document.createElement("div");
    E.style.visibility = "hidden", E.style.width = E.style.height = "10px", E.style.position = "absolute", E.style.top = E.style.left = "0px";
    for (const C of [t.loadedName, m]) {
      const T = this._document.createElement("span");
      T.textContent = "Hi", T.style.fontFamily = C, E.append(T);
    }
    return this._document.body.append(E), g(m, () => {
      E.remove(), e();
    }), i;
  }
}
class Hr {
  #t = /* @__PURE__ */ new Map();
  #e;
  constructor(t, e = null, s, i) {
    this.#e = t, this._inspectFont = e, s && (this.charProcOperatorList = s), i && Object.assign(this, i);
  }
  createNativeFontFace() {
    const {
      data: t
    } = this;
    if (!t || this.disableFontFace)
      return null;
    let e;
    if (!this.cssFontInfo)
      e = new FontFace(this.loadedName, t, {});
    else {
      const s = {
        weight: this.cssFontInfo.fontWeight
      };
      this.cssFontInfo.italicAngle && (s.style = `oblique ${this.cssFontInfo.italicAngle}deg`), e = new FontFace(Gi(this.cssFontInfo.fontFamily), t, s);
    }
    return this._inspectFont?.(this), e;
  }
  createFontFaceRule() {
    const {
      data: t
    } = this;
    if (!t || this.disableFontFace)
      return null;
    const e = `url(data:${this.mimetype};base64,${t.toBase64()});`;
    let s;
    if (!this.cssFontInfo)
      s = `@font-face {font-family:"${this.loadedName}";src:${e}}`;
    else {
      let i = `font-weight: ${this.cssFontInfo.fontWeight};`;
      this.cssFontInfo.italicAngle && (i += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), s = `@font-face {font-family:${Gi(this.cssFontInfo.fontFamily)};${i}src:${e}}`;
    }
    return this._inspectFont?.(this, e), s;
  }
  getPathGenerator(t, e) {
    let s = this.#t.get(e);
    if (s)
      return s;
    const i = `${this.loadedName}_path_${e}`;
    let n;
    try {
      n = t.get(i);
    } catch (r) {
      R(`getPathGenerator - ignoring character: "${r}".`);
    }
    return s = Ji(n?.path), this.fontExtraProperties || t.delete(i), this.#t.set(e, s), s;
  }
  get black() {
    return this.#e.black;
  }
  get bold() {
    return this.#e.bold;
  }
  get disableFontFace() {
    return this.#e.disableFontFace;
  }
  set disableFontFace(t) {
    k(this, "disableFontFace", !!t);
  }
  get fontExtraProperties() {
    return this.#e.fontExtraProperties;
  }
  get isInvalidPDFjsFont() {
    return this.#e.isInvalidPDFjsFont;
  }
  get isType3Font() {
    return this.#e.isType3Font;
  }
  get italic() {
    return this.#e.italic;
  }
  get missingFile() {
    return this.#e.missingFile;
  }
  get remeasure() {
    return this.#e.remeasure;
  }
  get vertical() {
    return this.#e.vertical;
  }
  get bbox() {
    return this.#e.bbox;
  }
  get fontMatrix() {
    return this.#e.fontMatrix;
  }
  get fallbackName() {
    return this.#e.fallbackName;
  }
  get loadedName() {
    return this.#e.loadedName;
  }
  get mimetype() {
    return this.missingFile ? null : "font/opentype";
  }
  get data() {
    return this.#e.data;
  }
  clearData() {
    this.#e.clearData();
  }
  get cssFontInfo() {
    return this.#e.cssFontInfo;
  }
  get systemFontInfo() {
    return this.#e.systemFontInfo;
  }
}
class ps {
  #t = null;
  #e = null;
  _fullReader = null;
  _rangeReaders = /* @__PURE__ */ new Set();
  _source = null;
  constructor(t, e, s) {
    this._source = t, this.#t = e, this.#e = s;
  }
  get _progressiveDataLength() {
    return this._fullReader?._loaded ?? 0;
  }
  getFullReader() {
    return J(!this._fullReader, "BasePDFStream.getFullReader can only be called once."), this._fullReader = new this.#t(this);
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const s = new this.#e(this, t, e);
    return this._rangeReaders.add(s), s;
  }
  cancelAllRequests(t) {
    this._fullReader?.cancel(t);
    for (const e of new Set(this._rangeReaders))
      e.cancel(t);
  }
}
class gs {
  onProgress = null;
  _contentLength = 0;
  _filename = null;
  _headersCapability = Promise.withResolvers();
  _isRangeSupported = !1;
  _isStreamingSupported = !1;
  _loaded = 0;
  _stream = null;
  constructor(t) {
    this._stream = t;
  }
  _callOnProgress() {
    this.onProgress?.({
      loaded: this._loaded,
      total: this._contentLength
    });
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  get filename() {
    return this._filename;
  }
  get contentLength() {
    return this._contentLength;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    j("Abstract method `read` called");
  }
  cancel(t) {
    j("Abstract method `cancel` called");
  }
}
class ms {
  _stream = null;
  constructor(t, e, s) {
    this._stream = t;
  }
  async read() {
    j("Abstract method `read` called");
  }
  cancel(t) {
    j("Abstract method `cancel` called");
  }
}
function Ur(d) {
  let t = !0, e = s("filename\\*", "i").exec(d);
  if (e) {
    e = e[1];
    let h = a(e);
    return h = unescape(h), h = o(h), h = l(h), n(h);
  }
  if (e = r(d), e) {
    const h = l(e);
    return n(h);
  }
  if (e = s("filename", "i").exec(d), e) {
    e = e[1];
    let h = a(e);
    return h = l(h), n(h);
  }
  function s(h, c) {
    return new RegExp("(?:^|;)\\s*" + h + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', c);
  }
  function i(h, c) {
    if (h) {
      if (!/^[\x00-\xFF]+$/.test(c))
        return c;
      try {
        const u = new TextDecoder(h, {
          fatal: !0
        }), f = cs(c);
        c = u.decode(f), t = !1;
      } catch {
      }
    }
    return c;
  }
  function n(h) {
    return t && /[\x80-\xff]/.test(h) && (h = i("utf-8", h), t && (h = i("iso-8859-1", h))), h;
  }
  function r(h) {
    const c = [];
    let u;
    const f = s("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
    for (; (u = f.exec(h)) !== null; ) {
      let [, g, m, b] = u;
      if (g = parseInt(g, 10), g in c) {
        if (g === 0)
          break;
        continue;
      }
      c[g] = [m, b];
    }
    const p = [];
    for (let g = 0; g < c.length && g in c; ++g) {
      let [m, b] = c[g];
      b = a(b), m && (b = unescape(b), g === 0 && (b = o(b))), p.push(b);
    }
    return p.join("");
  }
  function a(h) {
    if (h.startsWith('"')) {
      const c = h.slice(1).split('\\"');
      for (let u = 0; u < c.length; ++u) {
        const f = c[u].indexOf('"');
        f !== -1 && (c[u] = c[u].slice(0, f), c.length = u + 1), c[u] = c[u].replaceAll(/\\(.)/g, "$1");
      }
      h = c.join('"');
    }
    return h;
  }
  function o(h) {
    const c = h.indexOf("'");
    if (c === -1)
      return h;
    const u = h.slice(0, c), p = h.slice(c + 1).replace(/^[^']*'/, "");
    return i(u, p);
  }
  function l(h) {
    return !h.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(h) ? h : h.replaceAll(/=\?([\w-]*)\?([QB])\?((?:[^?]|\?(?!=))*)\?=/gi, function(c, u, f, p) {
      if (f === "q" || f === "Q")
        return p = p.replaceAll("_", " ").replaceAll(/=([0-9a-f]{2})/gi, (g, m) => String.fromCharCode(parseInt(m, 16))), i(u, p);
      try {
        p = atob(p);
      } catch {
      }
      return i(u, p);
    });
  }
  return "";
}
function fn(d, t) {
  const e = new Headers();
  if (!d || !t || typeof t != "object")
    return e;
  for (const s in t) {
    const i = t[s];
    i !== void 0 && e.append(s, i);
  }
  return e;
}
function Gr(d) {
  let t = d.length;
  for (; t > 0 && d[t - 1] !== " " && /\s/.test(d[t - 1]); )
    t--;
  return d.slice(0, t);
}
function bs(d) {
  return URL.parse(d)?.origin ?? null;
}
function pn({
  responseHeaders: d,
  isHttp: t,
  rangeChunkSize: e,
  disableRange: s
}) {
  const i = {
    contentLength: 0,
    isRangeSupported: !1
  }, n = parseInt(d.get("Content-Length"), 10);
  return !Number.isInteger(n) || (i.contentLength = n, n <= 2 * e) || s || !t || d.get("Accept-Ranges") !== "bytes" || (d.get("Content-Encoding") || "identity") === "identity" && (i.isRangeSupported = !0), i;
}
function gn(d) {
  const t = d.get("Content-Disposition");
  if (t) {
    let e = Ur(t);
    if (e.includes("%"))
      try {
        e = decodeURIComponent(e);
      } catch {
      }
    if (Qs(e))
      return e;
  }
  return null;
}
function ys(d, t) {
  return new es(`Unexpected server response (${d}) while retrieving PDF "${t.href}".`, d, d === 404 || d === 0 && t.protocol === "file:");
}
function mn(d, t) {
  if (d !== t)
    throw new Error(`Expected range response-origin "${d}" to match "${t}".`);
}
function bn(d, t, e, s) {
  return fetch(d, {
    method: "GET",
    headers: t,
    signal: s.signal,
    mode: "cors",
    credentials: e ? "include" : "same-origin",
    redirect: "follow"
  });
}
function yn(d, t) {
  if (d !== 200 && d !== 206)
    throw ys(d, t);
}
function As(d) {
  if (d instanceof Uint8Array)
    return d.buffer;
  if (d instanceof ArrayBuffer)
    return d;
  throw new Error(`getArrayBuffer - unexpected data: ${d}`);
}
class jr extends ps {
  _responseOrigin = null;
  constructor(t) {
    super(t, zr, $r);
    const {
      httpHeaders: e,
      url: s
    } = t;
    J(/https?:/.test(s.protocol), "PDFFetchStream only supports http(s):// URLs."), this.headers = fn(!0, e);
  }
}
class zr extends gs {
  _abortController = new AbortController();
  _reader = null;
  constructor(t) {
    super(t);
    const {
      disableRange: e,
      disableStream: s,
      rangeChunkSize: i,
      url: n,
      withCredentials: r
    } = t._source;
    this._isStreamingSupported = !s;
    const a = new Headers(t.headers);
    bn(n, a, r, this._abortController).then((o) => {
      t._responseOrigin = bs(o.url), yn(o.status, n), this._reader = o.body.getReader();
      const l = o.headers, {
        contentLength: h,
        isRangeSupported: c
      } = pn({
        responseHeaders: l,
        isHttp: !0,
        rangeChunkSize: i,
        disableRange: e
      });
      this._contentLength = h, this._isRangeSupported = c, this._filename = gn(l), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new Yt("Streaming is disabled.")), this._headersCapability.resolve();
    }).catch(this._headersCapability.reject);
  }
  async read() {
    await this._headersCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.byteLength, this._callOnProgress(), {
      value: As(t),
      done: !1
    });
  }
  cancel(t) {
    this._reader?.cancel(t).catch(() => {
    }), this._abortController.abort();
  }
}
class $r extends ms {
  _abortController = new AbortController();
  _readCapability = Promise.withResolvers();
  _reader = null;
  constructor(t, e, s) {
    super(t, e, s);
    const {
      url: i,
      withCredentials: n
    } = t._source, r = new Headers(t.headers);
    r.append("Range", `bytes=${e}-${s - 1}`), bn(i, r, n, this._abortController).then((a) => {
      const o = bs(a.url);
      mn(o, t._responseOrigin), yn(a.status, i), this._reader = a.body.getReader(), this._readCapability.resolve();
    }).catch(this._readCapability.reject), this._readCapability.promise.catch(() => {
    });
  }
  async read() {
    await this._readCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : {
      value: As(t),
      done: !1
    };
  }
  cancel(t) {
    this._reader?.cancel(t).catch(() => {
    }), this._abortController.abort();
  }
}
function ji(d) {
  return d instanceof Uint8Array && d.byteLength === d.buffer.byteLength ? d.buffer : new Uint8Array(d).buffer;
}
function ws() {
  for (const d of this._requests)
    d.resolve({
      value: void 0,
      done: !0
    });
  this._requests.length = 0;
}
class Wr extends ps {
  _progressiveDone = !1;
  _queuedChunks = [];
  constructor(t) {
    super(t, Vr, Xr);
    const {
      pdfDataRangeTransport: e
    } = t, {
      initialData: s,
      progressiveDone: i
    } = e;
    if (s?.length > 0) {
      const r = ji(s);
      this._queuedChunks.push(r);
    }
    this._progressiveDone = i;
    const n = (r) => {
      switch (r.type) {
        case "range":
        case "progressiveRead":
          this.#t(r.begin, r.chunk);
          break;
        case "progressiveDone":
          this._fullReader?.progressiveDone(), this._progressiveDone = !0;
          break;
      }
    };
    e.transportReady(n);
  }
  #t(t, e) {
    const s = ji(e);
    if (t === void 0)
      this._fullReader ? this._fullReader._enqueue(s) : this._queuedChunks.push(s);
    else {
      const i = this._rangeReaders.keys().find((n) => n._begin === t);
      J(i, "#onReceiveData - no `PDFDataTransportStreamRangeReader` instance found."), i._enqueue(s);
    }
  }
  getFullReader() {
    const t = super.getFullReader();
    return this._queuedChunks = null, t;
  }
  getRangeReader(t, e) {
    const s = super.getRangeReader(t, e);
    return s && (s.onDone = () => this._rangeReaders.delete(s), this._source.pdfDataRangeTransport.requestDataRange(t, e)), s;
  }
  cancelAllRequests(t) {
    super.cancelAllRequests(t), this._source.pdfDataRangeTransport.abort();
  }
}
class Vr extends gs {
  #t = ws.bind(this);
  _done = !1;
  _queuedChunks = null;
  _requests = [];
  constructor(t) {
    super(t);
    const {
      pdfDataRangeTransport: e,
      disableRange: s,
      disableStream: i
    } = t._source, {
      length: n,
      contentDispositionFilename: r
    } = e;
    this._queuedChunks = t._queuedChunks || [];
    for (const o of this._queuedChunks)
      this._loaded += o.byteLength;
    this._done = t._progressiveDone, this._contentLength = n, this._isStreamingSupported = !i, this._isRangeSupported = !s, Qs(r) && (this._filename = r), this._headersCapability.resolve();
    const a = this._loaded;
    Promise.resolve().then(() => {
      a > 0 && this._loaded === a && this._callOnProgress();
    });
  }
  _enqueue(t) {
    this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._queuedChunks.push(t), this._loaded += t.byteLength, this._callOnProgress());
  }
  async read() {
    if (this._queuedChunks.length > 0)
      return {
        value: this._queuedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this.#t();
  }
  progressiveDone() {
    this._done ||= !0, this._queuedChunks.length === 0 && this.#t();
  }
}
class Xr extends ms {
  #t = ws.bind(this);
  onDone = null;
  _begin = -1;
  _done = !1;
  _queuedChunk = null;
  _requests = [];
  constructor(t, e, s) {
    super(t, e, s), this._begin = e;
  }
  _enqueue(t) {
    this._done || (this._requests.length === 0 ? this._queuedChunk = t : (this._requests.shift().resolve({
      value: t,
      done: !1
    }), this.#t()), this._done = !0, this.onDone?.());
  }
  async read() {
    if (this._queuedChunk) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this.#t(), this.onDone?.();
  }
}
const Ps = 200, zi = 206;
function Yr(d) {
  return typeof d != "string" ? d : cs(d).buffer;
}
class Kr extends ps {
  #t = /* @__PURE__ */ new WeakMap();
  _responseOrigin = null;
  constructor(t) {
    super(t, qr, Qr);
    const {
      httpHeaders: e,
      url: s
    } = t;
    this.url = s, this.isHttp = /https?:/.test(s.protocol), this.headers = fn(this.isHttp, e);
  }
  _request(t) {
    const e = new XMLHttpRequest(), s = {
      validateStatus: null,
      onHeadersReceived: t.onHeadersReceived,
      onDone: t.onDone,
      onError: t.onError,
      onProgress: t.onProgress
    };
    this.#t.set(e, s), e.open("GET", this.url), e.withCredentials = this._source.withCredentials;
    for (const [i, n] of this.headers)
      e.setRequestHeader(i, n);
    return this.isHttp && "begin" in t && "end" in t ? (e.setRequestHeader("Range", `bytes=${t.begin}-${t.end - 1}`), s.validateStatus = (i) => i === zi || i === Ps) : s.validateStatus = (i) => i === Ps, e.responseType = "arraybuffer", J(t.onError, "Expected `onError` callback to be provided."), e.onerror = () => t.onError(e.status), e.onreadystatechange = this.#s.bind(this, e), e.onprogress = this.#e.bind(this, e), e.send(null), e;
  }
  #e(t, e) {
    this.#t.get(t)?.onProgress?.(e);
  }
  #s(t, e) {
    const s = this.#t.get(t);
    if (!s || (t.readyState >= 2 && s.onHeadersReceived && (s.onHeadersReceived(), delete s.onHeadersReceived), t.readyState !== 4) || !this.#t.has(t))
      return;
    if (this.#t.delete(t), t.status === 0 && this.isHttp) {
      s.onError(t.status);
      return;
    }
    const i = t.status || Ps;
    if (!s.validateStatus(i)) {
      s.onError(t.status);
      return;
    }
    const n = Yr(t.response);
    if (i === zi) {
      const r = t.getResponseHeader("Content-Range");
      /bytes \d+-\d+\/\d+/.test(r) ? s.onDone(n) : (R('Missing or invalid "Content-Range" header.'), s.onError(0));
    } else n ? s.onDone(n) : s.onError(t.status);
  }
  _abortRequest(t) {
    this.#t.has(t) && (this.#t.delete(t), t.abort());
  }
  getRangeReader(t, e) {
    const s = super.getRangeReader(t, e);
    return s && (s.onClosed = () => this._rangeReaders.delete(s)), s;
  }
}
class qr extends gs {
  #t = ws.bind(this);
  _cachedChunks = [];
  _done = !1;
  _requests = [];
  _storedError = null;
  constructor(t) {
    super(t), this._fullRequestXhr = t._request({
      onHeadersReceived: this.#e.bind(this),
      onDone: this.#s.bind(this),
      onError: this.#i.bind(this),
      onProgress: this.#n.bind(this)
    });
  }
  #e() {
    const t = this._stream, {
      disableRange: e,
      rangeChunkSize: s
    } = t._source, i = this._fullRequestXhr;
    t._responseOrigin = bs(i.responseURL);
    const n = i.getAllResponseHeaders(), r = new Headers(n ? Gr(n.trimStart()).split(/[\r\n]+/).map((l) => {
      const [h, ...c] = l.split(": ");
      return [h, c.join(": ")];
    }) : []), {
      contentLength: a,
      isRangeSupported: o
    } = pn({
      responseHeaders: r,
      isHttp: t.isHttp,
      rangeChunkSize: s,
      disableRange: e
    });
    this._contentLength = a, this._isRangeSupported = o, this._filename = gn(r), this._isRangeSupported && t._abortRequest(i), this._headersCapability.resolve();
  }
  #s(t) {
    this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._cachedChunks.push(t), this._done = !0, this._cachedChunks.length === 0 && this.#t();
  }
  #i(t) {
    this._storedError = ys(t, this._stream.url), this._headersCapability.reject(this._storedError);
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._cachedChunks.length = 0;
  }
  #n(t) {
    this.onProgress?.({
      loaded: t.loaded,
      total: t.lengthComputable ? t.total : this._contentLength
    });
  }
  async read() {
    if (await this._headersCapability.promise, this._storedError)
      throw this._storedError;
    if (this._cachedChunks.length > 0)
      return {
        value: this._cachedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this._headersCapability.reject(t), this.#t(), this._stream._abortRequest(this._fullRequestXhr), this._fullRequestXhr = null;
  }
}
class Qr extends ms {
  #t = ws.bind(this);
  onClosed = null;
  _done = !1;
  _queuedChunk = null;
  _requests = [];
  _storedError = null;
  constructor(t, e, s) {
    super(t, e, s), this._requestXhr = t._request({
      begin: e,
      end: s,
      onHeadersReceived: this.#e.bind(this),
      onDone: this.#s.bind(this),
      onError: this.#i.bind(this),
      onProgress: null
    });
  }
  #e() {
    const t = bs(this._requestXhr?.responseURL);
    try {
      mn(t, this._stream._responseOrigin);
    } catch (e) {
      this._storedError = e, this.#i(0);
    }
  }
  #s(t) {
    this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._queuedChunk = t, this._done = !0, this.#t(), this.onClosed?.();
  }
  #i(t) {
    this._storedError ??= ys(t, this._stream.url);
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._queuedChunk = null;
  }
  async read() {
    if (this._storedError)
      throw this._storedError;
    if (this._queuedChunk !== null) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this.#t(), this._stream._abortRequest(this._requestXhr), this.onClosed?.();
  }
}
function An(d, t = null) {
  const e = process.getBuiltinModule("fs"), {
    Readable: s
  } = process.getBuiltinModule("stream"), i = e.createReadStream(d, t);
  return s.toWeb(i);
}
class Jr extends ps {
  constructor(t) {
    super(t, Zr, ta);
    const {
      url: e
    } = t;
    J(e.protocol === "file:", "PDFNodeStream only supports file:// URLs.");
  }
}
class Zr extends gs {
  _reader = null;
  constructor(t) {
    super(t);
    const {
      disableRange: e,
      disableStream: s,
      rangeChunkSize: i,
      url: n
    } = t._source;
    this._isStreamingSupported = !s, process.getBuiltinModule("fs/promises").lstat(n).then((a) => {
      const o = An(n);
      this._reader = o.getReader();
      const {
        size: l
      } = a;
      this._contentLength = l, this._isRangeSupported = !e && l > 2 * i, !this._isStreamingSupported && this._isRangeSupported && this.cancel(new Yt("Streaming is disabled.")), this._headersCapability.resolve();
    }).catch((a) => {
      a.code === "ENOENT" && (a = ys(0, n)), this._headersCapability.reject(a);
    });
  }
  async read() {
    await this._headersCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.byteLength, this._callOnProgress(), {
      value: As(t),
      done: !1
    });
  }
  cancel(t) {
    this._reader?.cancel(t).catch(() => {
    });
  }
}
class ta extends ms {
  _readCapability = Promise.withResolvers();
  _reader = null;
  constructor(t, e, s) {
    super(t, e, s);
    const {
      url: i
    } = t._source;
    try {
      const n = An(i, {
        start: e,
        end: s - 1
      });
      this._reader = n.getReader(), this._readCapability.resolve();
    } catch (n) {
      this._readCapability.reject(n);
    }
    this._readCapability.promise.catch(() => {
    });
  }
  async read() {
    await this._readCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : {
      value: As(t),
      done: !1
    };
  }
  cancel(t) {
    this._reader?.cancel(t).catch(() => {
    });
  }
}
function ea(d) {
  return xe(d) ? jr : bt ? Jr : Kr;
}
class Ut {
  static #t = null;
  static #e = [];
  static #s = "";
  static #i = "";
  static get rendererPorts() {
    return this.#e;
  }
  static set rendererPorts(t) {
    if (!Array.isArray(t) || !t.every((e) => typeof Worker < "u" && e instanceof Worker))
      throw new Error("Invalid `rendererPorts` type.");
    this.#e = t;
  }
  static get rendererSrc() {
    return this.#s;
  }
  static set rendererSrc(t) {
    if (typeof t != "string")
      throw new Error("Invalid `rendererSrc` type.");
    this.#s = t;
  }
  static get workerPort() {
    return this.#t;
  }
  static set workerPort(t) {
    if (!(typeof Worker < "u" && t instanceof Worker) && t !== null)
      throw new Error("Invalid `workerPort` type.");
    this.#t = t;
  }
  static get workerSrc() {
    return this.#i;
  }
  static set workerSrc(t) {
    if (typeof t != "string")
      throw new Error("Invalid `workerSrc` type.");
    this.#i = t;
  }
}
class sa {
  #t;
  #e;
  constructor({
    parsedData: t,
    rawData: e
  }) {
    this.#t = t, this.#e = e;
  }
  getRaw() {
    return this.#e;
  }
  get(t) {
    return this.#t.get(t) ?? null;
  }
  [Symbol.iterator]() {
    return this.#t.entries();
  }
}
class ia {
  static strings = ["fontFamily", "fontWeight", "italicAngle"];
}
class na {
  static strings = ["css", "loadedName", "baseFontName", "src"];
}
class ue {
  static bools = ["black", "bold", "disableFontFace", "fontExtraProperties", "isInvalidPDFjsFont", "isType3Font", "italic", "missingFile", "remeasure", "vertical"];
  static strings = ["fallbackName", "loadedName"];
  static OFFSET_BBOX = Math.ceil(this.bools.length * 2 / 8);
  static OFFSET_FONT_MATRIX = this.OFFSET_BBOX + 1 + 8;
  static OFFSET_STRINGS = this.OFFSET_FONT_MATRIX + 1 + 48;
}
class Jt {
  static KIND = 0;
  static HAS_BBOX = 1;
  static HAS_BACKGROUND = 2;
  static SHADING_TYPE = 3;
  static N_COORD = 4;
  static N_COLOR = 8;
  static N_STOP = 12;
  static N_FIGURES = 16;
}
class ra {
  static get decoder() {
    return k(this, "decoder", new TextDecoder());
  }
  static get encoder() {
    return k(this, "encoder", new TextEncoder());
  }
}
function Pe(d, t, e, s = 0) {
  const {
    decoder: i
  } = ra;
  for (let r = 0; r < e; r++)
    s += t.getUint32(s) + 4;
  const n = t.getUint32(s);
  return i.decode(new Uint8Array(d, s + 4, n));
}
class aa {
  #t;
  #e;
  constructor(t) {
    this.#t = t, this.#e = new DataView(t);
  }
  #s(t) {
    return J(t < ia.strings.length, "Invalid string index"), Pe(this.#t, this.#e, t);
  }
  get fontFamily() {
    return k(this, "fontFamily", this.#s(0));
  }
  get fontWeight() {
    return k(this, "fontWeight", this.#s(1));
  }
  get italicAngle() {
    return k(this, "italicAngle", this.#s(2));
  }
}
class oa {
  #t;
  #e;
  constructor(t) {
    this.#t = t, this.#e = new DataView(t);
  }
  #s(t) {
    return J(t < na.strings.length, "Invalid string index"), Pe(this.#t, this.#e, t, 4);
  }
  get css() {
    return k(this, "css", this.#s(0));
  }
  get loadedName() {
    return k(this, "loadedName", this.#s(1));
  }
  get baseFontName() {
    return k(this, "baseFontName", this.#s(2));
  }
  get src() {
    return k(this, "src", this.#s(3));
  }
  get style() {
    let t = 0;
    t += 4 + this.#e.getUint32(t);
    const e = Pe(this.#t, this.#e, 0, t), s = Pe(this.#t, this.#e, 1, t);
    return k(this, "style", {
      style: e,
      weight: s
    });
  }
}
class la {
  #t;
  #e;
  constructor(t) {
    this.#t = t, this.#e = new DataView(t);
  }
  #s(t) {
    J(t < ue.bools.length, "Invalid boolean index");
    const e = Math.floor(t / 4), s = t * 2 % 8, i = this.#e.getUint8(e) >> s & 3;
    return i === 0 ? void 0 : i === 2;
  }
  get black() {
    return k(this, "black", this.#s(0));
  }
  get bold() {
    return k(this, "bold", this.#s(1));
  }
  get disableFontFace() {
    return k(this, "disableFontFace", this.#s(2));
  }
  get fontExtraProperties() {
    return k(this, "fontExtraProperties", this.#s(3));
  }
  get isInvalidPDFjsFont() {
    return k(this, "isInvalidPDFjsFont", this.#s(4));
  }
  get isType3Font() {
    return k(this, "isType3Font", this.#s(5));
  }
  get italic() {
    return k(this, "italic", this.#s(6));
  }
  get missingFile() {
    return k(this, "missingFile", this.#s(7));
  }
  get remeasure() {
    return k(this, "remeasure", this.#s(8));
  }
  get vertical() {
    return k(this, "vertical", this.#s(9));
  }
  #i(t, e, s, i) {
    const n = this.#e.getUint8(t++);
    if (n === 0)
      return;
    J(n === e, "Invalid array length.");
    const r = new Array(n);
    for (let a = 0; a < n; a++)
      r[a] = this.#e[s](t, !0), t += i;
    return r;
  }
  get bbox() {
    return k(this, "bbox", this.#i(ue.OFFSET_BBOX, 4, "getInt16", 2));
  }
  get fontMatrix() {
    return k(this, "fontMatrix", this.#i(ue.OFFSET_FONT_MATRIX, 6, "getFloat64", 8));
  }
  #n(t) {
    return J(t < ue.strings.length, "Invalid string index"), Pe(this.#t, this.#e, t, ue.OFFSET_STRINGS + 4);
  }
  get fallbackName() {
    return k(this, "fallbackName", this.#n(0));
  }
  get loadedName() {
    return k(this, "loadedName", this.#n(1));
  }
  #r(t) {
    let e = ue.OFFSET_STRINGS;
    for (let i = 0; i <= t; i++)
      e += 4 + this.#e.getUint32(e);
    const s = this.#e.getUint32(e);
    return {
      offset: e,
      length: s
    };
  }
  get data() {
    const {
      offset: t,
      length: e
    } = this.#r(2);
    return e ? new Uint8Array(this.#t, t + 4, e) : void 0;
  }
  clearData() {
    const {
      offset: t,
      length: e
    } = this.#r(2);
    e && (this.#e.setUint32(t, 0), this.#t = new Uint8Array(this.#t, 0, t + 4).slice().buffer, this.#e = new DataView(this.#t));
  }
  get cssFontInfo() {
    const {
      offset: t,
      length: e
    } = this.#r(1);
    let s = null;
    if (e) {
      const i = new Uint8Array(this.#t, t + 4, e).slice();
      s = new aa(i.buffer);
    }
    return k(this, "cssFontInfo", s);
  }
  get systemFontInfo() {
    const {
      offset: t,
      length: e
    } = this.#r(0);
    let s = null;
    if (e) {
      const i = new Uint8Array(this.#t, t + 4, e).slice();
      s = new oa(i.buffer);
    }
    return k(this, "systemFontInfo", s);
  }
}
class ha {
  constructor(t) {
    this.buffer = t, this.view = new DataView(t), this.data = new Uint8Array(t);
  }
  getIR() {
    const t = this.view, e = this.data[Jt.KIND], s = !!this.data[Jt.HAS_BBOX], i = !!this.data[Jt.HAS_BACKGROUND], n = t.getUint32(Jt.N_COORD, !0), r = t.getUint32(Jt.N_COLOR, !0), a = t.getUint32(Jt.N_STOP, !0);
    let o = 20;
    const l = new Float32Array(this.buffer, o, n * 2);
    o += n * 8;
    const h = new Uint8Array(this.buffer, o, r * 4);
    o += r * 4;
    const c = [];
    for (let p = 0; p < a; ++p) {
      const g = t.getFloat32(o, !0);
      o += 4;
      const m = t.getUint32(o, !0);
      o += 4, c.push([g, `#${m.toString(16).padStart(6, "0")}`]);
    }
    let u = null;
    if (s) {
      u = [];
      for (let p = 0; p < 4; ++p)
        u.push(t.getFloat32(o, !0)), o += 4;
    }
    let f = null;
    if (i && (f = new Uint8Array(this.buffer, o, 3), o += 3), e === 1)
      return ["RadialAxial", "axial", u, c, [l[0], l[1]], [l[2], l[3]], null, null];
    if (e === 2)
      return ["RadialAxial", "radial", u, c, [l[0], l[1]], [l[3], l[4]], l[2], l[5]];
    if (e === 3) {
      const p = this.data[Jt.SHADING_TYPE];
      let g = null;
      if (l.length > 0) {
        g = Dt.slice();
        for (let m = 0, b = l.length; m < b; m += 2)
          x.pointBoundingBox(l[m], l[m + 1], g);
      }
      return ["Mesh", p, l, h, n, g, u, f];
    }
    throw new Error(`Unsupported pattern kind: ${e}`);
  }
}
class ca {
  #t;
  constructor(t) {
    this.#t = t;
  }
  get path() {
    return W.isFloat16ArraySupported ? new Float16Array(this.#t) : new Float32Array(this.#t);
  }
}
const Zt = /* @__PURE__ */ Symbol("INITIAL_DATA"), Ms = () => ({
  ...Promise.withResolvers(),
  data: Zt
});
class si {
  #t = /* @__PURE__ */ new Map();
  get(t, e = null, s = null) {
    if (e) {
      const n = this.#t.getOrInsertComputed(t, Ms);
      return n.promise.then(() => e(n.data), s), null;
    }
    const i = this.#t.get(t);
    if (!i || i.data === Zt)
      throw new Error(`Requesting object that isn't resolved yet ${t}.`);
    return i.data;
  }
  has(t) {
    const e = this.#t.get(t);
    return !!e && e.data !== Zt;
  }
  delete(t) {
    const e = this.#t.get(t);
    return !e || e.data === Zt ? !1 : (this.#t.delete(t), !0);
  }
  resolve(t, e = null) {
    const s = this.#t.getOrInsertComputed(t, Ms);
    if (s.data !== Zt)
      throw new Error(`Object already resolved ${t}.`);
    s.data = e, s.resolve();
  }
  reject(t, e) {
    const s = this.#t.getOrInsertComputed(t, Ms);
    s.data === Zt && (s.promise.catch(() => {
    }), s.reject(e));
  }
  clear() {
    for (const {
      data: t
    } of this.#t.values())
      t?.bitmap?.close();
    this.#t.clear();
  }
  *[Symbol.iterator]() {
    for (const [t, {
      data: e
    }] of this.#t)
      e !== Zt && (yield [t, e]);
  }
}
class da {
  constructor({
    messageHandler: t,
    commonObjs: e,
    fontLoader: s,
    pageCache: i,
    pdfBug: n = !1,
    shouldCreatePageObjs: r = !1
  }) {
    this.messageHandler = t, this.commonObjs = e, this.fontLoader = s, this.pageCache = i, this.pdfBug = n, this.shouldCreatePageObjs = r;
  }
  resolveCommonObject(t, e, s) {
    if (e === "CopyLocalImage") {
      const {
        imageRef: i
      } = s;
      J(i, "The imageRef must be defined.");
      for (const n of this.pageCache.values()) {
        const r = n.objs || n;
        for (const [, a] of r) {
          if (a?.ref !== i)
            continue;
          if (!a.dataLen)
            return null;
          const o = structuredClone(a);
          return this.commonObjs.resolve(t, o), a.dataLen;
        }
      }
      return null;
    }
    switch (e) {
      case "Font":
        if ("error" in s) {
          const o = s.error;
          R(`Error during font loading: ${o}`), this.commonObjs.resolve(t, o);
          break;
        }
        const i = new la(s.buffer), n = this.pdfBug && globalThis.FontInspector?.enabled ? (o, l) => globalThis.FontInspector.fontAdded(o, l) : null, r = new Hr(i, n, s.charProcOperatorList, s.extra);
        this.fontLoader.bind(r).catch(() => this.messageHandler.sendWithPromise("FontFallback", {
          id: t
        }).catch((o) => {
          R(`FontFallback failed for "${t}": ${o}`);
        })).finally(() => {
          r.fontExtraProperties || r.clearData(), this.commonObjs.resolve(t, r);
        });
        break;
      case "FontPath":
        this.commonObjs.resolve(t, new ca(s));
        break;
      case "Image":
        this.commonObjs.resolve(t, s);
        break;
      case "Pattern":
        const a = new ha(s);
        this.commonObjs.resolve(t, a.getIR());
        break;
      default:
        throw new Error(`Got unknown common object type ${e}`);
    }
    return null;
  }
  resolveObject(t, e, s, i) {
    let n = this.pageCache.get(e);
    if (!n) {
      if (!this.shouldCreatePageObjs)
        return !1;
      n = new si(), this.pageCache.set(e, n);
    }
    const r = n.objs || n;
    if (r.has(t))
      return !1;
    if (n._intentStates?.size === 0)
      return i?.bitmap?.close(), !1;
    switch (s) {
      case "Image":
      case "Pattern":
        return r.resolve(t, i), !0;
      default:
        throw new Error(`Got unknown object type ${s}`);
    }
  }
}
const te = /* @__PURE__ */ Symbol("INTERNAL");
class ua {
  #t = !1;
  #e = !1;
  #s = !1;
  #i = !0;
  constructor(t, {
    name: e,
    intent: s,
    usage: i,
    rbGroups: n
  }) {
    this.#t = !!(t & gt.DISPLAY), this.#e = !!(t & gt.PRINT), this.name = e, this.intent = s, this.usage = i, this.rbGroups = n;
  }
  get visible() {
    if (this.#s)
      return this.#i;
    if (!this.#i)
      return !1;
    const {
      print: t,
      view: e
    } = this.usage;
    return this.#t ? e?.viewState !== "OFF" : this.#e ? t?.printState !== "OFF" : !0;
  }
  _setVisible(t, e, s = !1) {
    t !== te && j("Internal method `_setVisible` called."), this.#s = s, this.#i = e;
  }
  get serializable() {
    return {
      userSet: this.#s,
      visible: this.#i
    };
  }
}
class ii {
  #t = null;
  #e = /* @__PURE__ */ new Map();
  #s = null;
  #i = null;
  #n;
  creator = null;
  name = null;
  constructor(t, e = gt.DISPLAY, s = null) {
    if (this.#n = t, this.renderingIntent = e, t !== null) {
      this.name = t.name, this.creator = t.creator, this.#i = t.order;
      for (const i of t.groups)
        this.#e.set(i.id, new ua(e, i));
      if (s) {
        s.size !== this.#e.size && j("Incorrect serialized groupState.");
        for (const [i, n] of s)
          this.#e.get(i)._setVisible(te, n.visible, n.userSet);
      } else {
        if (t.baseState === "OFF")
          for (const i of this.#e.values())
            i._setVisible(te, !1);
        for (const i of t.on)
          this.#e.get(i)._setVisible(te, !0);
        for (const i of t.off)
          this.#e.get(i)._setVisible(te, !1);
      }
      this.#s = this.getHash();
    }
  }
  #r(t) {
    const e = t.length;
    if (e < 2)
      return !0;
    const s = t[0];
    for (let i = 1; i < e; i++) {
      const n = t[i];
      let r;
      if (Array.isArray(n))
        r = this.#r(n);
      else if (this.#e.has(n))
        r = this.#e.get(n).visible;
      else
        return R(`Optional content group not found: ${n}`), !0;
      switch (s) {
        case "And":
          if (!r)
            return !1;
          break;
        case "Or":
          if (r)
            return !0;
          break;
        case "Not":
          return !r;
        default:
          return !0;
      }
    }
    return s === "And";
  }
  isVisible(t) {
    if (this.#e.size === 0)
      return !0;
    if (!t)
      return hs("Optional content group not defined."), !0;
    if (t.type === "OCG")
      return this.#e.has(t.id) ? this.#e.get(t.id).visible : (R(`Optional content group not found: ${t.id}`), !0);
    if (t.type === "OCMD") {
      if (t.expression)
        return this.#r(t.expression);
      if (!t.policy || t.policy === "AnyOn") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return R(`Optional content group not found: ${e}`), !0;
          if (this.#e.get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOn") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return R(`Optional content group not found: ${e}`), !0;
          if (!this.#e.get(e).visible)
            return !1;
        }
        return !0;
      } else if (t.policy === "AnyOff") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return R(`Optional content group not found: ${e}`), !0;
          if (!this.#e.get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOff") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return R(`Optional content group not found: ${e}`), !0;
          if (this.#e.get(e).visible)
            return !1;
        }
        return !0;
      }
      return R(`Unknown optional content policy ${t.policy}.`), !0;
    }
    return R(`Unknown group type ${t.type}.`), !0;
  }
  setVisibility(t, e = !0, s = !0) {
    const i = this.#e.get(t);
    if (!i) {
      R(`Optional content group not found: ${t}`);
      return;
    }
    if (s && e && i.rbGroups.length)
      for (const n of i.rbGroups)
        for (const r of n)
          r !== t && this.#e.get(r)?._setVisible(te, !1, !0);
    i._setVisible(te, !!e, !0), this.#t = null;
  }
  setOCGState({
    state: t,
    preserveRB: e
  }) {
    let s;
    for (const i of t) {
      switch (i) {
        case "ON":
        case "OFF":
        case "Toggle":
          s = i;
          continue;
      }
      const n = this.#e.get(i);
      if (n)
        switch (s) {
          case "ON":
            this.setVisibility(i, !0, e);
            break;
          case "OFF":
            this.setVisibility(i, !1, e);
            break;
          case "Toggle":
            this.setVisibility(i, !n.visible, e);
            break;
        }
    }
    this.#t = null;
  }
  get hasInitialVisibility() {
    return this.#s === null || this.getHash() === this.#s;
  }
  getOrder() {
    return this.#e.size ? this.#i ? this.#i.slice() : [...this.#e.keys()] : null;
  }
  getGroup(t) {
    return this.#e.get(t) || null;
  }
  getHash() {
    if (this.#t !== null)
      return this.#t;
    const t = new Gs();
    for (const [e, s] of this.#e)
      t.update(`${e}:${s.visible}`);
    return this.#t = t.hexdigest();
  }
  [Symbol.iterator]() {
    return this.#e.entries();
  }
  get serializable() {
    const t = /* @__PURE__ */ new Map();
    for (const [e, s] of this.#e)
      t.set(e, s.serializable);
    return {
      data: this.#n,
      renderingIntent: this.renderingIntent,
      groupState: t
    };
  }
  static fromSerializable({
    data: t,
    renderingIntent: e,
    groupState: s
  }) {
    return new ii(t, e, s);
  }
}
class fa {
  #t = null;
  #e = null;
  #s = 0;
  #i = 0;
  #n = null;
  #r = null;
  get pagesNumber() {
    return this.#s;
  }
  set pagesNumber(t) {
    this.#s !== t && (this.#s = this.#i = t, this.#t = null, this.#e = null);
  }
  #a() {
    if (this.#t)
      return;
    const t = this.#s, e = this.#t = new Uint32Array(t);
    for (let s = 0; s < t; s++)
      e[s] = s + 1;
    this.#e = new Int32Array(e);
  }
  #o() {
    const t = /* @__PURE__ */ new Map(), e = this.#t;
    for (let s = 0, i = this.#s; s < i; s++) {
      const n = e[s], r = t.get(n);
      r ? r.push(s + 1) : t.set(n, [s + 1]);
    }
    return t;
  }
  movePages(t, e, s) {
    this.#a();
    const i = this.#t, n = e.length, r = new Uint32Array(n);
    let a = 0;
    for (let u = 0; u < n; u++) {
      const f = e[u] - 1;
      r[u] = i[f], f < s && a++;
    }
    const o = this.#s, l = o - n, h = new Int32Array(o), c = Y(s - a, 0, l);
    for (let u = 0, f = 0; u < o; u++)
      t.has(u + 1) || (i[f] = i[u], h[f++] = u + 1);
    i.copyWithin(c + n, c, l), i.set(r, c), h.copyWithin(c + n, c, l), h.set(e, c), this.#e = h, o === this.#i && i.every((u, f) => u === f + 1) && (this.#t = null);
  }
  deletePages(t) {
    this.#a();
    const e = this.#t, s = this.#o();
    this.#r = {
      pageNumberToId: e.slice(),
      pagesNumber: this.#s,
      prevPageNumbers: this.#e.slice()
    };
    const i = this.#s - t.length;
    this.#s = i;
    const n = this.#t = new Uint32Array(i);
    this.#e = new Int32Array(i);
    let r = 0, a = 0;
    for (const o of t) {
      const l = o - 1;
      l !== r && (n.set(e.subarray(r, l), a), a += l - r), r = l + 1;
    }
    r < e.length && n.set(e.subarray(r), a), this.#l(s, new Set(t));
  }
  cancelDelete() {
    this.#r && (this.#t = this.#r.pageNumberToId, this.#s = this.#r.pagesNumber, this.#e = this.#r.prevPageNumbers, this.#r = null);
  }
  cleanSavedData() {
    this.#r = null;
  }
  copyPages(t) {
    this.#a(), this.#n = {
      pageNumbers: t,
      pageIds: t.map((e) => this.#t[e - 1])
    };
  }
  cancelCopy() {
    this.#n = null;
  }
  pastePages(t) {
    this.#a();
    const e = this.#t, s = this.#o(), {
      pageNumbers: i,
      pageIds: n
    } = this.#n, r = this.#s + i.length;
    this.#s = r;
    const a = this.#t = new Uint32Array(r);
    this.#e = new Int32Array(r), a.set(e.subarray(0, t), 0), a.set(n, t), a.set(e.subarray(t), t + i.length), this.#l(s, null, t, i), this.#n = null;
  }
  #l(t, e = null, s = -1, i = null) {
    const n = this.#e, r = this.#t, a = s + (i?.length ?? 0), o = /* @__PURE__ */ new Map();
    for (let l = 0, h = this.#s; l < h; l++) {
      if (l >= s && l < a) {
        n[l] = -i[l - s];
        continue;
      }
      const c = r[l], u = t.get(c);
      let f = o.get(c) || 0;
      if (e && u)
        for (; f < u.length && e.has(u[f]); )
          f++;
      n[l] = u?.[f], o.set(c, f + 1);
    }
  }
  hasBeenAltered() {
    return this.#t !== null;
  }
  #h(t = null) {
    if (!this.#t)
      return null;
    const e = new Int32Array(this.#s).fill(-1), s = /* @__PURE__ */ new Map();
    if (t)
      for (const i of t) {
        const n = this.getPageId(i), r = s.get(n) ?? 0;
        s.set(n, r + 1), e[i - 1] = r;
      }
    else
      for (let i = 0, n = this.#s; i < n; i++) {
        const r = this.#t[i], a = s.get(r) ?? 0;
        s.set(r, a + 1), e[i] = a;
      }
    return e;
  }
  getPageMappingForSaving(t = null, e = this.#h()) {
    t ??= this.#o();
    let s = 0;
    for (const n of t.values())
      s = Math.max(s, n.length);
    const i = new Array(s);
    for (let n = 0; n < s; n++)
      i[n] = {
        document: null,
        pageIndices: [],
        includePages: []
      };
    for (const [n, r] of t)
      for (let a = 0, o = r.length; a < o; a++)
        i[a].includePages.push([n - 1, r[a] - 1]);
    for (const {
      includePages: n,
      pageIndices: r
    } of i) {
      n.sort((a, o) => a[0] - o[0]);
      for (let a = 0, o = n.length; a < o; a++)
        r.push(n[a][1]), n[a] = n[a][0];
    }
    return {
      pageInfos: i,
      copyLevels: e
    };
  }
  extractPages(t) {
    t = Array.from(t).sort((s, i) => s - i);
    const e = /* @__PURE__ */ new Map();
    for (let s = 0, i = t.length; s < i; s++) {
      const n = this.getPageId(t[s]);
      e.getOrInsertComputed(n, we).push(s + 1);
    }
    return this.getPageMappingForSaving(e, this.#h(t));
  }
  getPrevPageNumber(t) {
    return this.#e?.[t - 1] ?? 0;
  }
  getPageNumber(t) {
    if (!this.#t)
      return t;
    const e = this.#t;
    for (let s = 0, i = this.#s; s < i; s++)
      if (e[s] === t)
        return s + 1;
    return 0;
  }
  getPageId(t) {
    return this.#t?.[t - 1] ?? t;
  }
  getMapping() {
    return this.#t?.subarray(0, this.pagesNumber);
  }
}
const $i = 5e3;
function $s({
  bitmap: d,
  annotationBitmaps: t
}) {
  if (d?.close(), t)
    for (const [, , e] of t)
      e.close();
}
class pa {
  #t;
  #e = !1;
  #s;
  #i;
  #n = 0;
  #r;
  #a;
  #o;
  #l;
  #h;
  #u;
  #c;
  imageCoordinates = null;
  recordedBBoxes = null;
  constructor({
    rendererWorker: t,
    renderTasks: e,
    canvas: s,
    canvasFactory: i,
    annotationCanvasMap: n,
    operatorListState: r,
    initParams: a,
    onFrame: o,
    onError: l
  }) {
    this.#u = t, this.#c = e, this.#s = s, this.#i = i, this.#t = n, this.#h = r, this.#a = a, this.#r = a.renderTaskId, this.#l = o, this.#o = l;
  }
  async initialize(t, e) {
    try {
      await this.#u.promise;
    } catch {
      return !1;
    }
    if (!this.#u.messageHandler || this.#e)
      return !1;
    try {
      await this.#u.sendWithPromise("InitializeGraphics", {
        ...this.#a,
        width: this.#s.width,
        height: this.#s.height,
        transparency: t,
        optionalContentConfig: e.serializable
      });
    } catch (s) {
      return this.#e || R(`Failed to initialize graphics in renderer worker: ${s.message}. Falling back to main-thread rendering.`), !1;
    }
    return this.#e || this.#c.set(this.#r, this), !0;
  }
  async executeOperatorList(t, e, s) {
    const i = this.#u.messageHandler;
    if (!i)
      throw new Error("Renderer worker was destroyed during rendering.");
    const {
      lastChunk: n
    } = t, r = t.argsArray.length, a = this.#h;
    if (a.sentLength < r) {
      const h = a.sentLength;
      i.send("AppendOperatorList", {
        pageProxyId: this.#a.pageProxyId,
        operatorListId: a.id,
        fnArray: t.fnArray.slice(h, r),
        argsArray: t.argsArray.slice(h, r)
      }), a.sentLength = r;
    }
    let o = null;
    if (s && this.#n < r) {
      const h = this.#n;
      o = new Uint8Array(r - h);
      for (let c = h; c < r; c++)
        o[c - h] = s(c, t) ? 1 : 0;
      this.#n = r;
    }
    const l = await this.#u.sendWithPromise("ExecuteOperatorList", {
      renderTaskId: this.#r,
      operatorListIdx: e,
      operatorListLength: r,
      operationsFilterMask: o,
      lastChunk: n
    }).catch((h) => {
      if (!this.#e)
        throw h;
      return {
        operatorListIdx: e,
        aborted: !0
      };
    });
    if (l.aborted && !this.#e)
      throw new Error("Render task was aborted in the renderer worker.");
    if (n && l.operatorListIdx === r) {
      this.#c.delete(this.#r);
      const {
        recordedBBoxesBuffer: h,
        imageCoordinates: c
      } = l;
      h && (this.recordedBBoxes = fs.fromBuffer(h)), this.imageCoordinates = c ?? null;
    }
    return l.operatorListIdx;
  }
  cancel() {
    this.#e = !0, this.#c.delete(this.#r), this.#u.messageHandler?.send("CleanupRenderTask", {
      renderTaskId: this.#r
    });
  }
  drawFrame(t) {
    try {
      t.bitmap && this.#i.getNoAlphaContext(this.#s).drawImage(t.bitmap, 0, 0), t.annotationBitmaps && this.#f(t.annotationBitmaps);
    } catch (e) {
      this.#o(e);
      return;
    } finally {
      $s(t);
    }
    this.#l();
  }
  #f(t) {
    const e = this.#t, s = /* @__PURE__ */ new Set();
    for (const [i, n, r] of t) {
      const {
        canvas: a,
        context: o
      } = this.#i.create(r.width, r.height);
      if (o.drawImage(r, 0, 0), !n) {
        e.set(i, a);
        continue;
      }
      un(a, n), s.has(i) ? e.get(i).push(a) : (s.add(i), e.set(i, [a]));
    }
  }
}
class se {
  #t = Promise.withResolvers();
  #e;
  #s;
  #i = null;
  #n = 0;
  #r = /* @__PURE__ */ new WeakMap();
  #a = [];
  #o = /* @__PURE__ */ new Set();
  #l = null;
  #h = null;
  #u = 0;
  #c = /* @__PURE__ */ new Map();
  #f = null;
  #p = null;
  #m = null;
  static #d = 0;
  static #g = /* @__PURE__ */ new WeakSet();
  destroyed = !1;
  constructor({
    port: t = null,
    verbosity: e = Yi(),
    enableHWA: s = !1,
    enableWebGPU: i = !1
  } = {}) {
    this.verbosity = e, this.#e = s, this.#s = i, t ? this.#A(t) : this.#w();
  }
  static get isAvailable() {
    return (!!Ut.rendererSrc || Ut.rendererPorts.length > 0) && typeof Worker < "u" && W.isOffscreenCanvasSupported && !!globalThis.document?.fonts;
  }
  get promise() {
    return this.#t.promise;
  }
  get messageHandler() {
    return this.#i;
  }
  get port() {
    return this.#l;
  }
  #b() {
    this.#i.on("RenderFrame", (e) => {
      const s = this.#c.get(e.renderTaskId);
      s ? s.drawFrame(e) : $s(e);
    }), this.#t.resolve(), this.#i.send("configure", {
      verbosity: this.verbosity,
      enableHWA: this.#e,
      enableWebGPU: this.#s
    });
    const t = this.#a;
    this.#a = null;
    for (const e of t)
      e();
  }
  #y(t) {
    this.#a = null, this.#t.reject(t);
  }
  #A(t) {
    se.#g.add(t), this.#l = t;
    const e = se.#d++, s = `main${e}`, i = `renderer${e}`;
    this.#h = {
      sourceName: s,
      targetName: i
    };
    const n = new Vt("main", "renderer", t);
    n.send("Connect", {
      sourceName: i,
      targetName: s
    }), n.destroy(), this.#S(t, new Vt(s, i, t), !0);
  }
  #w() {
    try {
      const {
        rendererSrc: t
      } = Ut;
      if (!t)
        throw new Error('No "GlobalWorkerOptions.rendererSrc" specified.');
      const e = new Worker(rn(t), {
        type: "module"
      });
      this.#S(e, new Vt("main", "renderer", e), !1);
    } catch (t) {
      this.#y(t);
    }
  }
  #S(t, e, s) {
    let i = null;
    const n = (o) => {
      this.#f = null, clearTimeout(i), r.abort(), e.destroy(), s ? this.#l = null : t.terminate(), this.#y(new Error(`Renderer worker failed to initialize: "${o?.message ?? o}".`));
    };
    this.#f = n;
    const r = new AbortController(), a = (o, l) => {
      if (!this.#i) {
        n(l);
        return;
      }
      o.preventDefault(), R(`Renderer worker failed: "${l}". Falling back to main-thread rendering.`), this.destroy();
    };
    t.addEventListener("error", (o) => a(o, o.error?.message ?? o.message), {
      signal: r.signal
    }), t.addEventListener("messageerror", (o) => a(o, "Cannot deserialize a message."), {
      signal: r.signal
    }), s && (i = setTimeout(() => n("Connection timed out."), $i)), e.on("ready", (o) => {
      if (!(o?.testObj instanceof Uint8Array)) {
        n("TypedArray transfer test failed.");
        return;
      }
      const l = "6.5.438";
      if (l !== o.workerVersion) {
        n(`The API version "${l}" does not match the Worker version "${o.workerVersion}".`);
        return;
      }
      this.#f = null, clearTimeout(i), this.#i = e, s || (this.#p = t), this.#m = r, this.#b();
    });
  }
  destroy() {
    this.destroyed = !0, this.#l && (this.#i && (this.#_(this.#l), this.#i.send("Disconnect", null)), se.#g.delete(this.#l), this.#l = null), this.#f?.("Worker was destroyed."), this.#m?.abort(), this.#m = null, this.#p?.terminate(), this.#p = null, this.#i?.destroy(), this.#i = null;
    for (const t of this.#o)
      t(new Error("Renderer worker was destroyed."));
    this.#o.clear();
  }
  #_(t) {
    const {
      sourceName: e,
      targetName: s
    } = this.#h, i = new AbortController(), n = setTimeout(() => i.abort(), $i);
    t.addEventListener("message", ({
      data: r
    }) => {
      r?.targetName !== e || r.sourceName !== s || (r.action === "RenderFrame" ? $s(r.data) : r.action === "Disconnected" && (clearTimeout(n), i.abort()));
    }, {
      signal: i.signal
    });
  }
  static create({
    ports: t = [],
    ...e
  } = {}) {
    const s = t.find((i) => !this.#g.has(i)) ?? null;
    return !s && t.length > 0 && R("RendererWorker.create - no unused `rendererPorts` available, falling back to `rendererSrc`."), new se({
      ...e,
      port: s
    });
  }
  sendWithPromise(t, e) {
    const s = this.#i;
    if (!s)
      return Promise.reject(new Error("Renderer worker was destroyed."));
    const {
      promise: i,
      resolve: n,
      reject: r
    } = Promise.withResolvers();
    return this.#o.add(r), s.sendWithPromise(t, e).then(n, r), i.finally(() => {
      this.#o.delete(r);
    });
  }
  #v(t, e) {
    if (this.#a) {
      this.#a.push(() => this.#v(t, e));
      return;
    }
    this.#i?.send(t, e);
  }
  #C(t, e, s, i, n = !1) {
    try {
      if (this.#a) {
        const r = n ? structuredClone(e) : e;
        this.#a.push(() => this.#C(t, r, s, i));
        return;
      }
      this.#i?.send(t, e);
    } catch (r) {
      R(`RendererWorker - failed to send "${t}": ${r}`), this.#v("objFailed", {
        id: s,
        pageProxyId: i,
        reason: r.message
      });
    }
  }
  sendCommonObj(t, e, s) {
    this.#C("commonobj", [t, e, s], t, null, e === "Font");
  }
  sendObj(t, e, s, i) {
    this.#C("obj", [t, e, s, i], t, e);
  }
  cleanup(t) {
    this.#v("Cleanup", {
      keepLoadedFonts: t
    });
  }
  cleanupPage(t) {
    this.#v("cleanupPage", {
      pageProxyId: t
    });
  }
  createRenderTask({
    pageProxyId: t,
    operatorList: e,
    params: s,
    pageColors: i,
    canvasFactory: n,
    annotationCanvasMap: r,
    onFrame: a,
    onError: o
  }) {
    const {
      canvas: l,
      canvasContext: h,
      background: c
    } = s;
    if (!this.#i && !this.#a || h || c && typeof c != "string" || i || s.recordForDebugger)
      return null;
    const u = this.#r.getOrInsertComputed(e, () => ({
      id: this.#n++,
      sentLength: 0
    }));
    return new pa({
      rendererWorker: this,
      renderTasks: this.#c,
      canvas: l,
      canvasFactory: n,
      annotationCanvasMap: r,
      operatorListState: u,
      initParams: {
        pageProxyId: t,
        operatorListId: u.id,
        renderTaskId: this.#u++,
        hasAnnotationCanvasMap: !!r,
        recordOperations: s.recordOperations,
        recordImages: s.recordImages,
        partialFrames: s.partialFrames,
        transform: s.transform,
        viewport: s.viewport,
        background: c,
        pixelRatio: wt.pixelRatio
      },
      onFrame: a,
      onError: o
    });
  }
}
const ga = 1e5, ma = 30;
class mt {
  #t = Promise.withResolvers();
  #e = null;
  #s = !1;
  #i = !!globalThis.FontInspector?.enabled;
  #n = null;
  #r = null;
  #a = null;
  #o = 0;
  #l = 0;
  #h = wt.pixelRatio;
  #u = null;
  #c = null;
  #f = 0;
  #p = 0;
  #m = /* @__PURE__ */ Object.create(null);
  #d = [];
  #g = null;
  #b = [];
  #y = null;
  static #A = /* @__PURE__ */ new Map();
  static #w = /* @__PURE__ */ new Map();
  static #S = /* @__PURE__ */ new WeakMap();
  static #_ = null;
  static #v = /* @__PURE__ */ new Set();
  constructor({
    textContentSource: t,
    images: e,
    container: s,
    viewport: i
  }) {
    if (t instanceof ReadableStream)
      this.#g = t;
    else if (typeof t == "object")
      this.#g = new ReadableStream({
        start(l) {
          l.enqueue(t), l.close();
        }
      });
    else
      throw new Error('No "textContentSource" parameter specified.');
    this.#e = this.#c = s, this.#n = e, this.#p = i.scale * this.#h, this.#f = i.rotation, this.#a = {
      div: null,
      properties: null,
      ctx: null
    };
    const {
      pageWidth: n,
      pageHeight: r,
      pageX: a,
      pageY: o
    } = i.rawDims;
    this.#y = [1, 0, 0, -1, -a, o + r], this.#l = n, this.#o = r, mt.#D(), s.style.setProperty("--min-font-size", mt.#_), oe(s, i), this.#t.promise.finally(() => {
      mt.#v.delete(this), this.#a = null, this.#m = null;
    }).catch(() => {
    });
  }
  static get fontFamilyMap() {
    const {
      isWindows: t,
      isFirefox: e
    } = W.platform;
    return k(this, "fontFamilyMap", /* @__PURE__ */ new Map([["sans-serif", `${t && e ? "Calibri, " : ""}sans-serif`], ["monospace", `${t && e ? "Lucida Console, " : ""}monospace`]]));
  }
  render() {
    this.#n && this.#e.append(this.#n.render());
    const t = () => {
      this.#u.read().then(({
        value: e,
        done: s
      }) => {
        if (s) {
          this.#t.resolve();
          return;
        }
        this.#r ??= e.lang, Object.assign(this.#m, e.styles), this.#C(e.items), t();
      }, this.#t.reject);
    };
    return this.#u = this.#g.getReader(), mt.#v.add(this), t(), this.#t.promise;
  }
  update({
    viewport: t
  }) {
    const e = t.scale * wt.pixelRatio, s = t.rotation;
    s !== this.#f && (this.#f = s, oe(this.#c, {
      rotation: s
    })), e !== this.#p && (this.#p = e, this.#h = wt.pixelRatio);
  }
  cancel() {
    const t = new Yt("TextLayer task cancelled.");
    this.#u?.cancel(t).catch(() => {
    }), this.#u = null, this.#t.reject(t);
  }
  get textDivs() {
    return this.#b;
  }
  get textContentItemsStr() {
    return this.#d;
  }
  #C(t) {
    if (this.#s)
      return;
    this.#a.ctx ??= mt.#T(this.#r);
    const e = this.#b, s = this.#d;
    for (const i of t) {
      if (e.length > ga) {
        R("Ignoring additional textDivs for performance reasons."), this.#s = !0;
        return;
      }
      if (i.str === void 0) {
        if (i.type === "beginMarkedContentProps" || i.type === "beginMarkedContent") {
          const n = this.#e;
          this.#e = document.createElement("span"), this.#e.classList.add("markedContent"), i.id && this.#e.setAttribute("id", i.id), i.tag === "Artifact" && (this.#e.ariaHidden = !0), n.append(this.#e);
        } else i.type === "endMarkedContent" && (this.#e = this.#e.parentNode);
        continue;
      }
      s.push(i.str), this.#I(i);
    }
  }
  #I(t) {
    const e = document.createElement("span"), s = {
      angle: 0,
      canvasWidth: 0,
      hasText: t.str !== "",
      hasEOL: t.hasEOL,
      fontSize: 0
    };
    this.#b.push(e);
    const i = x.transform(this.#y, t.transform);
    let n = Math.atan2(i[1], i[0]);
    const r = this.#m[t.fontName];
    r.vertical && (n += Math.PI / 2);
    let a = this.#i && r.fontSubstitution || r.fontFamily;
    a = mt.fontFamilyMap.get(a) || a;
    const o = Math.hypot(i[2], i[3]), l = o * mt.#R(a, r, this.#r);
    let h, c;
    n === 0 ? (h = i[4], c = i[5] - l) : (h = i[4] + l * Math.sin(n), c = i[5] - l * Math.cos(n));
    const u = e.style;
    u.left = `${(100 * h / this.#l).toFixed(2)}%`, u.top = `${(100 * c / this.#o).toFixed(2)}%`;
    const f = Math.round(o * 100) / 100;
    u.setProperty("--font-height", `${f}px`), u.fontFamily = a, s.fontSize = f, e.setAttribute("role", "presentation"), e.textContent = t.str, e.dir = t.dir, this.#i && (e.dataset.fontName = r.fontSubstitutionLoadedName || t.fontName), n !== 0 && (s.angle = n * (180 / Math.PI));
    let p = !1;
    if (t.str.length > 1)
      p = !0;
    else if (t.str !== " " && t.transform[0] !== t.transform[3]) {
      const g = Math.abs(t.transform[0]), m = Math.abs(t.transform[3]);
      g !== m && Math.max(g, m) / Math.min(g, m) > 1.5 && (p = !0);
    }
    if (p && (s.canvasWidth = r.vertical ? t.height : t.width), this.#a.div = e, this.#a.properties = s, this.#k(this.#a), s.hasText && this.#e.append(e), s.hasEOL) {
      const g = document.createElement("br");
      g.setAttribute("role", "presentation"), this.#e.append(g);
    }
  }
  #k(t) {
    const {
      div: e,
      properties: s,
      ctx: i
    } = t, {
      style: n
    } = e, {
      canvasWidth: r,
      fontSize: a
    } = s;
    if (r !== 0 && a !== 0 && s.hasText) {
      const {
        fontFamily: o
      } = n, l = this.#h, h = mt.#O(a * this.#p / l) * l;
      mt.#P(i, h, o);
      const {
        width: c
      } = i.measureText(e.textContent);
      c > 0 && n.setProperty("--scale-x", r * h / (c * a));
    }
    s.angle !== 0 && n.setProperty("--rotate", `${s.angle}deg`);
  }
  static cleanup() {
    if (!(this.#v.size > 0)) {
      this.#A.clear();
      for (const {
        canvas: t
      } of this.#w.values())
        t.remove();
      this.#w.clear();
    }
  }
  static #T(t = null) {
    let e = this.#w.get(t ||= "");
    if (!e) {
      const s = document.createElement("canvas");
      s.style.cssText = "position:absolute;top:0;left:0;width:0;height:0;display:none;letter-spacing:normal;word-spacing:normal", s.lang = t, document.body.append(s), e = s.getContext("2d", {
        alpha: !1,
        willReadFrequently: !0
      }), this.#w.set(t, e), this.#S.set(e, {
        size: 0,
        family: ""
      });
    }
    return e;
  }
  static #O(t) {
    t = Math.fround(t);
    const e = Math.fround(t * ((1 << 17) + 1));
    return Math.fround(e - Math.fround(e - t));
  }
  static #P(t, e, s) {
    const i = this.#S.get(t);
    e === i.size && s === i.family || (t.font = `${e}px ${s}`, i.size = e, i.family = s);
  }
  static #D() {
    if (this.#_ !== null)
      return;
    const t = document.createElement("div");
    t.style.opacity = 0, t.style.lineHeight = 1, t.style.fontSize = "1px", t.style.position = "absolute", t.textContent = "X", document.body.append(t), this.#_ = t.getBoundingClientRect().height, t.remove();
  }
  static #R(t, e, s) {
    const i = this.#A.get(t);
    if (i)
      return i;
    const n = this.#T(s);
    this.#P(n, ma, t);
    const r = n.measureText(""), a = r.fontBoundingBoxAscent, o = Math.abs(r.fontBoundingBoxDescent);
    let l = 0.8;
    return a ? l = a / (a + o) : (W.platform.isFirefox && R("Enable the `dom.textMetrics.fontBoundingBox.enabled` preference in `about:config` to improve TextLayer rendering."), e.ascent ? l = e.ascent : e.descent && (l = 1 + e.descent)), this.#A.set(t, l), l;
  }
}
const ba = 100;
function ya(d = {}) {
  const t = new ni(), {
    docId: e
  } = t, s = d.url ? ir(d.url) : null, i = d.data ? nr(d.data) : null, n = d.httpHeaders || null, r = d.withCredentials === !0, a = d.password ?? null, o = d.range instanceof wn ? d.range : null, l = Number.isInteger(d.rangeChunkSize) && d.rangeChunkSize > 0 ? d.rangeChunkSize : 2 ** 16;
  let h = d.worker instanceof Fe ? d.worker : null;
  const c = d.verbosity, u = typeof d.docBaseUrl == "string" && !ds(d.docBaseUrl) ? d.docBaseUrl : null, f = Ge(d.cMapUrl), p = d.cMapPacked !== !1, g = Ge(d.iccUrl), m = Ge(d.standardFontDataUrl), b = Ge(d.wasmUrl), y = d.stopAtErrors !== !0, A = Number.isInteger(d.maxImageSize) && d.maxImageSize > -1 ? d.maxImageSize : -1, w = typeof d.isOffscreenCanvasSupported == "boolean" ? d.isOffscreenCanvasSupported : !bt, v = typeof d.isImageDecoderSupported == "boolean" ? d.isImageDecoderSupported : !bt, S = Number.isInteger(d.canvasMaxAreaInBytes) ? d.canvasMaxAreaInBytes : -1, _ = typeof d.disableFontFace == "boolean" ? d.disableFontFace : bt, E = d.fontExtraProperties === !0, C = d.enableXfa === !0, T = d.ownerDocument || globalThis.document, D = d.disableRange === !0, P = d.disableStream === !0, N = d.disableAutoFetch === !0, G = d.pdfBug === !0, z = d.CanvasFactory || (bt ? gr : Rr), F = d.FilterFactory || (bt ? pr : Lr), O = d.BinaryDataFactory || (bt ? mr : ki), rt = d.enableHWA === !0, lt = d.enableWebGPU === !0;
  lt && an();
  const Ft = d.useWasm !== !1, Tt = d.pagesMapper || new fa(), tt = null, et = typeof d.useSystemFonts == "boolean" ? d.useSystemFonts : !bt && !_, ht = typeof d.useWorkerFetch == "boolean" ? d.useWorkerFetch : !!(O === ki && f && p && m && b && xe(f, document.baseURI) && xe(m, document.baseURI) && xe(b, document.baseURI)), qt = d.disableWorkerRendering === !0 || !w || T !== globalThis.document || !1 || !se.isAvailable;
  Rn(c);
  const Gt = {
    canvasFactory: new z({
      ownerDocument: T,
      enableHWA: rt
    }),
    filterFactory: new F({
      docId: e,
      ownerDocument: T
    }),
    binaryDataFactory: ht ? null : new O({
      cMapUrl: f,
      standardFontDataUrl: m,
      wasmUrl: b
    })
  };
  if (h || (h = Fe.create({
    verbosity: c,
    port: Ut.workerPort
  }), t._worker = h), !qt) {
    const jt = se.create({
      verbosity: c,
      enableHWA: rt,
      enableWebGPU: lt,
      ports: Ut.rendererPorts
    });
    jt.promise.catch((Se) => {
      jt.destroyed || (R(`Renderer worker disabled: ${Se.message}`), jt.destroy());
    }), t._rendererWorker = jt;
  }
  const Q = {
    docId: e,
    apiVersion: "6.5.438",
    data: i,
    password: a,
    disableAutoFetch: N,
    rangeChunkSize: l,
    docBaseUrl: u,
    enableXfa: C,
    evaluatorOptions: {
      maxImageSize: A,
      disableFontFace: _,
      ignoreErrors: y,
      isOffscreenCanvasSupported: w,
      isImageDecoderSupported: v,
      canvasMaxAreaInBytes: S,
      fontExtraProperties: E,
      useSystemFonts: et,
      useWasm: Ft,
      useWorkerFetch: ht,
      cMapUrl: f,
      cMapPacked: p,
      iccUrl: g,
      standardFontDataUrl: m,
      wasmUrl: b
    }
  }, Be = {
    ownerDocument: T,
    pdfBug: G,
    styleElement: tt,
    rendererWorker: t._rendererWorker,
    enableWebGPU: lt,
    loadingParams: {
      disableAutoFetch: N,
      enableXfa: C
    }
  };
  return h.promise.then(function() {
    if (h.destroyed)
      throw new Error("Worker was destroyed");
    const jt = h.messageHandler.sendWithPromise("GetDocRequest", Q, i ? [i.buffer] : null);
    let Se;
    if (!i) if (o)
      Se = new Wr({
        pdfDataRangeTransport: o,
        disableRange: D,
        disableStream: P
      });
    else if (s) {
      const Ss = ea(s);
      Se = new Ss({
        url: s,
        httpHeaders: n,
        withCredentials: r,
        rangeChunkSize: l,
        disableRange: D,
        disableStream: P
      });
    } else
      throw new Error("getDocument - expected either `data`, `range`, or `url` parameter.");
    return jt.then((Ss) => {
      if (h.destroyed)
        throw new Error("Worker was destroyed");
      const mi = new Vt(e, Ss, h.port), Dn = new wa(mi, t, Se, Be, Gt, Tt);
      if (t._transport = Dn, t.destroyed)
        throw new Error("Loading aborted");
      mi.send("Ready", null);
    });
  }).catch(t._capability.reject).finally(t._setupCapability.resolve), t;
}
class ni {
  static #t = 0;
  _capability = Promise.withResolvers();
  _setupCapability = Promise.withResolvers();
  _transport = null;
  _worker = null;
  _rendererWorker = null;
  docId = `d${ni.#t++}`;
  destroyed = !1;
  onPassword = null;
  onProgress = null;
  get promise() {
    return this._capability.promise;
  }
  async destroy() {
    this.destroyed = !0, this._capability.promise.catch(() => {
    });
    try {
      this._worker?.port && (this._worker._pendingDestroy = !0), await this._setupCapability.promise, await this._transport?.destroy();
    } catch (t) {
      throw this._worker?.port && delete this._worker._pendingDestroy, t;
    } finally {
      this._rendererWorker?.destroy(), this._rendererWorker = null;
    }
    this._transport = null, this._worker?.destroy(), this._worker = null;
  }
  async getData() {
    return this._transport.getData();
  }
}
class wn {
  #t = Promise.withResolvers();
  #e = null;
  constructor(t, e, s = !1, i = null) {
    this.length = t, this.initialData = e, this.progressiveDone = s, this.contentDispositionFilename = i;
  }
  onDataRange(t, e) {
    this.#e({
      type: "range",
      begin: t,
      chunk: e
    });
  }
  onDataProgressiveRead(t) {
    this.#t.promise.then(() => {
      this.#e({
        type: "progressiveRead",
        chunk: t
      });
    });
  }
  onDataProgressiveDone() {
    this.#t.promise.then(() => {
      this.#e({
        type: "progressiveDone"
      });
    });
  }
  transportReady(t) {
    this.#e = t, this.#t.resolve();
  }
  requestDataRange(t, e) {
    j("Abstract method PDFDataRangeTransport.requestDataRange");
  }
  abort() {
  }
}
class Aa {
  constructor(t, e) {
    this._pdfInfo = t, this._transport = e;
  }
  get pagesMapper() {
    return this._transport.pagesMapper;
  }
  get annotationStorage() {
    return this._transport.annotationStorage;
  }
  get canvasFactory() {
    return this._transport.canvasFactory;
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get numPages() {
    return this._pdfInfo.numPages;
  }
  get fingerprints() {
    return this._pdfInfo.fingerprints;
  }
  get isPureXfa() {
    return k(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  get allXfaHtml() {
    return this._transport._htmlForXfa;
  }
  getPage(t) {
    return this._transport.getPage(t);
  }
  getPageIndex(t) {
    return this._transport.getPageIndex(t);
  }
  getDestinations() {
    return this._transport.getDestinations();
  }
  getDestination(t) {
    return this._transport.getDestination(t);
  }
  getPageLabels() {
    return this._transport.getPageLabels();
  }
  getPageLayout() {
    return this._transport.getPageLayout();
  }
  getPageMode() {
    return this._transport.getPageMode();
  }
  getViewerPreferences() {
    return this._transport.getViewerPreferences();
  }
  getOpenAction() {
    return this._transport.getOpenAction();
  }
  getAttachments() {
    return this._transport.getAttachments();
  }
  getAttachmentContent(t) {
    return this._transport.getAttachmentContent(t);
  }
  getAnnotationsByType(t, e) {
    return this._transport.getAnnotationsByType(t, e);
  }
  getJSActions() {
    return this._transport.getDocJSActions();
  }
  getOutline() {
    return this._transport.getOutline();
  }
  getOptionalContentConfig({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getOptionalContentConfig(e);
  }
  getPermissions() {
    return this._transport.getPermissions();
  }
  getMetadata() {
    return this._transport.getMetadata();
  }
  getMarkInfo() {
    return this._transport.getMarkInfo();
  }
  getData() {
    return this._transport.getData();
  }
  saveDocument(t) {
    return this._transport.saveDocument(t);
  }
  extractPages(t, e = null) {
    return this._transport.extractPages(t, e);
  }
  getDownloadInfo() {
    return this._transport.downloadInfoCapability.promise;
  }
  cleanup(t = !1) {
    return this._transport.startCleanup(t || this.isPureXfa);
  }
  cachedPageNumber(t) {
    return this._transport.cachedPageNumber(t);
  }
  get loadingParams() {
    return this._transport.loadingParams;
  }
  get loadingTask() {
    return this._transport.loadingTask;
  }
  getFieldObjects() {
    return this._transport.getFieldObjects();
  }
  getSignatures() {
    return this._transport.getSignatures();
  }
  getSignatureData(t) {
    return this._transport.getSignatureData(t);
  }
  hasJSActions() {
    return this._transport.hasJSActions();
  }
  getCalculationOrderIds() {
    return this._transport.getCalculationOrderIds();
  }
}
class ns {
  #t = !1;
  #e = null;
  static #s = 0;
  constructor(t, e, s, i, n = !1) {
    this._pageIndex = t, this._id = ns.#s++, this._pageInfo = e, this._transport = s, this._stats = n ? new xi() : null, this._pdfBug = n, this.commonObjs = s.commonObjs, this.objs = new si(), this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1, this.recordedBBoxes = null, this.#e = i, this.imageCoordinates = null;
  }
  clone(t) {
    const e = new ns(t, this._pageInfo, this._transport, this.#e, this._pdfBug);
    return e.clonedFromIndex = this.clonedFromIndex ?? this._pageIndex, this._transport.updatePage(e), e;
  }
  get pageNumber() {
    return this._pageIndex + 1;
  }
  set pageNumber(t) {
    this._pageIndex = t - 1, this._transport.updatePage(this);
  }
  get rotate() {
    return this._pageInfo.rotate;
  }
  get ref() {
    return this._pageInfo.ref;
  }
  get userUnit() {
    return this._pageInfo.userUnit;
  }
  get view() {
    return this._pageInfo.view;
  }
  getViewport({
    scale: t,
    rotation: e = this.rotate,
    offsetX: s = 0,
    offsetY: i = 0,
    dontFlip: n = !1
  } = {}) {
    return new Le({
      viewBox: this.view,
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: i,
      dontFlip: n
    });
  }
  getAnnotations({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getAnnotations(this._pageIndex, e);
  }
  getJSActions() {
    return this._transport.getPageJSActions(this._pageIndex);
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get isPureXfa() {
    return k(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  async getXfa() {
    return this._transport._htmlForXfa?.children[this._pageIndex] || null;
  }
  render({
    canvasContext: t,
    canvas: e = t.canvas,
    viewport: s,
    intent: i = "display",
    annotationMode: n = $t.ENABLE,
    transform: r = null,
    background: a = null,
    optionalContentConfigPromise: o = null,
    annotationCanvasMap: l = null,
    pageColors: h = null,
    printAnnotationStorage: c = null,
    isEditing: u = !1,
    recordImages: f = !1,
    recordOperations: p = !1,
    partialFrames: g = !1,
    operationsFilter: m = null
  }) {
    this._stats?.time("Overall");
    const b = this._transport.getRenderingIntent(i, n, c, u), {
      renderingIntent: y,
      cacheKey: A
    } = b;
    this.#t = !1, o ||= this._transport.getOptionalContentConfig(y);
    const w = this._intentStates.getOrInsertComputed(A, Ls);
    w.streamReaderCancelTimeout && (clearTimeout(w.streamReaderCancelTimeout), w.streamReaderCancelTimeout = null);
    const v = !!(y & gt.PRINT);
    w.displayReadyCapability || (w.displayReadyCapability = Promise.withResolvers(), w.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, this._stats?.time("Page Request"), this._pumpOperatorList(b));
    const S = !!(this._pdfBug && globalThis.StepperManager?.enabled), _ = !!e && !this.recordedBBoxes && (p || S), E = !!e && !this.imageCoordinates && f, C = (P) => {
      if (w.renderTasks.delete(T), _) {
        const {
          recordedBBoxes: N
        } = T;
        N && (T.stepper?.setOperatorBBoxes(N, T.debugMetadata), p && (this.recordedBBoxes = N));
      }
      E && !P && (this.imageCoordinates = T.imageCoordinates), v && (this.#t = !0), this.#i(), P ? (T.capability.reject(P), this._abortOperatorList({
        intentState: w,
        reason: P instanceof Error ? P : new Error(P)
      })) : T.capability.resolve(), this._stats && (this._stats.timeEnd("Rendering"), this._stats.timeEnd("Overall"), globalThis.Stats?.enabled && globalThis.Stats.add(this.pageNumber, this._stats));
    }, T = new me({
      callback: C,
      params: {
        canvas: e,
        canvasContext: t,
        viewport: s,
        transform: r,
        background: a,
        recordOperations: _,
        recordImages: E,
        partialFrames: g,
        recordForDebugger: S
      },
      objs: this.objs,
      commonObjs: this.commonObjs,
      annotationCanvasMap: l,
      operatorList: w.operatorList,
      pageIndex: this._pageIndex,
      pageProxyId: this._id,
      canvasFactory: this._transport.canvasFactory,
      filterFactory: this._transport.filterFactory,
      useRequestAnimationFrame: !v,
      pdfBug: this._pdfBug,
      pageColors: h,
      operationsFilter: m,
      rendererWorker: this._transport.rendererWorker,
      waitForGPU: () => this._transport.waitForGPU()
    });
    (w.renderTasks ||= /* @__PURE__ */ new Set()).add(T);
    const D = T.task;
    return Promise.all([w.displayReadyCapability.promise, o]).then(async ([P, N]) => {
      if (this.destroyed) {
        C();
        return;
      }
      if (this._stats?.time("Rendering"), !(N.renderingIntent & y))
        throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");
      await T.initializeGraphics({
        transparency: P,
        optionalContentConfig: N
      }), T.operatorListChanged();
    }).catch(C), D;
  }
  getOperatorList({
    intent: t = "display",
    annotationMode: e = $t.ENABLE,
    printAnnotationStorage: s = null,
    isEditing: i = !1
  } = {}) {
    function n() {
      a.operatorList.lastChunk && (a.opListReadCapability.resolve(a.operatorList), a.renderTasks.delete(o));
    }
    const r = this._transport.getRenderingIntent(t, e, s, i, !0), a = this._intentStates.getOrInsertComputed(r.cacheKey, Ls);
    let o;
    return a.opListReadCapability || (o = /* @__PURE__ */ Object.create(null), o.operatorListChanged = n, a.opListReadCapability = Promise.withResolvers(), (a.renderTasks ||= /* @__PURE__ */ new Set()).add(o), a.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, this._stats?.time("Page Request"), this._pumpOperatorList(r)), a.opListReadCapability.promise;
  }
  streamTextContent({
    includeMarkedContent: t = !1,
    disableNormalization: e = !1
  } = {}) {
    return this._transport.messageHandler.sendWithStream("GetTextContent", {
      pageId: this.#e.getPageId(this._pageIndex + 1) - 1,
      pageIndex: this._pageIndex,
      includeMarkedContent: t === !0,
      disableNormalization: e === !0
    }, {
      highWaterMark: 100,
      size: (i) => i.items.length
    });
  }
  async getTextContent(t = {}) {
    if (this._transport._htmlForXfa)
      return this.getXfa().then((n) => Me.textContent(n));
    const s = this.streamTextContent(t).getReader(), i = {
      items: [],
      styles: /* @__PURE__ */ Object.create(null),
      lang: null
    };
    for (; ; ) {
      const {
        value: n,
        done: r
      } = await s.read();
      if (r)
        break;
      i.lang ??= n.lang, Object.assign(i.styles, n.styles), i.items.push(...n.items);
    }
    return i;
  }
  getStructTree() {
    return this._transport.getStructTree(this._pageIndex);
  }
  _destroy() {
    this.destroyed = !0;
    const t = [];
    for (const e of this._intentStates.values())
      if (this._abortOperatorList({
        intentState: e,
        reason: new Error("Page was destroyed."),
        force: !0
      }), !e.opListReadCapability)
        for (const s of e.renderTasks)
          t.push(s.completed), s.cancel();
    return this.objs.clear(), this._transport.cleanupPage(this._id), this.#t = !1, Promise.all(t);
  }
  cleanup(t = !1) {
    this.#t = !0;
    const e = this.#i();
    return t && e && (this._stats &&= new xi()), e;
  }
  #i() {
    if (!this.#t || this.destroyed)
      return !1;
    for (const {
      renderTasks: t,
      operatorList: e
    } of this._intentStates.values())
      if (t.size > 0 || !e.lastChunk)
        return !1;
    return this._intentStates.clear(), this.objs.clear(), this._transport.cleanupPage(this._id), this.#t = !1, !0;
  }
  _startRenderPage(t, e) {
    const s = this._intentStates.get(e);
    s && (this._stats?.timeEnd("Page Request"), s.displayReadyCapability?.resolve(t));
  }
  _renderPageChunk(t, e) {
    for (let s = 0, i = t.length; s < i; s++)
      e.operatorList.fnArray.push(t.fnArray[s]), e.operatorList.argsArray.push(t.argsArray[s]);
    e.operatorList.lastChunk = t.lastChunk, e.operatorList.separateAnnots = t.separateAnnots;
    for (const s of e.renderTasks)
      s.operatorListChanged();
    t.lastChunk && this.#i();
  }
  _pumpOperatorList({
    renderingIntent: t,
    cacheKey: e,
    annotationStorageSerializable: s,
    modifiedIds: i
  }) {
    const {
      map: n,
      transfer: r
    } = s, o = this._transport.messageHandler.sendWithStream("GetOperatorList", {
      pageId: this.#e.getPageId(this._pageIndex + 1) - 1,
      pageIndex: this._pageIndex,
      pageProxyId: this._id,
      intent: t,
      cacheKey: e,
      annotationStorage: n,
      modifiedIds: i
    }, void 0, r).getReader(), l = this._intentStates.get(e);
    l.streamReader = o;
    const h = () => {
      o.read().then(({
        value: c,
        done: u
      }) => {
        if (u) {
          l.streamReader = null;
          return;
        }
        this._transport.destroyed || (this._renderPageChunk(c, l), h());
      }, (c) => {
        if (l.streamReader = null, !this._transport.destroyed) {
          if (l.operatorList) {
            l.operatorList.lastChunk = !0;
            for (const u of l.renderTasks)
              u.operatorListChanged();
            this.#i();
          }
          if (l.displayReadyCapability)
            l.displayReadyCapability.reject(c);
          else if (l.opListReadCapability)
            l.opListReadCapability.reject(c);
          else
            throw c;
        }
      });
    };
    h();
  }
  _abortOperatorList({
    intentState: t,
    reason: e,
    force: s = !1
  }) {
    if (t.streamReader) {
      if (t.streamReaderCancelTimeout && (clearTimeout(t.streamReaderCancelTimeout), t.streamReaderCancelTimeout = null), !s) {
        if (t.renderTasks.size > 0)
          return;
        if (e instanceof Ks) {
          let i = ba;
          e.extraDelay > 0 && e.extraDelay < 1e3 && (i += e.extraDelay), t.streamReaderCancelTimeout = setTimeout(() => {
            t.streamReaderCancelTimeout = null, this._abortOperatorList({
              intentState: t,
              reason: e,
              force: !0
            });
          }, i);
          return;
        }
      }
      if (t.streamReader.cancel(new Yt(e.message)).catch(() => {
      }), t.streamReader = null, !this._transport.destroyed) {
        for (const [i, n] of this._intentStates)
          if (n === t) {
            this._intentStates.delete(i);
            break;
          }
        this.cleanup();
      }
    }
  }
  get stats() {
    return this._stats;
  }
}
var Wt, Et, Bt, ne, as, re, ae, pt, Qe, vn, Sn, Je, be, Ze;
const ot = class ot {
  constructor({
    name: t = null,
    port: e = null,
    verbosity: s = Yi()
  } = {}) {
    kt(this, pt);
    kt(this, Wt, Promise.withResolvers());
    kt(this, Et, null);
    kt(this, Bt, null);
    kt(this, ne, null);
    if (this.name = t, this.destroyed = !1, this.verbosity = s, e) {
      if (K(ot, ae).has(e))
        throw new Error("Cannot use more than one PDFWorker per port.");
      K(ot, ae).set(e, this), Ot(this, pt, vn).call(this, e);
    } else
      Ot(this, pt, Sn).call(this);
  }
  get promise() {
    return K(this, Wt).promise;
  }
  get port() {
    return K(this, Bt);
  }
  get messageHandler() {
    return K(this, Et);
  }
  destroy() {
    this.destroyed = !0, K(this, ne)?.terminate(), dt(this, ne, null), K(ot, ae).delete(K(this, Bt)), dt(this, Bt, null), K(this, Et)?.destroy(), dt(this, Et, null);
  }
  static create(t) {
    const e = K(this, ae).get(t?.port);
    if (e) {
      if (e._pendingDestroy)
        throw new Error("PDFWorker.create - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
      return e;
    }
    return new ot(t);
  }
  static get workerSrc() {
    if (Ut.workerSrc)
      return Ut.workerSrc;
    throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
  }
  static get _setupFakeWorkerGlobal() {
    return k(this, "_setupFakeWorkerGlobal", (async () => K(this, be, Ze) ? K(this, be, Ze) : (await import(
      /*webpackIgnore: true*/
      /*@vite-ignore*/
      this.workerSrc
    )).WorkerMessageHandler)());
  }
};
Wt = new WeakMap(), Et = new WeakMap(), Bt = new WeakMap(), ne = new WeakMap(), as = new WeakMap(), re = new WeakMap(), ae = new WeakMap(), pt = new WeakSet(), Qe = function() {
  K(this, Wt).resolve(), K(this, Et).send("configure", {
    verbosity: this.verbosity
  });
}, vn = function(t) {
  dt(this, Bt, t), dt(this, Et, new Vt("main", "worker", t)), K(this, Et).on("ready", () => {
  }), Ot(this, pt, Qe).call(this);
}, Sn = function() {
  if (K(ot, re) || K(ot, be, Ze)) {
    Ot(this, pt, Je).call(this);
    return;
  }
  const {
    workerSrc: t
  } = ot;
  try {
    const e = new Worker(rn(t), {
      type: "module"
    }), s = new Vt("main", "worker", e), i = () => {
      n.abort(), s.destroy(), e.terminate(), this.destroyed ? K(this, Wt).reject(new Error("Worker was destroyed")) : Ot(this, pt, Je).call(this);
    }, n = new AbortController();
    e.addEventListener("error", () => {
      K(this, ne) || i();
    }, {
      signal: n.signal
    }), s.on("ready", (r) => {
      if (n.abort(), this.destroyed || !(r instanceof Uint8Array)) {
        i();
        return;
      }
      dt(this, Et, s), dt(this, Bt, e), dt(this, ne, e), Ot(this, pt, Qe).call(this);
    });
  } catch {
    hs("The worker has been disabled."), Ot(this, pt, Je).call(this);
  }
}, Je = function() {
  K(ot, re) || (R("Setting up fake worker."), dt(ot, re, !0)), ot._setupFakeWorkerGlobal.then((t) => {
    if (this.destroyed) {
      K(this, Wt).reject(new Error("Worker was destroyed"));
      return;
    }
    const e = new lr();
    dt(this, Bt, e);
    const s = `fake${yi(ot, as)._++}`, i = new Vt(s + "_worker", s, e);
    t.setup(i, e), dt(this, Et, new Vt(s, s + "_worker", e)), Ot(this, pt, Qe).call(this);
  }).catch((t) => {
    K(this, Wt).reject(new Error(`Setting up fake worker failed: "${t.message}".`));
  });
}, be = new WeakSet(), Ze = function() {
  try {
    return globalThis.pdfjsWorker?.WorkerMessageHandler || null;
  } catch {
    return null;
  }
}, kt(ot, be), kt(ot, as, 0), kt(ot, re, !1), kt(ot, ae, /* @__PURE__ */ new WeakMap()), bt && (dt(ot, re, !0), Ut.workerSrc ||= "./pdf.worker.mjs");
let Fe = ot;
class wa {
  downloadInfoCapability = Promise.withResolvers();
  #t = null;
  #e = !1;
  #s = /* @__PURE__ */ new Map();
  #i = null;
  #n = /* @__PURE__ */ new Map();
  #r = /* @__PURE__ */ new Map();
  #a = /* @__PURE__ */ new Map();
  #o = null;
  #l = null;
  constructor(t, e, s, i, n, r) {
    this.messageHandler = t, this.loadingTask = e, this.#i = s, this.commonObjs = new si(), this.fontLoader = new Br({
      ownerDocument: i.ownerDocument,
      styleElement: i.styleElement
    }), this.rendererWorker = i.rendererWorker, this.loadingParams = i.loadingParams, this._params = i, this.canvasFactory = n.canvasFactory, this.filterFactory = n.filterFactory, this.binaryDataFactory = n.binaryDataFactory, this.pagesMapper = r, this.destroyed = !1, this.destroyCapability = null, this.setupMessageHandler();
  }
  updatePage(t) {
    this.#n.set(t._id, t), this.#r.set(t._pageIndex, Promise.resolve(t));
  }
  #h(t, e = null) {
    return this.#s.getOrInsertComputed(t, () => this.messageHandler.sendWithPromise(t, e));
  }
  #u({
    loaded: t,
    total: e
  }) {
    this.loadingTask.onProgress?.({
      loaded: t,
      total: e,
      percent: e ? Y(Math.round(t / e * 100), 0, 100) : NaN
    });
  }
  get annotationStorage() {
    return k(this, "annotationStorage", new ti());
  }
  getRenderingIntent(t, e = $t.ENABLE, s = null, i = !1, n = !1) {
    let r = gt.DISPLAY, a = Ie;
    switch (t) {
      case "any":
        r = gt.ANY;
        break;
      case "display":
        break;
      case "print":
        r = gt.PRINT;
        break;
      default:
        R(`getRenderingIntent - invalid intent: ${t}`);
    }
    const o = r & gt.PRINT && s instanceof nn ? s : this.annotationStorage;
    switch (e) {
      case $t.DISABLE:
        r += gt.ANNOTATIONS_DISABLE;
        break;
      case $t.ENABLE:
        break;
      case $t.ENABLE_FORMS:
        r += gt.ANNOTATIONS_FORMS;
        break;
      case $t.ENABLE_STORAGE:
        r += gt.ANNOTATIONS_STORAGE, a = o.serializable;
        break;
      default:
        R(`getRenderingIntent - invalid annotationMode: ${e}`);
    }
    i && (r += gt.IS_EDITING), n && (r += gt.OPLIST);
    const {
      ids: l,
      hash: h
    } = o.modifiedIds, c = [r, a.hash, h];
    return {
      renderingIntent: r,
      cacheKey: c.join("_"),
      annotationStorageSerializable: a,
      modifiedIds: l
    };
  }
  destroy() {
    if (this.destroyCapability)
      return this.destroyCapability.promise;
    this.destroyed = !0, this.destroyCapability = Promise.withResolvers(), this.#o?.reject(new Error("Worker was destroyed during onPassword callback"));
    const t = [];
    for (const s of this.#n.values())
      t.push(s._destroy());
    this.#n.clear(), this.#r.clear(), this.#a.clear(), Object.hasOwn(this, "annotationStorage") && this.annotationStorage.resetModified();
    const e = this.messageHandler.sendWithPromise("Terminate", null);
    return t.push(e), Promise.all(t).then(() => {
      this.commonObjs.clear(), this.fontLoader.clear(), this.#s.clear(), this.filterFactory.destroy(), mt.cleanup(), this.#i?.cancelAllRequests(new Yt("Worker was terminated.")), this.messageHandler?.destroy(), this.messageHandler = null, this.rendererWorker = null, this.destroyCapability.resolve();
    }, this.destroyCapability.reject), this.destroyCapability.promise;
  }
  setupMessageHandler() {
    const {
      messageHandler: t,
      loadingTask: e
    } = this;
    t.on("GetReader", (i, n) => {
      J(this.#i, "GetReader - no `BasePDFStream` instance available."), this.#t = this.#i.getFullReader(), this.#t.onProgress = (r) => this.#u(r), n.onPull = () => {
        this.#t.read().then(function({
          value: r,
          done: a
        }) {
          if (a) {
            n.close();
            return;
          }
          J(r instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), n.enqueue(new Uint8Array(r), 1, [r]);
        }).catch((r) => {
          n.error(r);
        });
      }, n.onCancel = (r) => {
        this.#t.cancel(r), n.ready.catch((a) => {
          if (!this.destroyed)
            throw a;
        });
      };
    }), t.on("ReaderHeadersReady", async (i) => {
      await this.#t.headersReady;
      const {
        isStreamingSupported: n,
        isRangeSupported: r,
        contentLength: a
      } = this.#t;
      return n && r && (this.#t.onProgress = null), {
        isStreamingSupported: n,
        isRangeSupported: r,
        contentLength: a
      };
    }), t.on("GetRangeReader", (i, n) => {
      J(this.#i, "GetRangeReader - no `BasePDFStream` instance available.");
      const r = this.#i.getRangeReader(i.begin, i.end);
      if (!r) {
        n.close();
        return;
      }
      n.onPull = () => {
        r.read().then(function({
          value: a,
          done: o
        }) {
          if (o) {
            n.close();
            return;
          }
          J(a instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), n.enqueue(new Uint8Array(a), 1, [a]);
        }).catch((a) => {
          n.error(a);
        });
      }, n.onCancel = (a) => {
        r.cancel(a), n.ready.catch((o) => {
          if (!this.destroyed)
            throw o;
        });
      };
    }), t.on("GetDoc", ({
      pdfInfo: i
    }) => {
      this.pagesMapper.pagesNumber = i.numPages, this._numPages = i.numPages, this._htmlForXfa = i.htmlForXfa, delete i.htmlForXfa, e._capability.resolve(new Aa(i, this));
    }), t.on("DocException", (i) => {
      e._capability.reject(ut(i));
    }), t.on("PasswordRequest", (i) => {
      this.#o = Promise.withResolvers();
      try {
        if (!e.onPassword)
          throw ut(i);
        const n = (r) => {
          r instanceof Error ? this.#o.reject(r) : this.#o.resolve({
            password: r
          });
        };
        e.onPassword(n, i.code);
      } catch (n) {
        this.#o.reject(n);
      }
      return this.#o.promise;
    }), t.on("DataLoaded", (i) => {
      this.#u({
        loaded: i.length,
        total: i.length
      }), this.downloadInfoCapability.resolve(i);
    }), t.on("StartRenderPage", (i) => {
      if (this.destroyed)
        return;
      this.#n.get(i.pageProxyId)._startRenderPage(i.transparency, i.cacheKey);
    });
    const s = new da({
      messageHandler: t,
      commonObjs: this.commonObjs,
      fontLoader: this.fontLoader,
      pageCache: this.#n,
      pdfBug: this._params.pdfBug
    });
    this.rendererWorker?.promise.then(() => {
      this.rendererWorker?.messageHandler?.on("FontFallback", (i) => this.destroyed ? null : t.sendWithPromise("FontFallback", i));
    }, () => {
    }), t.on("commonobj", ([i, n, r]) => {
      if (this.destroyed)
        return null;
      const {
        rendererWorker: a
      } = this;
      if (n === "CopyLocalImage") {
        if (this.commonObjs.has(i))
          return null;
        const o = s.resolveCommonObject(i, n, r);
        return o && a?.sendCommonObj(i, "Image", this.commonObjs.get(i)), o;
      }
      return a?.sendCommonObj(i, n, r), this.commonObjs.has(i) || (s.resolveCommonObject(i, n, r), n === "Pattern" && this.commonObjs.get(i)[0] === "Mesh" && (this.#e = !0)), null;
    }), t.on("obj", ([i, n, r, a]) => {
      this.destroyed || (r === "Pattern" && a[0] === "Mesh" && (this.#e = !0), s.resolveObject(i, n, r, a) && this.rendererWorker?.sendObj(i, n, r, a));
    }), t.on("DocProgress", (i) => {
      this.destroyed || this.#u(i);
    }), t.on("FetchBinaryData", async (i) => {
      if (this.destroyed)
        throw new Error("Worker was destroyed.");
      if (!this.binaryDataFactory)
        throw new Error("`BinaryDataFactory` not initialized, see the `useWorkerFetch` parameter.");
      return this.binaryDataFactory.fetch(i);
    });
  }
  getData() {
    return this.messageHandler.sendWithPromise("GetData", null);
  }
  saveDocument(t = null) {
    this.annotationStorage.size <= 0 && R("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
    const {
      map: e,
      transfer: s
    } = this.annotationStorage.serializable;
    return this.messageHandler.sendWithPromise("SaveDocument", {
      isPureXfa: !!this._htmlForXfa,
      numPages: this._numPages,
      annotationStorage: e,
      supportsPrintToPDF: this.#l !== null,
      filename: this.#t?.filename ?? null
    }, s).finally(() => {
      this.#l = null, this.annotationStorage.resetModified();
    });
  }
  extractPages(t, e = null) {
    const s = {
      pageInfos: t
    };
    let i;
    const n = globalThis.ImageBitmap;
    if (typeof n == "function") {
      const r = Array.isArray(t) ? t : [t];
      for (const a of r)
        a?.image instanceof n && (i ||= []).push(a.image);
    }
    if (this.annotationStorage.size > 0) {
      const r = this.annotationStorage.serializable;
      let {
        map: a
      } = r;
      r.transfer?.length && (i ? i.push(...r.transfer) : i = r.transfer);
      const o = this.pagesMapper.getMapping();
      if (o) {
        const l = /* @__PURE__ */ new Map();
        for (const [h, c] of a) {
          if (c?.pageIndex !== void 0 && c.pageIndex >= 0 && c.pageIndex < o.length) {
            const u = e?.[c.pageIndex] ?? 0, f = o[c.pageIndex] - 1;
            if (f !== c.pageIndex || u !== 0) {
              l.set(h, {
                ...c,
                pageIndex: f,
                copyLevel: u
              });
              continue;
            }
          }
          l.set(h, c);
        }
        a = l;
      }
      s.annotationStorage = a;
    }
    return this.messageHandler.sendWithPromise("ExtractPages", s, i).finally(() => {
      this.annotationStorage.resetModified();
    });
  }
  waitForGPU() {
    return this._params.enableWebGPU && this.#e && !on() ? an() : null;
  }
  getPage(t) {
    if (!Number.isInteger(t) || t <= 0 || t > this.pagesMapper.pagesNumber)
      return Promise.reject(new Error("Invalid page request."));
    const e = t - 1, s = this.pagesMapper.getPageId(t) - 1, i = this.#r.get(e);
    if (i)
      return i;
    const n = this.messageHandler.sendWithPromise("GetPage", {
      pageIndex: s
    }).then((r) => {
      if (this.destroyed)
        throw new Error("Transport destroyed");
      r.refStr && this.#a.set(r.refStr, s);
      const a = new ns(e, r, this, this.pagesMapper, this._params.pdfBug);
      return this.#n.set(a._id, a), a;
    });
    return this.#r.set(e, n), n;
  }
  async getPageIndex(t) {
    if (!js(t))
      throw new Error("Invalid pageIndex request.");
    const e = await this.messageHandler.sendWithPromise("GetPageIndex", {
      num: t.num,
      gen: t.gen
    }), s = this.pagesMapper.getPageNumber(e + 1);
    if (s === 0)
      throw new Error("GetPageIndex: page has been removed.");
    return s - 1;
  }
  getAnnotations(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotations", {
      pageIndex: this.pagesMapper.getPageId(t + 1) - 1,
      intent: e
    });
  }
  getFieldObjects() {
    return this.#h("GetFieldObjects");
  }
  getSignatures() {
    return this.#h("GetSignatures");
  }
  getSignatureData(t) {
    return this.messageHandler.sendWithPromise("GetSignatureData", t);
  }
  hasJSActions() {
    return this.#h("HasJSActions");
  }
  getCalculationOrderIds() {
    return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
  }
  getDestinations() {
    return this.messageHandler.sendWithPromise("GetDestinations", null);
  }
  getDestination(t) {
    return typeof t != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
      id: t
    });
  }
  getPageLabels() {
    return this.messageHandler.sendWithPromise("GetPageLabels", null);
  }
  getPageLayout() {
    return this.messageHandler.sendWithPromise("GetPageLayout", null);
  }
  getPageMode() {
    return this.messageHandler.sendWithPromise("GetPageMode", null);
  }
  getViewerPreferences() {
    return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
  }
  getOpenAction() {
    return this.messageHandler.sendWithPromise("GetOpenAction", null);
  }
  getAttachments() {
    return this.messageHandler.sendWithPromise("GetAttachments", null);
  }
  getAttachmentContent(t) {
    return this.messageHandler.sendWithPromise("GetAttachmentContent", t);
  }
  getAnnotationsByType(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotationsByType", {
      types: t,
      pageIndexesToSkip: e
    });
  }
  getDocJSActions() {
    return this.#h("GetDocJSActions");
  }
  getPageJSActions(t) {
    return this.messageHandler.sendWithPromise("GetPageJSActions", {
      pageIndex: this.pagesMapper.getPageId(t + 1) - 1
    });
  }
  getStructTree(t) {
    return this.messageHandler.sendWithPromise("GetStructTree", {
      pageIndex: this.pagesMapper.getPageId(t + 1) - 1
    });
  }
  getOutline() {
    return this.messageHandler.sendWithPromise("GetOutline", null);
  }
  getOptionalContentConfig(t) {
    const e = "GetOptionalContentConfig";
    return this.#s.getOrInsertComputed(e, () => this.messageHandler.sendWithPromise(e, null).catch((s) => (R(`${e}: "${s}".`), null))).then((s) => new ii(s, t));
  }
  getPermissions() {
    return this.messageHandler.sendWithPromise("GetPermissions", null);
  }
  getMetadata() {
    const t = "GetMetadata";
    return this.#s.getOrInsertComputed(t, () => this.messageHandler.sendWithPromise(t, null).then((e) => ({
      info: e[0],
      metadata: e[1] ? new sa(e[1]) : null,
      contentDispositionFilename: this.#t?.filename ?? null,
      contentLength: this.#t?.contentLength ?? null,
      hasStructTree: e[2]
    })));
  }
  getMarkInfo() {
    return this.messageHandler.sendWithPromise("GetMarkInfo", null);
  }
  async startCleanup(t = !1) {
    if (!this.destroyed) {
      await this.messageHandler.sendWithPromise("Cleanup", null);
      for (const e of this.#n.values())
        if (!e.cleanup())
          throw new Error(`startCleanup: Page ${e.pageNumber} is currently rendering.`);
      this.commonObjs.clear(), t || this.fontLoader.clear(), this.rendererWorker?.cleanup(t), this.#s.clear(), this.filterFactory.destroy(!0), mt.cleanup();
    }
  }
  cleanupPage(t) {
    this.destroyed || this.messageHandler.send("CleanupPage", {
      pageProxyId: t
    }), this.rendererWorker?.cleanupPage(t);
  }
  cachedPageNumber(t) {
    if (!js(t))
      return null;
    const e = t.gen === 0 ? `${t.num}R` : `${t.num}R${t.gen}`, s = this.#a.get(e);
    if (s >= 0) {
      const i = this.pagesMapper.getPageNumber(s + 1);
      if (i !== 0)
        return i;
    }
    return null;
  }
}
class va {
  _internalRenderTask = null;
  onContinue = null;
  onError = null;
  onFrame = null;
  constructor(t) {
    this._internalRenderTask = t;
  }
  get promise() {
    return this._internalRenderTask.capability.promise;
  }
  cancel(t = 0) {
    this._internalRenderTask.cancel(null, t);
  }
  get separateAnnots() {
    const {
      separateAnnots: t
    } = this._internalRenderTask.operatorList;
    if (!t)
      return !1;
    const {
      annotationCanvasMap: e
    } = this._internalRenderTask;
    return t.form || t.canvas && e?.size > 0;
  }
  get imageCoordinates() {
    return this._internalRenderTask.imageCoordinates || null;
  }
  get isWorkerRendering() {
    return this._internalRenderTask.isWorkerRendering;
  }
}
class me {
  #t = null;
  #e = null;
  #s = null;
  #i = null;
  #n = null;
  static #r = /* @__PURE__ */ new WeakSet();
  constructor({
    callback: t,
    params: e,
    objs: s,
    commonObjs: i,
    annotationCanvasMap: n,
    operatorList: r,
    pageIndex: a,
    pageProxyId: o,
    canvasFactory: l,
    filterFactory: h,
    useRequestAnimationFrame: c = !1,
    pdfBug: u = !1,
    pageColors: f = null,
    operationsFilter: p = null,
    rendererWorker: g = null,
    waitForGPU: m = null
  }) {
    this.callback = t, this.params = e, this.objs = s, this.commonObjs = i, this.annotationCanvasMap = n, this.operatorListIdx = null, this.operatorList = r, this._pageIndex = a, this.canvasFactory = l, this.filterFactory = h, this._pdfBug = u, this.pageColors = f, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = c === !0 && typeof window < "u", this.cancelled = !1, this.capability = Promise.withResolvers(), this.task = new va(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = e.canvas, this._canvasContext = e.canvas ? null : e.canvasContext, this._operationsFilter = p, this.#n = m, this.#i = g?.createRenderTask({
      pageProxyId: o,
      operatorList: r,
      params: e,
      pageColors: f,
      canvasFactory: l,
      annotationCanvasMap: n,
      onFrame: () => this.task.onFrame?.(),
      onError: (b) => this.cancel(b)
    }) ?? null;
  }
  get completed() {
    return this.capability.promise.catch(() => {
    });
  }
  get isWorkerRendering() {
    return !!this.#i;
  }
  get imageCoordinates() {
    return this.#i ? this.#i.imageCoordinates : this.#e?.take();
  }
  get recordedBBoxes() {
    return this.#i ? this.#i.recordedBBoxes : this.#t?.take();
  }
  get debugMetadata() {
    return this.#t?.takeDebugMetadata() ?? null;
  }
  async initializeGraphics({
    transparency: t = !1,
    optionalContentConfig: e
  }) {
    if (!this.cancelled) {
      if (this._canvas) {
        if (me.#r.has(this._canvas))
          throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
        me.#r.add(this._canvas);
      }
      if (this._pdfBug && globalThis.StepperManager?.enabled && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint()), this.#i) {
        const s = await this.#i.initialize(t, e);
        if (this.cancelled)
          return;
        s || (this.#i = null);
      }
      if (!this.#i) {
        const {
          viewport: s,
          transform: i,
          background: n,
          recordOperations: r,
          recordImages: a,
          recordForDebugger: o
        } = this.params, l = this._canvasContext || this.canvasFactory.getNoAlphaContext(this._canvas), {
          dependencyTracker: h,
          imagesTracker: c
        } = wr(this._canvas, this.operatorList.fnArray.length, {
          recordOperations: r,
          recordImages: a,
          recordDebugMetadata: o
        });
        this.#t = h, this.#e = c, this.gfx = new Xt(l, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
          optionalContentConfig: e
        }, this.annotationCanvasMap, this.pageColors, h, c), this.gfx.beginDrawing({
          transform: i,
          viewport: s,
          transparency: t,
          background: n
        });
      }
      this.operatorListIdx = 0, this.graphicsReady = !0, this.graphicsReadyCallback?.();
    }
  }
  cancel(t = null, e = 0) {
    this.running = !1, this.cancelled = !0, this.#i?.cancel(), this.gfx?.endDrawing(), this.#s && (window.cancelAnimationFrame(this.#s), this.#s = null), me.#r.delete(this._canvas), t ||= new Ks(`Rendering cancelled, page ${this._pageIndex + 1}`, e), this.callback(t), this.task.onError?.(t);
  }
  operatorListChanged() {
    if (!this.graphicsReady) {
      this.graphicsReadyCallback ||= this._continueBound;
      return;
    }
    this.#t?.growOperationsCount(this.operatorList.fnArray.length), this.stepper?.updateOperatorList(this.operatorList), !this.running && this._continue();
  }
  _continue() {
    this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
  }
  _scheduleNext() {
    this._useRequestAnimationFrame ? this.#s = window.requestAnimationFrame(() => {
      this.#s = null, this._nextBound().catch(this._cancelBound);
    }) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
  }
  async _next() {
    if (this.cancelled)
      return;
    if (!this.#i) {
      const s = this.#n?.();
      if (s && (await s, this.cancelled))
        return;
    }
    const {
      operatorList: t
    } = this, {
      lastChunk: e
    } = t;
    if (this.#i) {
      if (this.operatorListIdx = await this.#i.executeOperatorList(t, this.operatorListIdx, this._operationsFilter), this.cancelled)
        return;
      if (this.operatorListIdx !== t.argsArray.length || e !== t.lastChunk) {
        this._continue();
        return;
      }
    } else
      this.operatorListIdx = this.gfx.executeOperatorList(t, this.operatorListIdx, this._continueBound, null, this.stepper, this._operationsFilter);
    this.operatorListIdx === t.argsArray.length && (this.running = !1, e && (this.gfx?.endDrawing(), me.#r.delete(this._canvas), this.callback()));
  }
}
const Sa = "6.5.438", _a = "0a4153349";
class _t {
  #t = null;
  #e = null;
  #s;
  #i = null;
  #n = !1;
  #r = !1;
  #a = null;
  #o;
  #l = null;
  #h = null;
  static #u = null;
  static get _keyboardManager() {
    return k(this, "_keyboardManager", new yt([[["Escape"], _t.prototype._hideDropdownFromKeyboard], [["Space"], _t.prototype._colorSelectFromKeyboard], [["ArrowDown", "ArrowRight"], _t.prototype._moveToNext], [["ArrowUp", "ArrowLeft"], _t.prototype._moveToPrevious], [["Home"], _t.prototype._moveToBeginning], [["End"], _t.prototype._moveToEnd]]));
  }
  constructor({
    editor: t = null,
    uiManager: e = null
  }) {
    t ? (this.#r = !1, this.#a = t) : this.#r = !0, this.#h = t?._uiManager || e, this.#o = this.#h._eventBus, this.#s = t?.color?.toUpperCase() || this.#h?.highlightColors.values().next().value || "#FFFF98", _t.#u ||= Object.freeze({
      blue: "pdfjs-editor-colorpicker-blue",
      green: "pdfjs-editor-colorpicker-green",
      pink: "pdfjs-editor-colorpicker-pink",
      red: "pdfjs-editor-colorpicker-red",
      yellow: "pdfjs-editor-colorpicker-yellow"
    });
  }
  renderButton() {
    const t = this.#t = document.createElement("button");
    t.className = "colorPicker", t.tabIndex = "0", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-button"), t.ariaHasPopup = "true", this.#a && (t.ariaControls = `${this.#a.id}_colorpicker_dropdown`);
    const e = this.#h._signal;
    t.addEventListener("click", this.#m.bind(this), {
      signal: e
    }), t.addEventListener("keydown", this.#p.bind(this), {
      signal: e
    });
    const s = this.#e = document.createElement("span");
    return s.className = "swatch", s.ariaHidden = "true", s.style.backgroundColor = this.#s, t.append(s), t;
  }
  renderMainDropdown() {
    const t = this.#i = this.#c();
    return t.ariaOrientation = "horizontal", t.ariaLabelledBy = "highlightColorPickerLabel", t;
  }
  #c() {
    const t = document.createElement("div"), e = this.#h._signal;
    t.addEventListener("contextmenu", xt, {
      signal: e
    }), t.className = "dropdown", t.role = "listbox", t.ariaMultiSelectable = "false", t.ariaOrientation = "vertical", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-dropdown"), this.#a && (t.id = `${this.#a.id}_colorpicker_dropdown`);
    for (const [s, i] of this.#h.highlightColors) {
      const n = document.createElement("button");
      n.tabIndex = "0", n.role = "option", n.setAttribute("data-color", i), n.title = s, n.setAttribute("data-l10n-id", _t.#u[s]);
      const r = document.createElement("span");
      n.append(r), r.className = "swatch", r.style.backgroundColor = i, n.ariaSelected = i === this.#s, n.addEventListener("click", this.#f.bind(this, i), {
        signal: e
      }), t.append(n);
    }
    return t.addEventListener("keydown", this.#p.bind(this), {
      signal: e
    }), t;
  }
  #f(t, e) {
    e.stopPropagation(), this.#o.dispatch("switchannotationeditorparams", {
      source: this,
      type: U.HIGHLIGHT_COLOR,
      value: t
    }), this.update(t);
  }
  _colorSelectFromKeyboard(t) {
    if (t.target === this.#t) {
      this.#m(t);
      return;
    }
    const e = t.target.getAttribute("data-color");
    e && this.#f(e, t);
  }
  _moveToNext(t) {
    if (!this.#g) {
      this.#m(t);
      return;
    }
    if (t.target === this.#t) {
      this.#i.firstElementChild?.focus();
      return;
    }
    t.target.nextSibling?.focus();
  }
  _moveToPrevious(t) {
    if (t.target === this.#i?.firstElementChild || t.target === this.#t) {
      this.#g && this._hideDropdownFromKeyboard();
      return;
    }
    this.#g || this.#m(t), t.target.previousSibling?.focus();
  }
  _moveToBeginning(t) {
    if (!this.#g) {
      this.#m(t);
      return;
    }
    this.#i.firstElementChild?.focus();
  }
  _moveToEnd(t) {
    if (!this.#g) {
      this.#m(t);
      return;
    }
    this.#i.lastElementChild?.focus();
  }
  #p(t) {
    _t._keyboardManager.exec(this, t);
  }
  #m(t) {
    if (this.#g) {
      this.hideDropdown();
      return;
    }
    if (this.#n = t.detail === 0, this.#l || (this.#l = new AbortController(), window.addEventListener("pointerdown", this.#d.bind(this), {
      signal: this.#h.combinedSignal(this.#l)
    })), this.#t.ariaExpanded = "true", this.#i) {
      this.#i.classList.remove("hidden");
      return;
    }
    const e = this.#i = this.#c();
    this.#t.append(e);
  }
  #d(t) {
    this.#i?.contains(t.target) || this.hideDropdown();
  }
  hideDropdown() {
    this.#i?.classList.add("hidden"), this.#t.ariaExpanded = "false", this.#l?.abort(), this.#l = null;
  }
  get #g() {
    return this.#i && !this.#i.classList.contains("hidden");
  }
  _hideDropdownFromKeyboard() {
    if (!this.#r) {
      if (!this.#g) {
        this.#a?.unselect();
        return;
      }
      this.hideDropdown(), this.#t.focus({
        preventScroll: !0,
        focusVisible: this.#n
      });
    }
  }
  update(t) {
    if (this.#e && (this.#e.style.backgroundColor = t), !this.#i)
      return;
    const e = this.#h.highlightColors.values();
    for (const s of this.#i.children)
      s.ariaSelected = e.next().value === t.toUpperCase();
  }
  destroy() {
    this.#t?.remove(), this.#t = null, this.#e = null, this.#i?.remove(), this.#i = null;
  }
}
class Oe {
  #t = null;
  #e = !1;
  #s = null;
  #i = null;
  static #n = null;
  constructor(t) {
    this.#s = t, this.#i = t._uiManager, Oe.#n ||= Object.freeze({
      freetext: "pdfjs-editor-color-picker-free-text-input",
      ink: "pdfjs-editor-color-picker-ink-input"
    });
  }
  renderButton() {
    if (this.#t)
      return this.#t;
    const {
      editorType: t,
      colorType: e,
      colorAndOpacityType: s,
      opacityType: i,
      color: n,
      opacity: r
    } = this.#s, a = this.#e = W.isAlphaColorInputSupported && i !== void 0, o = this.#t = document.createElement("input");
    if (o.type = "color", a) {
      o.setAttribute("alpha", "");
      const l = x.hexNums[Math.round((r ?? 1) * 255)];
      o.value = (n || "#000000") + l;
    } else
      o.value = n || "#000000";
    return o.className = "basicColorPicker", o.tabIndex = 0, o.setAttribute("data-l10n-id", Oe.#n[t]), o.addEventListener("input", () => {
      if (a) {
        const l = ve(o.value);
        if (!l)
          return;
        const [h, c, u, f] = l, p = x.makeHexColor(h, c, u);
        s !== void 0 ? this.#i.updateParams(s, {
          color: p,
          opacity: f
        }) : (this.#i.updateParams(e, p), this.#i.updateParams(i, f));
      } else
        this.#i.updateParams(e, o.value);
    }, {
      signal: this.#i._signal
    }), o;
  }
  update(t) {
    if (this.#t)
      if (this.#e) {
        const e = x.hexNums[Math.round(this.#s.opacity * 255)];
        this.#t.value = t + e;
      } else
        this.#t.value = t;
  }
  updateOpacity(t) {
    if (!this.#t || !this.#e)
      return;
    const e = x.hexNums[Math.round(t * 255)];
    this.#t.value = this.#s.color + e;
  }
  destroy() {
    this.#t?.remove(), this.#t = null;
  }
  hideDropdown() {
  }
}
function Wi(d) {
  return Math.floor(Y(d, 0, 1) * 255).toString(16).padStart(2, "0");
}
function Ce(d) {
  return Y(d, 0, 1) * 255;
}
class Vi {
  static CMYK_G([t, e, s, i]) {
    return ["G", 1 - Math.min(1, 0.3 * t + 0.59 * s + 0.11 * e + i)];
  }
  static G_CMYK([t]) {
    return ["CMYK", 0, 0, 0, 1 - t];
  }
  static G_RGB([t]) {
    return ["RGB", t, t, t];
  }
  static G_rgb([t]) {
    return t = Ce(t), [t, t, t];
  }
  static G_HTML([t]) {
    const e = Wi(t);
    return `#${e}${e}${e}`;
  }
  static RGB_G([t, e, s]) {
    return ["G", 0.3 * t + 0.59 * e + 0.11 * s];
  }
  static RGB_rgb(t) {
    return t.map(Ce);
  }
  static RGB_HTML(t) {
    return `#${t.map(Wi).join("")}`;
  }
  static T_HTML() {
    return "#00000000";
  }
  static T_rgb() {
    return [null];
  }
  static CMYK_RGB([t, e, s, i]) {
    return ["RGB", 1 - Math.min(1, t + i), 1 - Math.min(1, s + i), 1 - Math.min(1, e + i)];
  }
  static CMYK_rgb([t, e, s, i]) {
    return [Ce(1 - Math.min(1, t + i)), Ce(1 - Math.min(1, s + i)), Ce(1 - Math.min(1, e + i))];
  }
  static CMYK_HTML(t) {
    const e = this.CMYK_RGB(t).slice(1);
    return this.RGB_HTML(e);
  }
  static RGB_CMYK([t, e, s]) {
    const i = 1 - t, n = 1 - e, r = 1 - s, a = Math.min(i, n, r);
    return ["CMYK", i, n, r, a];
  }
}
class Ca {
  create(t, e, s = !1) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid SVG dimensions");
    const i = this._createSVG("svg:svg");
    return i.setAttribute("version", "1.1"), s || (i.setAttribute("width", `${t}px`), i.setAttribute("height", `${e}px`)), i.setAttribute("preserveAspectRatio", "none"), i.setAttribute("viewBox", `0 0 ${t} ${e}`), i;
  }
  createElement(t) {
    if (typeof t != "string")
      throw new Error("Invalid SVG element type");
    return this._createSVG(t);
  }
  _createSVG(t) {
    j("Abstract method `_createSVG` called.");
  }
}
class ri extends Ca {
  _createSVG(t) {
    return document.createElementNS(ct, t);
  }
}
const Ea = 9, le = /* @__PURE__ */ new WeakSet(), xa = (/* @__PURE__ */ new Date()).getTimezoneOffset() * 60 * 1e3;
class Is {
  static create(t) {
    switch (t.data.annotationType) {
      case q.LINK:
        return new ai(t);
      case q.TEXT:
        return new ka(t);
      case q.WIDGET:
        switch (t.data.fieldType) {
          case "Tx":
            return new Pa(t);
          case "Btn":
            return t.data.radioButton ? new Da(t) : t.data.checkBox ? new Ia(t) : new Fa(t);
          case "Ch":
            return new Oa(t);
          case "Sig":
            return new Ma(t);
        }
        return new ce(t);
      case q.POPUP:
        return new Ws(t);
      case q.FREETEXT:
        return new _n(t);
      case q.LINE:
        return new La(t);
      case q.SQUARE:
        return new Na(t);
      case q.CIRCLE:
        return new Ba(t);
      case q.POLYLINE:
        return new Cn(t);
      case q.CARET:
        return new Ua(t);
      case q.INK:
        return new oi(t);
      case q.POLYGON:
        return new Ha(t);
      case q.HIGHLIGHT:
        return new En(t);
      case q.UNDERLINE:
        return new Ga(t);
      case q.SQUIGGLY:
        return new ja(t);
      case q.STRIKEOUT:
        return new za(t);
      case q.STAMP:
        return new xn(t);
      case q.FILEATTACHMENT:
        return new $a(t);
      case q.RICHMEDIA:
      case q.SCREEN:
      case q.SOUND:
        return new Tn(t);
      default:
        return new V(t);
    }
  }
}
class V {
  #t = null;
  #e = !1;
  #s = null;
  constructor(t, {
    isRenderable: e = !1,
    ignoreBorder: s = !1,
    createQuadrilaterals: i = !1
  } = {}) {
    this.isRenderable = e, this.data = t.data, this.layer = t.layer, this.linkService = t.linkService, this.downloadManager = t.downloadManager, this.imageResourcesPath = t.imageResourcesPath, this.renderForms = t.renderForms, this.annotationStorage = t.annotationStorage, this.enableComment = t.enableComment, this.enableAnnotationEditing = t.enableAnnotationEditing !== !1, this.enableScripting = t.enableScripting, this.hasJSActions = t.hasJSActions, this._fieldObjects = t.fieldObjects, this.parent = t.parent, this.hasOwnCommentButton = !1, e && (this.contentElement = this.container = this._createContainer(s)), i && this._createQuadrilaterals();
  }
  static _hasPopupData({
    contentsObj: t,
    richText: e
  }) {
    return !!(t?.str || e?.str);
  }
  static get _svgFactory() {
    return k(this, "_svgFactory", new ri());
  }
  get _isEditable() {
    return this.enableAnnotationEditing && this.data.isEditable;
  }
  get hasPopupData() {
    return V._hasPopupData(this.data) || this.enableComment && !!this.commentText;
  }
  get commentData() {
    const {
      data: t
    } = this, e = this.annotationStorage?.getEditor(t.id);
    return e ? e.getData() : t;
  }
  get hasCommentButton() {
    return this.enableComment && this.hasPopupElement;
  }
  get commentButtonPosition() {
    const t = this.annotationStorage?.getEditor(this.data.id);
    if (t)
      return t.commentButtonPositionInPage;
    const {
      quadPoints: e,
      inkLists: s,
      rect: i
    } = this.data;
    let n = -1 / 0, r = -1 / 0;
    if (e?.length >= 8) {
      for (let a = 0; a < e.length; a += 8)
        e[a + 1] > r ? (r = e[a + 1], n = e[a + 2]) : e[a + 1] === r && (n = Math.max(n, e[a + 2]));
      return [n, r];
    }
    if (s?.length >= 1) {
      for (const a of s)
        for (let o = 0, l = a.length; o < l; o += 2)
          a[o + 1] > r ? (r = a[o + 1], n = a[o]) : a[o + 1] === r && (n = Math.max(n, a[o]));
      if (n !== 1 / 0)
        return [n, r];
    }
    return i ? [i[2], i[3]] : null;
  }
  _normalizePoint(t) {
    const {
      page: {
        view: e
      },
      viewport: {
        rawDims: {
          pageWidth: s,
          pageHeight: i,
          pageX: n,
          pageY: r
        }
      }
    } = this.parent;
    return t[1] = e[3] - t[1] + e[1], t[0] = 100 * (t[0] - n) / s, t[1] = 100 * (t[1] - r) / i, t;
  }
  get commentText() {
    const {
      data: t
    } = this;
    return this.annotationStorage.getRawValue(`${ye}${t.id}`)?.popup?.contents || t.contentsObj?.str || "";
  }
  set commentText(t) {
    const {
      data: e
    } = this, s = {
      deleted: !t,
      contents: t || ""
    };
    this.annotationStorage.updateEditor(e.id, {
      popup: s
    }) || this.annotationStorage.setValue(`${ye}${e.id}`, {
      id: e.id,
      annotationType: e.annotationType,
      page: this.parent.page,
      popup: s,
      popupRef: e.popupRef,
      modificationDate: /* @__PURE__ */ new Date()
    }), t || this.removePopup();
  }
  removePopup() {
    (this.#s?.popup || this.popup)?.remove(), this.#s = this.popup = null;
  }
  updateEdited(t) {
    if (!this.container)
      return;
    t.rect && (this.#t ||= {
      rect: this.data.rect.slice(0)
    });
    const {
      rect: e,
      popup: s
    } = t;
    e && this.#i(e);
    let i = this.#s?.popup || this.popup;
    !i && s?.text && (this._createPopup(s), i = this.#s.popup), i && (i.updateEdited(t), s?.deleted && (i.remove(), this.#s = null, this.popup = null));
  }
  resetEdited() {
    this.#t && (this.#i(this.#t.rect), this.#s?.popup.resetEdited(), this.#t = null);
  }
  #i(t) {
    const {
      container: {
        style: e
      },
      data: {
        rect: s,
        rotation: i
      },
      parent: {
        viewport: {
          rawDims: {
            pageWidth: n,
            pageHeight: r,
            pageX: a,
            pageY: o
          }
        }
      }
    } = this;
    s?.splice(0, 4, ...t), e.left = `${100 * (t[0] - a) / n}%`, e.top = `${100 * (r - t[3] + o) / r}%`, i === 0 ? (e.width = `${100 * (t[2] - t[0]) / n}%`, e.height = `${100 * (t[3] - t[1]) / r}%`) : this.setRotation(i);
  }
  _createContainer(t) {
    const {
      data: e,
      parent: {
        page: s,
        viewport: i
      }
    } = this, n = document.createElement("section");
    n.setAttribute("data-annotation-id", e.id), !(this instanceof ce) && !(this instanceof ai) && !(this instanceof Tn) && (n.tabIndex = 0);
    const {
      style: r
    } = n;
    if (r.zIndex = this.parent.zIndex, this.parent.zIndex += 2, e.alternativeText && (n.title = e.alternativeText), e.noRotate && n.classList.add("norotate"), !e.rect || this instanceof Ws) {
      const {
        rotation: g
      } = e;
      return !e.hasOwnCanvas && g !== 0 && this.setRotation(g, n), n;
    }
    const {
      width: a,
      height: o
    } = this;
    if (!t && e.borderStyle.width > 0) {
      r.borderWidth = `${e.borderStyle.width}px`;
      const g = e.borderStyle.horizontalCornerRadius, m = e.borderStyle.verticalCornerRadius;
      if (g > 0 || m > 0) {
        const y = `calc(${g}px * var(--total-scale-factor)) / calc(${m}px * var(--total-scale-factor))`;
        r.borderRadius = y;
      }
      switch (e.borderStyle.style) {
        case fe.SOLID:
          r.borderStyle = "solid";
          break;
        case fe.DASHED:
          r.borderStyle = "dashed";
          break;
        case fe.BEVELED:
          R("Unimplemented border style: beveled");
          break;
        case fe.INSET:
          R("Unimplemented border style: inset");
          break;
        case fe.UNDERLINE:
          r.borderBottomStyle = "solid";
          break;
      }
      const b = e.borderColor || null;
      b ? (this.#e = !0, r.borderColor = x.makeHexColor(...b)) : r.borderWidth = 0;
    }
    const l = x.normalizeRect([e.rect[0], s.view[3] - e.rect[1] + s.view[1], e.rect[2], s.view[3] - e.rect[3] + s.view[1]]), {
      pageWidth: h,
      pageHeight: c,
      pageX: u,
      pageY: f
    } = i.rawDims;
    r.left = `${100 * (l[0] - u) / h}%`, r.top = `${100 * (l[1] - f) / c}%`;
    const {
      rotation: p
    } = e;
    return e.hasOwnCanvas || p === 0 ? (r.width = `${100 * a / h}%`, r.height = `${100 * o / c}%`) : this.setRotation(p, n), n;
  }
  setRotation(t, e = this.container) {
    if (!this.data.rect)
      return;
    const {
      pageWidth: s,
      pageHeight: i
    } = this.parent.viewport.rawDims;
    let {
      width: n,
      height: r
    } = this;
    t % 180 !== 0 && ([n, r] = [r, n]), e.style.width = `${100 * n / s}%`, e.style.height = `${100 * r / i}%`, e.setAttribute("data-main-rotation", (360 - t) % 360);
  }
  get _commonActions() {
    const t = (e, s, i) => {
      const n = i.detail[e], r = n[0], a = n.slice(1);
      i.target.style[s] = Vi[`${r}_HTML`](a), this.annotationStorage.setValue(this.data.id, {
        [s]: Vi[`${r}_rgb`](a)
      });
    };
    return k(this, "_commonActions", {
      display: (e) => {
        const {
          display: s
        } = e.detail, i = s % 2 === 1;
        this.container.style.visibility = i ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noView: i,
          noPrint: s === 1 || s === 2
        });
      },
      print: (e) => {
        this.annotationStorage.setValue(this.data.id, {
          noPrint: !e.detail.print
        });
      },
      hidden: (e) => {
        const {
          hidden: s
        } = e.detail;
        this.container.style.visibility = s ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noPrint: s,
          noView: s
        });
      },
      focus: (e) => {
        setTimeout(() => e.target.focus({
          preventScroll: !1
        }), 0);
      },
      userName: (e) => {
        e.target.title = e.detail.userName;
      },
      readonly: (e) => {
        e.target.disabled = e.detail.readonly;
      },
      required: (e) => {
        this._setRequired(e.target, e.detail.required);
      },
      bgColor: (e) => {
        t("bgColor", "backgroundColor", e);
      },
      fillColor: (e) => {
        t("fillColor", "backgroundColor", e);
      },
      fgColor: (e) => {
        t("fgColor", "color", e);
      },
      textColor: (e) => {
        t("textColor", "color", e);
      },
      borderColor: (e) => {
        t("borderColor", "borderColor", e);
      },
      strokeColor: (e) => {
        t("strokeColor", "borderColor", e);
      },
      rotation: (e) => {
        const s = e.detail.rotation;
        this.setRotation(s), this.annotationStorage.setValue(this.data.id, {
          rotation: s
        });
      }
    });
  }
  _dispatchEventFromSandbox(t, e) {
    const s = this._commonActions;
    for (const i of Object.keys(e.detail))
      (t[i] || s[i])?.(e);
  }
  _setDefaultPropertiesFromJS(t) {
    if (!this.enableScripting)
      return;
    const e = this.annotationStorage.getRawValue(this.data.id);
    if (!e)
      return;
    const s = this._commonActions;
    for (const [i, n] of Object.entries(e)) {
      const r = s[i];
      if (r) {
        const a = {
          detail: {
            [i]: n
          },
          target: t
        };
        r(a), delete e[i];
      }
    }
  }
  _createQuadrilaterals() {
    if (!this.container)
      return;
    const {
      quadPoints: t
    } = this.data;
    if (!t)
      return;
    const [e, s, i, n] = this.data.rect.map(Math.fround);
    if (t.length === 8) {
      const [g, m, b, y] = t.subarray(2, 6);
      if (i === g && n === m && e === b && s === y)
        return;
    }
    const {
      style: r
    } = this.container;
    let a;
    if (this.#e) {
      const {
        borderColor: g,
        borderWidth: m
      } = r;
      r.borderWidth = 0, a = ["url('data:image/svg+xml;utf8,", `<svg xmlns="${ct}" preserveAspectRatio="none" viewBox="0 0 1 1">`, `<g fill="transparent" stroke="${g}" stroke-width="${m}">`], this.container.classList.add("hasBorder");
    }
    const o = i - e, l = n - s, h = V._svgFactory, c = h.createElement("svg");
    c.classList.add("quadrilateralsContainer"), c.setAttribute("width", 0), c.setAttribute("height", 0), c.role = "none";
    const u = h.createElement("defs");
    c.append(u);
    const f = h.createElement("clipPath"), p = `clippath_${this.data.id}`;
    f.setAttribute("id", p), f.setAttribute("clipPathUnits", "objectBoundingBox"), u.append(f);
    for (let g = 2, m = t.length; g < m; g += 8) {
      const b = t[g], y = t[g + 1], A = t[g + 2], w = t[g + 3], v = h.createElement("rect"), S = (A - e) / o, _ = (n - y) / l, E = (b - A) / o, C = (y - w) / l;
      v.setAttribute("x", S), v.setAttribute("y", _), v.setAttribute("width", E), v.setAttribute("height", C), f.append(v), a?.push(`<rect vector-effect="non-scaling-stroke" x="${S}" y="${_}" width="${E}" height="${C}"/>`);
    }
    this.#e && (a.push("</g></svg>')"), r.backgroundImage = a.join("")), this.container.append(c), this.container.style.clipPath = `url(#${p})`;
  }
  _createPopup(t = null) {
    const {
      data: e
    } = this;
    let s, i;
    t ? (s = {
      str: t.text
    }, i = t.date) : (s = e.contentsObj, i = e.modificationDate), this.#s = new Ws({
      data: {
        color: e.color,
        titleObj: e.titleObj,
        modificationDate: i,
        contentsObj: s,
        richText: e.richText,
        parentRect: e.rect,
        borderStyle: 0,
        id: `popup_${e.id}`,
        rotation: e.rotation,
        noRotate: !0
      },
      linkService: this.linkService,
      parent: this.parent,
      elements: [this]
    });
  }
  get hasPopupElement() {
    return !!(this.#s || this.popup || this.data.popupRef);
  }
  get extraPopupElement() {
    return this.#s;
  }
  render() {
    j("Abstract method `AnnotationElement.render` called");
  }
  _getElementsByName(t, e = null) {
    const s = [];
    if (this._fieldObjects) {
      const i = this._fieldObjects.get(t) || [];
      for (const {
        page: n,
        id: r,
        exportValues: a
      } of i) {
        if (n === -1 || r === e)
          continue;
        const o = typeof a == "string" ? a : null, l = document.querySelector(`[data-element-id="${r}"]`);
        if (l && !le.has(l)) {
          R(`_getElementsByName - element not allowed: ${r}`);
          continue;
        }
        s.push({
          id: r,
          exportValue: o,
          domElement: l
        });
      }
      return s;
    }
    for (const i of document.getElementsByName(t)) {
      const {
        exportValue: n
      } = i, r = i.getAttribute("data-element-id");
      r === e || !le.has(i) || s.push({
        id: r,
        exportValue: n,
        domElement: i
      });
    }
    return s;
  }
  show() {
    this.container && (this.container.hidden = !1), this.popup?.maybeShow();
  }
  hide() {
    this.container && (this.container.hidden = !0), this.popup?.forceHide();
  }
  getElementsToTriggerPopup() {
    return this.container;
  }
  addHighlightArea() {
    const t = this.getElementsToTriggerPopup();
    if (Array.isArray(t))
      for (const e of t)
        e.classList.add("highlightArea");
    else
      t.classList.add("highlightArea");
  }
  _editOnDoubleClick() {
    if (!this._isEditable)
      return;
    const {
      annotationEditorType: t,
      data: {
        id: e
      }
    } = this;
    this.container.addEventListener("dblclick", () => {
      this.linkService.eventBus?.dispatch("switchannotationeditormode", {
        source: this,
        mode: t,
        editId: e,
        mustEnterInEditMode: !0
      });
    });
  }
  updateOC(t) {
    if (!this.data.oc || !t)
      return;
    t.isVisible(this.data.oc) ? this.show() : this.hide();
  }
  get width() {
    return this.data.rect[2] - this.data.rect[0];
  }
  get height() {
    return this.data.rect[3] - this.data.rect[1];
  }
  _setBackgroundColor(t) {
    const e = this.data.backgroundColor || null;
    t.style.backgroundColor = e === null ? "transparent" : x.makeHexColor(...e);
  }
}
class Ta extends V {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.editor = t.editor;
  }
  render() {
    return this.container.className = "editorAnnotation", this.container;
  }
  createOrUpdatePopup() {
    const {
      editor: t
    } = this;
    t.hasComment && this._createPopup(t.comment);
  }
  get hasCommentButton() {
    return this.enableComment && this.editor.hasComment;
  }
  get commentButtonPosition() {
    return this.editor.commentButtonPositionInPage;
  }
  get commentText() {
    return this.editor.comment.text;
  }
  set commentText(t) {
    this.editor.comment = t, t || this.removePopup();
  }
  get commentData() {
    return this.editor.getData();
  }
  remove() {
    this.parent.removeAnnotation(this.data.id), this.container.remove(), this.container = null, this.removePopup();
  }
}
class ai extends V {
  constructor(t, e = null) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !!e?.ignoreBorder,
      createQuadrilaterals: !0
    }), this.isTooltipOnly = t.data.isTooltipOnly;
  }
  render() {
    const {
      data: t,
      linkService: e
    } = this, s = document.createElement("a");
    s.setAttribute("data-element-id", t.id);
    let i = !1;
    return t.url ? (e.addLinkAttributes(s, t.url, t.newWindow), i = !0) : t.action ? (this._bindNamedAction(s, t.action, t.overlaidText), i = !0) : t.attachment ? (this.#e(s, t.attachmentId, t.attachment, t.overlaidText, t.attachmentDest), i = !0) : t.setOCGState ? (this.#s(s, t.setOCGState, t.overlaidText), i = !0) : t.dest ? (this._bindLink(s, t.dest, t.overlaidText), i = !0) : (t.actions && (t.actions.has("Action") || t.actions.has("Mouse Up") || t.actions.has("Mouse Down")) && this.enableScripting && this.hasJSActions && (this._bindJSAction(s, t), i = !0), t.resetForm ? (this._bindResetFormAction(s, t.resetForm), i = !0) : this.isTooltipOnly && !i && (this._bindLink(s, ""), i = !0)), this.container.classList.add("linkAnnotation"), i && (this.contentElement = s, this.container.append(s)), this.container;
  }
  #t() {
    this.container.setAttribute("data-internal-link", "");
  }
  _bindLink(t, e, s = "") {
    t.href = this.linkService.getDestinationHash(e), t.onclick = () => (e && this.linkService.goToDestination(e), !1), (e || e === "") && this.#t(), s && (t.title = s);
  }
  _bindNamedAction(t, e, s = "") {
    t.href = this.linkService.getAnchorUrl(""), t.onclick = () => (this.linkService.executeNamedAction(e), !1), s && (t.title = s), this.#t();
  }
  #e(t, e, s, i = "", n = null) {
    t.href = this.linkService.getAnchorUrl(""), s.description ? t.title = s.description : i && (t.title = i);
    const r = async () => {
      const a = await this.linkService.getAttachmentContent(e);
      a && this.downloadManager?.openOrDownloadData(a, s.filename, n);
    };
    t.onclick = () => (r(), !1), this.#t();
  }
  #s(t, e, s = "") {
    t.href = this.linkService.getAnchorUrl(""), t.onclick = () => (this.linkService.executeSetOCGState(e), !1), s && (t.title = s), this.#t();
  }
  _bindJSAction(t, {
    actions: e,
    id: s,
    overlaidText: i
  }) {
    t.href = this.linkService.getAnchorUrl("");
    const n = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
    for (const r of e.keys()) {
      const a = n.get(r);
      a && (t[a] = () => (this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: s,
          name: r
        }
      }), !1));
    }
    i && (t.title = i), t.onclick ||= () => !1, this.#t();
  }
  _bindResetFormAction(t, e) {
    const s = t.onclick;
    if (s || (t.href = this.linkService.getAnchorUrl("")), this.#t(), !this._fieldObjects) {
      R('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), s || (t.onclick = () => !1);
      return;
    }
    t.onclick = () => {
      s?.();
      const {
        fields: i,
        refs: n,
        include: r
      } = e, a = [];
      if (i.length !== 0 || n.length !== 0) {
        const h = new Set(n);
        for (const u of i) {
          const f = this._fieldObjects.get(u) || [];
          for (const {
            id: p
          } of f)
            h.add(p);
        }
        const c = /* @__PURE__ */ new Map();
        for (const u of this._fieldObjects.values())
          for (const {
            id: f,
            kidIds: p
          } of u)
            p && c.set(f, p);
        for (const u of h)
          for (const f of c.get(u) || [])
            h.add(f);
        for (const u of this._fieldObjects.values())
          for (const f of u)
            h.has(f.id) === r && a.push(f);
      } else
        for (const h of this._fieldObjects.values())
          a.push(...h);
      const o = this.annotationStorage, l = [];
      for (const h of a) {
        const {
          id: c
        } = h;
        switch (l.push(c), h.type) {
          case "text": {
            const f = h.defaultValue || "";
            o.setValue(c, {
              value: f
            });
            break;
          }
          case "checkbox":
          case "radiobutton": {
            const f = h.defaultValue === h.exportValues;
            o.setValue(c, {
              value: f
            });
            break;
          }
          case "combobox":
          case "listbox": {
            const f = h.defaultValue || "";
            o.setValue(c, {
              value: f
            });
            break;
          }
          default:
            continue;
        }
        const u = document.querySelector(`[data-element-id="${c}"]`);
        if (u) {
          if (!le.has(u)) {
            R(`_bindResetFormAction - element not allowed: ${c}`);
            continue;
          }
        } else continue;
        u.dispatchEvent(new Event("resetform"));
      }
      return this.enableScripting && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: "app",
          ids: l,
          name: "ResetForm"
        }
      }), !1;
    };
  }
}
class ka extends V {
  constructor(t) {
    super(t, {
      isRenderable: !0
    });
  }
  render() {
    this.container.classList.add("textAnnotation");
    const t = document.createElement("img");
    return t.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", t.setAttribute("data-l10n-id", "pdfjs-text-annotation-type"), t.setAttribute("data-l10n-args", JSON.stringify({
      type: this.data.name
    })), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.append(t), this.container;
  }
}
class ce extends V {
  render() {
    return this.container;
  }
  _getKeyModifier(t) {
    return W.platform.isMac ? t.metaKey : t.ctrlKey;
  }
  _setEventListener(t, e, s, i, n) {
    s.includes("mouse") ? t.addEventListener(s, (r) => {
      this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: i,
          value: n(r),
          shift: r.shiftKey,
          modifier: this._getKeyModifier(r)
        }
      });
    }) : t.addEventListener(s, (r) => {
      if (s === "blur") {
        if (!e.focused || !r.relatedTarget)
          return;
        e.focused = !1;
      } else if (s === "focus") {
        if (e.focused)
          return;
        e.focused = !0;
      }
      n && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: i,
          value: n(r)
        }
      });
    });
  }
  _setEventListeners(t, e, s, i) {
    const {
      actions: n
    } = this.data;
    for (const [r, a] of s)
      (a === "Action" || n?.has(a)) && ((a === "Focus" || a === "Blur") && (e ||= {
        focused: !1
      }), this._setEventListener(t, e, r, a, i), a === "Focus" && !n?.has("Blur") ? this._setEventListener(t, e, "blur", "Blur", null) : a === "Blur" && !n?.has("Focus") && this._setEventListener(t, e, "focus", "Focus", null));
  }
  _setTextStyle(t) {
    const e = ["left", "center", "right"], {
      fontColor: s
    } = this.data.defaultAppearanceData, i = this.data.defaultAppearanceData.fontSize || Ea, n = t.style;
    let r;
    const a = 2, o = (l) => Math.round(10 * l) / 10;
    if (this.data.multiLine) {
      const l = Math.abs(this.data.rect[3] - this.data.rect[1] - a), h = Math.round(l / /* inlined export .LINE_FACTOR */
      (1.35 * i)) || 1, c = l / h;
      r = Math.min(i, o(c / /* inlined export .LINE_FACTOR */
      1.35));
    } else {
      const l = Math.abs(this.data.rect[3] - this.data.rect[1] - a);
      r = Math.min(i, o(l / /* inlined export .LINE_FACTOR */
      1.35));
    }
    n.fontSize = `calc(${r}px * var(--total-scale-factor))`, n.color = x.makeHexColor(...s), this.data.textAlignment !== null && !this.data.comb && (n.textAlign = e[this.data.textAlignment]);
  }
  _setRequired(t, e) {
    e ? t.setAttribute("required", !0) : t.removeAttribute("required"), t.setAttribute("aria-required", e);
  }
}
class Pa extends ce {
  constructor(t) {
    const e = t.renderForms || t.data.hasOwnCanvas || !t.data.hasAppearance && !!t.data.fieldValue;
    super(t, {
      isRenderable: e
    });
  }
  setPropertyOnSiblings(t, e, s, i) {
    const n = this.annotationStorage;
    for (const r of this._getElementsByName(t.name, t.id))
      r.domElement && (r.domElement[e] = s), n.setValue(r.id, {
        [i]: s
      });
  }
  render() {
    const t = this.annotationStorage, e = this.data.id;
    this.container.classList.add("textWidgetAnnotation");
    let s = null;
    if (this.renderForms) {
      const i = t.getValue(e, {
        value: this.data.fieldValue
      });
      let n = i.value || "";
      const r = t.getValue(e, {
        charLimit: this.data.maxLen
      }).charLimit;
      r && n.length > r && (n = n.slice(0, r));
      let a = i.formattedValue || this.data.textContent?.join(`
`) || null;
      a && this.data.comb && (a = a.replaceAll(/\s+/g, ""));
      const o = {
        userValue: n,
        formattedValue: a,
        lastCommittedValue: null,
        commitKey: 1,
        focused: !1
      };
      this.data.multiLine ? (s = document.createElement("textarea"), s.textContent = a ?? n, this.data.doNotScroll && (s.style.overflowY = "hidden")) : (s = document.createElement("input"), s.type = this.data.password ? "password" : "text", s.setAttribute("value", a ?? n), this.data.doNotScroll && (s.style.overflowX = "hidden")), this.data.hasOwnCanvas && (this.container.classList.add("hasOwnCanvas"), t.has(e) && this.container.classList.add("sandboxModified")), le.add(s), this.contentElement = s, s.setAttribute("data-element-id", e), s.disabled = this.data.readOnly, s.name = this.data.fieldName, s.tabIndex = 0;
      const {
        datetimeFormat: l,
        datetimeType: h,
        timeStep: c
      } = this.data, u = !!h && this.enableScripting;
      l && (s.title = l), this._setRequired(s, this.data.required), r && (s.maxLength = r), s.addEventListener("input", (p) => {
        t.setValue(e, {
          value: p.target.value
        }), this.setPropertyOnSiblings(s, "value", p.target.value, "value"), o.formattedValue = null;
      }), s.addEventListener("resetform", (p) => {
        const g = this.data.defaultFieldValue ?? "";
        s.value = o.userValue = g, o.formattedValue = null;
      });
      let f = (p) => {
        const {
          formattedValue: g
        } = o;
        g != null && (p.target.value = g), p.target.scrollLeft = 0;
      };
      if (this.enableScripting && this.hasJSActions) {
        s.addEventListener("focus", (g) => {
          if (o.focused)
            return;
          const {
            target: m
          } = g;
          if (u && (m.type = h, c && (m.step = c)), o.userValue) {
            const b = o.userValue;
            if (u)
              if (h === "time") {
                const y = new Date(b), A = [y.getHours(), y.getMinutes(), y.getSeconds()];
                m.value = A.map((w) => w.toString().padStart(2, "0")).join(":");
              } else
                m.value = new Date(b - xa).toISOString().split(h === "date" ? "T" : ".", 1)[0];
            else
              m.value = b;
          }
          o.lastCommittedValue = m.value, o.commitKey = 1, this.data.actions?.has("Focus") || (o.focused = !0);
        }), s.addEventListener("updatefromsandbox", (g) => {
          this.container.classList.add("sandboxModified");
          const m = {
            value(b) {
              o.userValue = b.detail.value ?? "", u || t.setValue(e, {
                value: o.userValue.toString()
              }), b.target.value = o.userValue;
            },
            formattedValue(b) {
              const {
                formattedValue: y
              } = b.detail;
              o.formattedValue = y, y != null && b.target !== document.activeElement && (b.target.value = y);
              const A = {
                formattedValue: y
              };
              u && (A.value = y), t.setValue(e, A);
            },
            selRange(b) {
              b.target.setSelectionRange(...b.detail.selRange);
            },
            charLimit: (b) => {
              const {
                charLimit: y
              } = b.detail, {
                target: A
              } = b;
              if (y === 0) {
                A.removeAttribute("maxLength");
                return;
              }
              A.setAttribute("maxLength", y);
              let w = o.userValue;
              !w || w.length <= y || (w = w.slice(0, y), A.value = o.userValue = w, t.setValue(e, {
                value: w
              }), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                source: this,
                detail: {
                  id: e,
                  name: "Keystroke",
                  value: w,
                  willCommit: !0,
                  commitKey: 1,
                  selStart: A.selectionStart,
                  selEnd: A.selectionEnd
                }
              }));
            }
          };
          this._dispatchEventFromSandbox(m, g);
        }), s.addEventListener("keydown", (g) => {
          o.commitKey = 1;
          let m = -1;
          if (g.key === "Escape" ? m = 0 : g.key === "Enter" && !this.data.multiLine ? m = 2 : g.key === "Tab" && (o.commitKey = 3), m === -1)
            return;
          const {
            value: b
          } = g.target;
          o.lastCommittedValue !== b && (o.lastCommittedValue = b, o.userValue = b, this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: b,
              willCommit: !0,
              commitKey: m,
              selStart: g.target.selectionStart,
              selEnd: g.target.selectionEnd
            }
          }));
        });
        const p = f;
        f = null, s.addEventListener("blur", (g) => {
          if (!o.focused || !g.relatedTarget)
            return;
          this.data.actions?.has("Blur") || (o.focused = !1);
          const {
            target: m
          } = g;
          let {
            value: b
          } = m;
          if (u) {
            if (b && h === "time") {
              const y = b.split(":").map((A) => parseInt(A, 10));
              b = new Date(2e3, 0, 1, y[0], y[1], y[2] || 0).valueOf(), m.step = "";
            } else
              b.includes("T") || (b = `${b}T00:00`), b = new Date(b).valueOf();
            m.type = "text";
          }
          o.userValue = b, o.lastCommittedValue !== b && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: b,
              willCommit: !0,
              commitKey: o.commitKey,
              selStart: g.target.selectionStart,
              selEnd: g.target.selectionEnd
            }
          }), p(g);
        }), this.data.actions?.has("Keystroke") && s.addEventListener("beforeinput", (g) => {
          o.lastCommittedValue = null;
          const {
            data: m,
            target: b
          } = g, {
            value: y,
            selectionStart: A,
            selectionEnd: w
          } = b;
          let v = A, S = w;
          switch (g.inputType) {
            case "deleteWordBackward": {
              const _ = /\w/;
              for (; v > 0 && !_.test(y[v - 1]); )
                v--;
              for (; v > 0 && _.test(y[v - 1]); )
                v--;
              break;
            }
            case "deleteWordForward": {
              const _ = y.substring(A).match(/^\W*\w*/);
              _ && (S += _[0].length);
              break;
            }
            case "deleteContentBackward":
              A === w && (v -= 1);
              break;
            case "deleteContentForward":
              A === w && (S += 1);
              break;
          }
          g.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: y,
              change: m || "",
              willCommit: !1,
              selStart: v,
              selEnd: S
            }
          });
        }), this._setEventListeners(s, o, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (g) => g.target.value);
      }
      if (f && s.addEventListener("blur", f), this.data.comb) {
        const g = (this.data.rect[2] - this.data.rect[0]) / r;
        s.classList.add("comb"), s.style.setProperty("--comb-width", `calc(${g}px * var(--total-scale-factor))`);
        const m = this.data.textAlignment;
        if (m === 1 || m === 2) {
          const b = () => {
            const y = r - s.value.length;
            s.style.setProperty("--comb-offset", `${m === 1 ? y >> 1 : y}`);
          };
          b();
          for (const y of ["input", "blur", "resetform", "updatefromsandbox"])
            s.addEventListener(y, b);
        }
      }
    } else
      s = document.createElement("div"), s.textContent = this.data.fieldValue, s.style.verticalAlign = "middle", s.style.display = "table-cell", this.data.hasOwnCanvas && (s.hidden = !0);
    return this._setTextStyle(s), this._setBackgroundColor(s), this._setDefaultPropertiesFromJS(s), this.container.append(s), this.container;
  }
}
class Ma extends ce {
  constructor(t) {
    super(t, {
      isRenderable: !!t.data.hasOwnCanvas
    });
  }
}
class Ia extends ce {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    const t = this.annotationStorage, e = this.data, s = e.id;
    let i = t.getValue(s, {
      value: e.exportValue === e.fieldValue
    }).value;
    typeof i == "string" && (i = i !== "Off", t.setValue(s, {
      value: i
    })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
    const n = document.createElement("input");
    return le.add(n), n.setAttribute("data-element-id", s), n.disabled = e.readOnly, this._setRequired(n, this.data.required), n.type = "checkbox", n.name = e.fieldName, i && n.setAttribute("checked", !0), n.setAttribute("exportValue", e.exportValue), n.tabIndex = 0, n.addEventListener("change", (r) => {
      const {
        name: a,
        checked: o
      } = r.target;
      for (const l of this._getElementsByName(a, s)) {
        const h = o && l.exportValue === e.exportValue;
        l.domElement && (l.domElement.checked = h), t.setValue(l.id, {
          value: h
        });
      }
      t.setValue(s, {
        value: o
      });
    }), n.addEventListener("resetform", (r) => {
      const a = e.defaultFieldValue || "Off";
      r.target.checked = a === e.exportValue;
    }), this.enableScripting && this.hasJSActions && (n.addEventListener("updatefromsandbox", (r) => {
      const a = {
        value(o) {
          o.target.checked = o.detail.value !== "Off", t.setValue(s, {
            value: o.target.checked
          });
        }
      };
      this._dispatchEventFromSandbox(a, r);
    }), this._setEventListeners(n, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (r) => r.target.checked)), this._setDefaultPropertiesFromJS(n), this.container.append(n), this.container;
  }
}
class Da extends ce {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("buttonWidgetAnnotation", "radioButton");
    const t = this.annotationStorage, e = this.data, s = e.id;
    let i = t.getValue(s, {
      value: e.buttonValue !== null && e.fieldValue === e.buttonValue
    }).value;
    if (typeof i == "string" && (i = i !== e.buttonValue, t.setValue(s, {
      value: i
    })), i)
      for (const r of this._getElementsByName(e.fieldName, s))
        t.setValue(r.id, {
          value: !1
        });
    const n = document.createElement("input");
    if (le.add(n), n.setAttribute("data-element-id", s), n.disabled = e.readOnly, this._setRequired(n, this.data.required), n.type = "radio", n.name = e.fieldName, i && n.setAttribute("checked", !0), n.tabIndex = 0, n.addEventListener("change", (r) => {
      const {
        name: a,
        checked: o
      } = r.target;
      for (const l of this._getElementsByName(a, s))
        t.setValue(l.id, {
          value: !1
        });
      t.setValue(s, {
        value: o
      });
    }), n.addEventListener("resetform", (r) => {
      const a = e.defaultFieldValue;
      r.target.checked = a != null && a === e.buttonValue;
    }), this.enableScripting && this.hasJSActions) {
      const r = e.buttonValue;
      n.addEventListener("updatefromsandbox", (a) => {
        const o = {
          value: (l) => {
            const h = r === l.detail.value;
            for (const c of this._getElementsByName(l.target.name)) {
              const u = h && c.id === s;
              c.domElement && (c.domElement.checked = u), t.setValue(c.id, {
                value: u
              });
            }
          }
        };
        this._dispatchEventFromSandbox(o, a);
      }), this._setEventListeners(n, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (a) => a.target.checked);
    }
    return this._setDefaultPropertiesFromJS(n), this.container.append(n), this.container;
  }
}
class Fa extends ai {
  constructor(t) {
    super(t, {
      ignoreBorder: t.data.hasAppearance
    });
  }
  render() {
    const t = super.render();
    t.classList.add("buttonWidgetAnnotation", "pushButton");
    const e = t.lastChild;
    return this.enableScripting && this.hasJSActions && e && (this._setDefaultPropertiesFromJS(e), e.addEventListener("updatefromsandbox", (s) => {
      this._dispatchEventFromSandbox({}, s);
    })), t;
  }
}
class Oa extends ce {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("choiceWidgetAnnotation");
    const t = this.annotationStorage, e = this.data.id, s = t.getValue(e, {
      value: this.data.fieldValue
    }), i = document.createElement("select");
    le.add(i), i.setAttribute("data-element-id", e), i.disabled = this.data.readOnly, this._setRequired(i, this.data.required), i.name = this.data.fieldName, i.tabIndex = 0;
    let n = this.data.combo && this.data.options.length > 0;
    this.data.combo || (i.size = this.data.options.length, this.data.multiSelect && (i.multiple = !0)), i.addEventListener("resetform", (c) => {
      const u = this.data.defaultFieldValue;
      for (const f of i.options)
        f.selected = f.value === u;
    });
    const r = (c, u) => {
      const f = u.replaceAll(" ", " ");
      c.textContent = f, f !== u && c.setAttribute("display-value", u);
    };
    for (const c of this.data.options) {
      const u = document.createElement("option");
      r(u, c.displayValue), u.value = c.exportValue, s.value.includes(c.exportValue) && (u.setAttribute("selected", !0), n = !1), i.append(u);
    }
    let a = null;
    if (n) {
      const c = document.createElement("option");
      c.value = " ", c.setAttribute("hidden", !0), c.setAttribute("selected", !0), i.prepend(c), a = () => {
        c.remove(), i.removeEventListener("input", a), a = null;
      }, i.addEventListener("input", a);
    }
    const o = (c) => {
      const u = c ? "value" : "textContent", {
        options: f,
        multiple: p
      } = i;
      return p ? Array.prototype.filter.call(f, (g) => g.selected).map((g) => g[u]) : f.selectedIndex === -1 ? null : f[f.selectedIndex][u];
    };
    let l = o(!1);
    const h = (c) => {
      const u = c.target.options;
      return Array.prototype.map.call(u, (f) => ({
        displayValue: f.getAttribute("display-value") || f.textContent,
        exportValue: f.value
      }));
    };
    return this.enableScripting && this.hasJSActions ? (i.addEventListener("updatefromsandbox", (c) => {
      const u = {
        value(f) {
          a?.();
          const p = f.detail.value, g = new Set(Array.isArray(p) ? p : [p]);
          for (const m of i.options)
            m.selected = g.has(m.value);
          t.setValue(e, {
            value: o(!0)
          }), l = o(!1);
        },
        multipleSelection(f) {
          i.multiple = !0;
        },
        remove(f) {
          const p = i.options, g = f.detail.remove;
          p[g].selected = !1, i.remove(g), p.length > 0 && Array.prototype.findIndex.call(p, (b) => b.selected) === -1 && (p[0].selected = !0), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        clear(f) {
          for (; i.length !== 0; )
            i.remove(0);
          t.setValue(e, {
            value: null,
            items: []
          }), l = o(!1);
        },
        insert(f) {
          const {
            index: p,
            displayValue: g,
            exportValue: m
          } = f.detail.insert, b = i.children[p], y = document.createElement("option");
          r(y, g), y.value = m, b ? b.before(y) : i.append(y), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        items(f) {
          const {
            items: p
          } = f.detail;
          for (; i.length !== 0; )
            i.remove(0);
          for (const g of p) {
            const {
              displayValue: m,
              exportValue: b
            } = g, y = document.createElement("option");
            r(y, m), y.value = b, i.append(y);
          }
          i.options.length > 0 && (i.options[0].selected = !0), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        indices(f) {
          const p = new Set(f.detail.indices);
          for (const g of f.target.options)
            g.selected = p.has(g.index);
          t.setValue(e, {
            value: o(!0)
          }), l = o(!1);
        },
        editable(f) {
          f.target.disabled = !f.detail.editable;
        }
      };
      this._dispatchEventFromSandbox(u, c);
    }), i.addEventListener("input", (c) => {
      const u = o(!0), f = o(!1);
      t.setValue(e, {
        value: u
      }), c.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: e,
          name: "Keystroke",
          value: l,
          change: f,
          changeEx: u,
          willCommit: !1,
          commitKey: 1,
          keyDown: !1
        }
      });
    }), this._setEventListeners(i, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (c) => c.target.value)) : i.addEventListener("input", function(c) {
      t.setValue(e, {
        value: o(!0)
      });
    }), this.data.combo && this._setTextStyle(i), this._setBackgroundColor(i), this._setDefaultPropertiesFromJS(i), this.container.append(i), this.container;
  }
}
class Ws extends V {
  constructor(t) {
    const {
      data: e,
      elements: s,
      parent: i
    } = t, n = !!i._commentManager;
    if (super(t, {
      isRenderable: !n && V._hasPopupData(e)
    }), this.elements = s, n && V._hasPopupData(e)) {
      const r = this.popup = this.#t();
      for (const a of s)
        a.popup = r;
    } else
      this.popup = null;
  }
  #t() {
    return new Ra({
      container: this.container,
      color: this.data.color,
      titleObj: this.data.titleObj,
      modificationDate: this.data.modificationDate || this.data.creationDate,
      contentsObj: this.data.contentsObj,
      richText: this.data.richText,
      rect: this.data.rect,
      parentRect: this.data.parentRect || null,
      parent: this.parent,
      elements: this.elements,
      open: this.data.open,
      commentManager: this.parent._commentManager
    });
  }
  render() {
    const {
      container: t
    } = this;
    t.classList.add("popupAnnotation"), t.role = "comment";
    const e = this.popup = this.#t(), s = [];
    for (const i of this.elements)
      i.popup = e, i.container.ariaHasPopup = "dialog", s.push(i.data.id), i.addHighlightArea();
    return this.container.setAttribute("aria-controls", s.map((i) => `${ge}${i}`).join(",")), this.container;
  }
}
class Ra {
  #t = null;
  #e = this.#W.bind(this);
  #s = this.#E.bind(this);
  #i = this.#x.bind(this);
  #n = this.#j.bind(this);
  #r = null;
  #a = null;
  #o = null;
  #l = null;
  #h = null;
  #u = null;
  #c = null;
  #f = !1;
  #p = null;
  #m = null;
  #d = null;
  #g = null;
  #b = null;
  #y = null;
  #A = null;
  #w = null;
  #S = null;
  #_ = null;
  #v = !1;
  #C = null;
  #I = null;
  constructor({
    container: t,
    color: e,
    elements: s,
    titleObj: i,
    modificationDate: n,
    contentsObj: r,
    richText: a,
    parent: o,
    rect: l,
    parentRect: h,
    open: c,
    commentManager: u = null
  }) {
    this.#a = t, this.#S = i, this.#o = r, this.#w = a, this.#u = o, this.#r = e, this.#A = l, this.#c = h, this.#h = s, this.#t = u, this.#C = s[0], this.#l = Hs.toDateObject(n), this.trigger = s.flatMap((f) => f.getElementsToTriggerPopup()), u || (this.#k(), this.#a.hidden = !0, c && this.#j());
  }
  #k() {
    if (this.#m)
      return;
    this.#m = new AbortController();
    const {
      signal: t
    } = this.#m;
    for (const e of this.trigger)
      e.addEventListener("click", this.#n, {
        signal: t
      }), e.addEventListener("pointerenter", this.#i, {
        signal: t
      }), e.addEventListener("pointerleave", this.#s, {
        signal: t
      }), e.classList.add("popupTriggerArea");
    for (const e of this.#h)
      e.container?.addEventListener("keydown", this.#e, {
        signal: t
      });
  }
  #T() {
    const t = this.#h.find((e) => e.hasCommentButton);
    t && (this.#b = t._normalizePoint(t.commentButtonPosition));
  }
  renderCommentButton() {
    if (this.#g) {
      this.#g.parentNode || this.#C.container.after(this.#g);
      return;
    }
    if (this.#b || this.#T(), !this.#b)
      return;
    const {
      signal: t
    } = this.#m = new AbortController(), e = this.#C.hasOwnCommentButton, s = () => {
      this.#t.toggleCommentPopup(this, !0, void 0, !e);
    }, i = () => {
      this.#t.toggleCommentPopup(this, !1, !0, !e);
    }, n = () => {
      this.#t.toggleCommentPopup(this, !1, !1);
    };
    if (e) {
      this.#g = this.#C.container;
      for (const r of this.trigger)
        r.ariaHasPopup = "dialog", r.ariaControls = "commentPopup", r.addEventListener("keydown", this.#e, {
          signal: t
        }), r.addEventListener("click", s, {
          signal: t
        }), r.addEventListener("pointerenter", i, {
          signal: t
        }), r.addEventListener("pointerleave", n, {
          signal: t
        }), r.classList.add("popupTriggerArea");
    } else {
      const r = this.#g = document.createElement("button");
      r.className = "annotationCommentButton";
      const a = this.#C.container;
      r.style.zIndex = parseInt(a.style.zIndex, 10) + 1, r.tabIndex = 0, r.ariaHasPopup = "dialog", r.ariaControls = "commentPopup", r.setAttribute("data-l10n-id", "pdfjs-show-comment-button"), this.#P(), this.#O(), r.addEventListener("keydown", this.#e, {
        signal: t
      }), r.addEventListener("click", s, {
        signal: t
      }), r.addEventListener("pointerenter", i, {
        signal: t
      }), r.addEventListener("pointerleave", n, {
        signal: t
      }), a.after(r);
    }
  }
  #O() {
    if (this.#C.extraPopupElement && !this.#C.editor)
      return;
    this.#g || this.renderCommentButton();
    const [t, e] = this.#b, {
      style: s
    } = this.#g;
    s.left = `calc(${t}%)`, s.top = `calc(${e}% - var(--comment-button-dim))`;
  }
  #P() {
    this.#C.extraPopupElement || (this.#g || this.renderCommentButton(), this.#g.style.backgroundColor = this.commentButtonColor || "");
  }
  get commentButtonColor() {
    const {
      color: t,
      opacity: e
    } = this.#C.commentData;
    return t ? this.#u._commentManager.makeCommentColor(t, e) : null;
  }
  focusCommentButton() {
    setTimeout(() => {
      this.#g?.focus();
    }, 0);
  }
  getData() {
    const {
      richText: t,
      color: e,
      opacity: s,
      creationDate: i,
      modificationDate: n
    } = this.#C.commentData;
    return {
      contentsObj: {
        str: this.comment
      },
      richText: t,
      color: e,
      opacity: s,
      creationDate: i,
      modificationDate: n
    };
  }
  get elementBeforePopup() {
    return this.#g;
  }
  get comment() {
    return this.#I ||= this.#C.commentText, this.#I;
  }
  set comment(t) {
    t !== this.comment && (this.#C.commentText = this.#I = t);
  }
  focus() {
    this.#C.container?.focus();
  }
  get parentBoundingClientRect() {
    return this.#C.layer.getBoundingClientRect();
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    this.#g && (this.#g.classList.toggle("selected", t), this.#g.ariaExpanded = e);
  }
  setSelectedCommentButton(t) {
    this.#g.classList.toggle("selected", t);
  }
  get commentPopupPosition() {
    if (this.#y)
      return this.#y;
    const {
      x: t,
      y: e,
      height: s
    } = this.#g.getBoundingClientRect(), {
      x: i,
      y: n,
      width: r,
      height: a
    } = this.#C.layer.getBoundingClientRect();
    return [(t - i) / r, (e + s - n) / a];
  }
  set commentPopupPosition(t) {
    this.#y = t;
  }
  hasDefaultPopupPosition() {
    return this.#y === null;
  }
  get commentButtonPosition() {
    return this.#b;
  }
  get commentButtonWidth() {
    return this.#g.getBoundingClientRect().width / this.parentBoundingClientRect.width;
  }
  editComment(t) {
    const [e, s] = this.#y || this.commentButtonPosition.map((l) => l / 100), i = this.parentBoundingClientRect, {
      x: n,
      y: r,
      width: a,
      height: o
    } = i;
    this.#t.showDialog(null, this, n + e * a, r + s * o, {
      ...t,
      parentDimensions: i
    });
  }
  render() {
    if (this.#p)
      return;
    const t = this.#p = document.createElement("div");
    if (t.className = "popup", this.#r) {
      const s = t.style.outlineColor = x.makeHexColor(...this.#r);
      t.style.backgroundColor = `color-mix(in srgb, ${s} 30%, white)`;
    }
    const e = document.createElement("span");
    if (e.className = "header", this.#S?.str) {
      const s = document.createElement("span");
      s.className = "title", e.append(s), {
        dir: s.dir,
        str: s.textContent
      } = this.#S;
    }
    if (t.append(e), this.#l) {
      const s = document.createElement("time");
      s.className = "popupDate", s.setAttribute("data-l10n-id", "pdfjs-annotation-date-time-string"), s.setAttribute("data-l10n-args", JSON.stringify({
        dateObj: this.#l.valueOf()
      })), s.dateTime = this.#l.toISOString(), e.append(s);
    }
    tn({
      html: this.#D || this.#o.str,
      dir: this.#o?.dir,
      className: "popupContent"
    }, t), this.#a.append(t);
  }
  get #D() {
    const t = this.#w, e = this.#o;
    return t?.str && (!e?.str || e.str === t.str) && this.#w.html || null;
  }
  get #R() {
    return this.#D?.attributes?.style?.fontSize || 0;
  }
  get #F() {
    return this.#D?.attributes?.style?.color || null;
  }
  #B(t) {
    const e = [], s = {
      str: t,
      html: {
        name: "div",
        attributes: {
          dir: "auto"
        },
        children: [{
          name: "p",
          children: e
        }]
      }
    }, i = {
      style: {
        color: this.#F,
        fontSize: this.#R ? `calc(${this.#R}px * var(--total-scale-factor))` : ""
      }
    };
    for (const n of t.split(`
`))
      e.push({
        name: "span",
        value: n,
        attributes: i
      });
    return s;
  }
  #W(t) {
    t.altKey || t.shiftKey || t.ctrlKey || t.metaKey || (t.key === "Enter" || t.key === "Escape" && this.#f) && this.#j();
  }
  updateEdited({
    rect: t,
    popup: e,
    deleted: s
  }) {
    if (this.#t) {
      s ? (this.remove(), this.#I = null) : e && (e.deleted ? this.remove() : (this.#P(), this.#I = e.text)), t && (this.#b = null, this.#T(), this.#O());
      return;
    }
    if (s || e?.deleted) {
      this.remove();
      return;
    }
    this.#k(), this.#_ ||= {
      contentsObj: this.#o,
      richText: this.#w
    }, t && (this.#d = null), e && e.text && (this.#w = this.#B(e.text), this.#l = Hs.toDateObject(e.date), this.#o = null), this.#p?.remove(), this.#p = null;
  }
  resetEdited() {
    this.#_ && ({
      contentsObj: this.#o,
      richText: this.#w
    } = this.#_, this.#_ = null, this.#p?.remove(), this.#p = null, this.#d = null);
  }
  remove() {
    if (this.#m?.abort(), this.#m = null, this.#p?.remove(), this.#p = null, this.#v = !1, this.#f = !1, this.#g?.remove(), this.#g = null, this.trigger)
      for (const t of this.trigger)
        t.classList.remove("popupTriggerArea");
  }
  #H() {
    if (this.#d !== null)
      return;
    const {
      page: {
        view: t
      },
      viewport: {
        rawDims: {
          pageWidth: e,
          pageHeight: s,
          pageX: i,
          pageY: n
        }
      }
    } = this.#u;
    let r = !!this.#c, a = r ? this.#c : this.#A;
    for (const p of this.#h)
      if (!a || x.intersect(p.data.rect, a) !== null) {
        a = p.data.rect, r = !0;
        break;
      }
    const o = x.normalizeRect([a[0], t[3] - a[1] + t[1], a[2], t[3] - a[3] + t[1]]), h = r ? a[2] - a[0] + 5 : 0, c = o[0] + h, u = o[1];
    this.#d = [100 * (c - i) / e, 100 * (u - n) / s];
    const {
      style: f
    } = this.#a;
    f.left = `${this.#d[0]}%`, f.top = `${this.#d[1]}%`;
  }
  #j() {
    if (this.#t) {
      this.#t.toggleCommentPopup(this, !1);
      return;
    }
    this.#f = !this.#f, this.#f ? (this.#x(), this.#a.addEventListener("click", this.#n), this.#a.addEventListener("keydown", this.#e)) : (this.#E(), this.#a.removeEventListener("click", this.#n), this.#a.removeEventListener("keydown", this.#e));
  }
  #x() {
    this.#p || this.render(), this.isVisible ? this.#f && this.#a.classList.add("focused") : (this.#H(), this.#a.hidden = !1, this.#a.style.zIndex = parseInt(this.#a.style.zIndex, 10) + 1e3);
  }
  #E() {
    this.#a.classList.remove("focused"), !(this.#f || !this.isVisible) && (this.#a.hidden = !0, this.#a.style.zIndex = parseInt(this.#a.style.zIndex, 10) - 1e3);
  }
  forceHide() {
    this.#v = this.isVisible, this.#v && (this.#a.hidden = !0);
  }
  maybeShow() {
    this.#t || (this.#k(), this.#v && (this.#p || this.#x(), this.#v = !1, this.#a.hidden = !1));
  }
  get isVisible() {
    return !this.#t && this.#a.hidden === !1;
  }
}
class _n extends V {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.textContent = t.data.textContent, this.textPosition = t.data.textPosition, this.annotationEditorType = B.FREETEXT;
  }
  render() {
    if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
      const t = this.contentElement = document.createElement("div");
      t.classList.add("annotationTextContent"), t.setAttribute("role", "comment");
      for (const e of this.textContent) {
        const s = document.createElement("span");
        s.textContent = e, t.append(s);
      }
      this.container.append(t);
    }
    return !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this._editOnDoubleClick(), this.container;
  }
}
class La extends V {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    this.container.classList.add("lineAnnotation");
    const {
      data: t,
      width: e,
      height: s
    } = this, i = V._svgFactory, n = i.create(e, s, !0), r = this.#t = i.createElement("svg:line");
    return r.setAttribute("x1", t.rect[2] - t.lineCoordinates[0]), r.setAttribute("y1", t.rect[3] - t.lineCoordinates[1]), r.setAttribute("x2", t.rect[2] - t.lineCoordinates[2]), r.setAttribute("y2", t.rect[3] - t.lineCoordinates[3]), r.setAttribute("stroke-width", t.borderStyle.width || 1), r.setAttribute("stroke", "transparent"), r.setAttribute("fill", "transparent"), n.append(r), this.container.append(n), !t.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class Na extends V {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    this.container.classList.add("squareAnnotation");
    const {
      data: t,
      width: e,
      height: s
    } = this, i = V._svgFactory, n = i.create(e, s, !0), r = t.borderStyle.width, a = this.#t = i.createElement("svg:rect");
    return a.setAttribute("x", r / 2), a.setAttribute("y", r / 2), a.setAttribute("width", e - r), a.setAttribute("height", s - r), a.setAttribute("stroke-width", r || 1), a.setAttribute("stroke", "transparent"), a.setAttribute("fill", "transparent"), n.append(a), this.container.append(n), !t.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class Ba extends V {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    this.container.classList.add("circleAnnotation");
    const {
      data: t,
      width: e,
      height: s
    } = this, i = V._svgFactory, n = i.create(e, s, !0), r = t.borderStyle.width, a = this.#t = i.createElement("svg:ellipse");
    return a.setAttribute("cx", e / 2), a.setAttribute("cy", s / 2), a.setAttribute("rx", e / 2 - r / 2), a.setAttribute("ry", s / 2 - r / 2), a.setAttribute("stroke-width", r || 1), a.setAttribute("stroke", "transparent"), a.setAttribute("fill", "transparent"), n.append(a), this.container.append(n), !t.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class Cn extends V {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: t,
        vertices: e,
        borderStyle: s,
        popupRef: i
      },
      width: n,
      height: r
    } = this;
    if (!e)
      return this.container;
    const a = V._svgFactory, o = a.create(n, r, !0);
    let l = [];
    for (let c = 0, u = e.length; c < u; c += 2) {
      const f = e[c] - t[0], p = t[3] - e[c + 1];
      l.push(`${f},${p}`);
    }
    l = l.join(" ");
    const h = this.#t = a.createElement(this.svgElementName);
    return h.setAttribute("points", l), h.setAttribute("stroke-width", s.width || 1), h.setAttribute("stroke", "transparent"), h.setAttribute("fill", "transparent"), o.append(h), this.container.append(o), !i && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class Ha extends Cn {
  constructor(t) {
    super(t), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
  }
}
class Ua extends V {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
}
class oi extends V {
  #t = null;
  #e = [];
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = this.data.it === "InkHighlight" ? B.HIGHLIGHT : B.INK;
  }
  #s(t, e) {
    switch (t) {
      case 90:
        return {
          transform: `rotate(90) translate(${-e[0]},${e[1]}) scale(1,-1)`,
          width: e[3] - e[1],
          height: e[2] - e[0]
        };
      case 180:
        return {
          transform: `rotate(180) translate(${-e[2]},${e[1]}) scale(1,-1)`,
          width: e[2] - e[0],
          height: e[3] - e[1]
        };
      case 270:
        return {
          transform: `rotate(270) translate(${-e[2]},${e[3]}) scale(1,-1)`,
          width: e[3] - e[1],
          height: e[2] - e[0]
        };
      default:
        return {
          transform: `translate(${-e[0]},${e[3]}) scale(1,-1)`,
          width: e[2] - e[0],
          height: e[3] - e[1]
        };
    }
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: t,
        rotation: e,
        inkLists: s,
        borderStyle: i,
        popupRef: n
      }
    } = this, {
      transform: r,
      width: a,
      height: o
    } = this.#s(e, t), l = V._svgFactory, h = l.create(a, o, !0), c = this.#t = l.createElement("svg:g");
    h.append(c), c.setAttribute("stroke-width", i.width || 1), c.setAttribute("stroke-linecap", "round"), c.setAttribute("stroke-linejoin", "round"), c.setAttribute("stroke-miterlimit", 10), c.setAttribute("stroke", "transparent"), c.setAttribute("fill", "transparent"), c.setAttribute("transform", r);
    for (const u of s) {
      const f = l.createElement(this.svgElementName);
      this.#e.push(f), f.setAttribute("points", u.join(",")), c.append(f);
    }
    return !n && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.append(h), this._editOnDoubleClick(), this.container;
  }
  updateEdited(t) {
    super.updateEdited(t);
    const {
      thickness: e,
      points: s,
      rect: i
    } = t, n = this.#t;
    if (e >= 0 && n.setAttribute("stroke-width", e || 1), s)
      for (let r = 0, a = this.#e.length; r < a; r++)
        this.#e[r].setAttribute("points", s[r].join(","));
    if (i) {
      const {
        transform: r,
        width: a,
        height: o
      } = this.#s(this.data.rotation, i);
      n.parentElement.setAttribute("viewBox", `0 0 ${a} ${o}`), n.setAttribute("transform", r);
    }
  }
  getElementsToTriggerPopup() {
    return this.#e;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class En extends V {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    }), this.annotationEditorType = B.HIGHLIGHT;
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("highlightAnnotation"), this._editOnDoubleClick(), t) {
      const s = document.createElement("mark");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class Ga extends V {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("underlineAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class ja extends V {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("squigglyAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class za extends V {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("strikeoutAnnotation"), t) {
      const s = document.createElement("s");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class xn extends V {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.annotationEditorType = B.STAMP;
  }
  render() {
    return this.container.classList.add("stampAnnotation"), this.container.setAttribute("role", "img"), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this._editOnDoubleClick(), this.container;
  }
}
class $a extends V {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0
    });
    const {
      fileId: e,
      file: s
    } = this.data;
    this.filename = s.filename, this.content = s.content, this.fileId = e, this.linkService.eventBus?.dispatch("fileattachmentannotation", {
      source: this,
      attachmentId: this.fileId,
      ...s
    });
  }
  render() {
    this.container.classList.add("fileAttachmentAnnotation");
    const {
      container: t,
      data: e
    } = this;
    let s;
    e.hasAppearance || e.fillAlpha === 0 ? s = document.createElement("div") : (s = document.createElement("img"), s.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(e.name) ? "paperclip" : "pushpin"}.svg`, e.fillAlpha && e.fillAlpha < 1 && (s.style = `filter: opacity(${Math.round(e.fillAlpha * 100)}%);`)), s.addEventListener("dblclick", this.#e.bind(this)), this.#t = s;
    const {
      isMac: i
    } = W.platform;
    return t.addEventListener("keydown", (n) => {
      n.key === "Enter" && (i ? n.metaKey : n.ctrlKey) && this.#e();
    }), !e.popupRef && this.hasPopupData ? (this.hasOwnCommentButton = !0, this._createPopup()) : s.classList.add("popupTriggerArea"), t.append(s), t;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
  async #e() {
    const {
      fileId: t,
      filename: e,
      content: s
    } = this, i = await this.linkService.getAttachmentContent(t) || s;
    i && this.downloadManager?.openOrDownloadData(i, e);
  }
}
class Tn extends V {
  #t = new AbortController();
  #e = null;
  #s = null;
  constructor(t) {
    super(t, {
      isRenderable: !!t.data.richMedia
    });
  }
  render() {
    this.container.classList.add("mediaAnnotation");
    const {
      filename: t
    } = this.data.richMedia, e = document.createElement("button");
    return e.className = "mediaPlayButton", e.type = "button", e.title = e.ariaLabel = t, e.addEventListener("click", () => this.#i(e), {
      signal: this.#t.signal
    }), this.container.append(e), this.container;
  }
  async #i(t) {
    const {
      fileId: e,
      filename: s,
      contentType: i
    } = this.data.richMedia;
    t.disabled = !0;
    let n;
    try {
      n = await this.linkService.getAttachmentContent(e);
    } catch {
      return;
    } finally {
      t.disabled = !1;
    }
    if (!n || !t.isConnected)
      return;
    const {
      signal: r
    } = this.#t, a = new Blob([n], {
      type: i
    });
    if (!/^(?:video|audio)\//.test(a.type))
      return;
    const o = URL.createObjectURL(a);
    this.#e = o;
    const l = a.type.startsWith("audio/"), h = document.createElement(l ? "audio" : "video");
    if (this.#s = h, h.className = "mediaContent", this._setBackgroundColor(h), h.src = o, h.title = s, h.controls = !0, h.autoplay = !0, h.tabIndex = 0, l) {
      let c = !1, u = !1;
      const f = () => {
        h.controls = c || u;
      };
      this.container.addEventListener("pointerenter", () => {
        c = !0, f();
      }, {
        signal: r
      }), this.container.addEventListener("pointerleave", () => {
        c = !1, f();
      }, {
        signal: r
      }), this.container.addEventListener("focusin", () => {
        u = !0, f();
      }, {
        signal: r
      }), this.container.addEventListener("focusout", () => {
        u = !1, f();
      }, {
        signal: r
      });
    }
    h.addEventListener("emptied", () => this.#n(o), {
      once: !0,
      signal: r
    }), t.replaceWith(h), h.play().catch(() => {
    });
  }
  #n(t = this.#e) {
    t && t === this.#e && (URL.revokeObjectURL(t), this.#e = null);
  }
  destroy() {
    this.#t.abort(), this.#s && (this.#s.pause(), this.#s.removeAttribute("src"), this.#s.load(), this.#s = null), this.#n();
  }
}
class li {
  #t = null;
  #e = null;
  #s = null;
  #i = /* @__PURE__ */ new Map();
  #n = null;
  #r = null;
  #a = [];
  #o = !1;
  zIndex = 0;
  constructor({
    div: t,
    accessibilityManager: e,
    annotationCanvasMap: s,
    annotationEditorUIManager: i,
    page: n,
    viewport: r,
    structTreeLayer: a,
    commentManager: o,
    linkService: l,
    annotationStorage: h
  }) {
    this.div = t, this.#t = e, this.#e = s, this.#n = a || null, this.#r = l || null, this.#s = h || new ti(), this.page = n, this.viewport = r, this._annotationEditorUIManager = i, this._commentManager = o || null;
  }
  hasEditableAnnotations() {
    return this.#i.size > 0;
  }
  async render(t) {
    const {
      annotations: e,
      optionalContentConfig: s
    } = t, i = this.div;
    oe(i, this.viewport);
    const n = /* @__PURE__ */ new Map(), r = [], a = {
      data: null,
      layer: i,
      linkService: this.#r,
      downloadManager: t.downloadManager,
      imageResourcesPath: t.imageResourcesPath || "",
      renderForms: t.renderForms !== !1,
      annotationStorage: this.#s,
      enableComment: t.enableComment === !0,
      enableAnnotationEditing: t.enableAnnotationEditing !== !1,
      enableScripting: t.enableScripting === !0,
      hasJSActions: t.hasJSActions,
      fieldObjects: t.fieldObjects,
      parent: this,
      elements: null
    };
    for (const o of e) {
      if (o.noHTML)
        continue;
      const l = o.annotationType === q.POPUP;
      if (l) {
        const u = n.get(o.id);
        if (!u)
          continue;
        if (!this._commentManager) {
          r.push(o);
          continue;
        }
        a.elements = u;
      } else if (o.rect[2] === o.rect[0] || o.rect[3] === o.rect[1])
        continue;
      a.data = o;
      const h = Is.create(a);
      if (!h.isRenderable)
        continue;
      l || (this.#a.push(h), o.popupRef && n.getOrInsertComputed(o.popupRef, we).push(h));
      const c = h.render();
      o.hidden && (c.style.visibility = "hidden"), h.updateOC(s), h._isEditable && (this.#i.set(h.data.id, h), this._annotationEditorUIManager?.renderAnnotationElement(h));
    }
    await this.#l();
    for (const o of r) {
      const l = a.elements = n.get(o.id);
      a.data = o;
      const h = Is.create(a);
      if (!h.isRenderable)
        continue;
      const c = h.render();
      h.contentElement.id = `${ge}${o.id}`, o.hidden && (c.style.visibility = "hidden"), l.at(-1).container.after(c);
    }
    this.#h();
  }
  async #l() {
    if (this.#a.length === 0)
      return;
    this.div.replaceChildren();
    const t = [];
    if (!this.#o) {
      this.#o = !0;
      for (const {
        contentElement: s,
        data: {
          hidden: i,
          id: n,
          oc: r
        }
      } of this.#a) {
        const a = s.id = `${ge}${n}`, o = s.localName === "a" && !i && !r;
        t.push(this.#n?.getAriaAttributes(a, {
          enableLinkOwnership: o
        }).then((l) => {
          if (l)
            for (const [h, c] of l)
              s.setAttribute(h, c);
        }));
      }
    }
    this.#a.sort(({
      data: {
        rect: [s, i, n, r]
      }
    }, {
      data: {
        rect: [a, o, l, h]
      }
    }) => {
      if (s === n && i === r)
        return 1;
      if (a === l && o === h)
        return -1;
      const c = r, u = i, f = (i + r) / 2, p = h, g = o, m = (o + h) / 2;
      if (f >= p && m <= u)
        return -1;
      if (m >= c && f <= g)
        return 1;
      const b = (s + n) / 2, y = (a + l) / 2;
      return b - y;
    });
    const e = document.createDocumentFragment();
    for (const s of this.#a)
      e.append(s.container), this._commentManager ? (s.extraPopupElement?.popup || s.popup)?.renderCommentButton() : s.extraPopupElement && e.append(s.extraPopupElement.render());
    if (this.div.append(e), await Promise.all(t), this.#t) {
      const s = await this.#n?.getAnnotationIds();
      for (const {
        contentElement: i
      } of this.#a)
        s?.has(i.id) || this.#t.addPointerInTextLayer(i, !1);
    }
  }
  async addLinkAnnotations(t) {
    const e = {
      data: null,
      layer: this.div,
      linkService: this.#r,
      parent: this
    };
    for (const s of t) {
      s.borderStyle ||= li._defaultBorderStyle, e.data = s;
      const i = Is.create(e);
      i.isRenderable && (i.render(), i.contentElement.id = `${ge}${s.id}`, this.#a.push(i));
    }
    await this.#l();
  }
  update({
    viewport: t,
    optionalContentConfig: e
  }) {
    const s = this.div;
    this.viewport = t, oe(s, {
      rotation: t.rotation
    });
    for (const i of this.#a)
      i.updateOC(e);
    this.#h(), s.hidden = !1;
  }
  destroy() {
    for (const t of this.#a)
      t.destroy?.(), this.#t?.removePointerInTextLayer(t.contentElement);
    this.#a.length = 0, this.#i.clear(), this.div.replaceChildren();
  }
  #h() {
    if (!this.#e)
      return;
    const t = this.div;
    for (const [e, s] of this.#e) {
      const i = t.querySelector(`[data-annotation-id="${e}"]`);
      if (!i)
        continue;
      if (Array.isArray(s))
        for (const l of s)
          l.className = "annotationContent", l.ariaHidden = !0;
      else
        s.className = "annotationContent", s.ariaHidden = !0;
      const n = [];
      for (const l of i.children)
        l.nodeName === "CANVAS" && n.push(l);
      for (const l of n)
        l.remove();
      const r = Array.isArray(s) ? s[0] : s, {
        firstChild: a
      } = i;
      if (a ? a.classList.contains("annotationContent") ? a.after(r) : a.before(r) : i.append(r), Array.isArray(s)) {
        let l = r;
        for (let h = 1, c = s.length; h < c; h++)
          l.after(s[h]), l = s[h];
      }
      this.#e.delete(e);
      const o = this.#i.get(e);
      o && (o._hasNoCanvas ? (this._annotationEditorUIManager?.setMissingCanvas(e, i.id, s), o._hasNoCanvas = !1) : o.canvas = s);
    }
  }
  refreshCanvases() {
    this.#h();
  }
  getEditableAnnotations() {
    return this.#i.values();
  }
  getEditableAnnotation(t) {
    return this.#i.get(t);
  }
  addFakeAnnotation(t) {
    const {
      div: e
    } = this, {
      id: s,
      rotation: i
    } = t, n = new Ta({
      data: {
        id: s,
        rect: t.getPDFRect(),
        rotation: i
      },
      editor: t,
      layer: e,
      parent: this,
      enableComment: !!this._commentManager,
      linkService: this.#r,
      annotationStorage: this.#s
    });
    return n.render(), n.contentElement.id = `${ge}${s}`, n.createOrUpdatePopup(), this.#a.push(n), n;
  }
  removeAnnotation(t) {
    const e = this.#a.findIndex((i) => i.data.id === t);
    if (e < 0)
      return;
    const [s] = this.#a.splice(e, 1);
    this.#t?.removePointerInTextLayer(s.contentElement);
  }
  updateFakeAnnotations(t) {
    if (t.length !== 0) {
      for (const e of t)
        e.updateFakeAnnotationElement(this);
      this.#l();
    }
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  static get _defaultBorderStyle() {
    return k(this, "_defaultBorderStyle", Object.freeze({
      width: 1,
      rawWidth: 1,
      style: fe.SOLID,
      dashArray: [3],
      horizontalCornerRadius: 0,
      verticalCornerRadius: 0
    }));
  }
}
const We = /\r\n?|\n/g;
class at extends I {
  #t = "";
  #e = `${this.id}-editor`;
  #s = null;
  #i;
  _colorPicker = null;
  static _freeTextDefaultContent = "";
  static _internalPadding = 0;
  static _defaultColor = null;
  static _defaultFontSize = 10;
  static get _keyboardManager() {
    const t = at.prototype, e = (n) => n.isEmpty(), s = Kt.TRANSLATE_SMALL, i = Kt.TRANSLATE_BIG;
    return k(this, "_keyboardManager", new yt([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], t.commitOrRemove, {
      bubbles: !0
    }], [["ctrl+Enter", "mac+meta+Enter"], t.commitOrRemove], [["Escape"], t.commitOrRemove], [["ArrowLeft"], t._translateEmpty, {
      args: [-s, 0],
      checker: e
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t._translateEmpty, {
      args: [-i, 0],
      checker: e
    }], [["ArrowRight"], t._translateEmpty, {
      args: [s, 0],
      checker: e
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t._translateEmpty, {
      args: [i, 0],
      checker: e
    }], [["ArrowUp"], t._translateEmpty, {
      args: [0, -s],
      checker: e
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t._translateEmpty, {
      args: [0, -i],
      checker: e
    }], [["ArrowDown"], t._translateEmpty, {
      args: [0, s],
      checker: e
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t._translateEmpty, {
      args: [0, i],
      checker: e
    }]]));
  }
  static _type = "freetext";
  static _editorType = B.FREETEXT;
  constructor(t) {
    super({
      ...t,
      name: "freeTextEditor"
    }), this.color = t.color || at._defaultColor || I._defaultLineColor, this.#i = t.fontSize || at._defaultFontSize, this.annotationElementId || this._uiManager.a11yAlert(I._l10nAlert.freetext), this.canAddComment = !1;
  }
  static initialize(t, e) {
    I.initialize(t, e);
    const s = getComputedStyle(document.documentElement);
    this._internalPadding = parseFloat(s.getPropertyValue("--freetext-padding"));
  }
  static updateDefaultParams(t, e) {
    switch (t) {
      case U.FREETEXT_SIZE:
        at._defaultFontSize = e;
        break;
      case U.FREETEXT_COLOR:
        at._defaultColor = e;
        break;
    }
  }
  updateParams(t, e) {
    switch (t) {
      case U.FREETEXT_SIZE:
        this.#n(e);
        break;
      case U.FREETEXT_COLOR:
        this.#r(e);
        break;
    }
  }
  static get defaultPropertiesToUpdate() {
    return [[U.FREETEXT_SIZE, at._defaultFontSize], [U.FREETEXT_COLOR, at._defaultColor || I._defaultLineColor]];
  }
  get propertiesToUpdate() {
    return [[U.FREETEXT_SIZE, this.#i], [U.FREETEXT_COLOR, this.color]];
  }
  get toolbarButtons() {
    return this._colorPicker ||= new Oe(this), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return U.FREETEXT_COLOR;
  }
  #n(t) {
    const e = (i) => {
      this.editorDiv.style.fontSize = `calc(${i}px * var(--total-scale-factor))`, this.translate(0, -(i - this.#i) * this.parentScale), this.#i = i, this.#o();
    }, s = this.#i;
    this.addCommands({
      cmd: e.bind(this, t),
      undo: e.bind(this, s),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: U.FREETEXT_SIZE,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  onUpdatedColor() {
    this.editorDiv.style.color = this.color, this._colorPicker?.update(this.color), super.onUpdatedColor();
  }
  #r(t) {
    const e = (i) => {
      this.color = i, this.onUpdatedColor();
    }, s = this.color;
    this.addCommands({
      cmd: e.bind(this, t),
      undo: e.bind(this, s),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: U.FREETEXT_COLOR,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _translateEmpty(t, e) {
    this._uiManager.translateSelectedEditors(t, e, !0);
  }
  getInitialTranslation() {
    const t = this.parentScale;
    return [-at._internalPadding * t, -(at._internalPadding + this.#i) * t];
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
  }
  enableEditMode() {
    if (!super.enableEditMode())
      return !1;
    this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), this.#s = new AbortController();
    const t = this._uiManager.combinedSignal(this.#s);
    return this.editorDiv.addEventListener("keydown", this.editorDivKeydown.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("focus", this.editorDivFocus.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("blur", this.editorDivBlur.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("input", this.editorDivInput.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("paste", this.editorDivPaste.bind(this), {
      signal: t
    }), !0;
  }
  disableEditMode() {
    return super.disableEditMode() ? (this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", this.#e), this._isDraggable = !0, this.#s?.abort(), this.#s = null, this.div.focus({
      preventScroll: !0
    }), this.isEditing = !1, this.parent.div.classList.add("freetextEditing"), !0) : !1;
  }
  focusin(t) {
    this._focusEventsAllowed && (super.focusin(t), t.target !== this.editorDiv && this.editorDiv.focus());
  }
  onceAdded(t) {
    this.width || (this.enableEditMode(), t && this.editorDiv.focus(), this._initialOptions?.isCentered && this.center(), this._initialOptions = null);
  }
  isEmpty() {
    return !this.editorDiv || this.editorDiv.innerText.trim() === "";
  }
  remove() {
    this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freetextEditing")), super.remove();
  }
  #a() {
    const t = [];
    this.editorDiv.normalize();
    let e = null;
    for (const s of this.editorDiv.childNodes)
      e?.nodeType === Node.TEXT_NODE && s.nodeName === "BR" || (t.push(at.#l(s)), e = s);
    return t.join(`
`);
  }
  #o() {
    const [t, e] = this.parentDimensions;
    let s;
    if (this.isAttachedToDOM)
      s = this.div.getBoundingClientRect();
    else {
      const {
        currentLayer: i,
        div: n
      } = this, r = n.style.display, a = n.classList.contains("hidden");
      n.classList.remove("hidden"), n.style.display = "hidden", i.div.append(this.div), s = n.getBoundingClientRect(), n.remove(), n.style.display = r, n.classList.toggle("hidden", a);
    }
    this.rotation % 180 === this.parentRotation % 180 ? (this.width = s.width / t, this.height = s.height / e) : (this.width = s.height / t, this.height = s.width / e), this.fixAndSetPosition();
  }
  commit() {
    if (!this.isInEditMode())
      return;
    super.commit(), this.disableEditMode();
    const t = this.#t, e = this.#t = this.#a().trimEnd();
    if (t === e)
      return;
    const s = (i) => {
      if (this.#t = i, !i) {
        this.remove();
        return;
      }
      this.#h(), this._uiManager.rebuild(this), this.#o();
    };
    this.addCommands({
      cmd: () => {
        s(e);
      },
      undo: () => {
        s(t);
      },
      mustExec: !1
    }), this.#o();
  }
  shouldGetKeyboardEvents() {
    return this.isInEditMode();
  }
  enterInEditMode() {
    this.enableEditMode(), this.editorDiv.focus();
  }
  keydown(t) {
    t.target === this.div && t.key === "Enter" && (this.enterInEditMode(), t.preventDefault());
  }
  editorDivKeydown(t) {
    at._keyboardManager.exec(this, t);
  }
  editorDivFocus(t) {
    this.isEditing = !0;
  }
  editorDivBlur(t) {
    this.isEditing = !1;
  }
  editorDivInput(t) {
    this.parent.div.classList.toggle("freetextEditing", this.isEmpty());
  }
  disableEditing() {
    this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
  }
  enableEditing() {
    this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
  }
  get canChangeContent() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    (this._isCopy || this.annotationElementId) && (t = this.x, e = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", this.#e), this.editorDiv.setAttribute("data-l10n-id", "pdfjs-free-text2"), this.editorDiv.setAttribute("data-l10n-attrs", "default-content"), this.enableEditing(), this.editorDiv.contentEditable = !0;
    const {
      style: s
    } = this.editorDiv;
    if (s.fontSize = `calc(${this.#i}px * var(--total-scale-factor))`, s.color = this.color, this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), this._isCopy || this.annotationElementId) {
      const [i, n] = this.parentDimensions;
      if (this.annotationElementId) {
        const {
          position: r
        } = this._initialData;
        let [a, o] = this.getInitialTranslation();
        [a, o] = this.pageTranslationToScreen(a, o);
        const [l, h] = this.pageDimensions, [c, u] = this.pageTranslation;
        let f, p;
        switch (this.rotation) {
          case 0:
            f = t + (r[0] - c) / l, p = e + this.height - (r[1] - u) / h;
            break;
          case 90:
            f = t + (r[0] - c) / l, p = e - (r[1] - u) / h, [a, o] = [o, -a];
            break;
          case 180:
            f = t - this.width + (r[0] - c) / l, p = e - (r[1] - u) / h, [a, o] = [-a, -o];
            break;
          case 270:
            f = t + (r[0] - c - this.height * h) / l, p = e + (r[1] - u - this.width * l) / h, [a, o] = [-o, a];
            break;
        }
        this.setAt(f * i, p * n, a, o);
      } else
        this._moveAfterPaste(t, e);
      this.#h(), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
    } else
      this._isDraggable = !1, this.editorDiv.contentEditable = !0;
    return this.div;
  }
  static #l(t) {
    return (t.nodeType === Node.TEXT_NODE ? t.nodeValue : t.innerText).replaceAll(We, "");
  }
  editorDivPaste(t) {
    const e = t.clipboardData || window.clipboardData, {
      types: s
    } = e;
    if (s.length === 1 && s[0] === "text/plain")
      return;
    t.preventDefault();
    const i = at.#c(e.getData("text") || "").replaceAll(We, `
`);
    if (!i)
      return;
    const n = window.getSelection();
    if (!n.rangeCount)
      return;
    this.editorDiv.normalize(), n.deleteFromDocument();
    const r = n.getRangeAt(0);
    if (!i.includes(`
`)) {
      r.insertNode(document.createTextNode(i)), this.editorDiv.normalize(), n.collapseToStart();
      return;
    }
    const {
      startContainer: a,
      startOffset: o
    } = r, l = [], h = [];
    if (a.nodeType === Node.TEXT_NODE) {
      const f = a.parentElement;
      if (h.push(a.nodeValue.slice(o).replaceAll(We, "")), f !== this.editorDiv) {
        let p = l;
        for (const g of this.editorDiv.childNodes) {
          if (g === f) {
            p = h;
            continue;
          }
          p.push(at.#l(g));
        }
      }
      l.push(a.nodeValue.slice(0, o).replaceAll(We, ""));
    } else if (a === this.editorDiv) {
      let f = l, p = 0;
      for (const g of this.editorDiv.childNodes)
        p++ === o && (f = h), f.push(at.#l(g));
    }
    this.#t = `${l.join(`
`)}${i}${h.join(`
`)}`, this.#h();
    const c = new Range();
    let u = Math.sumPrecise(l.map((f) => f.length));
    for (const {
      firstChild: f
    } of this.editorDiv.childNodes)
      if (f.nodeType === Node.TEXT_NODE) {
        const p = f.nodeValue.length;
        if (u <= p) {
          c.setStart(f, u), c.setEnd(f, u);
          break;
        }
        u -= p;
      }
    n.removeAllRanges(), n.addRange(c);
  }
  #h() {
    if (this.editorDiv.replaceChildren(), !!this.#t)
      for (const t of this.#t.split(`
`)) {
        const e = document.createElement("div");
        e.append(t ? document.createTextNode(t) : document.createElement("br")), this.editorDiv.append(e);
      }
  }
  #u() {
    return this.#t.replaceAll(" ", " ");
  }
  static #c(t) {
    return t.replaceAll(" ", " ");
  }
  get contentDiv() {
    return this.editorDiv;
  }
  getPDFRect() {
    const t = at._internalPadding * this.parentScale;
    return this.getRect(t, t);
  }
  static async deserialize(t, e, s) {
    let i = null;
    if (t instanceof _n) {
      const {
        data: {
          defaultAppearanceData: {
            fontSize: r,
            fontColor: a
          },
          rect: o,
          rotation: l,
          id: h,
          popupRef: c,
          richText: u,
          contentsObj: f,
          creationDate: p,
          modificationDate: g
        },
        textContent: m,
        textPosition: b,
        parent: {
          page: {
            pageNumber: y
          }
        }
      } = t;
      if (!m?.length)
        return null;
      i = t = {
        annotationType: B.FREETEXT,
        color: Array.from(a),
        fontSize: r,
        value: m.join(`
`),
        position: b,
        pageIndex: y - 1,
        rect: o.slice(0),
        rotation: l,
        annotationElementId: h,
        id: h,
        deleted: !1,
        popupRef: c,
        comment: f?.str || null,
        richText: u,
        creationDate: p,
        modificationDate: g
      };
    }
    const n = await super.deserialize(t, e, s);
    return n.#i = t.fontSize, n.color = x.makeHexColor(...t.color), n.#t = at.#c(t.value), n._initialData = i, t.comment && n.setCommentData(t), n;
  }
  serialize(t = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const e = I._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : this.color), s = Object.assign(super.serialize(t), {
      color: e,
      fontSize: this.#i,
      value: this.#u()
    });
    return this.addComment(s), t ? (s.isCopy = !0, s) : this.annotationElementId && !this.#f(s) ? null : (s.id = this.annotationElementId, s);
  }
  #f(t) {
    const {
      value: e,
      fontSize: s,
      color: i,
      pageIndex: n
    } = this._initialData;
    return this.hasEditedComment || this._hasBeenMoved || t.value !== e || t.fontSize !== s || t.color.some((r, a) => r !== i[a]) || t.pageIndex !== n;
  }
  renderAnnotationElement(t) {
    const e = super.renderAnnotationElement(t);
    if (!e)
      return null;
    const {
      style: s
    } = e;
    s.fontSize = `calc(${this.#i}px * var(--total-scale-factor))`, s.color = this.color, e.replaceChildren();
    for (const i of this.#t.split(`
`)) {
      const n = document.createElement("div");
      n.append(i ? document.createTextNode(i) : document.createElement("br")), e.append(n);
    }
    return t.updateEdited({
      rect: this.getPDFRect(),
      popup: this._uiManager.hasCommentManager() || this.hasEditedComment ? this.comment : {
        text: this.#t
      }
    }), e;
  }
  resetAnnotationElement(t) {
    super.resetAnnotationElement(t), t.resetEdited();
  }
}
class hi {
  #t = /* @__PURE__ */ Object.create(null);
  updateProperty(t, e) {
    this[t] = e, this.updateSVGProperty(t, e);
  }
  updateProperties(t) {
    if (t)
      for (const [e, s] of Object.entries(t))
        e.startsWith("_") || this.updateProperty(e, s);
  }
  updateSVGProperty(t, e) {
    this.#t[t] = e;
  }
  toSVGProperties() {
    const t = this.#t;
    return this.#t = /* @__PURE__ */ Object.create(null), {
      root: t
    };
  }
  reset() {
    this.#t = /* @__PURE__ */ Object.create(null);
  }
  updateAll(t = this) {
    this.updateProperties(t);
  }
  clone() {
    j("Not implemented");
  }
}
class H extends I {
  #t = null;
  #e;
  _clipPathId = null;
  _colorPicker = null;
  _drawId = null;
  _drawOutlines = null;
  _focusDrawId = null;
  static _currentDrawId = -1;
  static _currentParent = null;
  static #s = null;
  static #i = null;
  static #n = null;
  static #r = null;
  static _INNER_MARGIN = 3;
  constructor(t) {
    super(t), this.#e = t.mustBeCommitted || !1, this._addOutlines(t);
  }
  onUpdatedColor() {
    this._colorPicker?.update(this.color), super.onUpdatedColor();
  }
  onUpdatedOpacity() {
    this._colorPicker?.updateOpacity?.(this.opacity);
  }
  _addOutlines(t) {
    t.drawOutlines && (this.#a(t), this.#m());
  }
  #a({
    drawOutlines: t,
    drawId: e,
    drawingOptions: s,
    clipPathId: i
  }) {
    this._drawOutlines = t, this._drawingOptions ||= s, this.annotationElementId || this._uiManager.a11yAlert(I._l10nAlert[this.editorType]), e >= 0 ? (this._drawId = e, this._clipPathId = i ?? null, this.parent.drawLayer.finalizeDraw(e, t.defaultProperties), this.#l(this.parent)) : this._drawId = this.#o(t, this.parent), this.#b(t.box);
  }
  #o(t, e) {
    const {
      id: s,
      clipPathId: i
    } = e.drawLayer.draw(H._mergeSVGProperties(this._drawingOptions.toSVGProperties(), t.defaultSVGProperties), !1, this.constructor._hasClipPath);
    return this.constructor._hasClipPath && (this._clipPathId = i), this.#l(e), s;
  }
  #l(t) {
    const e = this._drawOutlines.getFocusSVGProperties(this.#f);
    e && (this._focusDrawId = t.drawLayer.drawOutline(e, this._drawOutlines.focusMustRemoveSelfIntersections));
  }
  #h(t = this.#f) {
    this._focusDrawId !== null && this.parent?.drawLayer.updateProperties(this._focusDrawId, this._drawOutlines.getFocusSVGProperties(t));
  }
  #u(t) {
    this._focusDrawId !== null && this.parent?.drawLayer.updateProperties(this._focusDrawId, {
      rootClass: t
    });
  }
  #c() {
    const {
      parent: t,
      _drawId: e,
      _focusDrawId: s,
      _isVisible: i
    } = this;
    if (!t || e === null)
      return;
    const n = {
      hidden: !i
    };
    t.drawLayer.updateProperties(e, {
      rootClass: n
    }), s !== null && t.drawLayer.updateProperties(s, {
      rootClass: n
    });
  }
  static _mergeSVGProperties(t, e) {
    const s = new Set(Object.keys(t));
    for (const [i, n] of Object.entries(e))
      s.has(i) ? Object.assign(t[i], n) : t[i] = n;
    return t;
  }
  static getDefaultDrawingOptions(t) {
    j("Not implemented");
  }
  static get typesMap() {
    j("Not implemented");
  }
  static get isDrawer() {
    return !0;
  }
  static get _hasClipPath() {
    return !1;
  }
  static get _hasDrawClass() {
    return !0;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  get _drawRotation() {
    return this.rotation;
  }
  get _opacityName() {
    return this.constructor.typesMap.get(this.opacityType);
  }
  get #f() {
    return (this.parentRotation - this._drawRotation + 360) % 360;
  }
  static updateDefaultParams(t, e) {
    const s = this.typesMap.get(t);
    s && this._defaultDrawingOptions.updateProperty(s, e), this._currentParent && (H.#s.updateProperty(s, e), this._currentParent.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  updateParams(t, e) {
    const s = this.constructor.typesMap.get(t);
    s && this._updateProperty(t, s, e);
  }
  static get defaultPropertiesToUpdate() {
    const t = [], e = this._defaultDrawingOptions;
    for (const [s, i] of this.typesMap)
      t.push([s, e[i]]);
    return t;
  }
  get propertiesToUpdate() {
    const t = [], {
      _drawingOptions: e
    } = this;
    for (const [s, i] of this.constructor.typesMap)
      t.push([s, e[i]]);
    return t;
  }
  _updateProperty(t, e, s) {
    const i = this._drawingOptions, n = i[e], r = (a) => {
      i.updateProperty(e, a);
      const o = this._drawOutlines.updateProperty(e, a);
      o && this.#b(o), this.parent?.drawLayer.updateProperties(this._drawId, i.toSVGProperties()), t === this.colorType ? this.onUpdatedColor() : t === this.opacityType && this.onUpdatedOpacity();
    };
    this.addCommands({
      cmd: r.bind(this, s),
      undo: r.bind(this, n),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: t,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _updateColorAndOpacity(t, e, s = this.colorAndOpacityType) {
    const i = this.constructor.typesMap.get(this.colorType), n = this._opacityName, r = this._drawingOptions, a = r[i], o = r[n], l = (h, c) => {
      r.updateProperty(i, h), r.updateProperty(n, c), this._drawOutlines.updateProperty(i, h), this._drawOutlines.updateProperty(n, c), this.parent?.drawLayer.updateProperties(this._drawId, r.toSVGProperties()), this.onUpdatedColor(), this.onUpdatedOpacity();
    };
    this.addCommands({
      cmd: l.bind(this, t, e),
      undo: l.bind(this, a, o),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: s,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _onResizing() {
    this.parent?.drawLayer.updateProperties(this._drawId, H._mergeSVGProperties(this._drawOutlines.getPathResizingSVGProperties(this.#g()), {
      bbox: this.#y()
    }));
  }
  _onResized() {
    this.parent?.drawLayer.updateProperties(this._drawId, H._mergeSVGProperties(this._drawOutlines.getPathResizedSVGProperties(this.#g()), {
      bbox: this.#y()
    })), this.#h();
  }
  _onTranslating(t, e) {
    this.parent?.drawLayer.updateProperties(this._drawId, {
      bbox: this.#y()
    });
  }
  _onTranslated() {
    this.parent?.drawLayer.updateProperties(this._drawId, H._mergeSVGProperties(this._drawOutlines.getPathTranslatedSVGProperties(this.#g(), this.parentDimensions), {
      bbox: this.#y()
    }));
  }
  _onStartDragging() {
    this.parent?.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !0
      }
    });
  }
  _onStopDragging() {
    this.parent?.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !1
      }
    });
  }
  get _mustBeDisabledOnCommit() {
    return !0;
  }
  commit() {
    super.commit(), this._mustBeDisabledOnCommit && (this.disableEditMode(), this.disableEditing());
  }
  disableEditing() {
    super.disableEditing(), this.div.classList.toggle("disabled", !0);
  }
  enableEditing() {
    super.enableEditing(), this.div.classList.toggle("disabled", !1);
  }
  getBaseTranslation() {
    return [0, 0];
  }
  get isResizable() {
    return !0;
  }
  onceAdded(t) {
    !this.annotationElementId && this._drawId !== null && this.parent.addUndoableEditor(this), this._isDraggable = !0, this.#e && (this.#e = !1, this.commit(), this.parent.setSelected(this), t && this.isOnScreen && this.div.focus());
  }
  remove() {
    this._uiManager.removeShouldRescale(this), this.#p(), super.remove();
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.#m(), this.#b(this._drawOutlines.box), this.isAttachedToDOM || this.parent.add(this)));
  }
  setParent(t) {
    let e = !1;
    this.parent && !t ? (this._uiManager.removeShouldRescale(this), this.#p()) : t && (this._uiManager.addShouldRescale(this), this.#m(t), e = !this.parent && this.div?.classList.contains("selectedEditor")), super.setParent(t), this.#c(), e && this.select();
  }
  #p() {
    if (this._drawId === null || !this.parent)
      return;
    const {
      drawLayer: t
    } = this.parent;
    t.remove(this._drawId), this._drawId = null, this._focusDrawId !== null && (t.remove(this._focusDrawId), this._focusDrawId = null), this._drawingOptions.reset();
  }
  #m(t = this.parent) {
    if (!(this._drawId !== null && this.parent === t)) {
      if (this._drawId !== null) {
        const {
          drawLayer: e
        } = this.parent;
        e.updateParent(this._drawId, t.drawLayer), this._focusDrawId !== null && e.updateParent(this._focusDrawId, t.drawLayer);
        return;
      }
      this._drawingOptions.updateAll(), this._drawId = this.#o(this._drawOutlines, t), this._clipPathId && this.#t && (this.#t.style.clipPath = this._clipPathId);
    }
  }
  #d([t, e, s, i]) {
    const {
      parentDimensions: [n, r],
      _drawRotation: a
    } = this;
    switch (a) {
      case 90:
        return [e, 1 - t, s * (r / n), i * (n / r)];
      case 180:
        return [1 - t, 1 - e, s, i];
      case 270:
        return [1 - e, t, s * (r / n), i * (n / r)];
      default:
        return [t, e, s, i];
    }
  }
  #g() {
    const {
      x: t,
      y: e,
      width: s,
      height: i,
      parentDimensions: [n, r],
      _drawRotation: a
    } = this;
    switch (a) {
      case 90:
        return [1 - e, t, s * (n / r), i * (r / n)];
      case 180:
        return [1 - t, 1 - e, s, i];
      case 270:
        return [e, 1 - t, s * (n / r), i * (r / n)];
      default:
        return [t, e, s, i];
    }
  }
  #b(t) {
    [this.x, this.y, this.width, this.height] = this.#d(t), this.div && (this.fixAndSetPosition(), this.setDims()), this._onResized();
  }
  #y(t = this.parentRotation) {
    const {
      x: e,
      y: s,
      width: i,
      height: n,
      _drawRotation: r,
      parentDimensions: [a, o]
    } = this;
    switch ((r * 4 + t) / 90) {
      case 1:
        return [1 - s - n, e, n, i];
      case 2:
        return [1 - e - i, 1 - s - n, i, n];
      case 3:
        return [s, 1 - e - i, n, i];
      case 4:
        return [e, s - i * (a / o), n * (o / a), i * (a / o)];
      case 5:
        return [1 - s, e, i * (a / o), n * (o / a)];
      case 6:
        return [1 - e - n * (o / a), 1 - s, n * (o / a), i * (a / o)];
      case 7:
        return [s - i * (a / o), 1 - e - n * (o / a), i * (a / o), n * (o / a)];
      case 8:
        return [e - i, s - n, i, n];
      case 9:
        return [1 - s, e - i, n, i];
      case 10:
        return [1 - e, 1 - s, i, n];
      case 11:
        return [s - n, 1 - e, n, i];
      case 12:
        return [e - n * (o / a), s, n * (o / a), i * (a / o)];
      case 13:
        return [1 - s - i * (a / o), e - n * (o / a), i * (a / o), n * (o / a)];
      case 14:
        return [1 - e, 1 - s - i * (a / o), n * (o / a), i * (a / o)];
      case 15:
        return [s, 1 - e, i * (a / o), n * (o / a)];
      default:
        return [e, s, i, n];
    }
  }
  rotate(t = this.parentRotation) {
    if (!this.parent || this._drawId === null)
      return;
    const e = (t - this._drawRotation + 360) % 360;
    this.parent.drawLayer.updateProperties(this._drawId, H._mergeSVGProperties({
      bbox: this.#y(t)
    }, this._drawOutlines.updateRotation(e))), this.#h(e);
  }
  show(t = this._isVisible) {
    super.show(t), this.#c();
  }
  select() {
    super.select(), this.#u({
      hovered: !1,
      selected: !0
    });
  }
  unselect() {
    super.unselect(), this.#u({
      selected: !1
    });
  }
  pointerover() {
    this.isSelected || this.#u({
      hovered: !0
    });
  }
  pointerleave() {
    this.isSelected || this.#u({
      hovered: !1
    });
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    const t = this._drawOutlines.updateParentDimensions(this.parentDimensions, this.parent.scale);
    t && this.#b(t);
  }
  static onScaleChangingWhenDrawing() {
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    this._isCopy && (t = this.x, e = this.y);
    const s = super.render();
    this.constructor._hasDrawClass && s.classList.add("draw");
    const i = this.#t = document.createElement("div");
    return s.append(i), i.setAttribute("aria-hidden", "true"), i.className = "internal", this._clipPathId && (i.style.clipPath = this._clipPathId), en(this, i, ["pointerover", "pointerleave"]), this.setDims(), this._uiManager.addShouldRescale(this), this.disableEditing(), this._isCopy && this._moveAfterPaste(t, e), s;
  }
  static createDrawerInstance(t) {
    j("Not implemented");
  }
  static _getDrawingTarget(t, {
    target: e
  }) {
    return e;
  }
  static _getPointerCoords({
    offsetX: t,
    offsetY: e,
    clientX: s,
    clientY: i
  }, n = null) {
    if (!n)
      return [t, e];
    let r = s - n.clientX, a = i - n.clientY;
    switch (this._currentParent.viewport.rotation) {
      case 90:
        [r, a] = [a, -r];
        break;
      case 180:
        [r, a] = [-r, -a];
        break;
      case 270:
        [r, a] = [-a, r];
        break;
    }
    return [n.offsetX + r, n.offsetY + a];
  }
  static _addDrawingListeners(t, e) {
  }
  static _endDrawingSession(t = !1) {
    return this._currentParent.endDrawingSession(t);
  }
  static startDrawing(t, e, s, i) {
    const {
      pointerId: n,
      pointerType: r
    } = i;
    if ($.isInitializedAndDifferentPointerType(r))
      return;
    const a = this._getDrawingTarget(t, i), [o, l] = this._getPointerCoords(i), {
      viewport: {
        rotation: h
      }
    } = t, {
      x: c,
      y: u,
      width: f,
      height: p
    } = a.getBoundingClientRect(), g = H.#i = new AbortController(), m = t.combinedSignal(g);
    if ($.setPointer(r, n), window.addEventListener("pointerup", (A) => {
      $.isSamePointerIdOrRemove(A.pointerId) && this._endDraw(A);
    }, {
      signal: m
    }), window.addEventListener("pointercancel", (A) => {
      $.isSamePointerIdOrRemove(A.pointerId) && this._endDrawingSession();
    }, {
      signal: m
    }), window.addEventListener("pointerdown", (A) => {
      $.isSamePointerType(A.pointerType) && ($.initializeAndAddPointerId(A.pointerId), H.#s.isCancellable() && (H.#s.removeLastElement(), H.#s.isEmpty() ? this._endDrawingSession(!0) : this._endDraw(null)));
    }, {
      capture: !0,
      passive: !1,
      signal: m
    }), window.addEventListener("contextmenu", xt, {
      signal: m
    }), a.addEventListener("pointermove", this._drawMove.bind(this), {
      signal: m
    }), a.addEventListener("touchmove", (A) => {
      $.isSameTimeStamp(A.timeStamp) && nt(A);
    }, {
      signal: m
    }), this._addDrawingListeners(a, m), t.toggleDrawing(), e._editorUndoBar?.hide(), H.#s) {
      t.drawLayer.updateProperties(this._currentDrawId, H.#s.startNew(o, l, f, p, h, i.timeStamp));
      return;
    }
    e.updateUIForDefaultProperties(this), H.#s = this.createDrawerInstance({
      x: o,
      y: l,
      box: [c, u, f, p],
      rotation: h,
      parent: t,
      isLTR: s,
      timeStamp: i.timeStamp
    }), H.#n = this.getDefaultDrawingOptions(), this._currentParent = t;
    const {
      id: b,
      clipPathId: y
    } = t.drawLayer.draw(this._mergeSVGProperties(H.#n.toSVGProperties(), H.#s.defaultSVGProperties), !0, this._hasClipPath);
    this._currentDrawId = b, H.#r = this._hasClipPath ? y : null;
  }
  static _drawMove(t) {
    if ($.isSameTimeStamp(t.timeStamp), !H.#s || !$.isSamePointerId(t.pointerId))
      return;
    if ($.isUsingMultiplePointers()) {
      this._endDraw(t);
      return;
    }
    let e;
    const s = t.getCoalescedEvents?.();
    if (s?.length) {
      const i = [], n = [];
      for (const r of s)
        i.push(...this._getPointerCoords(r, t)), n.push(r.timeStamp);
      e = H.#s.addPoints(i, n);
    } else
      e = H.#s.add(...this._getPointerCoords(t), t.timeStamp);
    this._currentParent.drawLayer.updateProperties(this._currentDrawId, e), $.setTimeStamp(t.timeStamp), nt(t);
  }
  static _cleanup(t) {
    t && (this._currentDrawId = -1, this._currentParent = null, H.#s = null, H.#n = null, H.#r = null, $.clearTimeStamp()), H.#i && (H.#i.abort(), H.#i = null, $.clearPointerIds());
  }
  static _endDraw(t) {
    const e = this._currentParent;
    if (e) {
      if (e.toggleDrawing(!0), this._cleanup(!1), e.drawLayer.updateProperties(this._currentDrawId, t?.target === e.div ? H.#s.end(...this._getPointerCoords(t), t.timeStamp) : H.#s.end()), this.supportMultipleDrawings) {
        const s = H.#s, i = this._currentDrawId, n = s.getLastElement();
        e.addCommands({
          cmd: () => {
            e.drawLayer.updateProperties(i, s.setLastElement(n));
          },
          undo: () => {
            e.drawLayer.updateProperties(i, s.removeLastElement());
          },
          mustExec: !1,
          type: U.DRAW_STEP
        });
        return;
      }
      this.endDrawing(!1);
    }
  }
  static endDrawing(t) {
    const e = this._currentParent;
    if (!e)
      return null;
    if (e.toggleDrawing(!0), e.cleanUndoStack(U.DRAW_STEP), !H.#s.isEmpty()) {
      const {
        pageDimensions: [s, i],
        scale: n
      } = e, r = e.createAndAddNewEditor({
        offsetX: 0,
        offsetY: 0
      }, !1, {
        drawId: this._currentDrawId,
        clipPathId: H.#r,
        drawOutlines: H.#s.getOutlines(s * n, i * n, n, this._INNER_MARGIN),
        drawingOptions: H.#n,
        mustBeCommitted: !t
      });
      return this._cleanup(!0), r;
    }
    return e.drawLayer.remove(this._currentDrawId), this._cleanup(!0), null;
  }
  createDrawingOptions(t) {
  }
  static deserializeDraw(t, e, s, i, n, r, a) {
    j("Not implemented");
  }
  static async deserialize(t, e, s) {
    const {
      rawDims: {
        pageWidth: i,
        pageHeight: n,
        pageX: r,
        pageY: a
      }
    } = e.viewport, o = this.deserializeDraw(r, a, i, n, this._INNER_MARGIN, t, s), l = await super.deserialize(t, e, s);
    return l.createDrawingOptions(t), l.#a({
      drawOutlines: o
    }), l.#m(), l.onScaleChanging(), l.rotate(), l;
  }
  serializeDraw(t) {
    const [e, s] = this.pageTranslation, [i, n] = this.pageDimensions;
    return this._drawOutlines.serialize([e, s, i, n], t);
  }
  renderAnnotationElement(t) {
    return t.updateEdited({
      rect: this.getPDFRect()
    }), null;
  }
  static canCreateNewEmptyEditor() {
    return !1;
  }
}
class M {
  static PRECISION = 1e-4;
  focusOutline = null;
  toSVGPath() {
    j("Abstract method `toSVGPath` must be implemented.");
  }
  get box() {
    j("Abstract getter `box` must be implemented.");
  }
  serialize(t, e) {
    j("Abstract method `serialize` must be implemented.");
  }
  get defaultSVGProperties() {
    j("Abstract getter `defaultSVGProperties` must be implemented.");
  }
  get defaultProperties() {
    return this.defaultSVGProperties;
  }
  getFocusSVGProperties(t) {
    return null;
  }
  get focusMustRemoveSelfIntersections() {
    return !1;
  }
  updateProperty(t, e) {
    return null;
  }
  updateParentDimensions(t, e) {
    return null;
  }
  serializeQuadPoints(t, e) {
    return null;
  }
  updateRotation(t) {
    return {};
  }
  getPathResizingSVGProperties(t) {
    return {};
  }
  getPathResizedSVGProperties(t) {
    return {};
  }
  getPathTranslatedSVGProperties(t, e) {
    return {};
  }
  static _rotateBox([t, e, s, i], n) {
    switch (n) {
      case 90:
        return [1 - e - i, t, i, s];
      case 180:
        return [1 - t - s, 1 - e - i, s, i];
      case 270:
        return [e, 1 - t - s, i, s];
    }
    return [t, e, s, i];
  }
  static _rescale(t, e, s, i, n, r) {
    r ||= new Float32Array(t.length);
    for (let a = 0, o = t.length; a < o; a += 2)
      r[a] = e + t[a] * i, r[a + 1] = s + t[a + 1] * n;
    return r;
  }
  static _rescaleAndSwap(t, e, s, i, n, r) {
    r ||= new Float32Array(t.length);
    for (let a = 0, o = t.length; a < o; a += 2)
      r[a] = e + t[a + 1] * i, r[a + 1] = s + t[a] * n;
    return r;
  }
  static _translate(t, e, s, i) {
    i ||= new Float32Array(t.length);
    for (let n = 0, r = t.length; n < r; n += 2)
      i[n] = e + t[n], i[n + 1] = s + t[n + 1];
    return i;
  }
  static svgRound(t) {
    return Math.round(t * 1e4);
  }
  static _normalizePoint(t, e, s, i, n, r = []) {
    switch (n) {
      case 90:
        r[0] = 1 - e / s, r[1] = t / i;
        break;
      case 180:
        r[0] = 1 - t / s, r[1] = 1 - e / i;
        break;
      case 270:
        r[0] = e / s, r[1] = 1 - t / i;
        break;
      default:
        r[0] = t / s, r[1] = e / i;
        break;
    }
    return r;
  }
  static createBezierPoints(t, e, s, i, n, r, a = []) {
    return a.push((t + 5 * s) / 6, (e + 5 * i) / 6, (5 * s + n) / 6, (5 * i + r) / 6, (s + n) / 2, (i + r) / 2), a;
  }
}
class ie {
  #t;
  #e = [];
  #s;
  #i;
  #n = [];
  #r = new Float32Array(18);
  #a;
  #o;
  #l;
  #h;
  #u;
  #c;
  #f = [];
  static #p = 8;
  static #m = 2;
  static #d = ie.#p + ie.#m;
  constructor(t, e, s, i, n, r, a = 0) {
    this.#t = s, this.#c = n * i, this.#i = r, this.#r.set([NaN, NaN, NaN, NaN, t, e], 6), this.#s = a, this.#h = ie.#p * i, this.#l = ie.#d * i, this.#u = i, this.#f.push(t, e);
  }
  isEmpty() {
    return isNaN(this.#r[8]);
  }
  isCancellable() {
    return this.#f.length <= 10;
  }
  removeLastElement() {
    return this.#r.fill(NaN), this.#n.length = this.#e.length = this.#f.length = 0, {
      path: {
        d: ""
      }
    };
  }
  #g() {
    const t = this.#r.subarray(4, 6), e = this.#r.subarray(16, 18), [s, i, n, r] = this.#t;
    return [(this.#a + (t[0] - e[0]) / 2 - s) / n, (this.#o + (t[1] - e[1]) / 2 - i) / r, (this.#a + (e[0] - t[0]) / 2 - s) / n, (this.#o + (e[1] - t[1]) / 2 - i) / r];
  }
  add(t, e) {
    this.#a = t, this.#o = e;
    const [s, i, n, r] = this.#t;
    let [a, o, l, h] = this.#r.subarray(8, 12);
    const c = t - l, u = e - h, f = Math.hypot(c, u);
    if (f < this.#l)
      return !1;
    const p = f - this.#h, g = p / f, m = g * c, b = g * u;
    let y = a, A = o;
    a = l, o = h, l += m, h += b, this.#f?.push(t, e);
    const w = -b / p, v = m / p, S = w * this.#c, _ = v * this.#c;
    return this.#r.set(this.#r.subarray(2, 8), 0), this.#r.set([l + S, h + _], 4), this.#r.set(this.#r.subarray(14, 18), 12), this.#r.set([l - S, h - _], 16), isNaN(this.#r[6]) ? (this.#n.length === 0 && (this.#r.set([a + S, o + _], 2), this.#n.push(NaN, NaN, NaN, NaN, (a + S - s) / n, (o + _ - i) / r), this.#r.set([a - S, o - _], 14), this.#e.push(NaN, NaN, NaN, NaN, (a - S - s) / n, (o - _ - i) / r)), this.#r.set([y, A, a, o, l, h], 6), !this.isEmpty()) : (this.#r.set([y, A, a, o, l, h], 6), Math.abs(Math.atan2(A - o, y - a) - Math.atan2(b, m)) < Math.PI / 2 ? ([a, o, l, h] = this.#r.subarray(2, 6), this.#n.push(NaN, NaN, NaN, NaN, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), [a, o, y, A] = this.#r.subarray(14, 18), this.#e.push(NaN, NaN, NaN, NaN, ((y + a) / 2 - s) / n, ((A + o) / 2 - i) / r), !0) : ([y, A, a, o, l, h] = this.#r.subarray(0, 6), this.#n.push(((y + 5 * a) / 6 - s) / n, ((A + 5 * o) / 6 - i) / r, ((5 * a + l) / 6 - s) / n, ((5 * o + h) / 6 - i) / r, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), [l, h, a, o, y, A] = this.#r.subarray(12, 18), this.#e.push(((y + 5 * a) / 6 - s) / n, ((A + 5 * o) / 6 - i) / r, ((5 * a + l) / 6 - s) / n, ((5 * o + h) / 6 - i) / r, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), !0));
  }
  toSVGPath() {
    if (this.isEmpty())
      return "";
    const t = this.#n, e = this.#e;
    if (isNaN(this.#r[6]) && !this.isEmpty())
      return this.#b();
    const s = [];
    s.push(`M${t[4]} ${t[5]}`);
    for (let i = 6; i < t.length; i += 6)
      isNaN(t[i]) ? s.push(`L${t[i + 4]} ${t[i + 5]}`) : s.push(`C${t[i]} ${t[i + 1]} ${t[i + 2]} ${t[i + 3]} ${t[i + 4]} ${t[i + 5]}`);
    this.#A(s);
    for (let i = e.length - 6; i >= 6; i -= 6)
      isNaN(e[i]) ? s.push(`L${e[i + 4]} ${e[i + 5]}`) : s.push(`C${e[i]} ${e[i + 1]} ${e[i + 2]} ${e[i + 3]} ${e[i + 4]} ${e[i + 5]}`);
    return this.#y(s), s.join(" ");
  }
  #b() {
    const [t, e, s, i] = this.#t, [n, r, a, o] = this.#g();
    return `M${(this.#r[2] - t) / s} ${(this.#r[3] - e) / i} L${(this.#r[4] - t) / s} ${(this.#r[5] - e) / i} L${n} ${r} L${a} ${o} L${(this.#r[16] - t) / s} ${(this.#r[17] - e) / i} L${(this.#r[14] - t) / s} ${(this.#r[15] - e) / i} Z`;
  }
  #y(t) {
    const e = this.#e;
    t.push(`L${e[4]} ${e[5]} Z`);
  }
  #A(t) {
    const [e, s, i, n] = this.#t, r = this.#r.subarray(4, 6), a = this.#r.subarray(16, 18), [o, l, h, c] = this.#g();
    t.push(`L${(r[0] - e) / i} ${(r[1] - s) / n} L${o} ${l} L${h} ${c} L${(a[0] - e) / i} ${(a[1] - s) / n}`);
  }
  newFreeDrawOutline(t, e, s, i, n, r) {
    return new kn(t, e, s, i, n, r);
  }
  getOutlines() {
    const t = this.#n, e = this.#e, s = this.#r, [i, n, r, a] = this.#t, o = new Float32Array((this.#f?.length ?? 0) + 2);
    for (let c = 0, u = o.length - 2; c < u; c += 2)
      o[c] = (this.#f[c] - i) / r, o[c + 1] = (this.#f[c + 1] - n) / a;
    if (o[o.length - 2] = (this.#a - i) / r, o[o.length - 1] = (this.#o - n) / a, isNaN(s[6]) && !this.isEmpty())
      return this.#w(o);
    const l = new Float32Array(this.#n.length + 24 + this.#e.length);
    let h = t.length;
    for (let c = 0; c < h; c += 2) {
      if (isNaN(t[c])) {
        l[c] = l[c + 1] = NaN;
        continue;
      }
      l[c] = t[c], l[c + 1] = t[c + 1];
    }
    h = this.#_(l, h);
    for (let c = e.length - 6; c >= 6; c -= 6)
      for (let u = 0; u < 6; u += 2) {
        if (isNaN(e[c + u])) {
          l[h] = l[h + 1] = NaN, h += 2;
          continue;
        }
        l[h] = e[c + u], l[h + 1] = e[c + u + 1], h += 2;
      }
    return this.#S(l, h), this.newFreeDrawOutline(l, o, this.#t, this.#u, this.#s, this.#i);
  }
  #w(t) {
    const e = this.#r, [s, i, n, r] = this.#t, [a, o, l, h] = this.#g(), c = new Float32Array(36);
    return c.set([NaN, NaN, NaN, NaN, (e[2] - s) / n, (e[3] - i) / r, NaN, NaN, NaN, NaN, (e[4] - s) / n, (e[5] - i) / r, NaN, NaN, NaN, NaN, a, o, NaN, NaN, NaN, NaN, l, h, NaN, NaN, NaN, NaN, (e[16] - s) / n, (e[17] - i) / r, NaN, NaN, NaN, NaN, (e[14] - s) / n, (e[15] - i) / r], 0), this.newFreeDrawOutline(c, t, this.#t, this.#u, this.#s, this.#i);
  }
  #S(t, e) {
    const s = this.#e;
    return t.set([NaN, NaN, NaN, NaN, s[4], s[5]], e), e += 6;
  }
  #_(t, e) {
    const s = this.#r.subarray(4, 6), i = this.#r.subarray(16, 18), [n, r, a, o] = this.#t, [l, h, c, u] = this.#g();
    return t.set([NaN, NaN, NaN, NaN, (s[0] - n) / a, (s[1] - r) / o, NaN, NaN, NaN, NaN, l, h, NaN, NaN, NaN, NaN, c, u, NaN, NaN, NaN, NaN, (i[0] - n) / a, (i[1] - r) / o], e), e += 24;
  }
}
class kn extends M {
  #t;
  #e = new Float32Array(4);
  #s;
  #i;
  #n;
  #r;
  #a;
  constructor(t, e, s, i, n, r) {
    super(), this.#a = t, this.#n = e, this.#t = s, this.#r = i, this.#s = n, this.#i = r, this.firstPoint = [NaN, NaN], this.lastPoint = [NaN, NaN], this.#o(r);
    const [a, o, l, h] = this.#e;
    for (let c = 0, u = t.length; c < u; c += 2)
      t[c] = (t[c] - a) / l, t[c + 1] = (t[c + 1] - o) / h;
    for (let c = 0, u = e.length; c < u; c += 2)
      e[c] = (e[c] - a) / l, e[c + 1] = (e[c + 1] - o) / h;
  }
  toSVGPath() {
    const t = [`M${this.#a[4]} ${this.#a[5]}`];
    for (let e = 6, s = this.#a.length; e < s; e += 6) {
      if (isNaN(this.#a[e])) {
        t.push(`L${this.#a[e + 4]} ${this.#a[e + 5]}`);
        continue;
      }
      t.push(`C${this.#a[e]} ${this.#a[e + 1]} ${this.#a[e + 2]} ${this.#a[e + 3]} ${this.#a[e + 4]} ${this.#a[e + 5]}`);
    }
    return t.push("Z"), t.join(" ");
  }
  serialize([t, e, s, i], n) {
    const r = s - t, a = i - e;
    let o, l;
    switch (n) {
      case 0:
        o = M._rescale(this.#a, t, i, r, -a), l = M._rescale(this.#n, t, i, r, -a);
        break;
      case 90:
        o = M._rescaleAndSwap(this.#a, t, e, r, a), l = M._rescaleAndSwap(this.#n, t, e, r, a);
        break;
      case 180:
        o = M._rescale(this.#a, s, e, -r, a), l = M._rescale(this.#n, s, e, -r, a);
        break;
      case 270:
        o = M._rescaleAndSwap(this.#a, s, i, -r, -a), l = M._rescaleAndSwap(this.#n, s, i, -r, -a);
        break;
    }
    return {
      outline: Array.from(o),
      points: [Array.from(l)]
    };
  }
  #o(t) {
    const e = this.#a;
    let s = e[4], i = e[5];
    const n = [s, i, s, i];
    let r = s, a = i, o = s, l = i;
    const h = t ? Math.max : Math.min, c = new Float32Array(4);
    for (let f = 6, p = e.length; f < p; f += 6) {
      const g = e[f + 4], m = e[f + 5];
      isNaN(e[f]) ? (x.pointBoundingBox(g, m, n), a > m ? (r = g, a = m) : a === m && (r = h(r, g)), l < m ? (o = g, l = m) : l === m && (o = h(o, g))) : (c.set(Dt, 0), x.bezierBoundingBox(s, i, ...e.slice(f, f + 6), c), x.rectBoundingBox(...c, n), a > c[1] ? (r = c[0], a = c[1]) : a === c[1] && (r = h(r, c[0])), l < c[3] ? (o = c[2], l = c[3]) : l === c[3] && (o = h(o, c[2]))), s = g, i = m;
    }
    const u = this.#e;
    u[0] = n[0] - this.#s, u[1] = n[1] - this.#s, u[2] = n[2] - n[0] + 2 * this.#s, u[3] = n[3] - n[1] + 2 * this.#s, this.firstPoint = [r, a], this.lastPoint = [o, l];
  }
  get box() {
    return this.#e;
  }
  newOutliner(t, e, s, i, n, r, a = 0) {
    return new ie(t, e, s, i, n, r, a);
  }
  updateThickness(t) {
    const e = this.getNewOutline(t);
    return this.#a = e.#a, this.#n = e.#n, this.#e.set(e.#e), this.firstPoint = e.firstPoint, this.lastPoint = e.lastPoint, this.#e;
  }
  getNewOutline(t, e) {
    const [s, i, n, r] = this.#e, [a, o, l, h] = this.#t, c = n * l, u = r * h, f = s * l + a, p = i * h + o, g = this.#n, m = this.newOutliner(g[0] * c + f, g[1] * u + p, this.#t, this.#r, t, this.#i, e ?? this.#s);
    for (let b = 2, y = g.length; b < y; b += 2)
      m.add(g[b] * c + f, g[b + 1] * u + p);
    return m.getOutlines();
  }
}
function Pn(d) {
  return {
    bbox: d.box,
    root: {
      viewBox: "0 0 1 1"
    },
    rootClass: {
      highlight: !0,
      free: d.isFree
    },
    path: {
      d: d.toSVGPath()
    }
  };
}
function Mn(d, t) {
  const {
    focusOutline: e
  } = d;
  return {
    bbox: M._rotateBox(e.box, t),
    root: {
      "data-main-rotation": t
    },
    rootClass: {
      highlightOutline: !0,
      free: d.isFree
    },
    path: {
      d: e.toSVGPath()
    }
  };
}
class Vs {
  #t;
  #e;
  #s;
  #i = [];
  #n = [];
  constructor(t, e = 0, s = 0, i = !0) {
    const n = Dt.slice(), r = 10 ** -4;
    for (const {
      x: g,
      y: m,
      width: b,
      height: y
    } of t) {
      const A = Math.floor((g - e) / r) * r, w = Math.ceil((g + b + e) / r) * r, v = Math.floor((m - e) / r) * r, S = Math.ceil((m + y + e) / r) * r, _ = [A, v, S, !0], E = [w, v, S, !1];
      this.#i.push(_, E), x.rectBoundingBox(A, v, w, S, n);
    }
    const a = n[2] - n[0] + 2 * s, o = n[3] - n[1] + 2 * s, l = n[0] - s, h = n[1] - s;
    let c = i ? -1 / 0 : 1 / 0, u = 1 / 0;
    const f = this.#i.at(i ? -1 : -2), p = [f[0], f[2]];
    for (const g of this.#i) {
      const [m, b, y, A] = g;
      !A && i ? b < u ? (u = b, c = m) : b === u && (c = Math.max(c, m)) : A && !i && (b < u ? (u = b, c = m) : b === u && (c = Math.min(c, m))), g[0] = (m - l) / a, g[1] = (b - h) / o, g[2] = (y - h) / o;
    }
    this.#t = new Float32Array([l, h, a, o]), this.#e = [c, u], this.#s = p;
  }
  getOutlines() {
    this.#i.sort((e, s) => e[0] - s[0] || e[1] - s[1] || e[2] - s[2]);
    const t = [];
    for (const e of this.#i)
      e[3] ? (t.push(...this.#h(e)), this.#o(e)) : (this.#l(e), t.push(...this.#h(e)));
    return this.#r(t);
  }
  #r(t) {
    const e = [], s = /* @__PURE__ */ new Set();
    for (const n of t) {
      const [r, a, o] = n;
      e.push([r, a, n], [r, o, n]);
    }
    e.sort((n, r) => n[1] - r[1] || n[0] - r[0]);
    for (let n = 0, r = e.length; n < r; n += 2) {
      const a = e[n][2], o = e[n + 1][2];
      a.push(o), o.push(a), s.add(a), s.add(o);
    }
    const i = [];
    for (; s.size > 0; ) {
      const n = s.values().next().value;
      let [r, a, o, l, h] = n;
      s.delete(n);
      let c = r, u = a;
      const f = [r, o];
      for (i.push(f); ; ) {
        let p;
        if (s.has(l))
          p = l;
        else if (s.has(h))
          p = h;
        else
          break;
        s.delete(p), [r, a, o, l, h] = p, c !== r && (f.push(c, u, r, u === a ? a : o), c = r), u = u === a ? o : a;
      }
      f.push(c, u);
    }
    return new Xs(i, this.#t, this.#e, this.#s);
  }
  #a(t) {
    const e = this.#n;
    let s = 0, i = e.length - 1;
    for (; s <= i; ) {
      const n = s + i >> 1, r = e[n][0];
      if (r === t)
        return n;
      r < t ? s = n + 1 : i = n - 1;
    }
    return i + 1;
  }
  #o([, t, e]) {
    const s = this.#a(t);
    this.#n.splice(s, 0, [t, e]);
  }
  #l([, t, e]) {
    const s = this.#a(t);
    for (let i = s; i < this.#n.length; i++) {
      const [n, r] = this.#n[i];
      if (n !== t)
        break;
      if (n === t && r === e) {
        this.#n.splice(i, 1);
        return;
      }
    }
    for (let i = s - 1; i >= 0; i--) {
      const [n, r] = this.#n[i];
      if (n !== t)
        break;
      if (n === t && r === e) {
        this.#n.splice(i, 1);
        return;
      }
    }
  }
  #h(t) {
    const [e, s, i] = t, n = [[e, s, i]], r = this.#a(i);
    for (let a = 0; a < r; a++) {
      const [o, l] = this.#n[a];
      for (let h = 0, c = n.length; h < c; h++) {
        const [, u, f] = n[h];
        if (!(l <= u || f <= o)) {
          if (u >= o) {
            if (f > l)
              n[h][1] = l;
            else {
              if (c === 1)
                return [];
              n.splice(h, 1), h--, c--;
            }
            continue;
          }
          n[h][2] = o, f > l && n.push([e, l, f]);
        }
      }
    }
    return n;
  }
}
class Xs extends M {
  #t;
  #e = null;
  #s;
  constructor(t, e, s, i) {
    super(), this.#s = t, this.#t = e, this.firstPoint = s, this.lastPoint = i;
  }
  static build(t, e) {
    const s = new Vs(t, 1e-3).getOutlines();
    return s.#e = t, s.focusOutline = new Vs(t, 25e-4, 1e-3, e).getOutlines(), s;
  }
  get isFree() {
    return !1;
  }
  get defaultSVGProperties() {
    return Pn(this);
  }
  getFocusSVGProperties(t) {
    return Mn(this, t);
  }
  updateRotation(t) {
    return {
      root: {
        "data-main-rotation": t
      }
    };
  }
  serializeQuadPoints([t, e], [s, i]) {
    const n = this.#e, r = new Float32Array(n.length * 8);
    let a = 0;
    for (const {
      x: o,
      y: l,
      width: h,
      height: c
    } of n) {
      const u = o * s + t, f = (1 - l) * i + e;
      r[a] = r[a + 4] = u, r[a + 1] = r[a + 3] = f, r[a + 2] = r[a + 6] = u + h * s, r[a + 5] = r[a + 7] = f - c * i, a += 8;
    }
    return r;
  }
  toSVGPath() {
    const t = [];
    for (const e of this.#s) {
      let [s, i] = e;
      t.push(`M${s} ${i}`);
      for (let n = 2; n < e.length; n += 2) {
        const r = e[n], a = e[n + 1];
        r === s ? (t.push(`V${a}`), i = a) : a === i && (t.push(`H${r}`), s = r);
      }
      t.push("Z");
    }
    return t.join(" ");
  }
  serialize([t, e, s, i], n) {
    const r = [], a = s - t, o = i - e;
    for (const l of this.#s) {
      const h = new Array(l.length);
      for (let c = 0; c < l.length; c += 2)
        h[c] = t + l[c] * a, h[c + 1] = i - l[c + 1] * o;
      r.push(h);
    }
    return r;
  }
  get box() {
    return this.#t;
  }
}
class ci extends ie {
  newFreeDrawOutline(t, e, s, i, n, r) {
    return new di(t, e, s, i, n, r);
  }
}
class Wa {
  #t;
  #e;
  constructor(t, e, s, i, n, r, a) {
    this.#t = new ci(t, e, s, i, n, r, a), this.#e = n;
  }
  add(t, e) {
    return this.#t.add(t, e) ? {
      path: {
        d: this.#t.toSVGPath()
      }
    } : null;
  }
  addPoints(t) {
    let e = !1;
    for (let s = 0, i = t.length; s < i; s += 2)
      e = this.#t.add(t[s], t[s + 1]) || e;
    return e ? {
      path: {
        d: this.#t.toSVGPath()
      }
    } : null;
  }
  end(t, e) {
    return t === void 0 ? null : this.add(t, e);
  }
  isEmpty() {
    return this.#t.isEmpty();
  }
  isCancellable() {
    return this.#t.isCancellable();
  }
  removeLastElement() {
    return this.#t.removeLastElement();
  }
  updateProperty(t, e) {
    return null;
  }
  getOutlines() {
    const t = this.#t.getOutlines();
    return t.buildFocusOutline(2 * this.#e), t;
  }
  get defaultSVGProperties() {
    return {
      bbox: [0, 0, 1, 1],
      root: {
        viewBox: "0 0 1 1"
      },
      rootClass: {
        highlight: !0,
        free: !0
      },
      path: {
        d: this.#t.toSVGPath()
      }
    };
  }
}
class di extends kn {
  static #t = 1.5;
  newOutliner(t, e, s, i, n, r, a = 0) {
    return new ci(t, e, s, i, n, r, a);
  }
  get isFree() {
    return !0;
  }
  buildFocusOutline(t) {
    this.focusOutline = this.getNewOutline(t / 2 + di.#t, 25e-4);
  }
  get defaultSVGProperties() {
    return Pn(this);
  }
  getFocusSVGProperties(t) {
    return Mn(this, t);
  }
  get focusMustRemoveSelfIntersections() {
    return !0;
  }
  updateRotation(t) {
    return {
      root: {
        "data-main-rotation": t
      }
    };
  }
  updateProperty(t, e) {
    if (t !== "thickness")
      return null;
    const s = this.updateThickness(e / 2);
    return this.buildFocusOutline(e), s;
  }
  getPathResizedSVGProperties() {
    return {
      path: {
        d: this.toSVGPath()
      }
    };
  }
}
class ui extends hi {
  constructor(t = null) {
    super(), super.updateProperties(t);
  }
  updateSVGProperty(t, e) {
    t !== "thickness" && super.updateSVGProperty(t, e);
  }
  clone() {
    const t = new ui();
    return t.updateAll(this), t;
  }
}
class Ct extends H {
  #t = null;
  #e = 0;
  #s = null;
  #i = 0;
  #n = "";
  #r = "";
  static _DEFAULT_OPACITY = 1;
  static _DEFAULT_THICKNESS = 12;
  static _defaultDrawingOptions = null;
  static _type = "highlight";
  static _editorType = B.HIGHLIGHT;
  static get _keyboardManager() {
    const t = Ct.prototype;
    return k(this, "_keyboardManager", new yt([[["ArrowLeft"], t._moveCaret, {
      args: [0]
    }], [["ArrowRight"], t._moveCaret, {
      args: [1]
    }], [["ArrowUp"], t._moveCaret, {
      args: [2]
    }], [["ArrowDown"], t._moveCaret, {
      args: [3]
    }]]));
  }
  constructor(t) {
    super({
      ...t,
      name: "highlightEditor"
    }), this.#t = t.anchorNode || null, this.#e = t.anchorOffset || 0, this.#s = t.focusNode || null, this.#i = t.focusOffset || 0, this.#n = t.methodOfCreation || (this._drawOutlines?.isFree ? "main_toolbar" : ""), this.#r = t.text || "", this._isDraggable = !1, this.defaultL10nId = "pdfjs-editor-highlight-editor", this.rotate();
  }
  static initialize(t, e) {
    I.initialize(t, e), this._defaultDrawingOptions ||= new ui({
      fill: e.highlightColors?.values().next().value || "#fff066",
      "fill-opacity": Ct._DEFAULT_OPACITY,
      thickness: Ct._DEFAULT_THICKNESS
    });
  }
  static getDefaultDrawingOptions(t) {
    const e = this._defaultDrawingOptions.clone();
    return e.updateProperties(t), e;
  }
  static get typesMap() {
    return k(this, "typesMap", /* @__PURE__ */ new Map([[U.HIGHLIGHT_COLOR, "fill"], [U.HIGHLIGHT_THICKNESS, "thickness"]]));
  }
  static get isDrawer() {
    return !1;
  }
  static get _hasClipPath() {
    return !0;
  }
  static get _hasDrawClass() {
    return !1;
  }
  _addOutlines(t) {
    const {
      boxes: e,
      drawOutlines: s
    } = t;
    !e && !s || (this._drawingOptions ||= t.drawingOptions || Ct.getDefaultDrawingOptions(), e && (t = {
      ...t,
      drawOutlines: Xs.build(e, this._uiManager.direction === "ltr")
    }), super._addOutlines(t));
  }
  get colorType() {
    return U.HIGHLIGHT_COLOR;
  }
  get color() {
    return this._drawingOptions.fill;
  }
  get opacity() {
    return this._drawingOptions["fill-opacity"];
  }
  get _opacityName() {
    return "fill-opacity";
  }
  get _drawRotation() {
    return this._drawOutlines?.isFree ? this.rotation : 0;
  }
  get isResizable() {
    return !1;
  }
  get _mustBeDisabledOnCommit() {
    return !1;
  }
  get _mustFixPosition() {
    return !this._drawOutlines?.isFree;
  }
  get telemetryInitialData() {
    return {
      action: "added",
      type: this._drawOutlines.isFree ? "free_highlight" : "highlight",
      color: this._uiManager.getNonHCMColorName(this.color),
      thickness: this._drawingOptions.thickness,
      methodOfCreation: this.#n
    };
  }
  get telemetryFinalData() {
    return {
      type: "highlight",
      color: this._uiManager.getNonHCMColorName(this.color)
    };
  }
  static computeTelemetryFinalData(t) {
    return {
      numberOfColors: t.get("color").size
    };
  }
  translateInPage(t, e) {
  }
  get toolbarPosition() {
    return this.#a(this._drawOutlines.focusOutline.lastPoint);
  }
  get commentButtonPosition() {
    return this.#a(this._drawOutlines.firstPoint);
  }
  #a([t, e]) {
    const [s, i, n, r] = this._drawOutlines.box;
    return [(t - s) / n, (e - i) / r];
  }
  updateParams(t, e) {
    switch (t) {
      case U.HIGHLIGHT_COLOR:
        this._updateColorAndOpacity(e, Ct._DEFAULT_OPACITY, t), this._reportTelemetry({
          action: "color_changed",
          color: this._uiManager.getNonHCMColorName(e)
        }, !0);
        break;
      case U.HIGHLIGHT_THICKNESS:
        super.updateParams(t, e), this._reportTelemetry({
          action: "thickness_changed",
          thickness: e
        }, !0);
        break;
    }
  }
  get propertiesToUpdate() {
    const t = super.propertiesToUpdate;
    return t.push([U.HIGHLIGHT_FREE, this._drawOutlines.isFree]), t;
  }
  get toolbarButtons() {
    return this._uiManager.highlightColors ? (this._colorPicker = new _t({
      editor: this
    }), [["colorPicker", this._colorPicker]]) : super.toolbarButtons;
  }
  fixAndSetPosition() {
    return super.fixAndSetPosition(this._drawRotation);
  }
  getRect(t, e) {
    return super.getRect(t, e, this._drawRotation);
  }
  onceAdded(t) {
    this.annotationElementId || this.parent.addUndoableEditor(this), t && this.div.focus();
  }
  remove() {
    this._reportTelemetry({
      action: "deleted"
    }), super.remove();
  }
  render() {
    if (this.div)
      return this.div;
    const t = super.render();
    return this.#r && (t.setAttribute("aria-label", this.#r), t.setAttribute("role", "mark")), this._drawOutlines.isFree ? t.classList.add("free") : t.addEventListener("keydown", this.#o.bind(this), {
      signal: this._uiManager._signal
    }), this.enableEditing(), t;
  }
  #o(t) {
    Ct._keyboardManager.exec(this, t);
  }
  _moveCaret(t) {
    switch (this.parent.unselect(this), t) {
      case 0:
      case 2:
        this.#l(!0);
        break;
      case 1:
      case 3:
        this.#l(!1);
        break;
    }
  }
  #l(t) {
    if (!this.#t)
      return;
    const e = window.getSelection();
    t ? e.setPosition(this.#t, this.#e) : e.setPosition(this.#s, this.#i);
  }
  unselect() {
    super.unselect(), this._drawOutlines.isFree || this.#l(!1);
  }
  static createDrawerInstance({
    x: t,
    y: e,
    box: s,
    parent: i,
    isLTR: n
  }) {
    return new Wa(t, e, s, i.scale, this._defaultDrawingOptions.thickness / 2, n, 1e-3);
  }
  static _getDrawingTarget(t, {
    target: e
  }) {
    return e.closest(".textLayer");
  }
  static _getPointerCoords({
    x: t,
    y: e
  }) {
    return [t, e];
  }
  static _addDrawingListeners(t, e) {
    t.classList.add("free"), e.addEventListener("abort", () => t.classList.remove("free"), {
      once: !0
    }), window.addEventListener("blur", () => this._endDraw(null), {
      signal: e
    }), window.addEventListener("pointerdown", nt, {
      capture: !0,
      passive: !1,
      signal: e
    });
  }
  static _endDrawingSession(t = !1) {
    return this.endDrawing(t);
  }
  createDrawingOptions({
    color: t,
    opacity: e,
    thickness: s
  }) {
    const {
      _defaultDrawingOptions: i,
      _DEFAULT_OPACITY: n
    } = Ct;
    this._drawingOptions = Ct.getDefaultDrawingOptions({
      fill: x.makeHexColor(...t),
      "fill-opacity": e || n,
      thickness: s || i.thickness
    });
  }
  static deserializeDraw(t, e, s, i, n, r, a) {
    const {
      quadPoints: o
    } = r;
    if (o) {
      const f = [];
      for (let p = 0, g = o.length; p < g; p += 8)
        f.push({
          x: (o[p] - t) / s,
          y: 1 - (o[p + 1] - e) / i,
          width: (o[p + 2] - o[p]) / s,
          height: (o[p + 1] - o[p + 5]) / i
        });
      return Xs.build(f, a.direction === "ltr");
    }
    const l = r.thickness || this._defaultDrawingOptions.thickness, h = (r.inkLists || r.outlines.points)[0], c = new ci(h[0] - t, i - (h[1] - e), [0, 0, s, i], 1, l / 2, !0, 1e-3);
    for (let f = 0, p = h.length; f < p; f += 2)
      c.add(h[f] - t, i - (h[f + 1] - e));
    const u = c.getOutlines();
    return u.buildFocusOutline(l), u;
  }
  static async deserialize(t, e, s) {
    let i = null;
    if (t instanceof En) {
      const {
        data: {
          quadPoints: r,
          rect: a,
          rotation: o,
          id: l,
          color: h,
          opacity: c,
          popupRef: u,
          richText: f,
          contentsObj: p,
          creationDate: g,
          modificationDate: m
        },
        parent: {
          page: {
            pageNumber: b
          }
        }
      } = t;
      i = t = {
        annotationType: B.HIGHLIGHT,
        color: Array.from(h),
        opacity: c,
        quadPoints: r,
        pageIndex: b - 1,
        rect: a.slice(0),
        rotation: o,
        annotationElementId: l,
        id: l,
        deleted: !1,
        popupRef: u,
        richText: f,
        comment: p?.str || null,
        creationDate: g,
        modificationDate: m
      };
    } else if (t instanceof oi) {
      const {
        data: {
          inkLists: r,
          rect: a,
          rotation: o,
          id: l,
          color: h,
          borderStyle: {
            rawWidth: c
          },
          popupRef: u,
          richText: f,
          contentsObj: p,
          creationDate: g,
          modificationDate: m
        },
        parent: {
          page: {
            pageNumber: b
          }
        }
      } = t;
      i = t = {
        annotationType: B.HIGHLIGHT,
        color: Array.from(h),
        thickness: c,
        inkLists: r,
        pageIndex: b - 1,
        rect: a.slice(0),
        rotation: o,
        annotationElementId: l,
        id: l,
        deleted: !1,
        popupRef: u,
        richText: f,
        comment: p?.str || null,
        creationDate: g,
        modificationDate: m
      };
    }
    const n = await super.deserialize(t, e, s);
    return n._initialData = i, t.comment && n.setCommentData(t), n;
  }
  serialize(t = !1) {
    if (this.isEmpty() || t)
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const e = super.serialize(t);
    return Object.assign(e, {
      color: I._colorManager.convert(this._uiManager.getNonHCMColor(this.color)),
      opacity: this.opacity,
      thickness: this._drawingOptions.thickness,
      quadPoints: this._drawOutlines.serializeQuadPoints(this.pageTranslation, this.pageDimensions),
      outlines: this._drawOutlines.serialize(e.rect, this._drawRotation)
    }), this.addComment(e), this.annotationElementId && !this.#h(e) ? null : (e.id = this.annotationElementId, e);
  }
  #h(t) {
    const {
      color: e
    } = this._initialData;
    return this.hasEditedComment || t.color.some((s, i) => s !== e[i]);
  }
  renderAnnotationElement(t) {
    return this.deleted ? (t.hide(), null) : (t.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
}
class zt {
  static #t = 10;
  static #e = 1e3 / 180;
  static #s = 100;
  static #i = 1e-3;
  #n;
  #r;
  #a;
  constructor(t, e, s) {
    this.#n = [t, e, s], this.#r = this.#a = s;
  }
  add(t, e, s) {
    const i = this.#n, n = i.at(-1);
    s = s > n ? s : n + zt.#i, i.push(t, e, s);
    const r = this.#o(s - zt.#t, !0), a = this.#l(this.#a - zt.#t);
    return a >= i.length / 2 && (i.copyWithin(0, a), i.length -= a), r;
  }
  get pendingPoints() {
    return this.#o(1 / 0, !1);
  }
  end() {
    return this.#o(1 / 0, !0);
  }
  #o(t, e) {
    const s = this.#n, i = this.#r, n = s.at(-1), r = [], a = this.#a;
    for (let o = this.#l(a) + 3; o < s.length; o += 3) {
      const l = s[o - 1], h = s[o + 2] - l, c = Math.min(Math.ceil(h / zt.#e), zt.#s);
      for (let u = 1; u <= c; u++) {
        const f = u === c ? s[o + 2] : l + h * u / c;
        if (f <= a)
          continue;
        if (f > t)
          return r;
        const p = Math.min(zt.#t, f - i, n - f);
        this.#h(f - p, f + p, r), e && (this.#a = f);
      }
    }
    return r;
  }
  #l(t) {
    const e = this.#n;
    let s = 0, i = e.length / 3 - 1;
    for (; s < i; ) {
      const n = s + i + 1 >> 1;
      e[3 * n + 2] <= t ? s = n : i = n - 1;
    }
    return 3 * s;
  }
  #h(t, e, s) {
    const i = this.#n, n = this.#l(t);
    let r = 0, a = 0, o = 0;
    for (let l = n; l < i.length - 3 && i[l + 2] < e; l += 3) {
      const h = i[l], c = i[l + 1], u = i[l + 2], f = i[l + 5], p = Math.max(u, t), g = Math.min(f, e);
      if (g <= p)
        continue;
      const m = g - p, b = (p + g - 2 * u) / (f - u);
      r += m * (h + b * (i[l + 3] - h) / 2), a += m * (c + b * (i[l + 4] - c) / 2), o += m;
    }
    o === 0 ? s.push(i[n], i[n + 1]) : s.push(r / o, a / o);
  }
}
function Ht(d, t) {
  return `${M.svgRound(d[t])} ${M.svgRound(d[t + 1])}`;
}
function In(d, t, e) {
  for (let s = e, i = t.length; s < i; s += 6)
    d.push(`C${Ht(t, s)} ${Ht(t, s + 2)} ${Ht(t, s + 4)}`);
}
function ts(d) {
  const t = `M${Ht(d, 4)}`;
  if (d.length === 6)
    return `${t}Z`;
  if (d.length === 12 && isNaN(d[6]))
    return `${t}L${Ht(d, 10)}`;
  const e = [t];
  return In(e, d, 6), e.join("");
}
class Va {
  #t = new Float64Array(6);
  #e = new Float64Array(2);
  #s;
  #i;
  #n;
  #r = null;
  #a;
  #o;
  #l = 1;
  #h = new Float64Array(2);
  #u = "";
  #c = 0;
  #f = new Ne();
  #p;
  #m;
  constructor(t, e, s, i, n, r, a) {
    this.#p = s, this.#m = i, this.#n = n, this.#a = r, this.#i = [], this.#d(t, e, a);
  }
  #d(t, e, s) {
    [t, e] = this.#g(t, e);
    const i = this.#s = [NaN, NaN, NaN, NaN, t, e];
    this.#o = [t, e], this.#i.push({
      line: i,
      points: this.#o
    }), this.#t.set(i, 0), this.#c = 0, this.#l = 1, this.#h.set(this.#e), this.#r = s === void 0 ? null : new zt(t, e, s);
  }
  updateProperty(t, e) {
    t === "stroke-width" && (this.#a = e);
  }
  #g(t, e) {
    return M._normalizePoint(t, e, this.#p, this.#m, this.#n, this.#e);
  }
  isEmpty() {
    return !this.#i?.length;
  }
  isCancellable() {
    return this.#l <= 5;
  }
  add(t, e, s) {
    return this.#b(t, e, s), {
      path: {
        d: this.#v()
      }
    };
  }
  addPoints(t, e) {
    for (let s = 0, i = t.length; s < i; s += 2)
      this.#b(t[s], t[s + 1], e?.[s / 2]);
    return {
      path: {
        d: this.#v()
      }
    };
  }
  #b(t, e, s) {
    [t, e] = this.#g(t, e);
    const [i, n] = this.#h;
    this.#y(t, e, i, n) || (this.#l++, this.#h.set(this.#e)), this.#r ? this.#A(this.#r.add(t, e, s)) : this.#w(t, e);
  }
  #y(t, e, s, i) {
    return Math.hypot(this.#p * (t - s), this.#m * (e - i)) <= 2;
  }
  #A(t) {
    for (let e = 0, s = t.length; e < s; e += 2)
      this.#w(t[e], t[e + 1]);
  }
  #w(t, e) {
    const [, , s, i, n, r] = this.#t;
    this.#y(t, e, n, r) || (this.#o.push(t, e), isNaN(s) ? this.#s.push(NaN, NaN, NaN, NaN, t, e) : (isNaN(this.#t[0]) && this.#s.splice(6, 6), M.createBezierPoints(s, i, n, r, t, e, this.#s)), this.#t.copyWithin(0, 2), this.#t[4] = t, this.#t[5] = e);
  }
  #S() {
    const t = this.#s;
    if (this.#o.length < 6 || this.#c === t.length)
      return;
    const e = [this.#u];
    this.#c === 0 && (e.push(`M${Ht(t, 4)}`), this.#c = 6), In(e, t, this.#c), this.#u = e.join(""), this.#c = t.length;
  }
  #_() {
    if (this.#s) {
      if (this.#r && (this.#A(this.#r.end()), this.#r = null), this.#o.length < 6)
        this.#u += ts(this.#s);
      else {
        const [, , t, e, s, i] = this.#t;
        M.createBezierPoints(t, e, s, i, s, i, this.#s), this.#S();
      }
      this.#s = this.#o = null;
    }
  }
  end(t, e, s) {
    return this.#s && t !== void 0 && this.#b(t, e, s), this.#_(), {
      path: {
        d: this.#u
      }
    };
  }
  startNew(t, e, s, i, n, r) {
    this.#p = s, this.#m = i, this.#n = n;
    const a = this.#i.at(-1);
    return a && (a.line = new Float32Array(a.line), a.points = new Float32Array(a.points)), this.#d(t, e, r), null;
  }
  getLastElement() {
    return this.#i.at(-1);
  }
  setLastElement(t) {
    return this.#i ? (this.#i.push(t), this.#u += ts(t.line), {
      path: {
        d: this.#u
      }
    }) : this.#f.setLastElement(t);
  }
  removeLastElement() {
    return this.#i ? (this.#s = this.#o = this.#r = null, this.#i.pop(), this.#u = this.#i.map(({
      line: t
    }) => ts(t)).join(""), {
      path: {
        d: this.#u
      }
    }) : this.#f.removeLastElement();
  }
  #v() {
    this.#S();
    const t = [this.#u];
    this.#c === 0 && (t.push(`M${Ht(this.#s, 4)}`), this.#o.length === 4 && t.push(`L${Ht(this.#s, 10)}`));
    let e = this.#r?.pendingPoints;
    e?.length || (e = this.#e);
    for (let s = 0, i = e.length; s < i; s += 2)
      t.push(`L${Ht(e, s)}`);
    return t.join("");
  }
  getOutlines(t, e, s, i) {
    this.#_();
    const n = this.#i.at(-1);
    return n.line = new Float32Array(n.line), n.points = new Float32Array(n.points), this.#f.build(this.#i, t, e, s, this.#n, this.#a, i), this.#t = null, this.#s = null, this.#i = null, this.#u = null, this.#f;
  }
  get defaultSVGProperties() {
    return {
      root: {
        viewBox: "0 0 10000 10000"
      },
      rootClass: {
        draw: !0
      },
      bbox: [0, 0, 1, 1]
    };
  }
}
class Ne extends M {
  #t;
  #e = 0;
  #s;
  #i;
  #n;
  #r;
  #a;
  #o;
  #l;
  build(t, e, s, i, n, r, a) {
    this.#n = e, this.#r = s, this.#a = i, this.#o = n, this.#l = r, this.#s = a ?? 0, this.#i = t, this.#c();
  }
  get thickness() {
    return this.#l;
  }
  setLastElement(t) {
    return this.#i.push(t), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  removeLastElement() {
    return this.#i.pop(), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  toSVGPath() {
    return this.#i.map(({
      line: t
    }) => ts(t)).join("");
  }
  serialize([t, e, s, i], n) {
    const r = [], a = [], [o, l, h, c] = this.#u();
    let u, f, p, g, m, b, y, A, w;
    switch (this.#o) {
      case 0:
        w = M._rescale, u = t, f = e + i, p = s, g = -i, m = t + o * s, b = e + (1 - l - c) * i, y = t + (o + h) * s, A = e + (1 - l) * i;
        break;
      case 90:
        w = M._rescaleAndSwap, u = t, f = e, p = s, g = i, m = t + l * s, b = e + o * i, y = t + (l + c) * s, A = e + (o + h) * i;
        break;
      case 180:
        w = M._rescale, u = t + s, f = e, p = -s, g = i, m = t + (1 - o - h) * s, b = e + l * i, y = t + (1 - o) * s, A = e + (l + c) * i;
        break;
      case 270:
        w = M._rescaleAndSwap, u = t + s, f = e + i, p = -s, g = -i, m = t + (1 - l - c) * s, b = e + (1 - o - h) * i, y = t + (1 - l) * s, A = e + (1 - o) * i;
        break;
    }
    for (const {
      line: v,
      points: S
    } of this.#i)
      r.push(w(v, u, f, p, g, n ? new Array(v.length) : null)), a.push(w(S, u, f, p, g, n ? new Array(S.length) : null));
    return {
      lines: r,
      points: a,
      rect: [m, b, y, A]
    };
  }
  static deserialize(t, e, s, i, n, {
    paths: {
      lines: r,
      points: a
    },
    rotation: o,
    thickness: l
  }) {
    const h = [];
    let c, u, f, p, g;
    switch (o) {
      case 0:
        g = M._rescale, c = -t / s, u = e / i + 1, f = 1 / s, p = -1 / i;
        break;
      case 90:
        g = M._rescaleAndSwap, c = -e / i, u = -t / s, f = 1 / i, p = 1 / s;
        break;
      case 180:
        g = M._rescale, c = t / s + 1, u = -e / i, f = -1 / s, p = 1 / i;
        break;
      case 270:
        g = M._rescaleAndSwap, c = e / i + 1, u = t / s + 1, f = -1 / i, p = -1 / s;
        break;
    }
    if (!r) {
      r = [];
      for (const b of a) {
        const y = b.length;
        if (y === 2) {
          r.push(new Float32Array([NaN, NaN, NaN, NaN, b[0], b[1]]));
          continue;
        }
        if (y === 4) {
          r.push(new Float32Array([NaN, NaN, NaN, NaN, b[0], b[1], NaN, NaN, NaN, NaN, b[2], b[3]]));
          continue;
        }
        const A = new Float32Array(3 * y);
        r.push(A);
        let [w, v, S, _] = b.subarray(0, 4);
        A.set([NaN, NaN, NaN, NaN, w, v], 0);
        for (let E = 4; E <= y; E += 2) {
          const C = Math.min(E, y - 2), T = b[C], D = b[C + 1];
          A.set(M.createBezierPoints(w, v, S, _, T, D), (E - 2) * 3), [w, v, S, _] = [S, _, T, D];
        }
      }
    }
    for (let b = 0, y = r.length; b < y; b++)
      h.push({
        line: g(r[b].map((A) => A ?? NaN), c, u, f, p),
        points: g(a[b].map((A) => A ?? NaN), c, u, f, p)
      });
    const m = new this.prototype.constructor();
    return m.build(h, s, i, 1, o, l, n), m;
  }
  #h(t = this.#l) {
    const e = this.#s + t / 2 * this.#a;
    return this.#o % 180 === 0 ? [e / this.#n, e / this.#r] : [e / this.#r, e / this.#n];
  }
  #u() {
    const [t, e, s, i] = this.#t, [n, r] = this.#h(0);
    return [t + n, e + r, s - 2 * n, i - 2 * r];
  }
  #c() {
    const t = this.#t = ee.slice();
    for (const {
      line: i
    } of this.#i) {
      if (i.length <= 12) {
        for (let a = 4, o = i.length; a < o; a += 6)
          x.pointBoundingBox(i[a], i[a + 1], t);
        continue;
      }
      let n = i[4], r = i[5];
      for (let a = 6, o = i.length; a < o; a += 6) {
        const [l, h, c, u, f, p] = i.subarray(a, a + 6);
        x.bezierBoundingBox(n, r, l, h, c, u, f, p, t), n = f, r = p;
      }
    }
    const [e, s] = this.#h();
    t[0] = Y(t[0] - e, 0, 1), t[1] = Y(t[1] - s, 0, 1), t[2] = Y(t[2] + e, 0, 1), t[3] = Y(t[3] + s, 0, 1), t[2] -= t[0], t[3] -= t[1];
  }
  get box() {
    return this.#t;
  }
  updateProperty(t, e) {
    return t === "stroke-width" ? this.#f(e) : null;
  }
  #f(t) {
    const [e, s] = this.#h();
    this.#l = t;
    const [i, n] = this.#h(), [r, a] = [i - e, n - s], o = this.#t;
    return o[0] -= r, o[1] -= a, o[2] += 2 * r, o[3] += 2 * a, o;
  }
  updateParentDimensions([t, e], s) {
    const [i, n] = this.#h();
    this.#n = t, this.#r = e, this.#a = s;
    const [r, a] = this.#h(), o = r - i, l = a - n, h = this.#t;
    return h[0] -= o, h[1] -= l, h[2] += 2 * o, h[3] += 2 * l, h;
  }
  updateRotation(t) {
    return this.#e = t, {
      path: {
        transform: this.rotationTransform
      }
    };
  }
  get viewBox() {
    return this.#t.map(M.svgRound).join(" ");
  }
  get defaultProperties() {
    const [t, e] = this.#t;
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${M.svgRound(t)} ${M.svgRound(e)}`
      }
    };
  }
  get rotationTransform() {
    const [, , t, e] = this.#t;
    let s = 0, i = 0, n = 0, r = 0, a = 0, o = 0;
    switch (this.#e) {
      case 90:
        i = e / t, n = -t / e, a = t;
        break;
      case 180:
        s = -1, r = -1, a = t, o = e;
        break;
      case 270:
        i = -e / t, n = t / e, o = e;
        break;
      default:
        return "";
    }
    return `matrix(${s} ${i} ${n} ${r} ${M.svgRound(a)} ${M.svgRound(o)})`;
  }
  getPathResizingSVGProperties([t, e, s, i]) {
    const [n, r] = this.#h(), [a, o, l, h] = this.#t;
    if (Math.abs(l - n) <= M.PRECISION || Math.abs(h - r) <= M.PRECISION) {
      const g = t + s / 2 - (a + l / 2), m = e + i / 2 - (o + h / 2);
      return {
        path: {
          "transform-origin": `${M.svgRound(t)} ${M.svgRound(e)}`,
          transform: `${this.rotationTransform} translate(${g} ${m})`
        }
      };
    }
    const c = (s - 2 * n) / (l - 2 * n), u = (i - 2 * r) / (h - 2 * r), f = l / s, p = h / i;
    return {
      path: {
        "transform-origin": `${M.svgRound(a)} ${M.svgRound(o)}`,
        transform: `${this.rotationTransform} scale(${f} ${p}) translate(${M.svgRound(n)} ${M.svgRound(r)}) scale(${c} ${u}) translate(${M.svgRound(-n)} ${M.svgRound(-r)})`
      }
    };
  }
  getPathResizedSVGProperties([t, e, s, i]) {
    const [n, r] = this.#h(), a = this.#t, [o, l, h, c] = a;
    if (a[0] = t, a[1] = e, a[2] = s, a[3] = i, Math.abs(h - n) <= M.PRECISION || Math.abs(c - r) <= M.PRECISION) {
      const m = t + s / 2 - (o + h / 2), b = e + i / 2 - (l + c / 2);
      for (const {
        line: y,
        points: A
      } of this.#i)
        M._translate(y, m, b, y), M._translate(A, m, b, A);
      return {
        root: {
          viewBox: this.viewBox
        },
        path: {
          "transform-origin": `${M.svgRound(t)} ${M.svgRound(e)}`,
          transform: this.rotationTransform || null,
          d: this.toSVGPath()
        }
      };
    }
    const u = (s - 2 * n) / (h - 2 * n), f = (i - 2 * r) / (c - 2 * r), p = -u * (o + n) + t + n, g = -f * (l + r) + e + r;
    if (u !== 1 || f !== 1 || p !== 0 || g !== 0)
      for (const {
        line: m,
        points: b
      } of this.#i)
        M._rescale(m, p, g, u, f, m), M._rescale(b, p, g, u, f, b);
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${M.svgRound(t)} ${M.svgRound(e)}`,
        transform: this.rotationTransform || null,
        d: this.toSVGPath()
      }
    };
  }
  getPathTranslatedSVGProperties([t, e], s) {
    const [i, n] = s, r = this.#t, a = t - r[0], o = e - r[1];
    if (this.#n === i && this.#r === n)
      for (const {
        line: l,
        points: h
      } of this.#i)
        M._translate(l, a, o, l), M._translate(h, a, o, h);
    else {
      const l = this.#n / i, h = this.#r / n;
      this.#n = i, this.#r = n;
      for (const {
        line: c,
        points: u
      } of this.#i)
        M._rescale(c, a, o, l, h, c), M._rescale(u, a, o, l, h, u);
      r[2] *= l, r[3] *= h;
    }
    return r[0] = t, r[1] = e, {
      root: {
        viewBox: this.viewBox
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${M.svgRound(t)} ${M.svgRound(e)}`
      }
    };
  }
  get defaultSVGProperties() {
    const t = this.#t;
    return {
      root: {
        viewBox: this.viewBox
      },
      rootClass: {
        draw: !0
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${M.svgRound(t[0])} ${M.svgRound(t[1])}`,
        transform: this.rotationTransform || null
      },
      bbox: t
    };
  }
}
class vs extends hi {
  constructor(t) {
    super(), this._viewParameters = t, super.updateProperties({
      fill: "none",
      stroke: I._defaultLineColor,
      "stroke-opacity": 1,
      "stroke-width": 1,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-miterlimit": 10
    });
  }
  updateSVGProperty(t, e) {
    t === "stroke-width" && (e ??= this["stroke-width"], e *= this._viewParameters.realScale), super.updateSVGProperty(t, e);
  }
  clone() {
    const t = new vs(this._viewParameters);
    return t.updateAll(this), t;
  }
}
class fi extends H {
  static _type = "ink";
  static _editorType = B.INK;
  static _defaultDrawingOptions = null;
  constructor(t) {
    super({
      ...t,
      name: "inkEditor"
    }), this._willKeepAspectRatio = !0, this.defaultL10nId = "pdfjs-editor-ink-editor";
  }
  static initialize(t, e) {
    I.initialize(t, e), this._defaultDrawingOptions = new vs(e.viewParameters);
  }
  static getDefaultDrawingOptions(t) {
    const e = this._defaultDrawingOptions.clone();
    return e.updateProperties(t), e;
  }
  static get supportMultipleDrawings() {
    return !0;
  }
  static get typesMap() {
    return k(this, "typesMap", /* @__PURE__ */ new Map([[U.INK_THICKNESS, "stroke-width"], [U.INK_COLOR, "stroke"], [U.INK_OPACITY, "stroke-opacity"]]));
  }
  static createDrawerInstance({
    x: t,
    y: e,
    box: [, , s, i],
    rotation: n,
    timeStamp: r
  }) {
    return new Va(t, e, s, i, n, this._defaultDrawingOptions["stroke-width"], r);
  }
  static deserializeDraw(t, e, s, i, n, r) {
    return Ne.deserialize(t, e, s, i, n, r);
  }
  static async deserialize(t, e, s) {
    let i = null;
    if (t instanceof oi) {
      const {
        data: {
          inkLists: r,
          rect: a,
          rotation: o,
          id: l,
          color: h,
          opacity: c,
          borderStyle: {
            rawWidth: u
          },
          popupRef: f,
          richText: p,
          contentsObj: g,
          creationDate: m,
          modificationDate: b
        },
        parent: {
          page: {
            pageNumber: y
          }
        }
      } = t;
      i = t = {
        annotationType: B.INK,
        color: Array.from(h),
        thickness: u,
        opacity: c,
        paths: {
          points: r
        },
        boxes: null,
        pageIndex: y - 1,
        rect: a.slice(0),
        rotation: o,
        annotationElementId: l,
        id: l,
        deleted: !1,
        popupRef: f,
        richText: p,
        comment: g?.str || null,
        creationDate: m,
        modificationDate: b
      };
    }
    const n = await super.deserialize(t, e, s);
    return n._initialData = i, t.comment && n.setCommentData(t), n;
  }
  get toolbarButtons() {
    return this._colorPicker ||= new Oe(this), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return U.INK_COLOR;
  }
  get colorAndOpacityType() {
    return U.INK_COLOR_AND_OPACITY;
  }
  get opacityType() {
    return U.INK_OPACITY;
  }
  updateParams(t, e) {
    if (t === U.INK_COLOR_AND_OPACITY) {
      this._updateColorAndOpacity(e.color, e.opacity);
      return;
    }
    super.updateParams(t, e);
  }
  static updateDefaultParams(t, e) {
    if (t === U.INK_COLOR_AND_OPACITY) {
      super.updateDefaultParams(U.INK_COLOR, e.color), super.updateDefaultParams(U.INK_OPACITY, e.opacity);
      return;
    }
    super.updateDefaultParams(t, e);
  }
  get color() {
    return this._drawingOptions.stroke;
  }
  get opacity() {
    return this._drawingOptions["stroke-opacity"];
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    super.onScaleChanging();
    const {
      _drawId: t,
      _drawingOptions: e,
      parent: s
    } = this;
    e.updateSVGProperty("stroke-width"), s.drawLayer.updateProperties(t, e.toSVGProperties());
  }
  static onScaleChangingWhenDrawing() {
    const t = this._currentParent;
    t && (super.onScaleChangingWhenDrawing(), this._defaultDrawingOptions.updateSVGProperty("stroke-width"), t.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  createDrawingOptions({
    color: t,
    thickness: e,
    opacity: s
  }) {
    this._drawingOptions = fi.getDefaultDrawingOptions({
      stroke: x.makeHexColor(...t),
      "stroke-width": e,
      "stroke-opacity": s
    });
  }
  serialize(t = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const {
      lines: e,
      points: s
    } = this.serializeDraw(t), {
      _drawingOptions: {
        stroke: i,
        "stroke-opacity": n,
        "stroke-width": r
      }
    } = this, a = Object.assign(super.serialize(t), {
      color: I._colorManager.convert(i),
      opacity: n,
      thickness: r,
      paths: {
        lines: e,
        points: s
      }
    });
    return this.addComment(a), t ? (a.isCopy = !0, a) : this.annotationElementId && !this.#t(a) ? null : (a.id = this.annotationElementId, a);
  }
  #t(t) {
    const {
      color: e,
      thickness: s,
      opacity: i,
      pageIndex: n
    } = this._initialData;
    return this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized || t.color.some((r, a) => r !== e[a]) || t.thickness !== s || t.opacity !== i || t.pageIndex !== n;
  }
  renderAnnotationElement(t) {
    if (this.deleted)
      return t.hide(), null;
    const {
      points: e,
      rect: s
    } = this.serializeDraw(!1);
    return t.updateEdited({
      rect: s,
      thickness: this._drawingOptions["stroke-width"],
      points: e,
      popup: this.comment
    }), null;
  }
}
class Ys extends Ne {
  toSVGPath() {
    let t = super.toSVGPath();
    return t.endsWith("Z") || (t += "Z"), t;
  }
}
const Ve = 8, Ee = 3;
class pe {
  static #t = {
    maxDim: 512,
    sigmaSFactor: 0.02,
    sigmaR: 25,
    kernelSize: 16
  };
  static #e(t, e, s, i) {
    return s -= t, i -= e, s === 0 ? i > 0 ? 0 : 4 : s === 1 ? i + 6 : 2 - i;
  }
  static #s = new Int32Array([0, 1, -1, 1, -1, 0, -1, -1, 0, -1, 1, -1, 1, 0, 1, 1]);
  static #i(t, e, s, i, n, r, a) {
    const o = this.#e(s, i, n, r);
    for (let l = 0; l < 8; l++) {
      const h = (-l + o - a + 16) % 8, c = this.#s[2 * h], u = this.#s[2 * h + 1];
      if (t[(s + c) * e + (i + u)] !== 0)
        return h;
    }
    return -1;
  }
  static #n(t, e, s, i, n, r, a) {
    const o = this.#e(s, i, n, r);
    for (let l = 0; l < 8; l++) {
      const h = (l + o + a + 16) % 8, c = this.#s[2 * h], u = this.#s[2 * h + 1];
      if (t[(s + c) * e + (i + u)] !== 0)
        return h;
    }
    return -1;
  }
  static #r(t, e, s, i) {
    const n = t.length, r = new Int32Array(n);
    for (let h = 0; h < n; h++)
      r[h] = t[h] <= i ? 1 : 0;
    for (let h = 1; h < s - 1; h++)
      r[h * e] = r[h * e + e - 1] = 0;
    for (let h = 0; h < e; h++)
      r[h] = r[e * s - 1 - h] = 0;
    let a = 1, o;
    const l = [];
    for (let h = 1; h < s - 1; h++) {
      o = 1;
      for (let c = 1; c < e - 1; c++) {
        const u = h * e + c, f = r[u];
        if (f === 0)
          continue;
        let p = h, g = c;
        if (f === 1 && r[u - 1] === 0)
          a += 1, g -= 1;
        else if (f >= 1 && r[u + 1] === 0)
          a += 1, g += 1, f > 1 && (o = f);
        else {
          f !== 1 && (o = Math.abs(f));
          continue;
        }
        const m = [c, h], b = g === c + 1, y = {
          isHole: b,
          points: m,
          id: a,
          parent: 0
        };
        l.push(y);
        let A;
        for (const D of l)
          if (D.id === o) {
            A = D;
            break;
          }
        A ? A.isHole ? y.parent = b ? A.parent : o : y.parent = b ? o : A.parent : y.parent = b ? o : 0;
        const w = this.#i(r, e, h, c, p, g, 0);
        if (w === -1) {
          r[u] = -a, r[u] !== 1 && (o = Math.abs(r[u]));
          continue;
        }
        let v = this.#s[2 * w], S = this.#s[2 * w + 1];
        const _ = h + v, E = c + S;
        p = _, g = E;
        let C = h, T = c;
        for (; ; ) {
          const D = this.#n(r, e, C, T, p, g, 1);
          v = this.#s[2 * D], S = this.#s[2 * D + 1];
          const P = C + v, N = T + S;
          m.push(N, P);
          const G = C * e + T;
          if (r[G + 1] === 0 ? r[G] = -a : r[G] === 1 && (r[G] = a), P === h && N === c && C === _ && T === E) {
            r[u] !== 1 && (o = Math.abs(r[u]));
            break;
          } else
            p = C, g = T, C = P, T = N;
        }
      }
    }
    return l;
  }
  static #a(t, e, s, i) {
    if (s - e <= 4) {
      for (let _ = e; _ < s - 2; _ += 2)
        i.push(t[_], t[_ + 1]);
      return;
    }
    const n = t[e], r = t[e + 1], a = t[s - 4] - n, o = t[s - 3] - r, l = Math.hypot(a, o), h = a / l, c = o / l, u = h * r - c * n, f = o / a, p = 1 / l, g = Math.atan(f), m = Math.cos(g), b = Math.sin(g), y = p * (Math.abs(m) + Math.abs(b)), A = p * (1 - y + y ** 2), w = Math.max(Math.atan(Math.abs(b + m) * A), Math.atan(Math.abs(b - m) * A));
    let v = 0, S = e;
    for (let _ = e + 2; _ < s - 2; _ += 2) {
      const E = Math.abs(u - h * t[_ + 1] + c * t[_]);
      E > v && (S = _, v = E);
    }
    v > (l * w) ** 2 ? (this.#a(t, e, S + 2, i), this.#a(t, S, s, i)) : i.push(n, r);
  }
  static #o(t) {
    const e = [], s = t.length;
    return this.#a(t, 0, s, e), e.push(t[s - 2], t[s - 1]), e.length <= 4 ? null : e;
  }
  static #l(t, e, s, i, n, r) {
    const a = new Float32Array(r ** 2), o = -2 * i ** 2, l = r >> 1;
    for (let g = 0; g < r; g++) {
      const m = (g - l) ** 2;
      for (let b = 0; b < r; b++)
        a[g * r + b] = Math.exp((m + (b - l) ** 2) / o);
    }
    const h = new Float32Array(256), c = -2 * n ** 2;
    for (let g = 0; g < 256; g++)
      h[g] = Math.exp(g ** 2 / c);
    const u = t.length, f = new Uint8Array(u), p = new Uint32Array(256);
    for (let g = 0; g < s; g++)
      for (let m = 0; m < e; m++) {
        const b = g * e + m, y = t[b];
        let A = 0, w = 0;
        for (let S = 0; S < r; S++) {
          const _ = g + S - l;
          if (!(_ < 0 || _ >= s))
            for (let E = 0; E < r; E++) {
              const C = m + E - l;
              if (C < 0 || C >= e)
                continue;
              const T = t[_ * e + C], D = a[S * r + E] * h[Math.abs(T - y)];
              A += T * D, w += D;
            }
        }
        const v = f[b] = Math.round(A / w);
        p[v]++;
      }
    return [f, p];
  }
  static #h(t) {
    const e = new Uint32Array(256);
    for (const s of t)
      e[s]++;
    return e;
  }
  static #u(t) {
    const e = t.length, s = new Uint8ClampedArray(e >> 2);
    let i = -1 / 0, n = 1 / 0;
    for (let a = 0, o = s.length; a < o; a++) {
      const l = s[a] = t[a << 2];
      i = Math.max(i, l), n = Math.min(n, l);
    }
    const r = 255 / (i - n);
    for (let a = 0, o = s.length; a < o; a++)
      s[a] = (s[a] - n) * r;
    return s;
  }
  static #c(t) {
    let e, s = -1 / 0, i = -1 / 0;
    const n = t.findIndex((o) => o !== 0);
    let r = n, a = n;
    for (e = n; e < 256; e++) {
      const o = t[e];
      o > s && (e - r > i && (i = e - r, a = e - 1), s = o, r = e);
    }
    for (e = a - 1; e >= 0 && !(t[e] > t[e + 1]); e--)
      ;
    return e;
  }
  static #f(t) {
    const e = t, {
      width: s,
      height: i
    } = t, {
      maxDim: n
    } = this.#t;
    let r = s, a = i;
    if (s > n || i > n) {
      let u = s, f = i, p = Math.log2(Math.max(s, i) / n);
      const g = Math.floor(p);
      p = p === g ? g - 1 : g;
      for (let b = 0; b < p; b++) {
        r = Math.ceil(u / 2), a = Math.ceil(f / 2);
        const y = new OffscreenCanvas(r, a);
        y.getContext("2d").drawImage(t, 0, 0, u, f, 0, 0, r, a), u = r, f = a, t !== e && t.close(), t = y.transferToImageBitmap();
      }
      const m = Math.min(n / r, n / a);
      r = Math.round(r * m), a = Math.round(a * m);
    }
    const l = new OffscreenCanvas(r, a).getContext("2d", {
      willReadFrequently: !0
    });
    l.fillStyle = "white", l.fillRect(0, 0, r, a), l.filter = "grayscale(1)", l.drawImage(t, 0, 0, t.width, t.height, 0, 0, r, a);
    const h = l.getImageData(0, 0, r, a).data;
    return [this.#u(h), r, a];
  }
  static extractContoursFromText(t, {
    fontFamily: e,
    fontStyle: s,
    fontWeight: i
  }, n, r, a, o) {
    let l = new OffscreenCanvas(1, 1), h = l.getContext("2d", {
      alpha: !1
    });
    const c = 200, u = h.font = `${s} ${i} ${c}px ${e}`, {
      actualBoundingBoxLeft: f,
      actualBoundingBoxRight: p,
      actualBoundingBoxAscent: g,
      actualBoundingBoxDescent: m,
      fontBoundingBoxAscent: b,
      fontBoundingBoxDescent: y,
      width: A
    } = h.measureText(t), w = 1.5, v = Math.ceil(Math.max(Math.abs(f) + Math.abs(p) || 0, A) * w), S = Math.ceil(Math.max(Math.abs(g) + Math.abs(m) || c, Math.abs(b) + Math.abs(y) || c) * w);
    l = new OffscreenCanvas(v, S), h = l.getContext("2d", {
      alpha: !0,
      willReadFrequently: !0
    }), h.font = u, h.filter = "grayscale(1)", h.fillStyle = "white", h.fillRect(0, 0, v, S), h.fillStyle = "black", h.fillText(t, v * (w - 1) / 2, S * (3 - w) / 2);
    const _ = this.#u(h.getImageData(0, 0, v, S).data), E = this.#h(_), C = this.#c(E), T = this.#r(_, v, S, C);
    return this.processDrawnLines({
      lines: {
        curves: T,
        width: v,
        height: S
      },
      pageWidth: n,
      pageHeight: r,
      rotation: a,
      innerMargin: o,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static process(t, e, s, i, n) {
    const [r, a, o] = this.#f(t), [l, h] = this.#l(r, a, o, Math.hypot(a, o) * this.#t.sigmaSFactor, this.#t.sigmaR, this.#t.kernelSize), c = this.#c(h), u = this.#r(l, a, o, c);
    return this.processDrawnLines({
      lines: {
        curves: u,
        width: a,
        height: o
      },
      pageWidth: e,
      pageHeight: s,
      rotation: i,
      innerMargin: n,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static processDrawnLines({
    lines: t,
    pageWidth: e,
    pageHeight: s,
    rotation: i,
    innerMargin: n,
    mustSmooth: r,
    areContours: a
  }) {
    i % 180 !== 0 && ([e, s] = [s, e]);
    const {
      curves: o,
      width: l,
      height: h
    } = t, c = t.thickness ?? 0, u = [], f = Math.min(e / l, s / h), p = f / e, g = f / s, m = [];
    for (const {
      points: y
    } of o) {
      const A = r ? this.#o(y) : y;
      if (!A)
        continue;
      m.push(A);
      const w = A.length, v = new Float32Array(w), S = new Float32Array(3 * (w === 2 ? 2 : w - 2));
      if (u.push({
        line: S,
        points: v
      }), w === 2) {
        v[0] = A[0] * p, v[1] = A[1] * g, S.set([NaN, NaN, NaN, NaN, v[0], v[1]], 0);
        continue;
      }
      let [_, E, C, T] = A;
      _ *= p, E *= g, C *= p, T *= g, v.set([_, E, C, T], 0), S.set([NaN, NaN, NaN, NaN, _, E], 0);
      for (let D = 4; D < w; D += 2) {
        const P = v[D] = A[D] * p, N = v[D + 1] = A[D + 1] * g;
        S.set(M.createBezierPoints(_, E, C, T, P, N), (D - 2) * 3), [_, E, C, T] = [C, T, P, N];
      }
    }
    if (u.length === 0)
      return null;
    const b = a ? new Ys() : new Ne();
    return b.build(u, e, s, 1, i, a ? 0 : c, n), {
      outline: b,
      newCurves: m,
      areContours: a,
      thickness: c,
      width: l,
      height: h
    };
  }
  static async compressSignature({
    outlines: t,
    areContours: e,
    thickness: s,
    width: i,
    height: n
  }) {
    let r = 1 / 0, a = -1 / 0, o = 0;
    for (const y of t) {
      o += y.length;
      for (let A = 2, w = y.length; A < w; A++) {
        const v = y[A] - y[A - 2];
        r = Math.min(r, v), a = Math.max(a, v);
      }
    }
    let l;
    r >= -128 && a <= 127 ? l = Int8Array : r >= -32768 && a <= 32767 ? l = Int16Array : l = Int32Array;
    const h = t.length, c = Ve + Ee * h, u = new Uint32Array(c);
    let f = 0;
    u[f++] = c * Uint32Array.BYTES_PER_ELEMENT + (o - 2 * h) * l.BYTES_PER_ELEMENT, u[f++] = 0, u[f++] = i, u[f++] = n, u[f++] = e ? 0 : 1, u[f++] = Math.max(0, Math.floor(s ?? 0)), u[f++] = h, u[f++] = l.BYTES_PER_ELEMENT;
    for (const y of t)
      u[f++] = y.length - 2, u[f++] = y[0], u[f++] = y[1];
    const p = new CompressionStream("deflate-raw"), g = p.writable.getWriter();
    await g.ready, g.write(u);
    const m = l.prototype.constructor;
    for (const y of t) {
      const A = new m(y.length - 2);
      for (let w = 2, v = y.length; w < v; w++)
        A[w - 2] = y[w] - y[w - 2];
      g.write(A);
    }
    return g.close(), (await new Response(p.readable).bytes()).toBase64();
  }
  static async decompressSignature(t) {
    try {
      const e = Uint8Array.fromBase64(t), {
        readable: s,
        writable: i
      } = new DecompressionStream("deflate-raw"), n = i.getWriter();
      await n.ready, n.write(e).then(async () => {
        await n.ready, await n.close();
      }).catch(() => {
      });
      let r = null, a = 0;
      for await (const A of s)
        r ||= new Uint8Array(new Uint32Array(A.buffer, 0, 4)[0]), r.set(A, a), a += A.length;
      const o = new Uint32Array(r.buffer, 0, r.length >> 2), l = o[1];
      if (l !== 0)
        throw new Error(`Invalid version: ${l}`);
      const h = o[2], c = o[3], u = o[4] === 0, f = o[5], p = o[6], g = o[7], m = [], b = (Ve + Ee * p) * Uint32Array.BYTES_PER_ELEMENT;
      let y;
      switch (g) {
        case Int8Array.BYTES_PER_ELEMENT:
          y = new Int8Array(r.buffer, b);
          break;
        case Int16Array.BYTES_PER_ELEMENT:
          y = new Int16Array(r.buffer, b);
          break;
        case Int32Array.BYTES_PER_ELEMENT:
          y = new Int32Array(r.buffer, b);
          break;
      }
      a = 0;
      for (let A = 0; A < p; A++) {
        const w = o[Ee * A + Ve], v = new Float32Array(w + 2);
        m.push(v);
        for (let S = 0; S < Ee - 1; S++)
          v[S] = o[Ee * A + Ve + S + 1];
        for (let S = 0; S < w; S++)
          v[S + 2] = v[S] + y[a++];
      }
      return {
        areContours: u,
        thickness: f,
        outlines: m,
        width: h,
        height: c
      };
    } catch (e) {
      return R(`decompressSignature: ${e}`), null;
    }
  }
}
class pi extends hi {
  constructor() {
    super(), super.updateProperties({
      fill: I._defaultLineColor,
      "stroke-width": 0
    });
  }
  clone() {
    const t = new pi();
    return t.updateAll(this), t;
  }
}
class gi extends vs {
  constructor(t) {
    super(t), super.updateProperties({
      stroke: I._defaultLineColor,
      "stroke-width": 1
    });
  }
  clone() {
    const t = new gi(this._viewParameters);
    return t.updateAll(this), t;
  }
}
class Mt extends H {
  #t = !1;
  #e = null;
  #s = null;
  #i = null;
  #n = !1;
  static _type = "signature";
  static _editorType = B.SIGNATURE;
  static _defaultDrawingOptions = null;
  constructor(t) {
    super({
      ...t,
      mustBeCommitted: !0,
      name: "signatureEditor"
    }), this._willKeepAspectRatio = !0, this.#s = t.signatureData || null, this.#e = null, this.defaultL10nId = "pdfjs-editor-signature-editor1";
  }
  static initialize(t, e) {
    I.initialize(t, e), this._defaultDrawingOptions = new pi(), this._defaultDrawnSignatureOptions = new gi(e.viewParameters);
  }
  static getDefaultDrawingOptions(t) {
    const e = this._defaultDrawingOptions.clone();
    return e.updateProperties(t), e;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  static get typesMap() {
    return k(this, "typesMap", /* @__PURE__ */ new Map());
  }
  static get isDrawer() {
    return !1;
  }
  get telemetryFinalData() {
    return {
      type: "signature",
      hasDescription: !!this.#e
    };
  }
  static computeTelemetryFinalData(t) {
    const e = t.get("hasDescription");
    return {
      hasAltText: e.get(!0) ?? 0,
      hasNoAltText: e.get(!1) ?? 0
    };
  }
  get isResizable() {
    return !0;
  }
  onceAdded(t) {
    this.#n = this._drawId === null, super.onceAdded(t);
  }
  onScaleChanging() {
    this._drawId !== null && super.onScaleChanging();
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    const {
      _isCopy: s
    } = this;
    if (s && (this._isCopy = !1, t = this.x, e = this.y), super.render(), this._drawId === null)
      if (this.#s) {
        const {
          lines: i,
          mustSmooth: n,
          areContours: r,
          description: a,
          uuid: o,
          heightInPage: l
        } = this.#s, {
          rawDims: {
            pageWidth: h,
            pageHeight: c
          },
          rotation: u
        } = this.parent.viewport, f = pe.processDrawnLines({
          lines: i,
          pageWidth: h,
          pageHeight: c,
          rotation: u,
          innerMargin: Mt._INNER_MARGIN,
          mustSmooth: n,
          areContours: r
        });
        this.addSignature(f, l, a, o);
      } else
        this.div.setAttribute("data-l10n-args", JSON.stringify({
          description: ""
        })), this.div.hidden = !0, this._uiManager.getSignature(this);
    else
      this.div.setAttribute("data-l10n-args", JSON.stringify({
        description: this.#e || ""
      }));
    return s && (this._isCopy = !0, this._moveAfterPaste(t, e)), this.div;
  }
  setUuid(t) {
    this.#i = t, this.addEditToolbar();
  }
  getUuid() {
    return this.#i;
  }
  get description() {
    return this.#e;
  }
  set description(t) {
    this.#e = t, this.div && (this.div.setAttribute("data-l10n-args", JSON.stringify({
      description: t
    })), super.addEditToolbar().then((e) => {
      e?.updateEditSignatureButton(t);
    }));
  }
  getSignaturePreview() {
    const {
      newCurves: t,
      areContours: e,
      thickness: s,
      width: i,
      height: n
    } = this.#s, r = Math.max(i, n), a = pe.processDrawnLines({
      lines: {
        curves: t.map((o) => ({
          points: o
        })),
        thickness: s,
        width: i,
        height: n
      },
      pageWidth: r,
      pageHeight: r,
      rotation: 0,
      innerMargin: 0,
      mustSmooth: !1,
      areContours: e
    });
    return {
      areContours: e,
      outline: a.outline
    };
  }
  get toolbarButtons() {
    return this._uiManager.signatureManager ? [["editSignature", this._uiManager.signatureManager]] : super.toolbarButtons;
  }
  addSignature(t, e, s, i) {
    const {
      x: n,
      y: r
    } = this, {
      outline: a
    } = this.#s = t;
    this.#t = a instanceof Ys, this.description = s;
    let o;
    this.#t ? o = Mt.getDefaultDrawingOptions() : (o = Mt._defaultDrawnSignatureOptions.clone(), o.updateProperties({
      "stroke-width": a.thickness
    })), this._addOutlines({
      drawOutlines: a,
      drawingOptions: o
    });
    const [, l] = this.pageDimensions;
    let h = e / l;
    h = h >= 1 ? 0.5 : h, this.width *= h / this.height, this.width >= 1 && (h *= 0.9 / this.width, this.width = 0.9), this.height = h, this.setDims(), this.x = n, this.y = r, this.center(), this._onResized(), this.onScaleChanging(), this.rotate(), this._uiManager.addToAnnotationStorage(this), this.setUuid(i), this._reportTelemetry({
      action: "pdfjs.signature.inserted",
      data: {
        hasBeenSaved: !!i,
        hasDescription: !!s
      }
    }), this.div.hidden = !1, this.#n && (this.#n = !1, this.parent.addUndoableEditor(this));
  }
  getFromImage(t) {
    const {
      rawDims: {
        pageWidth: e,
        pageHeight: s
      },
      rotation: i
    } = this.parent.viewport;
    return pe.process(t, e, s, i, Mt._INNER_MARGIN);
  }
  getFromText(t, e) {
    const {
      rawDims: {
        pageWidth: s,
        pageHeight: i
      },
      rotation: n
    } = this.parent.viewport;
    return pe.extractContoursFromText(t, e, s, i, n, Mt._INNER_MARGIN);
  }
  getDrawnSignature(t) {
    const {
      rawDims: {
        pageWidth: e,
        pageHeight: s
      },
      rotation: i
    } = this.parent.viewport;
    return pe.processDrawnLines({
      lines: t,
      pageWidth: e,
      pageHeight: s,
      rotation: i,
      innerMargin: Mt._INNER_MARGIN,
      mustSmooth: !1,
      areContours: !1
    });
  }
  createDrawingOptions({
    areContours: t,
    thickness: e
  }) {
    t ? this._drawingOptions = Mt.getDefaultDrawingOptions() : (this._drawingOptions = Mt._defaultDrawnSignatureOptions.clone(), this._drawingOptions.updateProperties({
      "stroke-width": e
    }));
  }
  serialize(t = !1) {
    if (this.isEmpty())
      return null;
    const {
      lines: e,
      points: s
    } = this.serializeDraw(t), {
      _drawingOptions: {
        "stroke-width": i
      }
    } = this, n = Object.assign(super.serialize(t), {
      isSignature: !0,
      areContours: this.#t,
      color: [0, 0, 0],
      thickness: this.#t ? 0 : i
    });
    return this.addComment(n), t ? (n.paths = {
      lines: e,
      points: s
    }, n.uuid = this.#i, n.isCopy = !0) : n.lines = e, this.#e && (n.accessibilityData = {
      type: "Figure",
      alt: this.#e
    }), n;
  }
  static deserializeDraw(t, e, s, i, n, r) {
    return r.areContours ? Ys.deserialize(t, e, s, i, n, r) : Ne.deserialize(t, e, s, i, n, r);
  }
  static async deserialize(t, e, s) {
    const i = await super.deserialize(t, e, s);
    return i.#t = t.areContours, i.description = t.accessibilityData?.alt || "", i.#i = t.uuid, i;
  }
}
class Xa extends I {
  #t = null;
  #e = null;
  #s = null;
  #i = null;
  #n = null;
  #r = "";
  #a = null;
  #o = !1;
  #l = null;
  #h = !1;
  #u = !1;
  static _type = "stamp";
  static _editorType = B.STAMP;
  constructor(t) {
    super({
      ...t,
      name: "stampEditor"
    }), this.#i = t.bitmapUrl, this.#n = t.bitmapFile, this.defaultL10nId = "pdfjs-editor-stamp-editor";
  }
  static initialize(t, e) {
    I.initialize(t, e);
  }
  static isHandlingMimeForPasting(t) {
    return Us.has(t);
  }
  static paste(t, e) {
    e.pasteEditor({
      mode: B.STAMP
    }, {
      bitmapFile: t.getAsFile()
    });
  }
  altTextFinish() {
    this._uiManager.useNewAltTextFlow && (this.div.hidden = !1), super.altTextFinish();
  }
  get telemetryFinalData() {
    return {
      type: "stamp",
      hasAltText: !!this.altTextData?.altText
    };
  }
  static computeTelemetryFinalData(t) {
    const e = t.get("hasAltText");
    return {
      hasAltText: e.get(!0) ?? 0,
      hasNoAltText: e.get(!1) ?? 0
    };
  }
  #c(t, e = !1) {
    if (!t) {
      this.remove();
      return;
    }
    this.#t = t.bitmap, e || (this.#e = t.id, this.#h = t.isSvg), t.file && (this.#r = t.file.name), this.#m();
  }
  #f() {
    if (this.#s = null, this._uiManager.enableWaiting(!1), !!this.#a) {
      if (this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && this.#t) {
        this.addEditToolbar().then(() => {
          this._editToolbar.hide(), this._uiManager.editAltText(this, !0);
        });
        return;
      }
      if (!this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && this.#t) {
        this._reportTelemetry({
          action: "pdfjs.image.image_added",
          data: {
            alt_text_modal: !1,
            alt_text_type: "empty"
          }
        });
        try {
          this.mlGuessAltText();
        } catch {
        }
      }
      this.div.focus();
    }
  }
  async mlGuessAltText(t = null, e = !0) {
    if (this.hasAltTextData())
      return null;
    const {
      mlManager: s
    } = this._uiManager;
    if (!s)
      throw new Error("No ML.");
    if (!await s.isEnabledFor("altText"))
      throw new Error("ML isn't enabled for alt text.");
    const {
      data: i,
      width: n,
      height: r
    } = t || this.copyCanvas(null, null, !0).imageData, a = await s.guess({
      name: "altText",
      request: {
        data: i,
        width: n,
        height: r,
        channels: i.length / (n * r)
      }
    });
    if (!a)
      throw new Error("No response from the AI service.");
    if (a.error)
      throw new Error("Error from the AI service.");
    if (a.cancel)
      return null;
    if (!a.output)
      throw new Error("No valid response from the AI service.");
    const o = a.output;
    return await this.setGuessedAltText(o), e && !this.hasAltTextData() && (this.altTextData = {
      alt: o,
      decorative: !1
    }), o;
  }
  #p() {
    if (this.#e) {
      this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(this.#e).then((s) => this.#c(s, !0)).finally(() => this.#f());
      return;
    }
    if (this.#i) {
      const s = this.#i;
      this.#i = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromUrl(s).then((i) => this.#c(i)).finally(() => this.#f());
      return;
    }
    if (this.#n) {
      const s = this.#n;
      this.#n = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromFile(s).then((i) => this.#c(i)).finally(() => this.#f());
      return;
    }
    const t = document.createElement("input");
    t.type = "file", t.accept = Us.keys().join(",");
    const e = this._uiManager._signal;
    this.#s = new Promise((s) => {
      t.addEventListener("change", async () => {
        if (!t.files || t.files.length === 0)
          this.remove();
        else {
          this._uiManager.enableWaiting(!0);
          const i = await this._uiManager.imageManager.getFromFile(t.files[0]);
          this._reportTelemetry({
            action: "pdfjs.image.image_selected",
            data: {
              alt_text_modal: this._uiManager.useNewAltTextFlow
            }
          }), this.#c(i);
        }
        s();
      }, {
        signal: e
      }), t.addEventListener("cancel", () => {
        this.remove(), s();
      }, {
        signal: e
      });
    }).finally(() => this.#f()), t.click();
  }
  remove() {
    this.#e && (this.#t = null, this._uiManager.imageManager.deleteId(this.#e), this.#a?.remove(), this.#a = null, this.#l && (clearTimeout(this.#l), this.#l = null)), super.remove();
  }
  rebuild() {
    if (!this.parent) {
      this.#e && this.#p();
      return;
    }
    super.rebuild(), this.div !== null && (this.#e && this.#a === null && this.#p(), this.isAttachedToDOM || this.parent.add(this));
  }
  onceAdded(t) {
    this._isDraggable = !0, t && this.div.focus();
  }
  isEmpty() {
    return !(this.#s || this.#t || this.#i || this.#n || this.#e || this.#o);
  }
  get toolbarButtons() {
    return [["altText", this.createAltText()]];
  }
  get isResizable() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    return this._isCopy && (t = this.x, e = this.y), super.render(), this.div.hidden = !0, this.createAltText(), this.#o || (this.#t ? this.#m() : this.#p()), this._isCopy && this._moveAfterPaste(t, e), this._uiManager.addShouldRescale(this), this.div;
  }
  setCanvas(t, e) {
    const {
      id: s,
      bitmap: i
    } = this._uiManager.imageManager.getFromCanvas(t, e);
    e.remove(), s && this._uiManager.imageManager.isValidId(s) && (this.#e = s, i && (this.#t = i), this.#o = !1, this.#m());
  }
  _onResized() {
    this.onScaleChanging();
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    this.#l !== null && clearTimeout(this.#l);
    const t = 200;
    this.#l = setTimeout(() => {
      this.#l = null, this.#g();
    }, t);
  }
  #m() {
    const {
      div: t
    } = this;
    let {
      width: e,
      height: s
    } = this.#t;
    const [i, n] = this.pageDimensions, r = 0.75;
    if (this.width)
      e = this.width * i, s = this.height * n;
    else if (e > r * i || s > r * n) {
      const o = Math.min(r * i / e, r * n / s);
      e *= o, s *= o;
    }
    this._uiManager.enableWaiting(!1);
    const a = this.#a = document.createElement("canvas");
    a.setAttribute("role", "img"), this.addContainer(a), this.width = e / i, this.height = s / n, this.setDims(), this._initialOptions?.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, (!this._uiManager.useNewAltTextWhenAddingImage || !this._uiManager.useNewAltTextFlow || this.annotationElementId) && (t.hidden = !1), this.#g(), this.#u || (this.parent.addUndoableEditor(this), this.#u = !0), this._reportTelemetry({
      action: "inserted_image"
    }), this.#r && this.div.setAttribute("aria-description", this.#r), this.annotationElementId || this._uiManager.a11yAlert(I._l10nAlert.stamp);
  }
  copyCanvas(t, e, s = !1) {
    t ||= 224;
    const {
      width: i,
      height: n
    } = this.#t, r = new wt();
    let a = this.#t, o = i, l = n, h = null;
    if (e) {
      if (i > e || n > e) {
        const S = Math.min(e / i, e / n);
        o = Math.floor(i * S), l = Math.floor(n * S);
      }
      h = document.createElement("canvas");
      const u = h.width = Math.ceil(o * r.sx), f = h.height = Math.ceil(l * r.sy);
      this.#h || (a = this.#d(u, f));
      const p = h.getContext("2d");
      p.filter = this._uiManager.hcmFilter;
      let g = "white", m = "#cfcfd8";
      this._uiManager.hcmFilter !== "none" ? m = "black" : qn.isDarkMode && (g = "#8f8f9d", m = "#42414d");
      const b = 15, y = b * r.sx, A = b * r.sy, w = new OffscreenCanvas(y * 2, A * 2), v = w.getContext("2d");
      v.fillStyle = g, v.fillRect(0, 0, y * 2, A * 2), v.fillStyle = m, v.fillRect(0, 0, y, A), v.fillRect(y, A, y, A), p.fillStyle = p.createPattern(w, "repeat"), p.fillRect(0, 0, u, f), p.drawImage(a, 0, 0, a.width, a.height, 0, 0, u, f);
    }
    let c = null;
    if (s) {
      let u, f;
      if (r.symmetric && a.width < t && a.height < t)
        u = a.width, f = a.height;
      else if (a = this.#t, i > t || n > t) {
        const m = Math.min(t / i, t / n);
        u = Math.floor(i * m), f = Math.floor(n * m), this.#h || (a = this.#d(u, f));
      }
      const g = new OffscreenCanvas(u, f).getContext("2d", {
        willReadFrequently: !0
      });
      g.drawImage(a, 0, 0, a.width, a.height, 0, 0, u, f), c = {
        width: u,
        height: f,
        data: g.getImageData(0, 0, u, f).data
      };
    }
    return {
      canvas: h,
      width: o,
      height: l,
      imageData: c
    };
  }
  #d(t, e) {
    const {
      width: s,
      height: i
    } = this.#t;
    let n = s, r = i, a = this.#t;
    for (; n > 2 * t || r > 2 * e; ) {
      const o = n, l = r;
      n > 2 * t && (n = Math.ceil(n / 2)), r > 2 * e && (r = Math.ceil(r / 2));
      const h = new OffscreenCanvas(n, r);
      h.getContext("2d").drawImage(a, 0, 0, o, l, 0, 0, n, r), a = h.transferToImageBitmap();
    }
    return a;
  }
  #g() {
    const [t, e] = this.parentDimensions, {
      width: s,
      height: i
    } = this, n = new wt(), r = Math.ceil(s * t * n.sx), a = Math.ceil(i * e * n.sy), o = this.#a;
    if (!o || o.width === r && o.height === a)
      return;
    o.width = r, o.height = a;
    const l = this.#h ? this.#t : this.#d(r, a), h = o.getContext("2d");
    h.filter = this._uiManager.hcmFilter, h.drawImage(l, 0, 0, l.width, l.height, 0, 0, r, a);
  }
  #b(t) {
    if (t) {
      if (this.#h) {
        const i = this._uiManager.imageManager.getSvgUrl(this.#e);
        if (i)
          return i;
      }
      const e = document.createElement("canvas");
      return {
        width: e.width,
        height: e.height
      } = this.#t, e.getContext("2d").drawImage(this.#t, 0, 0), e.toDataURL();
    }
    if (this.#h) {
      const [e, s] = this.pageDimensions, i = Math.round(this.width * e * Ae.PDF_TO_CSS_UNITS), n = Math.round(this.height * s * Ae.PDF_TO_CSS_UNITS), r = new OffscreenCanvas(i, n);
      return r.getContext("2d").drawImage(this.#t, 0, 0, this.#t.width, this.#t.height, 0, 0, i, n), r.transferToImageBitmap();
    }
    return structuredClone(this.#t);
  }
  static async deserialize(t, e, s) {
    let i = null, n = !1;
    if (t instanceof xn) {
      const {
        data: {
          rect: g,
          rotation: m,
          id: b,
          structParent: y,
          popupRef: A,
          richText: w,
          contentsObj: v,
          creationDate: S,
          modificationDate: _
        },
        container: E,
        parent: {
          page: {
            pageNumber: C
          }
        },
        canvas: T
      } = t;
      let D, P;
      T ? (delete t.canvas, {
        id: D,
        bitmap: P
      } = s.imageManager.getFromCanvas(E.id, T), T.remove()) : (n = !0, t._hasNoCanvas = !0);
      const N = (await e._structTree.getAriaAttributes(`${ge}${b}`))?.get("aria-label") || "";
      i = t = {
        annotationType: B.STAMP,
        bitmapId: D,
        bitmap: P,
        pageIndex: C - 1,
        rect: g.slice(0),
        rotation: m,
        annotationElementId: b,
        id: b,
        deleted: !1,
        accessibilityData: {
          decorative: !1,
          altText: N
        },
        isSvg: !1,
        structParent: y,
        popupRef: A,
        richText: w,
        comment: v?.str || null,
        creationDate: S,
        modificationDate: _
      };
    }
    const r = await super.deserialize(t, e, s), {
      rect: a,
      bitmap: o,
      bitmapUrl: l,
      bitmapId: h,
      isSvg: c,
      accessibilityData: u
    } = t;
    n ? (s.addMissingCanvas(t.id, r), r.#o = !0) : h && s.imageManager.isValidId(h) ? (r.#e = h, o && (r.#t = o)) : r.#i = l, r.#h = c;
    const [f, p] = r.pageDimensions;
    return r.width = (a[2] - a[0]) / f, r.height = (a[3] - a[1]) / p, u && (r.altTextData = u), r._initialData = i, t.comment && r.setCommentData(t), r.#u = !!i, r;
  }
  serialize(t = !1, e = null) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const s = Object.assign(super.serialize(t), {
      bitmapId: this.#e,
      isSvg: this.#h
    });
    if (this.addComment(s), t)
      return s.bitmapUrl = this.#b(!0), s.accessibilityData = this.serializeAltText(!0), s.isCopy = !0, s;
    const {
      decorative: i,
      altText: n
    } = this.serializeAltText(!1);
    if (!i && n && (s.accessibilityData = {
      type: "Figure",
      alt: n
    }), this.annotationElementId) {
      const a = this.#y(s);
      if (a.isSame)
        return null;
      if (a.isSameAltText)
        delete s.accessibilityData;
      else {
        const o = this._initialData.structParent ?? -1;
        s.accessibilityData ? s.accessibilityData.structParent = o : o >= 0 && (s.accessibilityData = {
          type: "Figure",
          alt: "",
          structParent: o
        });
      }
      return s.id = this.annotationElementId, delete s.bitmapId, s;
    }
    if (e === null)
      return s;
    e.stamps ||= /* @__PURE__ */ new Map();
    const r = this.#h ? (s.rect[2] - s.rect[0]) * (s.rect[3] - s.rect[1]) : null;
    if (!e.stamps.has(this.#e))
      e.stamps.set(this.#e, {
        area: r,
        serialized: s
      }), s.bitmap = this.#b(!1);
    else if (this.#h) {
      const a = e.stamps.get(this.#e);
      r > a.area && (a.area = r, a.serialized.bitmap.close(), a.serialized.bitmap = this.#b(!1));
    }
    return s;
  }
  #y(t) {
    const {
      pageIndex: e,
      accessibilityData: {
        altText: s
      }
    } = this._initialData, i = t.pageIndex === e, n = (t.accessibilityData?.alt || "") === s;
    return {
      isSame: !this.hasEditedComment && !this._hasBeenMoved && !this._hasBeenResized && i && n,
      isSameAltText: n
    };
  }
  renderAnnotationElement(t) {
    return this.deleted ? (t.hide(), null) : (t.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
}
class Lt {
  #t;
  #e = !1;
  #s = null;
  #i = null;
  #n = null;
  #r = /* @__PURE__ */ new Map();
  #a = !1;
  #o = !1;
  #l = !1;
  #h = null;
  #u = null;
  #c = null;
  #f = null;
  #p = null;
  #m = -1;
  #d;
  static _initialized = !1;
  static #g = new Map([at, fi, Xa, Ct, Mt].map((t) => [t._editorType, t]));
  constructor({
    uiManager: t,
    pageIndex: e,
    div: s,
    structTreeLayer: i,
    accessibilityManager: n,
    annotationLayer: r,
    drawLayer: a,
    textLayer: o,
    viewport: l,
    l10n: h
  }) {
    const c = [...Lt.#g.values()];
    if (!Lt._initialized) {
      Lt._initialized = !0;
      for (const u of c)
        u.initialize(h, t);
    }
    t.registerEditorTypes(c), this.#d = t, this.pageIndex = e, this.div = s, this.#t = n, this.#s = r, this.viewport = l, this.#c = o, this.drawLayer = a, this._structTree = i, this.#d.addLayer(this);
  }
  get isEmpty() {
    return this.#r.size === 0;
  }
  get isInvisible() {
    return this.isEmpty && this.#d.getMode() === B.NONE;
  }
  updateToolbar(t) {
    this.#d.updateToolbar(t);
  }
  updateMode(t = this.#d.getMode()) {
    switch (this.#_(), t) {
      case B.NONE:
        this.div.classList.toggle("nonEditing", !0), this.disableTextSelection(), this.togglePointerEvents(!1), this.toggleAnnotationLayerPointerEvents(!0), this.disableClick();
        return;
      case B.INK:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
        break;
      case B.HIGHLIGHT:
        this.enableTextSelection(), this.togglePointerEvents(!1), this.disableClick();
        break;
      default:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
    }
    this.toggleAnnotationLayerPointerEvents(!1);
    const {
      classList: e
    } = this.div;
    if (e.toggle("nonEditing", !1), t === B.POPUP)
      e.toggle("commentEditing", !0);
    else {
      e.toggle("commentEditing", !1);
      for (const s of Lt.#g.values())
        e.toggle(`${s._type}Editing`, t === s._editorType);
    }
    this.div.hidden = !1;
  }
  hasTextLayer(t) {
    return t === this.#c?.div;
  }
  setEditingState(t) {
    this.#d.setEditingState(t);
  }
  addCommands(t) {
    this.#d.addCommands(t);
  }
  cleanUndoStack(t) {
    this.#d.cleanUndoStack(t);
  }
  toggleDrawing(t = !1) {
    this.div.classList.toggle("drawing", !t);
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  toggleAnnotationLayerPointerEvents(t = !1) {
    this.#s?.togglePointerEvents(t);
  }
  get #b() {
    return this.#r.size !== 0 ? this.#r.values() : this.#d.getEditors(this.pageIndex);
  }
  async enable() {
    this.#l = !0, this.div.tabIndex = 0, this.togglePointerEvents(!0), this.div.classList.toggle("nonEditing", !1), this.#p?.abort(), this.#p = null;
    const t = /* @__PURE__ */ new Set();
    for (const s of this.#b)
      s.enableEditing(), s.show(!0), s.annotationElementId && (this.#d.removeChangedExistingAnnotation(s), t.add(s.annotationElementId));
    const e = this.#s;
    if (e)
      for (const s of e.getEditableAnnotations()) {
        if (s.hide(), this.#d.isDeletedAnnotationElement(s.data.id) || t.has(s.data.id))
          continue;
        const i = await this.deserialize(s);
        i && (this.addOrRebuild(i), i.enableEditing());
      }
    this.#l = !1, this.#d._eventBus.dispatch("editorsrendered", {
      source: this,
      pageNumber: this.pageIndex + 1
    });
  }
  disable() {
    if (this.#o = !0, this.div.tabIndex = -1, this.togglePointerEvents(!1), this.div.classList.toggle("nonEditing", !0), this.#c && !this.#p) {
      this.#p = new AbortController();
      const i = this.#d.combinedSignal(this.#p);
      this.#c.div.addEventListener("pointerdown", (n) => {
        const {
          clientX: a,
          clientY: o,
          timeStamp: l
        } = n, h = this.#m;
        if (l - h > 500) {
          this.#m = l;
          return;
        }
        this.#m = -1;
        const {
          classList: c
        } = this.div;
        c.toggle("getElements", !0);
        const u = document.elementsFromPoint(a, o);
        if (c.toggle("getElements", !1), !this.div.contains(u[0]))
          return;
        let f;
        const p = new RegExp(`^${ye}[0-9]+$`);
        for (const m of u)
          if (p.test(m.id)) {
            f = m.id;
            break;
          }
        if (!f)
          return;
        const g = this.#r.get(f);
        g?.annotationElementId === null && (nt(n), g.dblclick(n));
      }, {
        signal: i,
        capture: !0
      });
    }
    const t = this.#s, e = [];
    if (t) {
      const i = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
      for (const r of this.#b) {
        if (r.disableEditing(), !r.annotationElementId) {
          e.push(r);
          continue;
        }
        if (r.serialize() !== null) {
          i.set(r.annotationElementId, r);
          continue;
        } else
          n.set(r.annotationElementId, r);
        this.getEditableAnnotation(r.annotationElementId)?.show(), r.remove();
      }
      for (const r of t.getEditableAnnotations()) {
        const {
          id: a
        } = r.data;
        if (this.#d.isDeletedAnnotationElement(a)) {
          r.updateEdited({
            deleted: !0
          });
          continue;
        }
        let o = n.get(a);
        if (o) {
          o.resetAnnotationElement(r), o.show(!1), r.show();
          continue;
        }
        o = i.get(a), o && (this.#d.addChangedExistingAnnotation(o), o.renderAnnotationElement(r) && o.show(!1)), r.show();
      }
    }
    this.#_(), this.isEmpty && (this.div.hidden = !0);
    const {
      classList: s
    } = this.div;
    for (const i of Lt.#g.values())
      s.remove(`${i._type}Editing`);
    this.disableTextSelection(), this.toggleAnnotationLayerPointerEvents(!0), t?.updateFakeAnnotations(e), this.#o = !1;
  }
  getEditableAnnotation(t) {
    return this.#s?.getEditableAnnotation(t) || null;
  }
  setActiveEditor(t) {
    this.#d.getActive() !== t && this.#d.setActiveEditor(t);
  }
  enableTextSelection() {
    if (this.div.tabIndex = -1, this.#c?.div && !this.#f) {
      this.#f = new AbortController();
      const t = this.#d.combinedSignal(this.#f);
      this.#c.div.addEventListener("pointerdown", this.#y.bind(this), {
        signal: t
      }), this.#c.div.classList.add("highlighting");
    }
  }
  disableTextSelection() {
    this.div.tabIndex = 0, this.#c?.div && this.#f && (this.#f.abort(), this.#f = null, this.#c.div.classList.remove("highlighting"));
  }
  #y(t) {
    this.#d.unselectAll();
    const {
      target: e
    } = t;
    if (e === this.#c.div || (e.getAttribute("role") === "img" || e.classList.contains("endOfContent") || e.classList.contains("textLayerImages") || e.classList.contains("textLayerImagePlaceholder")) && this.#c.div.contains(e)) {
      const {
        isMac: s
      } = W.platform;
      if (t.button !== 0 || t.ctrlKey && s)
        return;
      this.#d.showAllEditors("highlight", !0, !0), Ct.startDrawing(this, this.#d, this.#d.direction === "ltr", t), t.preventDefault();
    }
  }
  enableClick() {
    if (this.#i)
      return;
    this.#i = new AbortController();
    const t = this.#d.combinedSignal(this.#i);
    this.div.addEventListener("pointerdown", this.pointerdown.bind(this), {
      signal: t
    });
    const e = this.pointerup.bind(this);
    this.div.addEventListener("pointerup", e, {
      signal: t
    }), this.div.addEventListener("pointercancel", e, {
      signal: t
    });
  }
  disableClick() {
    this.#i?.abort(), this.#i = null;
  }
  attach(t) {
    this.#r.set(t.id, t);
    const {
      annotationElementId: e
    } = t;
    e && this.#d.isDeletedAnnotationElement(e) && this.#d.removeDeletedAnnotationElement(t);
  }
  detach(t) {
    this.#r.delete(t.id), this.#t?.removePointerInTextLayer(t.contentDiv), !this.#o && t.annotationElementId && this.#d.addDeletedAnnotationElement(t);
  }
  remove(t) {
    this.detach(t), this.#d.removeEditor(t), t.div.remove(), t.isAttachedToDOM = !1;
  }
  changeParent(t) {
    t.parent !== this && (t.parent && t.annotationElementId && (this.#d.addDeletedAnnotationElement(t), I.deleteAnnotationElement(t), t.annotationElementId = null), this.attach(t), t.parent?.detach(t), t.setParent(this), t.div && t.isAttachedToDOM && (t.div.remove(), this.div.append(t.div)));
  }
  add(t) {
    if (!(t.parent === this && t.isAttachedToDOM)) {
      if (this.changeParent(t), this.#d.addEditor(t), this.attach(t), !t.isAttachedToDOM) {
        const e = t.render();
        this.div.append(e), t.isAttachedToDOM = !0;
      }
      t.fixAndSetPosition(), t.onceAdded(!this.#l), this.#d.addToAnnotationStorage(t), t._reportTelemetry(t.telemetryInitialData);
    }
  }
  moveEditorInDOM(t) {
    if (!t.isAttachedToDOM)
      return;
    const {
      activeElement: e
    } = document;
    t.div.contains(e) && !this.#n && (t._focusEventsAllowed = !1, this.#n = setTimeout(() => {
      this.#n = null, t.div.contains(document.activeElement) ? t._focusEventsAllowed = !0 : (t.div.addEventListener("focusin", () => {
        t._focusEventsAllowed = !0;
      }, {
        once: !0,
        signal: this.#d._signal
      }), e.focus());
    }, 0)), t._structTreeParentId = this.#t?.moveElementInDOM(this.div, t.div, t.contentDiv, !0);
  }
  addOrRebuild(t) {
    t.needsToBeRebuilt() ? (t.parent ||= this, t.rebuild(), t.show()) : this.add(t);
  }
  addUndoableEditor(t) {
    const e = () => t._uiManager.rebuild(t), s = () => {
      t.remove();
    };
    this.addCommands({
      cmd: e,
      undo: s,
      mustExec: !1
    });
  }
  getEditorByUID(t) {
    for (const e of this.#r.values())
      if (e.uid === t)
        return e;
    return null;
  }
  get #A() {
    return Lt.#g.get(this.#d.getMode());
  }
  combinedSignal(t) {
    return this.#d.combinedSignal(t);
  }
  #w(t) {
    const e = this.#A;
    return e ? new e.prototype.constructor(t) : null;
  }
  canCreateNewEmptyEditor() {
    return this.#A?.canCreateNewEmptyEditor();
  }
  async pasteEditor(t, e) {
    this.updateToolbar(t), await this.#d.updateMode(t.mode);
    const {
      offsetX: s,
      offsetY: i
    } = this.#S(), n = this.#d.getId(), r = this.#w({
      parent: this,
      id: n,
      x: s,
      y: i,
      uiManager: this.#d,
      isCentered: !0,
      ...e
    });
    r && this.add(r);
  }
  async deserialize(t) {
    return await Lt.#g.get(t.annotationType ?? t.annotationEditorType)?.deserialize(t, this, this.#d) || null;
  }
  createAndAddNewEditor(t, e, s = {}) {
    const i = this.#d.getId(), n = this.#w({
      parent: this,
      id: i,
      x: t.offsetX,
      y: t.offsetY,
      uiManager: this.#d,
      isCentered: e,
      ...s
    });
    return n && this.add(n), n;
  }
  get boundingClientRect() {
    return this.div.getBoundingClientRect();
  }
  #S() {
    const {
      x: t,
      y: e,
      width: s,
      height: i
    } = this.boundingClientRect, n = Math.max(0, t), r = Math.max(0, e), a = Math.min(window.innerWidth, t + s), o = Math.min(window.innerHeight, e + i), l = (n + a) / 2 - t, h = (r + o) / 2 - e, [c, u] = this.viewport.rotation % 180 === 0 ? [l, h] : [h, l];
    return {
      offsetX: c,
      offsetY: u
    };
  }
  addNewEditor(t = {}) {
    this.createAndAddNewEditor(this.#S(), !0, t);
  }
  setSelected(t) {
    this.#d.setSelected(t);
  }
  toggleSelected(t) {
    this.#d.toggleSelected(t);
  }
  unselect(t) {
    this.#d.unselect(t);
  }
  pointerup(t) {
    const {
      isMac: e
    } = W.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div || !this.#a || (this.#a = !1, this.#A?.isDrawer && this.#A.supportMultipleDrawings))
      return;
    if (!this.#e) {
      this.#e = !0;
      return;
    }
    const s = this.#d.getMode();
    if (s === B.STAMP || s === B.POPUP || s === B.SIGNATURE) {
      this.#d.unselectAll();
      return;
    }
    this.createAndAddNewEditor(t, !1);
  }
  pointerdown(t) {
    if (this.#d.getMode() === B.HIGHLIGHT && this.enableTextSelection(), this.#a) {
      this.#a = !1;
      return;
    }
    const {
      isMac: e
    } = W.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div)
      return;
    if (this.#a = !0, this.#A?.isDrawer) {
      this.startDrawingSession(t);
      return;
    }
    const s = this.#d.getActive();
    this.#e = !s || s.isEmpty();
  }
  startDrawingSession(t) {
    if (this.div.focus({
      preventScroll: !0
    }), this.#h) {
      this.#A.startDrawing(this, this.#d, !1, t);
      return;
    }
    this.#d.setCurrentDrawingSession(this), this.#h = new AbortController();
    const e = this.#d.combinedSignal(this.#h);
    this.div.addEventListener("blur", ({
      relatedTarget: s
    }) => {
      s && !this.div.contains(s) && (this.#u = null, this.commitOrRemove());
    }, {
      signal: e
    }), this.#A.startDrawing(this, this.#d, !1, t);
  }
  pause(t) {
    if (t) {
      const {
        activeElement: e
      } = document;
      this.div.contains(e) && (this.#u = e);
      return;
    }
    this.#u && setTimeout(() => {
      this.#u?.focus(), this.#u = null;
    }, 0);
  }
  endDrawingSession(t = !1) {
    return this.#h ? (this.#d.setCurrentDrawingSession(null), this.#h.abort(), this.#h = null, this.#u = null, this.#A.endDrawing(t)) : null;
  }
  findNewParent(t, e, s) {
    const i = this.#d.findParent(e, s);
    return i === null || i === this ? !1 : (i.changeParent(t), !0);
  }
  commitOrRemove() {
    return this.#h ? (this.endDrawingSession(), !0) : !1;
  }
  onScaleChanging() {
    this.#h && this.#A.onScaleChangingWhenDrawing(this);
  }
  destroy() {
    this.commitOrRemove(), this.#d.getActive()?.parent === this && (this.#d.commitOrRemove(), this.#d.setActiveEditor(null)), this.#n && (clearTimeout(this.#n), this.#n = null);
    for (const t of this.#r.values())
      this.#t?.removePointerInTextLayer(t.contentDiv), t.setParent(null), t.isAttachedToDOM = !1, t.div.remove();
    this.div = null, this.#r.clear(), this.#d.removeLayer(this);
  }
  #_() {
    for (const t of this.#r.values())
      t.isEmpty() && t.remove();
  }
  async render({
    viewport: t
  }) {
    this.viewport = t, oe(this.div, t);
    for (const e of this.#d.getEditors(this.pageIndex))
      this.add(e), e.rebuild();
    await this.#d.findClonesForPage(this), this.div.hidden = this.isEmpty, this.updateMode();
  }
  update({
    viewport: t
  }) {
    this.#d.commitOrRemove(), this.#_();
    const e = this.viewport.rotation, s = t.rotation;
    if (this.viewport = t, oe(this.div, {
      rotation: s
    }), e !== s)
      for (const i of this.#r.values())
        i.rotate(s);
  }
  get pageDimensions() {
    const {
      pageWidth: t,
      pageHeight: e
    } = this.viewport.rawDims;
    return [t, e];
  }
  get scale() {
    return this.#d.viewParameters.realScale;
  }
}
function Ya(d, t) {
  return d === t ? 0 : d.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
}
function Xe(d) {
  return d ? d.nodeType === Node.ELEMENT_NODE ? d.closest(".textLayer") : d.parentElement?.closest(".textLayer") || null : null;
}
function Ka(d, t, e, s) {
  if (d === e)
    return t <= s;
  const i = d.compareDocumentPosition(e);
  return i & Node.DOCUMENT_POSITION_FOLLOWING ? !0 : i & Node.DOCUMENT_POSITION_PRECEDING ? !1 : null;
}
function Xi(d, t, e) {
  if (d.nodeType !== Node.ELEMENT_NODE || !d.classList.contains("textLayer") || t !== d.childNodes.length)
    return {
      container: d,
      offset: t
    };
  let s = d.lastChild;
  return s?.nodeType === Node.ELEMENT_NODE && s.classList.contains("endOfContent") && (s = s.previousSibling), !s || !e.contains(s) ? null : s.nodeType === Node.TEXT_NODE ? {
    container: s,
    offset: s.textContent.length
  } : {
    container: s,
    offset: s.childNodes.length
  };
}
class L {
  #t = null;
  #e = /* @__PURE__ */ new Map();
  #s = null;
  #i = null;
  #n = null;
  #r = null;
  #a = /* @__PURE__ */ new Map();
  static #o = 0;
  static #l = 0;
  static #h = null;
  static #u = /* @__PURE__ */ new Set();
  static #c = !1;
  static #f = /* @__PURE__ */ new Set();
  static #p = /* @__PURE__ */ new WeakMap();
  constructor({
    filterFactory: t = null,
    pageColors: e = null,
    pageIndex: s,
    textLayer: i = null
  }) {
    if (this.pageIndex = s, this.#i = t, this.#n = e, i) {
      const n = L.#p.get(i);
      if (n?.selectionDiv && (n.selectionDiv.remove(), L.#u.delete(n.selectionDiv)), L.#p.set(i, {
        drawLayer: this
      }), L.#f.add(i), this.#s = i, this.#r = new MutationObserver((r) => {
        if (!(!this.#t || !this.#s?.isConnected || !L.#d())) {
          for (const {
            addedNodes: a
          } of r)
            for (const o of a)
              if (o.nodeType === Node.ELEMENT_NODE && o.classList.contains("endOfContent")) {
                L.#b();
                return;
              }
        }
      }), this.#r.observe(i, {
        childList: !0
      }), L.#h === null) {
        L.#h = new AbortController();
        const {
          signal: r
        } = L.#h;
        document.addEventListener("selectionchange", L.#b.bind(L), {
          signal: r
        }), document.addEventListener("pointerdown", () => {
          L.#c = !0;
        }, {
          signal: r
        }), document.addEventListener("pointerup", () => {
          L.#c = !1;
        }, {
          signal: r
        }), window.addEventListener("blur", () => {
          L.#c = !1;
        }, {
          signal: r
        });
      }
    }
  }
  setParent(t) {
    if (!this.#t) {
      this.#t = t, this.#s?.isConnected && L.#d() && L.#b();
      return;
    }
    if (this.#t !== t) {
      if (this.#e.size > 0)
        for (const e of this.#e.values())
          e.remove(), t.append(e);
      this.#t = t;
    }
  }
  static #m(t) {
    const e = this.#p.get(t);
    e?.selectionDiv && (e.selectionDiv.remove(), this.#u.delete(e.selectionDiv), e.selectionDiv = null, e.path = null);
  }
  static #d() {
    const t = document.getSelection();
    return !!t && !t.isCollapsed;
  }
  static #g() {
    return this.#f.keys().filter((t) => t.isConnected).toArray().sort(Ya);
  }
  static #b() {
    const t = document.getSelection();
    if (!t || t.isCollapsed) {
      for (const r of this.#u)
        r.remove();
      this.#u.clear();
      return;
    }
    const e = /* @__PURE__ */ new WeakMap(), s = this.#g(), i = [];
    for (let r = 0, a = t.rangeCount; r < a; r++) {
      const o = t.getRangeAt(r);
      if (o.collapsed)
        continue;
      let {
        startContainer: l,
        startOffset: h,
        endContainer: c,
        endOffset: u
      } = o, f = Xe(l), p = Xe(c);
      const g = f === null, m = p === null;
      if (this.#c && g !== m)
        return;
      if (t.rangeCount === 1) {
        const {
          anchorNode: A,
          anchorOffset: w,
          focusNode: v,
          focusOffset: S
        } = t, _ = Xe(A), E = Xe(v), C = Ka(A, w, v, S);
        _ && E && C !== null && (C ? (l = A, h = w, f = _, c = v, u = S, p = E) : (l = v, h = S, f = E, c = A, u = w, p = _));
      }
      const b = s.filter((A) => o.intersectsNode(A));
      if (b.length === 0)
        continue;
      let y = !1;
      if (f || (f = b[0], l = f, h = 0, y = !0), p || (p = b.at(-1), c = p, u = p.childNodes.length, y = !0), c.nodeType === Node.ELEMENT_NODE) {
        if (c.classList.contains("endOfContent")) {
          const A = c.previousSibling;
          if (!A)
            continue;
          c = A, u = A.nodeType === Node.TEXT_NODE ? A.textContent.length : A.childNodes.length;
        } else if (c.classList.contains("textLayer") && c.childNodes.length === u) {
          const A = Xi(c, u, p);
          if (!A)
            continue;
          c = A.container, u = A.offset;
        }
      }
      if (l.nodeType === Node.ELEMENT_NODE) {
        const A = Xi(l, h, f);
        if (!A)
          continue;
        l = A.container, h = A.offset;
      }
      if (f === p && !y && b.includes(f)) {
        i.push([o, f]);
        continue;
      }
      for (const A of b) {
        const w = A.firstChild;
        if (!w)
          continue;
        const v = document.createRange();
        if (A === f ? v.setStart(l, h) : v.setStartBefore(w), A === p)
          v.setEnd(c, u);
        else {
          const S = A.lastChild;
          if (!S)
            continue;
          if (S.nodeType === Node.ELEMENT_NODE && S.classList.contains("endOfContent")) {
            const _ = S.previousSibling;
            if (!_)
              continue;
            v.setEndAfter(_);
          } else
            v.setEndAfter(S);
        }
        v.collapsed || i.push([v, A]);
      }
    }
    const n = new Set(i.map((r) => r[1]));
    for (const r of this.#f)
      n.has(r) || this.#m(r);
    for (const [r, a] of i) {
      const o = L.#p.get(a);
      if (!o)
        continue;
      let l = e.get(a);
      if (!l) {
        const p = a.getBoundingClientRect();
        l = (g, m, b, y) => ({
          x: (g - p.x) / p.width,
          y: (m - p.y) / p.height,
          width: b / p.width,
          height: y / p.height
        }), e.set(a, l);
      }
      const h = [];
      for (let {
        x: p,
        y: g,
        width: m,
        height: b
      } of r.getClientRects())
        m === 0 || b === 0 || ({
          x: p,
          y: g,
          width: m,
          height: b
        } = l(p, g, m, b), !(m === 1 && b === 1) && h.push(`M${p} ${g} h${m} v${b} h-${m} Z`));
      if (h.length === 0)
        continue;
      const c = o.drawLayer;
      let u = o.selectionDiv, f = o.path;
      if (!u) {
        const p = `clip_selection_${L.#l++}`;
        u = document.createElement("div"), u.className = "selection", u.style.clipPath = `url(#${p})`;
        const g = c.#i?.createSelectionStyle(c.#n);
        if (g)
          for (const [y, A] of Object.entries(g))
            u.style.setProperty(y, A);
        const m = L._svgFactory.create(1, 1, !0);
        m.setAttribute("aria-hidden", "true"), m.setAttribute("width", "100%"), m.setAttribute("height", "100%");
        const b = L._svgFactory.createElement("clipPath");
        b.setAttribute("id", p), b.setAttribute("clipPathUnits", "objectBoundingBox"), f = L._svgFactory.createElement("path"), b.append(f), m.append(b), u.append(m), o.path = f, o.selectionDiv = u;
      }
      c.#t && u.parentNode !== c.#t && (c.#t.append(u), this.#u.add(u)), f.setAttribute("d", h.join(" "));
    }
  }
  static get _svgFactory() {
    return k(this, "_svgFactory", new ri());
  }
  static #y(t, [e, s, i, n]) {
    const {
      style: r
    } = t;
    r.top = `${100 * s}%`, r.left = `${100 * e}%`, r.width = `${100 * i}%`, r.height = `${100 * n}%`;
  }
  #A() {
    const t = L._svgFactory.create(1, 1, !0);
    return this.#t.append(t), t.setAttribute("aria-hidden", "true"), t;
  }
  #w(t, e) {
    const s = L._svgFactory.createElement("clipPath");
    t.append(s);
    const i = `clip_${e}`;
    s.setAttribute("id", i), s.setAttribute("clipPathUnits", "objectBoundingBox");
    const n = L._svgFactory.createElement("use");
    return s.append(n), n.setAttribute("href", `#${e}`), n.classList.add("clip"), i;
  }
  #S(t, e) {
    for (const [s, i] of Object.entries(e))
      i === null ? t.removeAttribute(s) : t.setAttribute(s, i);
  }
  draw(t, e = !1, s = !1) {
    const i = L.#o++, n = this.#A(), r = L._svgFactory.createElement("defs");
    n.append(r);
    const a = L._svgFactory.createElement("path");
    r.append(a);
    const o = `path_${i}`;
    a.setAttribute("id", o), a.setAttribute("vector-effect", "non-scaling-stroke"), e && this.#a.set(i, a);
    const l = s ? this.#w(r, o) : null, h = L._svgFactory.createElement("use");
    return n.append(h), h.setAttribute("href", `#${o}`), this.updateProperties(n, t), this.#e.set(i, n), {
      id: i,
      clipPathId: `url(#${l})`
    };
  }
  drawOutline(t, e) {
    const s = L.#o++, i = this.#A(), n = L._svgFactory.createElement("defs");
    i.append(n);
    const r = L._svgFactory.createElement("path");
    n.append(r);
    const a = `path_${s}`;
    r.setAttribute("id", a), r.setAttribute("vector-effect", "non-scaling-stroke");
    let o;
    if (e) {
      const c = L._svgFactory.createElement("mask");
      n.append(c), o = `mask_${s}`, c.setAttribute("id", o), c.setAttribute("maskUnits", "objectBoundingBox");
      const u = L._svgFactory.createElement("rect");
      c.append(u), u.setAttribute("width", "1"), u.setAttribute("height", "1"), u.setAttribute("fill", "white");
      const f = L._svgFactory.createElement("use");
      c.append(f), f.setAttribute("href", `#${a}`), f.setAttribute("stroke", "none"), f.setAttribute("fill", "black"), f.setAttribute("fill-rule", "nonzero"), f.classList.add("mask");
    }
    const l = L._svgFactory.createElement("use");
    i.append(l), l.setAttribute("href", `#${a}`), o && l.setAttribute("mask", `url(#${o})`);
    const h = l.cloneNode();
    return i.append(h), l.classList.add("mainOutline"), h.classList.add("secondaryOutline"), this.updateProperties(i, t), this.#e.set(s, i), s;
  }
  finalizeDraw(t, e) {
    this.#a.delete(t), this.updateProperties(t, e);
  }
  updateProperties(t, e) {
    if (!e)
      return;
    const {
      root: s,
      bbox: i,
      rootClass: n,
      path: r
    } = e, a = typeof t == "number" ? this.#e.get(t) : t;
    if (a) {
      if (s && this.#S(a, s), i && L.#y(a, i), n) {
        const {
          classList: o
        } = a;
        for (const [l, h] of Object.entries(n))
          o.toggle(l, h);
      }
      if (r) {
        const l = a.firstElementChild.firstElementChild;
        this.#S(l, r);
      }
    }
  }
  updateParent(t, e) {
    if (e === this)
      return;
    const s = this.#e.get(t);
    s && (e.#t.append(s), this.#e.delete(t), e.#e.set(t, s));
  }
  remove(t) {
    this.#a.delete(t), this.#t !== null && (this.#e.get(t).remove(), this.#e.delete(t));
  }
  destroy() {
    this.#t = null;
    for (const t of this.#e.values())
      t.remove();
    this.#e.clear(), this.#a.clear(), this.#r?.disconnect(), this.#r = null, this.#s && (L.#p.get(this.#s)?.drawLayer === this && (L.#m(this.#s), L.#p.delete(this.#s), L.#f.delete(this.#s), L.#f.size === 0 && (L.#h?.abort(), L.#h = null, L.#c = !1)), this.#s = null);
  }
}
function Ye(d) {
  return `${(d * 100).toFixed(2)}%`;
}
class rs {
  #t = [];
  #e = /* @__PURE__ */ new Map();
  #s = null;
  #i = 0;
  #n = 0;
  #r = 0;
  static #a = null;
  constructor(t, e, s, i) {
    this.#i = t, this.#t = e, this.#n = s.rawDims.pageWidth, this.#r = s.rawDims.pageHeight, this.#s = i;
  }
  render() {
    const t = document.createElement("div");
    t.className = "textLayerImages";
    for (let e = 0; e < this.#t.length; e += 6) {
      const s = this.#o(this.#t.subarray(e, e + 6));
      s && t.append(s);
    }
    return t.addEventListener("contextmenu", (e) => {
      if (!(e.target instanceof HTMLCanvasElement))
        return;
      const s = e.target, i = this.#e.get(s);
      if (!i)
        return;
      const n = rs.#a?.deref();
      if (n === s)
        return;
      n && (n.width = 0, n.height = 0), rs.#a = new WeakRef(s);
      const {
        inverseTransform: r,
        x1: a,
        y1: o,
        width: l,
        height: h
      } = i, c = this.#s(), u = Math.ceil(a * c.width), f = Math.ceil(o * c.height), p = Math.floor((a + l / this.#n) * c.width), g = Math.floor((o + h / this.#r) * c.height);
      s.width = p - u, s.height = g - f;
      const m = s.getContext("2d");
      m.setTransform(...r), m.translate(-u, -f), m.drawImage(c, 0, 0);
    }), t;
  }
  #o([t, e, s, i, n, r]) {
    const a = Math.hypot((n - t) * this.#n, (r - e) * this.#r), o = Math.hypot((s - t) * this.#n, (i - e) * this.#r);
    if (a < this.#i || o < this.#i)
      return null;
    const l = [(n - t) * this.#n / a, (r - e) * this.#r / a, (s - t) * this.#n / o, (i - e) * this.#r / o, 0, 0], h = x.inverseTransform(l), c = document.createElement("canvas");
    return c.className = "textLayerImagePlaceholder", c.width = 0, c.height = 0, Object.assign(c.style, {
      opacity: 0,
      position: "absolute",
      left: Ye(t),
      top: Ye(e),
      width: Ye(a / this.#n),
      height: Ye(o / this.#r),
      transformOrigin: "0% 0%",
      transform: `matrix(${l.join(",")})`
    }), this.#e.set(c, {
      inverseTransform: h,
      width: a,
      height: o,
      x1: t,
      y1: e
    }), c;
  }
}
globalThis._pdfjsTestingUtils = {
  HighlightOutliner: Vs
};
globalThis.pdfjsLib = {
  AbortException: Yt,
  AnnotationEditorLayer: Lt,
  AnnotationEditorParamsType: U,
  AnnotationEditorType: B,
  AnnotationEditorUIManager: Kt,
  AnnotationLayer: li,
  AnnotationMode: $t,
  AnnotationType: q,
  applyOpacity: zn,
  build: _a,
  ColorPicker: _t,
  createValidAbsoluteUrl: Ki,
  CSSConstants: Qn,
  DOMSVGFactory: ri,
  DrawLayer: L,
  FeatureTest: W,
  fetchData: qs,
  findContrastColor: $n,
  getDocument: ya,
  getFilenameFromUrl: Xn,
  getPdfFilenameFromUrl: Yn,
  getRGB: Re,
  getRGBA: ve,
  getUuid: Qi,
  GlobalWorkerOptions: Ut,
  ImageKind: Ke,
  InvalidPDFException: Rs,
  isDataScheme: ds,
  isPdfFile: Qs,
  isValidExplicitDest: ar,
  makeArr: we,
  makeMap: ss,
  makeObj: Ls,
  makeSet: jn,
  MathClamp: Y,
  noContextMenu: xt,
  normalizeUnicode: Un,
  OPS: Nt,
  OutputScale: wt,
  PasswordException: Os,
  PasswordResponses: On,
  PDFDataRangeTransport: wn,
  PDFDateString: Hs,
  PDFWorker: Fe,
  PermissionFlag: Fn,
  PixelsPerInch: Ae,
  RenderingCancelledException: Ks,
  renderRichText: tn,
  ResponseException: es,
  setLayerDimensions: oe,
  shadow: k,
  SignatureExtractor: pe,
  stopEvent: nt,
  SupportedImageMimeTypes: Us,
  TextLayer: mt,
  TextLayerImages: rs,
  TouchManager: sn,
  updateUrlHash: qi,
  Util: x,
  VerbosityLevel: os,
  version: Sa,
  XfaLayer: Zi
};
export {
  Yt as AbortException,
  Lt as AnnotationEditorLayer,
  U as AnnotationEditorParamsType,
  B as AnnotationEditorType,
  Kt as AnnotationEditorUIManager,
  li as AnnotationLayer,
  $t as AnnotationMode,
  q as AnnotationType,
  Qn as CSSConstants,
  _t as ColorPicker,
  ri as DOMSVGFactory,
  L as DrawLayer,
  W as FeatureTest,
  Ut as GlobalWorkerOptions,
  Ke as ImageKind,
  Rs as InvalidPDFException,
  Y as MathClamp,
  Nt as OPS,
  wt as OutputScale,
  wn as PDFDataRangeTransport,
  Hs as PDFDateString,
  Fe as PDFWorker,
  Os as PasswordException,
  On as PasswordResponses,
  Fn as PermissionFlag,
  Ae as PixelsPerInch,
  Ks as RenderingCancelledException,
  es as ResponseException,
  pe as SignatureExtractor,
  Us as SupportedImageMimeTypes,
  mt as TextLayer,
  rs as TextLayerImages,
  sn as TouchManager,
  x as Util,
  os as VerbosityLevel,
  Zi as XfaLayer,
  zn as applyOpacity,
  _a as build,
  Ki as createValidAbsoluteUrl,
  qs as fetchData,
  $n as findContrastColor,
  ya as getDocument,
  Xn as getFilenameFromUrl,
  Yn as getPdfFilenameFromUrl,
  Re as getRGB,
  ve as getRGBA,
  Qi as getUuid,
  ds as isDataScheme,
  Qs as isPdfFile,
  ar as isValidExplicitDest,
  we as makeArr,
  ss as makeMap,
  Ls as makeObj,
  jn as makeSet,
  xt as noContextMenu,
  Un as normalizeUnicode,
  tn as renderRichText,
  oe as setLayerDimensions,
  k as shadow,
  nt as stopEvent,
  qi as updateUrlHash,
  Sa as version
};
